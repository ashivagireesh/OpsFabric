(function (global) {
  "use strict";

  var state = {
    data: null,
    states: null,
    districts: null,
    subdistrictCache: {},
    rbacVerticalId: null,
    rbacNodeId: null,
    rbacNodeName: "",
    rbacHierarchyData: null,
    rbacVerticalSelections: {},
    facetRbacVerticalId: null,
    facetRbacNodeId: null,
    facetRbacNodeName: "",
    facetRbacHierarchyData: null,
    facetRbacVerticalSelections: {},
    facetRbacActivated: false,
    hierarchyLimit: 25,
    hierarchySearch: "",
    activeHierarchyVisual: "hierarchy",
    analyticsRiskBand: "",
    analyticsLocks: {},
    analyticsDelegatesBound: false,
    renderSignatures: {},
    activeAnalyticsView: "visuals",
    agentReportDirty: true,
    agentReportLoaded: false,
    agentReportRefreshing: false,
    agentReportRefreshGeneration: 0,
    visualFrame: null,
    mapView: {scale: 1, x: 0, y: 0},
    mapSelectedStateName: "",
    mapSelectedStateCode: "",
    mapPointer: null,
    suppressMapClick: false,
    generation: 0,
    dashboardRequest: null,
    mapGeneration: 0,
    geographySyncGeneration: 0,
    selectedFilterId: null,
    selectedFilterVersion: null,
    savedFilters: [],
    fieldCatalog: [],
    buckets: [],
    expandedClassBuckets: {},
    selectedClassBucketId: null,
    selectedClassBucketVersion: null,
    selectedBucketId: null,
    selectedBucketVersion: null,
    bucketConfigurations: [],
    bucketRiskBands: [],
    configSummaryCache: {},
    configEditorFromBucket: false,
    configEditorReplaceId: null,
    inlineConfigEditorVersionId: null,
    inlineConfigEditorActiveTab: "definition",
    configEditorBaseline: null,
    subbucketEditorBaseline: null,
    activeBucketEditorTab: "setup",
    subbucketTabs: {},
    configurationDrawerOpen: false,
    configurationDrawerMode: "editor",
    nativeDrawerCloseRequested: false,
    nativeDrawerClosePending: false,
    appliedConfiguration: null,
    appliedBucket: null,
    appliedClassBucket: null,
    analysisTreeSubbuckets: {},
    expandedAnalysisBuckets: {},
    activeAnalysisSideTab: "facets",
    analysisRailCollapsed: false,
    activeFilterDrawerTab: "basic",
    filterDrawerOpen: false,
    kpisCollapsed: false,
    monitoring: {policies: [], buckets: [], schedules: []},
    modules: [],
    selectedModuleCode: null,
    recommendationCatalog: {
      findingTypes: [],
      workflowActions: [],
      escalationRoles: []
    },
    recommendations: [],
    recommendationPreviews: {},
    selectedRecommendationConditionId: null,
    findings: [],
    runs: [],
    findingSummary: {},
    findingPageMeta: {},
    runPageMeta: {},
    selectedScheduleId: null,
    findingPage: 1,
    runPage: 1
  };
  var $ = function (id) { return document.getElementById(id); };
  var cssEscape = global.CSS && typeof global.CSS.escape === "function" ?
    global.CSS.escape : function (value) {
      return String(value).replace(/["\\]/g, "\\$&");
    };
  var findingsRefreshTimer;
  var recommendationPreviewTimer;
  var fmt = new Intl.NumberFormat("en-IN");
  var money = new Intl.NumberFormat("en-IN", {style: "currency", currency: "INR", maximumFractionDigits: 0});
  var fieldTypes = {
    TRANSACTION_COUNT: "NUMBER", TOTAL_AMOUNT: "NUMBER", SUCCESS_RATE: "NUMBER",
    FAILURE_COUNT: "NUMBER", RISK_SCORE: "NUMBER", ABSENT_DAYS: "NUMBER",
    GEO_DISTANCE_KM: "NUMBER", RISK_CATEGORY: "STRING", GEO_ANOMALY_YN: "STRING",
    AMOUNT_OUTLIER_YN: "STRING", AMOUNT_ANOMALY_SEVERITY: "STRING",
    PLATFORM: "STRING", APPLICATION_VERSION: "STRING", MOST_USED_SERVICE: "STRING",
    SERVICE_NAME: "STRING", RESPONSE_CODE: "STRING", AGENT_STATUS: "STRING",
    AGENT_TYPE: "STRING", VENDOR_NAME: "STRING"
  };
  var fieldLabels = {
    TRANSACTION_COUNT: "Transaction Count", TOTAL_AMOUNT: "Total Amount",
    SUCCESS_RATE: "Success Rate", FAILURE_COUNT: "Failure Count",
    RISK_SCORE: "Risk Score", ABSENT_DAYS: "Absent Days",
    GEO_DISTANCE_KM: "Geo Distance (km)", RISK_CATEGORY: "Risk Category",
    GEO_ANOMALY_YN: "Geo Anomaly", AMOUNT_OUTLIER_YN: "Amount Outlier",
    AMOUNT_ANOMALY_SEVERITY: "Amount Anomaly Severity", PLATFORM: "Platform",
    APPLICATION_VERSION: "Application Version", MOST_USED_SERVICE: "Most Used Service",
    SERVICE_NAME: "Service in Selected Period", RESPONSE_CODE: "Response Code in Selected Period",
    AGENT_STATUS: "Agent Status", AGENT_TYPE: "Agent Type", VENDOR_NAME: "Vendor"
  };
  var operatorLabels = {
    EQ: "Equals (EQ)", NE: "Not equal (NE)", GT: "Greater than (GT)",
    GE: "Greater than or equal (GE)", LT: "Less than (LT)",
    LE: "Less than or equal (LE)", BETWEEN: "Between",
    IN: "In list", NOT_IN: "Not in list", CONTAINS: "Contains",
    STARTS_WITH: "Starts with", ENDS_WITH: "Ends with",
    IS_NULL: "Is empty / null", IS_NOT_NULL: "Is not empty / null",
    IN_CURRENT_PERIOD: "In current period", IN_PREVIOUS_PERIOD: "In previous period",
    IN_ROLLING_PERIOD: "In rolling period"
  };
  var metricLabels = {
    AGENT_COUNT: "Agents",
    TRANSACTION_COUNT: "Transactions",
    TOTAL_AMOUNT: "Transaction Amount",
    SUCCESS_RATE: "Success Rate",
    FAILURE_COUNT: "Failures",
    REVERSAL_COUNT: "Reversals",
    FINANCIAL_COUNT: "Financial Transactions",
    UNIQUE_CUSTOMERS: "Agent-Customer Relationships",
    UNIQUE_DEVICES: "Agent-Device Relationships",
    RISK_SCORE: "Average Risk Score",
    GEO_ANOMALY_COUNT: "Geo Anomalies"
  };

  function escapeHtml(value) {
    return String(value == null ? "" : value).replace(/[&<>"']/g, function (c) {
      return {"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"}[c];
    });
  }
  function compactHierarchyName(name, levelName) {
    var fullName = String(name == null ? "" : name).trim();
    var level = String(levelName == null ? "" : levelName).trim();
    if (!fullName || !level) { return fullName; }
    var escapedLevel = level.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")
      .replace(/\s+/g, "\\s+");
    var compactName = fullName.replace(
      new RegExp("^\\s*" + escapedLevel + "(?:\\s*[-:–]\\s*|\\s+)", "i"), ""
    ).trim();
    return compactName || fullName;
  }
  function debounce(fn, wait) {
    var timer;
    return function () {
      clearTimeout(timer);
      var args = arguments, context = this;
      timer = setTimeout(function () { fn.apply(context, args); }, wait);
    };
  }
  function fetchJson(url) {
    return fetch(url, {headers: {Accept: "application/json"}}).then(function (response) {
      if (!response.ok) { throw new Error("HTTP " + response.status); }
      return response.json();
    });
  }
  function server(process, data) {
    var transport;
    global.__alaServerCallCounts = global.__alaServerCallCounts || {};
    global.__alaServerCallCounts[process] =
      Number(global.__alaServerCallCounts[process] || 0) + 1;
    var promise = new Promise(function (resolve, reject) {
      transport = apex.server.process(process, data || {}, {dataType: "json"})
        .done(resolve)
        .fail(function (xhr) {
          reject(new Error(
            (xhr.responseJSON && (xhr.responseJSON.error || xhr.responseJSON.message)) ||
            xhr.responseText || xhr.statusText || "Request failed"
          ));
        });
    });
    promise.abort = function () {
      if (transport && typeof transport.abort === "function") { transport.abort(); }
    };
    return promise;
  }
  function notify(message) {
    if (apex.message && apex.message.showPageSuccess) { apex.message.showPageSuccess(message); }
  }
  function mountSubbucketSupportingPanels() {
    var source = $("ala-subbucket-support-panels");
    var target = $("ala-subbucket-editor");
    if (!source || !target) { return; }
    Array.prototype.slice.call(source.children).forEach(function (panel) {
      target.appendChild(panel);
    });
    source.remove();
  }
  function showError(message) {
    $("ala-error").hidden = false;
    $("ala-error").textContent = message;
    if (apex.message && apex.message.showErrors) {
      if (apex.message.clearErrors) { apex.message.clearErrors(); }
      apex.message.showErrors([{
        type: "error",
        location: "page",
        message: String(message || "An unexpected error occurred."),
        unsafe: false
      }]);
    }
  }

  function configurationEditorSnapshot() {
    if (!$("ala-inline-config-editor")) { return null; }
    return JSON.stringify({
      configId: state.selectedFilterId,
      name: $("ala-filter-name").value,
      description: $("ala-filter-description").value,
      sharingMode: $("ala-sharing-mode").value,
      dateScope: collectWindowScope(),
      classification: {
        priority: Number($("ala-config-priority").value || 100),
        criticality: $("ala-config-criticality").value,
        riskClass: $("ala-config-risk").value,
        riskPoints: Number($("ala-config-risk-points").value || 0)
      },
      outputType: $("ala-config-output").value,
      rule: collectConditions(),
      recommendations: collectRecommendationRows()
    });
  }

  function subbucketEditorSnapshot() {
    if (!$("ala-subbucket-editor") || $("ala-subbucket-editor").hidden) { return null; }
    return JSON.stringify(bucketPayload());
  }

  function configurationEditorIsDirty() {
    return state.configurationDrawerOpen &&
      state.configurationDrawerMode === "editor" &&
      state.configEditorBaseline != null &&
      configurationEditorSnapshot() !== state.configEditorBaseline;
  }

  function subbucketEditorIsDirty() {
    return state.subbucketEditorBaseline != null &&
      subbucketEditorSnapshot() !== state.subbucketEditorBaseline;
  }

  function promptUnsavedChanges(subject) {
    return new Promise(function (resolve) {
      var overlay = document.createElement("div");
      overlay.className = "ala-unsaved-dialog";
      overlay.innerHTML =
        '<button type="button" class="ala-unsaved-backdrop" data-unsaved-choice="cancel" ' +
        'aria-label="Cancel navigation"></button><section role="alertdialog" aria-modal="true" ' +
        'aria-labelledby="ala-unsaved-title"><div class="ala-unsaved-icon">' +
        '<span class="fa fa-exclamation-triangle"></span></div><div><h3 id="ala-unsaved-title">' +
        'Unsaved ' + escapeHtml(subject) + ' changes</h3><p>Save your changes before leaving, ' +
        'discard them, or continue editing.</p></div><div class="ala-unsaved-actions">' +
        '<button type="button" class="ala-button ala-button--secondary" ' +
        'data-unsaved-choice="cancel">Continue Editing</button>' +
        '<button type="button" class="ala-button ala-button--danger" ' +
        'data-unsaved-choice="discard">Discard</button>' +
        '<button type="button" class="ala-button" data-unsaved-choice="save">Save Draft</button>' +
        "</div></section>";
      document.body.appendChild(overlay);
      function finish(choice) {
        overlay.remove();
        resolve(choice);
      }
      overlay.querySelectorAll("[data-unsaved-choice]").forEach(function (button) {
        button.addEventListener("click", function () {
          finish(button.dataset.unsavedChoice);
        });
      });
      overlay.querySelector(".ala-unsaved-actions [data-unsaved-choice=cancel]").focus();
    });
  }

  function guardConfigurationChanges() {
    if (!configurationEditorIsDirty()) { return Promise.resolve(true); }
    return promptUnsavedChanges("configuration").then(function (choice) {
      if (choice === "cancel") { return false; }
      if (choice === "discard") { return true; }
      return saveFilter(false);
    });
  }

  function guardSubbucketNavigation() {
    return guardConfigurationChanges().then(function (allowed) {
      if (!allowed) { return false; }
      if (!subbucketEditorIsDirty()) { return true; }
      return promptUnsavedChanges("Subbucket").then(function (choice) {
        if (choice === "cancel") { return false; }
        if (choice === "discard") { return true; }
        return saveBucket(false);
      });
    });
  }

  function collectGroup(group) {
    var children = [];
    var holder = group.querySelector(":scope > .ala-rule-children");
    Array.prototype.forEach.call(holder.children, function (child) {
      if (child.classList.contains("ala-rule-group")) {
        children.push(collectGroup(child));
      } else if (child.classList.contains("ala-condition")) {
        var fieldKey = child.querySelector("[data-role=field]").value;
        var fieldMeta = state.fieldCatalog.find(function (item) { return item.key === fieldKey; });
        var field = fieldMeta ? fieldMeta.code : fieldKey.replace(/^.*:/, "");
        var op = child.querySelector("[data-role=op]").value;
        var value = child.querySelector("[data-role=value]").value;
        var value2 = child.querySelector("[data-role=value2]").value;
        if (field && (value !== "" || op === "IS_NULL" || op === "IS_NOT_NULL")) {
          children.push({
            conditionId: child.dataset.conditionId,
            fieldKey: fieldKey, field: field, operator: op, op: op,
            value: value, value2: op === "BETWEEN" ? value2 : ""
          });
        }
      }
    });
    return {operator: group.querySelector(":scope > .ala-rule-group-head [data-role=group-op]").value, children: children};
  }
  function collectConditions() {
    var root = $("ala-condition-root").querySelector(":scope > .ala-rule-group");
    return root ? collectGroup(root) : {operator: "AND", children: []};
  }
  function newConditionId() {
    return "COND-" + Date.now().toString(36).toUpperCase() + "-" +
      Math.random().toString(36).slice(2, 8).toUpperCase();
  }
  function conditionCount(node) {
    return (node.children || []).reduce(function (total, child) {
      return total + (child.children ? conditionCount(child) : 1);
    }, 0);
  }
  function updateConditionSummary() {
    var tree = collectConditions();
    var count = conditionCount(tree);
    document.querySelectorAll("#ala-condition-root .ala-condition").forEach(
      function (row,index) {
        var marker = row.querySelector(".ala-condition-sequence");
        if (marker) {
          marker.textContent = index + 1;
          marker.setAttribute("aria-label","Condition " + (index + 1));
        }
      }
    );
    document.querySelectorAll("#ala-condition-root .ala-rule-group").forEach(
      function (group) {
        var summary = group.querySelector(
          ":scope > .ala-rule-group-head [data-role=group-summary]"
        );
        if (!summary) { return; }
        var definition = collectGroup(group);
        var groupCount = conditionCount(definition);
        var all = definition.operator !== "OR";
        summary.textContent = groupCount === 1 ?
          "Agent matches when this condition is true." :
          (groupCount ?
            "Agent matches when " + (all ?
              "all " + groupCount + " conditions are true." :
              "any one of " + groupCount + " conditions is true.") :
            "Add the first condition to define this rule.");
      }
    );
    $("ala-condition-summary").textContent = count ?
      count + " condition" + (count === 1 ? "" : "s") + " active" :
      "No advanced conditions";
    if ($("ala-builder-condition-count")) {
      $("ala-builder-condition-count").textContent =
        count + " condition" + (count === 1 ? "" : "s");
    }
  }
  function collectWindowScope() {
    if (!$("ala-config-window-mode")) {
      return {mode: "RUNTIME", anchor: "SCHEDULER_RUN_DATE"};
    }
    var mode = $("ala-config-window-mode").value || "RUNTIME";
    return {
      mode: mode,
      anchor: "SCHEDULER_RUN_DATE",
      value: ["LAST_N_DAYS", "LAST_N_COMPLETE_MONTHS"].indexOf(mode) >= 0 ?
        Number($("ala-config-window-value").value || 1) : null,
      startOffset: mode === "CUSTOM_RELATIVE" ?
        Number($("ala-config-window-start").value || 0) : null,
      endOffset: mode === "CUSTOM_RELATIVE" ?
        Number($("ala-config-window-end").value || 0) : null
    };
  }
  function updateWindowControls() {
    var mode = $("ala-config-window-mode").value;
    $("ala-window-value-control").hidden =
      ["LAST_N_DAYS", "LAST_N_COMPLETE_MONTHS"].indexOf(mode) < 0;
    $("ala-window-start-control").hidden = mode !== "CUSTOM_RELATIVE";
    $("ala-window-end-control").hidden = mode !== "CUSTOM_RELATIVE";
    var labels = {
      RUNTIME: "Runtime selected range", CURRENT_DAY: "Current day",
      PREVIOUS_DAY: "Previous day", LAST_N_DAYS: "Last N days",
      MONTH_TO_DATE: "Month to date", PREVIOUS_MONTH: "Previous complete month",
      LAST_N_COMPLETE_MONTHS: "Last N complete months",
      YEAR_TO_DATE: "Year to date", ROLLING_360: "Rolling 360 days",
      CUSTOM_RELATIVE: "Custom relative range"
    };
    $("ala-window-preview").textContent = labels[mode] || mode;
  }
  function setWindowScope(scope) {
    scope = scope || {};
    var mode = String(scope.mode || "RUNTIME").toUpperCase();
    if (["DAILY", "MONTHLY", "YEAR_360"].indexOf(mode) >= 0) {
      mode = mode === "DAILY" ? "CURRENT_DAY" :
        (mode === "MONTHLY" ? "MONTH_TO_DATE" : "ROLLING_360");
    }
    $("ala-config-window-mode").value = mode;
    if (!$("ala-config-window-mode").value) {
      $("ala-config-window-mode").value = "RUNTIME";
    }
    $("ala-config-window-value").value = scope.value == null ? 7 : scope.value;
    $("ala-config-window-start").value =
      scope.startOffset == null ? -7 : scope.startOffset;
    $("ala-config-window-end").value =
      scope.endOffset == null ? -1 : scope.endOffset;
    updateWindowControls();
  }
  function filterPayload(analysisOverride, payloadOptions) {
    var payload = {
      mode: $("ala-mode").value,
      asOfDate: $("ala-date").value,
      metric: $("ala-metric").value,
      stateCode: $("ala-state").value,
      districtCode: $("ala-district").value,
      subdistrictCode: $("ala-subdistrict").value,
      villageCode: $("ala-village").value,
      search: $("ala-search").value,
      agentStatus: $("ala-status").value,
      riskCategory: $("ala-risk").value,
      platform: $("ala-platform").value,
      applicationVersion: $("ala-application-version").value,
      serviceFamily: $("ala-service-family").value,
      serviceName: $("ala-service-name").value,
      transactionType: $("ala-transaction-type").value,
      isOnus: $("ala-is-onus").value,
      isOriginal: $("ala-is-original").value,
      responseCode: $("ala-response-code").value,
      isFinancial: $("ala-is-financial").value,
      rbacVerticalId: state.rbacVerticalId,
      rbacNodeId: state.rbacNodeId,
      analyticsRiskBand: state.analyticsRiskBand || null
    };
    if (payloadOptions && payloadOptions.authorizedDefinitionScope) {
      // Definition validation must be repeatable.  The RBAC hierarchy in
      // Map & Analytics is an interactive drill-down, not part of an
      // Advanced Configuration or Bucket definition.  Keep the server's
      // mandatory user authorization (null means all permitted scopes), but
      // do not inherit the currently displayed hierarchy or the geography
      // controls populated by a selected hierarchy node.
      payload.rbacVerticalId = null;
      payload.rbacNodeId = null;
      if (state.rbacNodeId != null) {
        payload.stateCode = "";
        payload.districtCode = "";
        payload.subdistrictCode = "";
        payload.villageCode = "";
      }
    }
    if (payloadOptions &&
        Object.prototype.hasOwnProperty.call(payloadOptions, "rbacNodeOverride")) {
      payload.rbacNodeId = payloadOptions.rbacNodeOverride;
    }
    if (payloadOptions && payloadOptions.responseMode) {
      payload.responseMode = payloadOptions.responseMode;
    }
    var applied = analysisOverride ||
      (state.appliedClassBucket ?
        {kind: "CLASS_BUCKET", classBucketId: state.appliedClassBucket.id} :
        (state.appliedBucket ? {kind: "BUCKET", bucket: state.appliedBucket} : null));
    if (applied && applied.kind === "CLASS_BUCKET") {
      payload.conditions = {operator: "AND", children: []};
      payload.classBucketId = Number(applied.classBucketId);
    } else if (applied && applied.kind === "BUCKET") {
      payload.conditions = {operator: "AND", children: []};
      payload.bucket = applied.bucket;
    } else {
      payload.conditions = applied && applied.conditions ?
        applied.conditions : collectConditions();
      payload.configDateScope = applied && applied.configDateScope ?
        applied.configDateScope : collectWindowScope();
    }
    return payload;
  }
  function selectedOptionLabel(id, fallback) {
    var control = $(id);
    var option = control && control.selectedOptions && control.selectedOptions[0];
    return option ? option.textContent.trim() : fallback;
  }
  function activeAnalyticsFilterCount() {
    var count = 0;
    if ($("ala-mode").value !== "DAILY") { count += 1; }
    if ($("ala-metric").value !== "AGENT_COUNT") { count += 1; }
    [
      "ala-state", "ala-district", "ala-subdistrict", "ala-village", "ala-search",
      "ala-status", "ala-risk", "ala-platform", "ala-application-version",
      "ala-service-family",
      "ala-service-name", "ala-transaction-type", "ala-is-onus",
      "ala-is-original", "ala-response-code", "ala-is-financial"
    ].forEach(function (id) {
      if ($(id).value) { count += 1; }
    });
    if (state.rbacVerticalId) { count += 1; }
    if (state.rbacNodeId) { count += 1; }
    if (state.analyticsRiskBand) { count += 1; }
    return count;
  }
  function analyticsScopeItems() {
    var hierarchyData = state.rbacHierarchyData || {};
    var items = [{label: "All permitted scope", nodeId: "", nodeName: ""}];
    var vertical = (hierarchyData.hierarchies || []).find(function (item) {
      return String(item.id) === String(state.rbacVerticalId);
    });
    if (state.rbacVerticalId && vertical) {
      items.push({label: vertical.name, nodeId: "", nodeName: ""});
    }
    (hierarchyData.trail || []).forEach(function (item) {
      if (!items.some(function (entry) { return entry.label === item.name; })) {
        items.push({label: item.name, nodeId: item.id, nodeName: item.name});
      }
    });
    return items;
  }
  function updateAnalyticsScope() {
    var scope = $("ala-analytics-scope");
    if (!scope) { return; }
    var items = analyticsScopeItems();
    scope.innerHTML = items.map(function (item, index) {
      return (index ? '<span class="fa fa-chevron-right" aria-hidden="true"></span>' : "") +
        '<button type="button" data-analytics-scope-node="' +
        escapeHtml(item.nodeId) + '" data-analytics-scope-name="' +
        escapeHtml(item.nodeName) + '"' +
        (index === items.length - 1 ? ' aria-current="page"' : "") +
        ' title="Go to ' + escapeHtml(item.label) + '">' +
        escapeHtml(item.label) + "</button>";
    }).join("");
    scope.querySelectorAll("[data-analytics-scope-node]").forEach(function (button) {
      button.addEventListener("click", function () {
        if (String(button.dataset.analyticsScopeNode || "") ===
            String(state.rbacNodeId || "") &&
            button.getAttribute("aria-current") === "page") {
          return;
        }
        selectRbacNode(
          button.dataset.analyticsScopeNode,
          button.dataset.analyticsScopeNode ?
            (button.dataset.analyticsScopeName || "") : ""
        ).catch(function () {});
      });
    });
  }
  function updateAnalyticsContext() {
    if (!$("ala-context-period")) { return; }
    $("ala-context-period").textContent = selectedOptionLabel("ala-mode", "Daily");
    $("ala-context-date").textContent = $("ala-date").value || "Latest available";
    $("ala-context-metric").textContent = selectedOptionLabel("ala-metric", "Agents");
    var geography = "All India";
    if ($("ala-subdistrict").value) {
      geography = selectedOptionLabel("ala-subdistrict", $("ala-subdistrict").value);
    } else if ($("ala-district").value) {
      geography = selectedOptionLabel("ala-district", $("ala-district").value);
    } else if ($("ala-state").value) {
      geography = selectedOptionLabel("ala-state", $("ala-state").value);
    }
    $("ala-context-geo").textContent = geography;
    $("ala-filter-count").textContent = String(activeAnalyticsFilterCount());
    updateAnalyticsScope();
  }
  function analyticsCardHead(title, helper, cardId, labelledAction) {
    return '<div class="ala-control-card-head"><div><h3>' +
      escapeHtml(title) + '</h3><small>' + escapeHtml(helper) +
      '</small></div><div class="ala-control-card-actions">' +
      '<button type="button" class="ala-card-action ala-card-action--icon" ' +
      'data-analytics-lock="' + escapeHtml(cardId) +
      '" title="Lock drill interactions" aria-label="Lock drill interactions" ' +
      'aria-pressed="false"><span class="fa fa-unlock"></span></button>' +
      '<button type="button" class="ala-card-action ' +
      (labelledAction ? "" : "ala-card-action--icon") +
      '" data-analytics-fullscreen="' + escapeHtml(cardId) +
      '" title="Full Screen" aria-label="Full Screen"><span class="fa fa-expand"></span>' +
      (labelledAction ? "<span>Full Screen</span>" : "") + "</button></div></div>";
  }
  function mountAgentReport() {
    var results = $("ala-agent-ir-region");
    var reportSlot = $("ala-agent-report-slot");
    if (!results || !reportSlot) { return false; }
    if (results.parentElement !== reportSlot) {
      reportSlot.appendChild(results);
    }
    results.classList.add("ala-control-card", "ala-agent-ir-card");
    var resultsTitle = results.querySelector(".t-Region-title");
    if (resultsTitle) { resultsTitle.textContent = "Agent Drill-through"; }
    var resultsHead = results.querySelector(".t-Region-header");
    if (!results.querySelector(".ala-agent-ir-header-actions")) {
      (resultsHead || results).insertAdjacentHTML(resultsHead ? "beforeend" : "afterbegin",
        '<div class="ala-agent-ir-header-actions"><span id="ala-agent-count"></span>' +
        '<button type="button" class="ala-card-action ala-card-action--icon" ' +
        'data-analytics-fullscreen="ala-agent-ir-region" title="Full Screen" ' +
        'aria-label="Full Screen"><span class="fa fa-expand"></span></button></div>');
    }
    return true;
  }
  function retryAgentReportMount(attempt) {
    if (mountAgentReport() || attempt >= 20) { return; }
    global.setTimeout(function () {
      retryAgentReportMount(attempt + 1);
    }, 100);
  }
  function prepareAnalyticsControlPlane() {
    if ($("ala-control-plane")) {
      retryAgentReportMount(0);
      return;
    }
    var workspace = $("ala-workspace");
    var mapCard = workspace && workspace.querySelector(".ala-map-wrap");
    var analytics = document.querySelector("#ala-panel-analytics .ala-analytics");
    var contextbar = document.querySelector("#ala-panel-analytics>.ala-contextbar");
    var kpiRail = $("ala-kpi-rail");
    var facetPanel = $("ala-side-panel-facets");
    var viewTabs = document.querySelector(".ala-analytics-view-tabs");
    var agentPanel = $("ala-agent-details-view");
    if (!workspace || !mapCard || !analytics || !contextbar || !kpiRail ||
        !facetPanel || !viewTabs || !agentPanel) {
      return;
    }
    var main = document.createElement("div");
    main.className = "ala-analytics-main";
    var controlPlane = document.createElement("div");
    controlPlane.id = "ala-control-plane";
    controlPlane.className = "ala-control-plane";
    controlPlane.innerHTML =
      '<div class="ala-control-plane-grid"><div class="ala-analysis-cards"></div></div>';
    workspace.appendChild(main);
    main.appendChild(viewTabs);
    main.appendChild(controlPlane);
    main.appendChild(agentPanel);
    var grid = controlPlane.querySelector(".ala-control-plane-grid");
    var cards = controlPlane.querySelector(".ala-analysis-cards");
    contextbar.classList.add("ala-facet-contextbar");
    facetPanel.insertBefore(
      contextbar, facetPanel.querySelector(".ala-facet-accordions")
    );

    mapCard.id = "ala-map-card";
    mapCard.classList.add("ala-control-card");
    mapCard.insertAdjacentHTML("afterbegin", analyticsCardHead(
      "Risk Geography & Agent Locations",
      "Click a region or agent to drill through.",
      "ala-map-card",
      true
    ));
    var mapHead = mapCard.querySelector(".ala-control-card-head");
    var mapActions = mapHead && mapHead.querySelector(".ala-control-card-actions");
    if (mapActions) {
      mapActions.classList.add("ala-map-floating-actions");
      mapCard.appendChild(mapActions);
    }
    if (mapHead) { mapHead.remove(); }
    $("ala-map").setAttribute("aria-label", "India risk band, agent and transaction map");
    mapCard.querySelector(".ala-map-legend").setAttribute("aria-label", "Risk band legend");
    mapCard.querySelector(".ala-map-legend").innerHTML =
      '<span class="ala-risk-gradient-key" aria-hidden="true"></span>' +
      '<span>Low</span><span>Medium</span><span>High</span><span>Critical</span>' +
      '<span class="ala-legend-item"><i class="ala-risk-swatch is-unclassified"></i>No score</span>' +
      '<span id="ala-map-marker-summary" class="ala-map-marker-summary"></span>';
    grid.insertBefore(mapCard, cards);

    function configureChartCard(card, target, id, title, helper) {
      card.id = id;
      card.className = "ala-panel ala-control-card ala-chart-card";
      var oldHead = card.querySelector(".ala-panel__head");
      if (oldHead) { oldHead.remove(); }
      card.insertAdjacentHTML("afterbegin", analyticsCardHead(title, helper, id, false));
      target.className = "ala-advanced-chart";
      cards.appendChild(card);
    }
    var hierarchyCard = document.createElement("section");
    hierarchyCard.innerHTML =
      '<div class="ala-hierarchy-view-tabs" role="tablist" aria-label="RBAC analytics view">' +
      '<button type="button" class="is-active" role="tab" aria-selected="true" ' +
      'data-hierarchy-view="hierarchy"><span class="fa fa-sitemap"></span> Agents by Hierarchy</button>' +
      '<button type="button" role="tab" aria-selected="false" data-hierarchy-view="risk">' +
      '<span class="fa fa-pie-chart"></span> Risk Band Distribution</button></div>' +
      '<section id="ala-hierarchy-view-panel" class="ala-hierarchy-view-panel">' +
      '<nav class="ala-vertical-navigation" aria-label="RBAC vertical analytics">' +
      '<div id="ala-vertical-tabs" class="ala-vertical-tabs" role="tablist"></div>' +
      '<div class="ala-rbac-scope-line"><span class="ala-rbac-scope-label">' +
      '<span class="fa fa-shield" aria-hidden="true"></span>Scope</span>' +
      '<nav id="ala-analytics-scope" class="ala-scope-breadcrumb" ' +
      'aria-label="RBAC analytical scope breadcrumb"></nav></div>' +
      '<div id="ala-vertical-trail" class="ala-vertical-trail ala-legacy-vertical-trail" ' +
      'aria-label="Hierarchy drill-down path"></div>' +
      '</nav><div class="ala-hierarchy-tools">' +
      '<label for="ala-hierarchy-limit">Display <select id="ala-hierarchy-limit">' +
      '<option value="5">5</option><option value="10">10</option>' +
      '<option value="25" selected>25</option><option value="ALL">All</option>' +
      '</select></label><label class="ala-hierarchy-search" for="ala-hierarchy-search">' +
      '<span class="fa fa-search" aria-hidden="true"></span>' +
      '<span class="u-VisuallyHidden">Search RBAC hierarchy records</span>' +
      '<input id="ala-hierarchy-search" type="search" autocomplete="off" ' +
      'placeholder="Search hierarchy records"></label>' +
      '<span id="ala-hierarchy-auto-scale" class="ala-hierarchy-auto-scale">' +
      'Auto scale</span></div><div id="ala-hierarchy-chart" class="ala-advanced-chart"></div>' +
      '</section><section id="ala-hierarchy-risk-panel" ' +
      'class="ala-hierarchy-view-panel ala-hierarchy-risk-panel" hidden>' +
      '<div id="ala-risk-distribution" class="ala-advanced-chart"></div></section>';
    configureChartCard(
      hierarchyCard, hierarchyCard.querySelector("#ala-hierarchy-chart"), "ala-hierarchy-card",
      "RBAC Analytics", "Drill through hierarchy or inspect risk bands."
    );
    cards.classList.add("is-single-card");
    kpiRail.classList.add("ala-rbac-kpi-rail");
    kpiRail.classList.add("ala-map-kpi-strip");
    kpiRail.classList.remove("is-collapsed");
    state.kpisCollapsed = false;
    mapCard.insertBefore(kpiRail, mapCard.firstChild);
    hierarchyCard.classList.add("ala-hierarchy-card");
    var hierarchyHead = hierarchyCard.querySelector(".ala-control-card-head");
    var hierarchyViewTabs = hierarchyCard.querySelector(".ala-hierarchy-view-tabs");
    hierarchyHead.insertBefore(
      hierarchyViewTabs, hierarchyHead.querySelector(".ala-control-card-actions")
    );
    analytics.remove();

    retryAgentReportMount(0);
    if (!$("ala-chart-tooltip")) {
      document.body.insertAdjacentHTML("beforeend",
        '<div id="ala-chart-tooltip" class="ala-chart-tooltip" role="tooltip" hidden></div>');
    }
    updateAnalyticsScope();
    function syncAnalysisSideHeight() {
      var side = $("ala-analysis-side");
      if (!side || !mapCard) { return; }
      if (global.innerWidth <= 760) {
        side.style.height = "";
        return;
      }
      var sideTop = side.getBoundingClientRect().top;
      var mapBottom = mapCard.getBoundingClientRect().bottom;
      side.style.height = Math.max(540, Math.round(mapBottom - sideTop)) + "px";
    }
    function syncMapProjection() {
      var svg = $("ala-map");
      var width = svg ? Math.round(svg.getBoundingClientRect().width) : 0;
      if (!state.data || !width || Math.abs(width - (state.mapLayoutWidth || 0)) < 2) {
        return;
      }
      state.mapLayoutWidth = width;
      renderMap(state.data);
    }
    global.requestAnimationFrame(syncAnalysisSideHeight);
    global.addEventListener("resize", debounce(syncAnalysisSideHeight, 120));
    global.addEventListener("resize", debounce(syncMapProjection, 160));
    if (global.ResizeObserver) {
      var analysisSideObserver = new ResizeObserver(syncAnalysisSideHeight);
      analysisSideObserver.observe(mapCard);
    }
  }
  function setAgentReportStatus(message, busy) {
    var status = $("ala-agent-report-status");
    var tab = $("ala-analytics-view-agents-tab");
    if (status) { status.textContent = message; }
    if (tab) {
      tab.classList.toggle("is-loading", Boolean(busy));
      tab.setAttribute("aria-busy", busy ? "true" : "false");
    }
  }
  function refreshAgentReport(attempt) {
    if (!mountAgentReport()) {
      attempt = Number(attempt || 0);
      retryAgentReportMount(0);
      setAgentReportStatus("Preparing secured Agent Details…", true);
      if (attempt < 20) {
        global.setTimeout(function () {
          refreshAgentReport(attempt + 1);
        }, 100);
      } else {
        setAgentReportStatus("Agent Details could not be mounted — reopen the tab", false);
      }
      return;
    }
    if (!state.agentReportDirty || state.agentReportRefreshing ||
        !global.apex || !apex.region) {
      return;
    }
    var report = apex.region("ala-agent-ir-region");
    if (!report || typeof report.refresh !== "function") { return; }
    var refreshGeneration = state.generation;
    state.agentReportRefreshing = true;
    state.agentReportRefreshGeneration = refreshGeneration;
    setAgentReportStatus("Refreshing secured agent table…", true);
    var complete = function () {
      state.agentReportRefreshing = false;
      state.agentReportLoaded = true;
      if (state.agentReportRefreshGeneration === state.generation) {
        state.agentReportDirty = false;
        var agentTab = $("ala-analytics-view-agents-tab");
        if (agentTab) { agentTab.classList.remove("is-dirty"); }
        setAgentReportStatus(
          fmt.format(((state.data || {}).kpis || {}).agents || 0) +
            " matching agents loaded",
          false
        );
      } else {
        state.agentReportDirty = true;
        setAgentReportStatus("Filters changed — reopen this tab to refresh", false);
      }
    };
    var reportPayload = filterPayload();
    reportPayload.reportOnly = "Y";
    server("AGENT_LOCATION_DASHBOARD", {
      x01: JSON.stringify(reportPayload)
    }).then(function () {
      if (refreshGeneration !== state.generation) {
        state.agentReportRefreshing = false;
        state.agentReportDirty = true;
        setAgentReportStatus("Filters changed — reopen this tab to refresh", false);
        return;
      }
      if (apex.jQuery) {
        apex.jQuery("#ala-agent-ir-region")
          .off("apexafterrefresh.alaAgentDetails")
          .one("apexafterrefresh.alaAgentDetails", complete);
      }
      report.refresh();
      if (!apex.jQuery) {
        global.setTimeout(complete, 250);
      }
    }).catch(function (error) {
      state.agentReportRefreshing = false;
      state.agentReportDirty = true;
      setAgentReportStatus("Agent Details could not be loaded", false);
      showError("Agent Details query failed: " + error.message);
    });
  }
  function switchAnalyticsView(name) {
    prepareAnalyticsControlPlane();
    var selected = name === "agents" ? "agents" : "visuals";
    state.activeAnalyticsView = selected;
    document.querySelectorAll("[data-analytics-view]").forEach(function (button) {
      var active = button.dataset.analyticsView === selected;
      button.classList.toggle("is-active", active);
      button.setAttribute("aria-selected", active ? "true" : "false");
      button.tabIndex = active ? 0 : -1;
    });
    var visualPanel = $("ala-control-plane");
    var agentPanel = $("ala-agent-details-view");
    if (visualPanel) { visualPanel.hidden = selected !== "visuals"; }
    if (agentPanel) { agentPanel.hidden = selected !== "agents"; }
    if (selected === "agents") {
      global.requestAnimationFrame(function () { refreshAgentReport(0); });
    } else if (state.data) {
      global.requestAnimationFrame(function () {
        scheduleAnalyticsVisuals(state.data);
      });
    }
  }
  function switchFilterDrawerTab(name) {
    state.activeFilterDrawerTab = name || "basic";
    document.querySelectorAll("[data-filter-drawer-tab]").forEach(function (button) {
      button.classList.toggle("is-active", button.dataset.filterDrawerTab === state.activeFilterDrawerTab);
    });
    document.querySelectorAll("[data-filter-drawer-panel]").forEach(function (panel) {
      panel.hidden = panel.dataset.filterDrawerPanel !== state.activeFilterDrawerTab;
    });
  }
  function openFilterDrawer() {
    var root = $("ala-filter-drawer-root");
    if (!root) {
      setAnalysisRailCollapsed(false);
      switchAnalysisSideTab("facets");
      return;
    }
    root.hidden = false;
    state.filterDrawerOpen = true;
    switchFilterDrawerTab(state.activeFilterDrawerTab);
    requestAnimationFrame(function () { root.classList.add("is-open"); });
  }
  function closeFilterDrawer() {
    var root = $("ala-filter-drawer-root");
    if (!root) { return; }
    state.filterDrawerOpen = false;
    root.classList.remove("is-open");
    setTimeout(function () {
      if (!state.filterDrawerOpen) { root.hidden = true; }
    }, 220);
  }
  function toggleKpis() {
    var toggle = $("ala-toggle-kpis");
    if (!toggle) { return; }
    state.kpisCollapsed = !state.kpisCollapsed;
    $("ala-kpi-rail").classList.toggle("is-collapsed", state.kpisCollapsed);
    toggle.setAttribute("aria-expanded", state.kpisCollapsed ? "false" : "true");
    toggle.title = state.kpisCollapsed ?
      "Expand analytics snapshot" : "Collapse analytics snapshot";
    toggle.innerHTML = '<span class="fa fa-chevron-' +
      (state.kpisCollapsed ? "down" : "up") + '"></span>';
  }
  function thresholdHint() {
    var rule = collectConditions();
    var exactNumeric = null;
    function visit(node) {
      (node.children || []).forEach(function (child) {
        if (child.children) { visit(child); }
        else if (!exactNumeric && child.operator === "EQ" && child.value !== "" &&
                 !isNaN(Number(child.value))) { exactNumeric = child; }
      });
    }
    visit(rule);
    return exactNumeric ?
      " This is an exact-value rule. If " + escapeHtml(exactNumeric.value) +
      " is a threshold, choose Greater than or equal (GE)." : "";
  }
  function statisticsSummary(data, validation, kind) {
    var k = data.kpis || {};
    var agents = Number(k.agents || 0);
    var zero = agents === 0;
    var subject = kind === "CLASS_BUCKET" ? "Bucket" :
      (kind === "BUCKET" ? "Subbucket" : "configuration");
    var heading = validation ?
      (zero ? "Valid " + subject + ", but no agents matched." :
        "Valid " + subject + " — execution completed.") :
      (zero ? subject.charAt(0).toUpperCase() + subject.slice(1) +
        " applied — no agents matched." :
        subject.charAt(0).toUpperCase() + subject.slice(1) + " applied to analytics.");
    var bandSummary = kind === "BUCKET" && (data.bucketRiskBands || []).length ?
      '<div class="ala-band-result-grid">' + data.bucketRiskBands.map(function (band) {
        return '<div style="--band-colour:' + escapeHtml(band.colour || "#7b8794") +
          '"><span>' + escapeHtml(band.name) + '</span><b>' +
          fmt.format(band.agents || 0) + '</b><small>Avg score ' +
          Number(band.averageScore || 0).toFixed(2) + '</small></div>';
      }).join("") + '</div>' : "";
    if (kind === "CLASS_BUCKET" && (data.classificationSummary || []).length) {
      var singleWinner = data.classificationAssignmentMode === "SINGLE";
      bandSummary = '<div class="ala-band-result-grid">' +
        data.classificationSummary.map(function (row) {
          return '<div style="--band-colour:' + escapeHtml(row.colour || "#7b8794") +
            '"><span>' + escapeHtml(row.name) + '</span><b>' +
            fmt.format(row.selectedAgents || 0) +
            '</b><small>' + (singleWinner ? "Winning agents" : "Assigned agents") +
            ' · ' + fmt.format(row.candidateAgents || 0) + ' candidates · avg ' +
            Number(row.selectedAverageScore || row.averageScore || 0).toFixed(2) +
            '</small></div>';
        }).join("") + "</div>";
    }
    return '<div class="ala-result-heading"><span class="fa ' +
      (zero ? "fa-exclamation-circle" : "fa-check-circle") + '"></span><div><strong>' +
      heading + '</strong><small>' + escapeHtml(data.mode || $("ala-mode").value) + " · " +
      escapeHtml(data.fromDate || "") + " to " + escapeHtml(data.toDate || "") +
      (validation ? " · Analytics hierarchy drill-down ignored; RBAC permissions enforced" : "") +
      (zero ? thresholdHint() : "") + '</small></div></div>' +
      '<div class="ala-result-statistics">' +
      '<div><span>Matching agents</span><b>' + fmt.format(agents) + '</b></div>' +
      '<div><span>Transacting agents</span><b>' + fmt.format(k.transactingAgents || 0) + '</b></div>' +
      '<div><span>Transactions</span><b>' + fmt.format(k.transactions || 0) + '</b></div>' +
      '<div><span>Total amount</span><b>' + money.format(k.totalAmount || 0) + '</b></div>' +
      '<div><span>Success rate</span><b>' + Number(k.successRate || 0).toFixed(2) + '%</b></div>' +
      '<div><span>Failures</span><b>' + fmt.format(k.failureCount || 0) + '</b></div>' +
      '</div>' + bandSummary;
  }
  function appliedOutcomeSummary(data, kind) {
    var k = data.kpis || {};
    var agents = Number(k.agents || 0);
    var zero = agents === 0;
    var subject = kind === "CLASS_BUCKET" ? "Bucket" :
      (kind === "BUCKET" ? "Subbucket" : "Configuration");
    var identity = appliedRuleIdentity();
    var appliedName = identity && identity.name ? identity.name : subject;
    var badges = '<span class="ala-applied-summary-badge ala-applied-summary-count">' +
      '<span class="ala-applied-badge-label">Matching agents</span><b>' +
      fmt.format(agents) + '</b></span>';
    if (kind === "CLASS_BUCKET") {
      var matchingClassifications = (data.classificationSummary || []).filter(function (row) {
        return Number(row.selectedAgents || 0) > 0;
      });
      var totalSubbuckets = state.appliedClassBucket &&
        (state.appliedClassBucket.subbuckets || []).length;
      var governedConditions = matchingClassifications.reduce(function (total, row) {
        return total + Number(row.conditionCount || 0);
      }, 0);
      badges += '<span class="ala-applied-summary-badge ala-applied-summary-level">' +
        '<span class="ala-applied-badge-label">Matched subbuckets</span><b>' +
        fmt.format(matchingClassifications.length) + '</b>' +
        (totalSubbuckets ? '<span class="ala-applied-badge-meta">of ' +
          fmt.format(totalSubbuckets) + ' governed</span>' : "") + '</span>';
      badges += '<span class="ala-applied-summary-badge ala-applied-summary-level">' +
        '<span class="ala-applied-badge-label">Conditions</span><b>' +
        fmt.format(governedConditions) +
        '</b><span class="ala-applied-badge-meta">across matched subbuckets</span></span>';
    }
    if (kind === "BUCKET" && state.appliedBucket) {
      var bucketConfigurations = state.appliedBucket.configurations || [];
      var bucketConditionCount = bucketConfigurations.reduce(function (total, config) {
        return total + Number(config.conditionCount || 0);
      }, 0);
      badges += '<span class="ala-applied-summary-badge ala-applied-summary-level">' +
        '<span class="ala-applied-badge-label">Configurations</span><b>' +
        fmt.format(bucketConfigurations.length) + '</b></span>';
      if (bucketConditionCount) {
        badges += '<span class="ala-applied-summary-badge ala-applied-summary-level">' +
          '<span class="ala-applied-badge-label">Conditions</span><b>' +
          fmt.format(bucketConditionCount) + '</b></span>';
      }
    }
    if (kind === "CONFIG" && state.appliedConfiguration) {
      var configurationConditionCount = conditionCount(
        state.appliedConfiguration.rule || {children: []}
      );
      badges += '<span class="ala-applied-summary-badge ala-applied-summary-level">' +
        '<span class="ala-applied-badge-label">Executed conditions</span><b>' +
        fmt.format(configurationConditionCount) + '</b></span>';
    }
    return '<div class="ala-result-heading ala-result-heading--applied"><span class="fa ' +
      (zero ? "fa-exclamation-circle" : "fa-check-circle") +
      '"></span><div class="ala-applied-summary-copy"><span class="ala-applied-summary-kicker">' +
      subject + (zero ? " applied — no agents matched" : " applied to analytics") +
      '</span><strong class="ala-applied-summary-name">' + escapeHtml(appliedName) +
      '</strong><small>' + escapeHtml(data.mode || $("ala-mode").value) + " · " +
      escapeHtml(data.fromDate || "") + " to " + escapeHtml(data.toDate || "") +
      (zero ? thresholdHint() : "") + '</small></div><div class="ala-applied-summary-badges">' +
      badges + '</div></div>';
  }
  function renderAppliedRuleOutcome(data) {
    var result = $("ala-applied-rule-result");
    // The applied-rule context is already visible in the Governed Rule Explorer.
    // Keep this compatibility anchor hidden so applying a rule does not add a
    // duplicate full-width summary row above the analytics workspace.
    if (!result) { return; }
    result.hidden = true;
    result.innerHTML = "";
  }

  function load(testOnly, analysisOverride, testResultId, renderOptions) {
    var generation = ++state.generation;
    $("ala-loading").hidden = false;
    $("ala-error").hidden = true;
    if (state.dashboardRequest && typeof state.dashboardRequest.abort === "function") {
      state.dashboardRequest.abort();
    }
    var dashboardRequest = server("AGENT_LOCATION_DASHBOARD", {
      x01: JSON.stringify(filterPayload(analysisOverride, renderOptions))
    });
    state.dashboardRequest = dashboardRequest;
    return dashboardRequest
      .then(function (data) {
        // A newer dashboard request owns the screen.  Returning the older
        // payload would let its action callback overwrite the newer result.
        if (generation !== state.generation) { return null; }
        if (!testOnly) {
          state.data = data;
          render(data, renderOptions);
        }
        if (testOnly) {
          var result = $(testResultId || "ala-test-result");
          var kind = analysisOverride && analysisOverride.kind === "CLASS_BUCKET" ?
            "CLASS_BUCKET" :
            (analysisOverride && analysisOverride.kind === "BUCKET" ? "BUCKET" : "CONFIG");
          result.hidden = false;
          result.classList.toggle(
            "is-zero", Number((data.kpis || {}).agents || 0) === 0
          );
          result.innerHTML = statisticsSummary(data, true, kind);
        }
        return data;
      })
      .catch(function (error) {
        if (generation !== state.generation &&
            /\babort(?:ed)?\b/i.test(String(error && error.message))) {
          return null;
        }
        if (generation === state.generation) { showError("Dashboard query failed: " + error.message); }
        throw error;
      })
      .finally(function () {
        if (state.dashboardRequest === dashboardRequest) {
          state.dashboardRequest = null;
        }
        if (generation === state.generation) { $("ala-loading").hidden = true; }
      });
  }
  var debouncedLoad = debounce(function () { load(false).catch(function () {}); }, 400);
  function loadFacets() {
    return load(false, null, null, {preserveRbac: true});
  }
  var debouncedFacetLoad = debounce(function () {
    loadFacets().catch(function () {});
  }, 400);

  function setOptions(id, items, selected, placeholder, valueKey, labelKey) {
    var select = $(id);
    var html = '<option value="">' + escapeHtml(placeholder) + "</option>";
    (items || []).forEach(function (item) {
      var value = item[valueKey], label = item[labelKey];
      html += '<option value="' + escapeHtml(value) + '"' +
        (String(value) === String(selected) ? " selected" : "") + ">" +
        escapeHtml(label) + (item.count != null ? " (" + fmt.format(item.count) + ")" : "") +
        "</option>";
    });
    select.innerHTML = html;
    if (selected && !Array.prototype.some.call(select.options, function (option) {
      return option.value === String(selected);
    })) {
      select.insertAdjacentHTML("beforeend", '<option value="' + escapeHtml(selected) +
        '" selected>' + escapeHtml(selected) + "</option>");
    }
  }
  function setAgentOptions(items) {
    var datalist = $("ala-agent-options");
    if (!datalist) { return; }
    datalist.innerHTML = (items || []).map(function (item) {
      var label = item.name || "Unnamed agent";
      if (item.branch) { label += " · " + item.branch; }
      return '<option value="' + escapeHtml(item.id) + '" label="' +
        escapeHtml(label) + '"></option>';
    }).join("");
  }
  function setGeographyControl(id, value, label) {
    var control = $(id);
    value = value == null ? "" : String(value);
    if (!control) { return; }
    if (value && !Array.prototype.some.call(control.options, function (option) {
      return option.value === value;
    })) {
      control.insertAdjacentHTML("beforeend", '<option value="' +
        escapeHtml(value) + '">' + escapeHtml(label || value) + "</option>");
    }
    control.value = value;
  }
  function applyRbacGeography(hierarchyData) {
    var geography = (hierarchyData || {}).geography || {};
    if (!state.rbacNodeId || Number(geography.stateCount || 0) !== 1) {
      setGeographyControl("ala-state", "", "");
      setGeographyControl("ala-district", "", "");
      setGeographyControl("ala-subdistrict", "", "");
      state.mapSelectedStateName = "";
      state.mapSelectedStateCode = "";
      updateAnalyticsContext();
      return;
    }
    setGeographyControl(
      "ala-state", geography.stateCode, geography.stateName || geography.stateCode
    );
    state.mapSelectedStateName = geography.stateName || "";
    state.mapSelectedStateCode = geography.stateCode || "";
    if (Number(geography.districtCount || 0) === 1) {
      setGeographyControl(
        "ala-district", geography.districtCode,
        geography.districtName || geography.districtCode
      );
    } else {
      setGeographyControl("ala-district", "", "");
    }
    if (Number(geography.subdistrictCount || 0) === 1) {
      setGeographyControl(
        "ala-subdistrict", geography.subdistrictCode,
        geography.subdistrictName || geography.subdistrictCode
      );
    } else {
      setGeographyControl("ala-subdistrict", "", "");
    }
    updateAnalyticsContext();
  }
  function reloadRbacScope(source) {
    if ($("ala-loading")) { $("ala-loading").hidden = false; }
    return loadRbacHierarchy().then(function (hierarchyData) {
      if (source !== "map") { applyRbacGeography(hierarchyData); }
      return load(false, null, null, source === "map" ? {preserveRbac: true} : null);
    }).catch(function (error) {
      if ($("ala-loading")) { $("ala-loading").hidden = true; }
      throw error;
    });
  }
  function selectRbacNode(nodeId, nodeName, source) {
    state.hierarchySearch = "";
    if ($("ala-hierarchy-search")) { $("ala-hierarchy-search").value = ""; }
    rememberRbacNode(nodeId == null || nodeId === "" ? null : {
      id: Number(nodeId),
      name: nodeName || ""
    });
    return reloadRbacScope(source || "rbac");
  }
  function selectRbacVertical(verticalId, source) {
    state.hierarchySearch = "";
    if ($("ala-hierarchy-search")) { $("ala-hierarchy-search").value = ""; }
    var nextVerticalId = verticalId == null || verticalId === "" ?
      null : Number(verticalId);
    if (state.rbacVerticalId && state.rbacVerticalId !== nextVerticalId) {
      state.rbacVerticalSelections[String(state.rbacVerticalId)] = {
        nodeId: state.rbacNodeId,
        nodeName: state.rbacNodeName
      };
    }
    state.rbacVerticalId = nextVerticalId;
    var remembered = nextVerticalId ?
      state.rbacVerticalSelections[String(nextVerticalId)] : null;
    state.rbacNodeId = remembered && remembered.nodeId ? Number(remembered.nodeId) : null;
    state.rbacNodeName = remembered ? remembered.nodeName || "" : "";
    updateAnalyticsContext();
    return reloadRbacScope(source || "rbac");
  }
  function currentGeographyLevel() {
    if ($("ala-subdistrict").value) { return "subdistrict"; }
    if ($("ala-district").value) { return "district"; }
    if ($("ala-state").value) { return "state"; }
    return "";
  }
  function hierarchyGeographyRank(levelName) {
    var level = normalizeName(levelName).toLowerCase();
    if (level === "state" || level === "statename") { return 1; }
    if (level === "district" || level === "districtname") { return 2; }
    if (level === "subdistrict" || level === "subdistrictname" ||
        level === "taluk" || level === "tehsil") {
      return 3;
    }
    return 0;
  }
  function geographyRank(levelName) {
    return levelName === "state" ? 1 :
      (levelName === "district" ? 2 : (levelName === "subdistrict" ? 3 : 0));
  }
  function finishMapRbacSync(data, generation) {
    if (data && generation === state.geographySyncGeneration) {
      renderRiskDistribution(data);
      renderHierarchyChart(data);
    }
    return data;
  }
  function synchronizeMapWithRbacAnalytics() {
    var generation = ++state.geographySyncGeneration;
    $("ala-app").dataset.mapRbacSync = "loading";
    return load(false, null, null, {
      preserveRbac: true,
      rbacNodeOverride: null
    }).then(function (scopeData) {
      if (!scopeData || generation !== state.geographySyncGeneration) {
        return scopeData;
      }
      var target = scopeData.mapRbacTarget || {};
      rememberRbacNode(target.id ? {
        id: Number(target.id),
        name: target.name || ""
      } : null);
      if (!target.id) {
        return loadRbacHierarchy().then(function () {
          return finishMapRbacSync(scopeData, generation);
        });
      }
      return loadRbacHierarchy().then(function () {
        return finishMapRbacSync(scopeData, generation);
      });
    }).catch(function (error) {
      if (generation === state.geographySyncGeneration) {
        showError("Map and RBAC Analytics synchronization failed: " + error.message);
      }
      throw error;
    }).finally(function () {
      if (generation === state.geographySyncGeneration) {
        $("ala-app").dataset.mapRbacSync = "ready";
      }
    });
  }
  function rememberRbacNode(node) {
    state.rbacNodeId = node && node.id ? Number(node.id) : null;
    state.rbacNodeName = state.rbacNodeId ? (node.name || "") : "";
    if (state.rbacVerticalId) {
      state.rbacVerticalSelections[String(state.rbacVerticalId)] = {
        nodeId: state.rbacNodeId,
        nodeName: state.rbacNodeName
      };
    }
    updateAnalyticsContext();
  }
  function primeFacetRbacSelector(hierarchies) {
    var hierarchy = $("ala-rbac-hierarchy");
    if (!hierarchy || state.facetRbacActivated) { return; }
    hierarchy.innerHTML = '<option value="" selected>Select hierarchy manually</option>' +
      (hierarchies || []).map(function (item) {
        return '<option value="' + escapeHtml(item.id) + '">' +
          escapeHtml(item.name) + "</option>";
      }).join("");
    $("ala-rbac-trail").innerHTML = "";
    $("ala-rbac-nodes").innerHTML =
      "<small>Select an RBAC hierarchy to load it. Map and RBAC Analytics activity will not change this control.</small>";
  }
  function rememberFacetRbacNode(node) {
    state.facetRbacNodeId = node && node.id ? Number(node.id) : null;
    state.facetRbacNodeName = state.facetRbacNodeId ? (node.name || "") : "";
    if (state.facetRbacVerticalId) {
      state.facetRbacVerticalSelections[String(state.facetRbacVerticalId)] = {
        nodeId: state.facetRbacNodeId,
        nodeName: state.facetRbacNodeName
      };
    }
  }
  function renderFacetRbacHierarchy(data) {
    state.facetRbacHierarchyData = data || {};
    var hierarchy = $("ala-rbac-hierarchy");
    if (!hierarchy) { return; }
    var hierarchies = data.hierarchies || [];
    var selectedVertical = state.facetRbacVerticalId == null ?
      "" : String(state.facetRbacVerticalId);
    hierarchy.innerHTML = '<option value="">Select hierarchy manually</option>' +
      hierarchies.map(function (item) {
        return '<option value="' + escapeHtml(item.id) + '"' +
          (String(item.id) === selectedVertical ? " selected" : "") + ">" +
          escapeHtml(item.name) + "</option>";
      }).join("");
    var selectedVerticalData = hierarchies.find(function (item) {
      return String(item.id) === selectedVertical;
    });
    var trail = data.trail || [];
    $("ala-rbac-trail").innerHTML = state.facetRbacVerticalId ?
      '<button type="button" data-rbac-node="" data-facet-rbac-node=""><span>All ' +
      escapeHtml(selectedVerticalData ? selectedVerticalData.name : "permitted scope") +
      "</span></button>" + trail.map(function (item) {
        var compactName = compactHierarchyName(item.name, item.levelName);
        return '<i class="fa fa-chevron-right"></i><button type="button" ' +
          'data-rbac-node="' + escapeHtml(item.id) + '" data-facet-rbac-node="' +
          escapeHtml(item.id) +
          '" data-facet-rbac-name="' + escapeHtml(item.name) +
          '" title="' + escapeHtml(item.name) + '"><span>' +
          escapeHtml(compactName) + '</span><small>' +
          escapeHtml(item.levelName || "") + "</small></button>";
      }).join("") : "";
    var nodes = data.nodes || [];
    $("ala-rbac-nodes").innerHTML = nodes.length ? nodes.map(function (item) {
      var compactName = compactHierarchyName(item.name, item.levelName);
      return '<button type="button" class="ala-rbac-node ' +
        (item.hasChildren ? "has-children" : "") + '" data-rbac-node="' +
        escapeHtml(item.id) + '" data-facet-rbac-node="' + escapeHtml(item.id) +
        '" data-facet-rbac-name="' + escapeHtml(item.name) +
        '" title="' + escapeHtml(item.name) + '"><span class="fa fa-' +
        (item.hasChildren ? "sitemap" : "map-marker") + '"></span><span><strong>' +
        escapeHtml(compactName) + '</strong><small>' + escapeHtml(item.levelName) +
        '</small></span><span class="fa fa-chevron-right"></span></button>';
    }).join("") : "<small>No lower hierarchy levels are available.</small>";
    document.querySelectorAll(
      "#ala-rbac-trail [data-facet-rbac-node],#ala-rbac-nodes [data-facet-rbac-node]"
    ).forEach(function (button) {
      button.addEventListener("click", function () {
        selectFacetRbacNode(
          button.dataset.facetRbacNode,
          button.dataset.facetRbacNode ?
            (button.dataset.facetRbacName || "") : ""
        ).catch(function () {});
      });
    });
  }
  function applyFacetRbacScope(data) {
    state.hierarchySearch = "";
    if ($("ala-hierarchy-search")) { $("ala-hierarchy-search").value = ""; }
    state.rbacVerticalId = state.facetRbacVerticalId;
    state.rbacNodeId = state.facetRbacNodeId;
    state.rbacNodeName = state.facetRbacNodeName;
    if (state.rbacVerticalId) {
      state.rbacVerticalSelections[String(state.rbacVerticalId)] = {
        nodeId: state.rbacNodeId,
        nodeName: state.rbacNodeName
      };
    }
    renderAnalyticsRbacHierarchy(data);
    applyRbacGeography(data);
    return load(false);
  }
  function loadFacetRbacHierarchy() {
    if (!state.facetRbacVerticalId) { return Promise.resolve(null); }
    if ($("ala-loading")) { $("ala-loading").hidden = false; }
    return server("AGENT_LOCATION_RBAC_HIERARCHY", {
      x01: state.facetRbacVerticalId,
      x02: state.facetRbacNodeId == null ? "" : state.facetRbacNodeId,
      x03: $("ala-mode") ? $("ala-mode").value : "DAILY",
      x04: $("ala-date") ? $("ala-date").value : ""
    }).then(function (data) {
      renderFacetRbacHierarchy(data);
      return applyFacetRbacScope(data);
    }).catch(function (error) {
      $("ala-rbac-nodes").innerHTML =
        "<small>RBAC hierarchy could not be loaded.</small>";
      if ($("ala-loading")) { $("ala-loading").hidden = true; }
      showError("RBAC hierarchy could not be loaded: " + error.message);
      throw error;
    });
  }
  function selectFacetRbacNode(nodeId, nodeName) {
    state.facetRbacActivated = true;
    rememberFacetRbacNode(nodeId == null || nodeId === "" ? null : {
      id: Number(nodeId),
      name: nodeName || ""
    });
    return loadFacetRbacHierarchy();
  }
  function selectFacetRbacVertical(verticalId) {
    var nextVerticalId = verticalId == null || verticalId === "" ?
      null : Number(verticalId);
    if (!nextVerticalId) {
      state.facetRbacActivated = false;
      state.facetRbacVerticalId = null;
      state.facetRbacNodeId = null;
      state.facetRbacNodeName = "";
      primeFacetRbacSelector(
        ((state.rbacHierarchyData || {}).hierarchies) || []
      );
      return Promise.resolve(null);
    }
    if (state.facetRbacVerticalId &&
        state.facetRbacVerticalId !== nextVerticalId) {
      state.facetRbacVerticalSelections[String(state.facetRbacVerticalId)] = {
        nodeId: state.facetRbacNodeId,
        nodeName: state.facetRbacNodeName
      };
    }
    state.facetRbacActivated = true;
    state.facetRbacVerticalId = nextVerticalId;
    var remembered = state.facetRbacVerticalSelections[String(nextVerticalId)];
    state.facetRbacNodeId = remembered && remembered.nodeId ?
      Number(remembered.nodeId) : null;
    state.facetRbacNodeName = remembered ? remembered.nodeName || "" : "";
    return loadFacetRbacHierarchy();
  }
  function renderAnalyticsRbacHierarchy(data) {
    state.rbacHierarchyData = data || {};
    var hierarchies = data.hierarchies || [];
    primeFacetRbacSelector(hierarchies);
    var selectedVertical = state.rbacVerticalId == null ? "" : String(state.rbacVerticalId);

    var selectedVerticalData = hierarchies.find(function (item) {
      return String(item.id) === selectedVertical;
    });
    var trail = data.trail || [];
    var trailHtml = state.rbacVerticalId ?
      '<button type="button" data-rbac-node=""><span>All ' +
      escapeHtml(selectedVerticalData ? selectedVerticalData.name : "permitted scope") +
      "</span></button>" + trail.map(function (item) {
        var compactName = compactHierarchyName(item.name, item.levelName);
        return '<i class="fa fa-chevron-right"></i><button type="button" data-rbac-node="' +
          escapeHtml(item.id) + '" data-rbac-name="' + escapeHtml(item.name) +
          '" title="' + escapeHtml(item.name) + '"><span>' + escapeHtml(compactName) +
          '</span><small>' + escapeHtml(item.levelName || "") + "</small></button>";
      }).join("") : "";

    var verticalTabs = $("ala-vertical-tabs");
    if (verticalTabs) {
      verticalTabs.innerHTML = hierarchies.map(function (item) {
        var selected = String(item.id) === selectedVertical;
        return '<button type="button" role="tab" data-rbac-vertical="' +
          escapeHtml(item.id) + '" aria-selected="' + (selected ? "true" : "false") +
          '" class="' + (selected ? "is-active" : "") + '"><strong>' +
          escapeHtml(item.name) + "</strong></button>";
      }).join("");
    }
    if ($("ala-vertical-trail")) {
      $("ala-vertical-trail").innerHTML = trailHtml ||
        '<span>Select an available RBAC vertical to view its hierarchy.</span>';
    }
    document.querySelectorAll("#ala-vertical-trail [data-rbac-node]").forEach(function (button) {
      button.addEventListener("click", function () {
        selectRbacNode(
          button.dataset.rbacNode,
          button.dataset.rbacNode ? (button.dataset.rbacName || "") : ""
        ).catch(function () {});
      });
    });
    if (verticalTabs) {
      verticalTabs.querySelectorAll("[data-rbac-vertical]").forEach(function (button) {
        button.addEventListener("click", function () {
          if (String(state.rbacVerticalId) === button.dataset.rbacVertical) { return; }
          selectRbacVertical(button.dataset.rbacVertical).catch(function () {});
        });
      });
    }
    updateAnalyticsScope();
  }
  function loadRbacHierarchy() {
    return server("AGENT_LOCATION_RBAC_HIERARCHY", {
      x01: state.rbacVerticalId == null ? "" : state.rbacVerticalId,
      x02: state.rbacNodeId == null ? "" : state.rbacNodeId,
      x03: $("ala-mode") ? $("ala-mode").value : "DAILY",
      x04: $("ala-date") ? $("ala-date").value : ""
    }).then(function (data) {
      var hierarchies = data.hierarchies || [];
      var selectedAvailable = hierarchies.some(function (item) {
        return String(item.id) === String(state.rbacVerticalId);
      });
      if ((!state.rbacVerticalId || !selectedAvailable) && hierarchies.length) {
        state.rbacVerticalId = Number(hierarchies[0].id);
        state.rbacNodeId = null;
        state.rbacNodeName = "";
        return server("AGENT_LOCATION_RBAC_HIERARCHY", {
          x01: state.rbacVerticalId,
          x02: "",
          x03: $("ala-mode") ? $("ala-mode").value : "DAILY",
          x04: $("ala-date") ? $("ala-date").value : ""
        }).then(function (selectedData) {
          renderAnalyticsRbacHierarchy(selectedData);
          return selectedData;
        });
      }
      renderAnalyticsRbacHierarchy(data);
      return data;
    }).catch(function (error) {
      if ($("ala-hierarchy-chart")) {
        $("ala-hierarchy-chart").innerHTML =
          '<div class="ala-empty">RBAC Analytics hierarchy could not be loaded.</div>';
      }
      showError("RBAC hierarchy could not be loaded: " + error.message);
      throw error;
    });
  }
  function render(data, renderOptions) {
    if (!$("ala-date").value) { $("ala-date").value = data.toDate; }
    $("ala-watermark").textContent = "Profile as of " + (data.profileAsOf || "—");
    var k = data.kpis || {};
    $("ala-kpi-agents").textContent = fmt.format(k.agents || 0);
    $("ala-kpi-active").textContent = fmt.format(k.transactingAgents || 0);
    $("ala-kpi-tx").textContent = fmt.format(k.transactions || 0);
    $("ala-kpi-amount").textContent = money.format(k.totalAmount || 0);
    $("ala-kpi-success").textContent = Number(k.successRate || 0).toFixed(2) + "%";
    $("ala-kpi-zero").textContent = fmt.format(k.zeroTransactionAgents || 0);
    var mapEmpty = $("ala-map-empty");
    var noMatches = Number(k.agents || 0) === 0;
    mapEmpty.hidden = !noMatches;
    mapEmpty.querySelector("strong").textContent = state.appliedClassBucket ?
      "No agents match this Bucket classification" :
      (state.appliedBucket ? "No agents match this Subbucket" :
      (conditionCount(collectConditions()) ?
        "No agents match this configuration" : "No agents match the selected filters"));
    renderAppliedRuleOutcome(data);
    renderAppliedRuleCard(data);
    var current = {
      state: $("ala-state").value,
      district: $("ala-district").value,
      subdistrict: $("ala-subdistrict").value,
      platform: $("ala-platform").value,
      applicationVersion: $("ala-application-version").value,
      serviceFamily: $("ala-service-family").value,
      serviceName: $("ala-service-name").value,
      transactionType: $("ala-transaction-type").value,
      isOnus: $("ala-is-onus").value,
      isOriginal: $("ala-is-original").value,
      responseCode: $("ala-response-code").value,
      isFinancial: $("ala-is-financial").value
    };
    setOptions("ala-state", data.states, current.state, "All States", "code", "name");
    setOptions("ala-district", data.districts, current.district, "All Districts", "code", "name");
    setOptions("ala-subdistrict", data.subdistricts, current.subdistrict, "All Subdistricts", "code", "name");
    setAgentOptions(data.agentOptions);
    setOptions(
      "ala-platform", data.platforms, current.platform,
      "All Platforms", "name", "name"
    );
    setOptions(
      "ala-application-version", data.applicationVersions, current.applicationVersion,
      "All Versions", "name", "name"
    );
    setOptions(
      "ala-service-family", data.serviceFamilies, current.serviceFamily,
      "All Service Families", "name", "name"
    );
    setOptions(
      "ala-service-name", data.serviceNames, current.serviceName,
      current.serviceFamily ? "All Services in Family" : "All Service Names", "name", "name"
    );
    setOptions(
      "ala-transaction-type", data.transactionTypes, current.transactionType,
      "All Transaction Types", "name", "name"
    );
    setOptions(
      "ala-is-onus", data.onusOptions || [
        {name: "YES", label: "Yes"}, {name: "NO", label: "No"}
      ], current.isOnus, "All", "name", "label"
    );
    setOptions(
      "ala-is-original", data.originalOptions || [
        {name: "YES", label: "Yes"}, {name: "NO", label: "No"}
      ], current.isOriginal, "All", "name", "label"
    );
    setOptions(
      "ala-response-code", data.responseCodes, current.responseCode,
      "All Response Codes", "name", "name"
    );
    setOptions(
      "ala-is-financial", data.financialOptions || [
        {name: "YES", label: "Yes"}, {name: "NO", label: "No"}
      ], current.isFinancial, "All", "name", "label"
    );
    renderChips("ala-status-chips", data.statuses, "ala-status");
    renderChips("ala-risk-chips", data.risks, "ala-risk");
    renderAgents(data);
    updateConditionSummary();
    updateAnalyticsContext();
    scheduleAnalyticsVisuals(data, renderOptions);
  }
  function scheduleAnalyticsVisuals(data, renderOptions) {
    if (state.visualFrame) { global.cancelAnimationFrame(state.visualFrame); }
    var generation = state.generation;
    state.visualFrame = global.requestAnimationFrame(function () {
      if (generation !== state.generation) { return; }
      if (!(renderOptions && renderOptions.preserveRbac)) {
        renderRiskDistribution(data);
        renderHierarchyChart(data);
      }
      renderMap(data);
      state.visualFrame = null;
    });
  }
  function renderChips(id, items, controlId) {
    var selected = $(controlId).value;
    $(id).innerHTML = (items || []).map(function (item) {
      return '<button type="button" class="ala-chip ' +
        (item.name === selected ? "is-active" : "") + '" data-value="' +
        escapeHtml(item.name) + '">' + escapeHtml(item.name) + " " +
        fmt.format(item.count) + "</button>";
    }).join("");
    $(id).querySelectorAll("button").forEach(function (button) {
      button.addEventListener("click", function () {
        $(controlId).value = selected === button.dataset.value ? "" : button.dataset.value;
        loadFacets().catch(function () {});
      });
    });
  }
  function metricValue(row, metric) {
    if (metric === "AGENT_COUNT") {
      return Number(row.count != null ? row.count : (row.agentCount != null ? row.agentCount : 1));
    }
    if (metric === "TOTAL_AMOUNT") { return Number(row.amount || row.totalAmount || 0); }
    if (metric === "SUCCESS_RATE") {
      return Number(row.transactions || row.transactionCount || 0) ?
        100 * Number(row.successCount || 0) / Number(row.transactions || row.transactionCount || 0) : 0;
    }
    if (metric === "FAILURE_COUNT") { return Number(row.failureCount || 0); }
    if (metric === "REVERSAL_COUNT") { return Number(row.reversalCount || 0); }
    if (metric === "FINANCIAL_COUNT") { return Number(row.financialCount || 0); }
    if (metric === "UNIQUE_CUSTOMERS") { return Number(row.uniqueCustomers || 0); }
    if (metric === "UNIQUE_DEVICES") { return Number(row.uniqueDevices || 0); }
    if (metric === "RISK_SCORE") { return Number(row.riskScore || 0); }
    if (metric === "GEO_ANOMALY_COUNT") {
      return Number(row.geoAnomalyCount != null ? row.geoAnomalyCount : (row.geoAnomaly === "Y" ? 1 : 0));
    }
    return Number(row.transactions || row.transactionCount || 0);
  }
  function metricLabel(value, metric) {
    if (metric === "TOTAL_AMOUNT") { return money.format(value); }
    if (metric === "SUCCESS_RATE") { return Number(value).toFixed(2) + "%"; }
    if (metric === "RISK_SCORE") { return Number(value).toFixed(2); }
    return fmt.format(Math.round(value));
  }
  function riskKey(value) {
    var key = String(value || "UNCLASSIFIED").toUpperCase();
    if (key.indexOf("CRITICAL") >= 0) { return "critical"; }
    if (key.indexOf("HIGH") >= 0) { return "high"; }
    if (key.indexOf("MEDIUM") >= 0 || key.indexOf("MODERATE") >= 0) { return "medium"; }
    if (key.indexOf("LOW") >= 0) { return "low"; }
    return "unclassified";
  }
  function riskColour(value) {
    return {
      low: "#4f963f",
      medium: "#f0ad00",
      high: "#ea7818",
      critical: "#cf2f3f",
      unclassified: "#9aa3aa"
    }[riskKey(value)];
  }
  function interpolateColour(from, to, amount) {
    function channel(hex, offset) {
      return parseInt(hex.slice(offset, offset + 2), 16);
    }
    amount = Math.max(0, Math.min(1, Number(amount) || 0));
    return "#" + [1, 3, 5].map(function (offset) {
      return Math.round(channel(from, offset) +
        (channel(to, offset) - channel(from, offset)) * amount)
        .toString(16).padStart(2, "0");
    }).join("");
  }
  function areaRiskIntensity(row) {
    if (!row) { return null; }
    var low = Number(row.low || 0);
    var medium = Number(row.medium || 0);
    var high = Number(row.high || 0);
    var critical = Number(row.critical || 0);
    var classified = low + medium + high + critical;
    if (classified) {
      return (low * 12 + medium * 38 + high * 68 + critical * 94) / classified;
    }
    var score = Number(row.riskScore);
    return isFinite(score) && score > 0 ? Math.max(0, Math.min(100, score)) : null;
  }
  function gradientRiskColour(row) {
    var value = areaRiskIntensity(row);
    if (value == null) { return "#b7c1c9"; }
    var stops = [
      [0, "#2f7d32"],
      [25, "#78ad45"],
      [45, "#f0ad00"],
      [70, "#ea7818"],
      [100, "#c9263b"]
    ];
    for (var index = 1; index < stops.length; index += 1) {
      if (value <= stops[index][0]) {
        var previous = stops[index - 1];
        return interpolateColour(
          previous[1],
          stops[index][1],
          (value - previous[0]) / (stops[index][0] - previous[0])
        );
      }
    }
    return stops[stops.length - 1][1];
  }
  function riskFromScore(value) {
    value = Number(value);
    if (!isFinite(value) || value <= 0) { return "UNCLASSIFIED"; }
    if (value >= 75) { return "CRITICAL"; }
    if (value >= 50) { return "HIGH"; }
    if (value >= 25) { return "MEDIUM"; }
    return "LOW";
  }
  function dominantAreaRisk(row) {
    if (!row) { return "UNCLASSIFIED"; }
    var categories = [
      ["LOW", Number(row.low || 0)],
      ["MEDIUM", Number(row.medium || 0)],
      ["HIGH", Number(row.high || 0)],
      ["CRITICAL", Number(row.critical || 0)]
    ].sort(function (a, b) { return b[1] - a[1]; });
    return categories[0][1] ? categories[0][0] : riskFromScore(row.riskScore);
  }
  function shouldRenderVisual(key, payload) {
    var signature = JSON.stringify(payload);
    if (state.renderSignatures[key] === signature) { return false; }
    state.renderSignatures[key] = signature;
    return true;
  }
  function renderRiskDistribution(data) {
    var target = $("ala-risk-distribution");
    if (!target) { return; }
    var total = Number((data.kpis || {}).agents || 0);
    var rows = [
      {name: "Low", key: "low"},
      {name: "Medium", key: "medium"},
      {name: "High", key: "high"},
      {name: "Critical", key: "critical"},
      {name: "Unclassified", key: "unclassified"}
    ].map(function (row) {
      row.count = 0;
      row.colour = riskColour(row.name);
      return row;
    });
    (data.risks || []).forEach(function (source) {
      var key = riskKey(source.name);
      var row = rows.find(function (candidate) { return candidate.key === key; });
      if (row) { row.count += Number(source.count || 0); }
    });
    if (!rows.length || !total) {
      target.innerHTML = '<div class="ala-empty">No risk distribution is available.</div>';
      return;
    }
    if (!shouldRenderVisual("risk", {
      total: total,
      rows: rows.map(function (row) { return [row.name, row.count]; }),
      selected: state.analyticsRiskBand
    })) { return; }
    var cursor = 0;
    var segments = rows.map(function (row) {
      var percentage = 100 * row.count / total;
      var start = cursor;
      cursor += percentage;
      if (!row.count) { return ""; }
      return '<circle class="ala-risk-ring-segment is-' + row.key +
        (state.analyticsRiskBand === row.name ? " is-selected" : "") +
        '" cx="60" cy="60" r="46" pathLength="100" fill="none" stroke="' +
        row.colour + '" stroke-width="20" stroke-dasharray="' +
        percentage.toFixed(3) + ' 100" stroke-dashoffset="' +
        (-start).toFixed(3) + '" transform="rotate(-90 60 60)" data-risk-drill="' +
        escapeHtml(row.name) + '" tabindex="0" role="button" aria-label="' +
        escapeHtml(row.name) + ", " + fmt.format(row.count) + " agents, " +
        percentage.toFixed(1) + ' percent" data-chart-tooltip="' +
        escapeHtml(row.name) + " · " + fmt.format(row.count) + " agents · " +
        percentage.toFixed(1) + '%"><title>' + escapeHtml(row.name) +
        ": " + fmt.format(row.count) + " agents (" + percentage.toFixed(1) +
        '%). Click to drill.</title></circle>';
    }).join("");
    target.innerHTML =
      '<div class="ala-risk-donut-wrap"><div class="ala-risk-ring-wrap">' +
      '<svg class="ala-risk-ring" viewBox="0 0 120 120" role="img" ' +
      'aria-label="Interactive agent risk distribution">' +
      '<circle class="ala-risk-ring-track" cx="60" cy="60" r="46" pathLength="100" ' +
      'fill="none" stroke-width="20"></circle>' + segments +
      '<text x="60" y="56" text-anchor="middle" class="ala-risk-ring-total">' +
      fmt.format(total) + '</text><text x="60" y="70" text-anchor="middle" ' +
      'class="ala-risk-ring-label">AGENTS</text></svg>' +
      '<small>Click a segment to drill</small></div><div class="ala-risk-legend-list">' +
      '<div class="ala-risk-legend-head"><span>Risk band</span><span>Agents</span>' +
      '<span>Share</span></div>' +
      rows.map(function (row) {
        var selected = state.analyticsRiskBand === row.name;
        return '<button type="button" class="ala-risk-legend-row ' +
          (selected ? "is-selected" : "") + '" data-risk-drill="' +
          escapeHtml(row.name) + '"><i style="--risk-colour:' + row.colour +
          '"></i><span>' + escapeHtml(row.name) + '</span><b>' +
          fmt.format(row.count) + '</b><small>' +
          (100 * row.count / total).toFixed(1) + '%</small></button>';
      }).join("") + '</div></div>' +
      (state.analyticsRiskBand ?
        '<div class="ala-risk-clear-row"><button type="button" ' +
        'class="ala-chart-clear" data-clear-risk-drill>' +
        '<span class="fa fa-times"></span> Clear risk drill</button></div>' : "");
  }
  function refreshHierarchyVisual() {
    delete state.renderSignatures.hierarchy;
    if (state.data) { renderHierarchyChart(state.data); }
  }
  function hierarchyAutoScale(rowCount) {
    if (rowCount <= 5) { return 1.25; }
    if (rowCount <= 10) { return 1.1; }
    if (rowCount <= 25) { return 0.9; }
    return 0.75;
  }
  function switchHierarchyVisual(view) {
    state.activeHierarchyVisual = view === "risk" ? "risk" : "hierarchy";
    document.querySelectorAll("[data-hierarchy-view]").forEach(function (button) {
      var active = button.dataset.hierarchyView === state.activeHierarchyVisual;
      button.classList.toggle("is-active", active);
      button.setAttribute("aria-selected", active ? "true" : "false");
    });
    $("ala-hierarchy-view-panel").hidden = state.activeHierarchyVisual !== "hierarchy";
    $("ala-hierarchy-risk-panel").hidden = state.activeHierarchyVisual !== "risk";
  }
  function selectedHierarchyAgent(data, currentNode) {
    if (!currentNode || !/agent/i.test(String(currentNode.levelName || ""))) {
      return null;
    }
    var securedAgent = (state.rbacHierarchyData || {}).selectedAgent || {};
    var agents = (data && data.agents) || [];
    var agent = agents.find(function (item) {
      return String(item.id) === String(securedAgent.id || currentNode.name);
    });
    if (!agent && agents.length === 1) { agent = agents[0]; }
    if (!agent && securedAgent.id) {
      agent = {
        id: securedAgent.id,
        name: securedAgent.name,
        drawerUrl: securedAgent.drawerUrl
      };
    } else if (agent && securedAgent.drawerUrl && !agent.drawerUrl) {
      agent.drawerUrl = securedAgent.drawerUrl;
    }
    return agent || null;
  }
  function hierarchyAgentSummaryHtml(agent) {
    var transactions = Number(agent.transactions || 0);
    var successCount = Number(agent.successCount || 0);
    var successRate = transactions ? 100 * successCount / transactions : 0;
    var riskName = agent.riskCategory || "Unclassified";
    var riskClass = String(riskName).toLowerCase().replace(/[^a-z0-9]+/g, "-");
    var location = [
      agent.branch, agent.village, agent.subdistrict, agent.district, agent.state
    ].filter(Boolean).join(" · ");
    var supporting = [
      agent.platform ? "Platform " + agent.platform : "",
      agent.applicationVersion ? "Version " + agent.applicationVersion : "",
      agent.mostUsedService ? "Top service " + agent.mostUsedService : ""
    ].filter(Boolean).join(" · ");
    var kpis = [
      ["Transactions", fmt.format(transactions)],
      ["Amount", money.format(Number(agent.amount || 0))],
      ["Success rate", successRate.toFixed(2) + "%"],
      ["Risk score", Number(agent.riskScore || 0).toFixed(2)],
      ["Unique customers", fmt.format(Number(agent.uniqueCustomers || 0))],
      ["Unique devices", fmt.format(Number(agent.uniqueDevices || 0))]
    ];
    return '<section class="ala-terminal-agent" aria-label="Selected agent analytical summary">' +
      '<header class="ala-terminal-agent-head"><span class="ala-terminal-agent-avatar">' +
      '<i class="fa fa-user"></i></span><span><small>Selected agent analytics</small>' +
      '<strong>' + escapeHtml(agent.id || "Agent") + " · " +
      escapeHtml(agent.name || "Name unavailable") + '</strong><em>' +
      escapeHtml(location || "Location unavailable") +
      '</em></span><span class="ala-terminal-agent-badges">' +
      (agent.status ? '<b>Status ' + escapeHtml(agent.status) + "</b>" : "") +
      '<b class="is-' + escapeHtml(riskClass) + '">' + escapeHtml(riskName) +
      ' risk</b></span></header><div class="ala-terminal-agent-kpis">' +
      kpis.map(function (item) {
        return '<div><span>' + escapeHtml(item[0]) + '</span><strong>' +
          escapeHtml(item[1]) + "</strong></div>";
      }).join("") + '</div><footer class="ala-terminal-agent-footer"><span>' +
      escapeHtml(supporting || "Complete profile and behavioural statistics are available.") +
      '</span><button type="button" class="ala-button ala-button--small" ' +
      'data-hierarchy-agent-drawer' + (agent.drawerUrl ? "" : " disabled") +
      '><i class="fa fa-external-link"></i> View complete statistics</button></footer></section>';
  }
  function bindHierarchyControls() {
    if (!$("ala-hierarchy-limit")) { return; }
    $("ala-hierarchy-limit").value = String(state.hierarchyLimit);
    $("ala-hierarchy-limit").addEventListener("change", function () {
      state.hierarchyLimit = $("ala-hierarchy-limit").value === "ALL" ?
        "ALL" : Number($("ala-hierarchy-limit").value);
      refreshHierarchyVisual();
    });
    if ($("ala-hierarchy-search")) {
      $("ala-hierarchy-search").value = state.hierarchySearch;
      $("ala-hierarchy-search").addEventListener("input", function () {
        state.hierarchySearch = $("ala-hierarchy-search").value || "";
        refreshHierarchyVisual();
      });
    }
    document.querySelectorAll("[data-hierarchy-view]").forEach(function (button) {
      button.addEventListener("click", function () {
        switchHierarchyVisual(button.dataset.hierarchyView);
      });
    });
    switchHierarchyVisual(state.activeHierarchyVisual);
  }
  function renderHierarchyChart(data) {
    var target = $("ala-hierarchy-chart");
    if (!target) { return; }
    var allRows = data.hierarchySummary || [];
    var baseAvailableRows = currentGeographyLevel() ?
      allRows.filter(function (row) { return Number(row.agents || 0) > 0; }) :
      allRows;
    var searchValue = normalizeName(state.hierarchySearch || "").toLowerCase();
    var availableRows = searchValue ? baseAvailableRows.filter(function (row) {
      return [
        row.name,
        compactHierarchyName(row.name, row.levelName),
        row.levelName
      ].some(function (value) {
        return normalizeName(value || "").toLowerCase().indexOf(searchValue) >= 0;
      });
    }) : baseAvailableRows;
    var rows = state.hierarchyLimit === "ALL" ?
      availableRows.slice() : availableRows.slice(0, Number(state.hierarchyLimit));
    var autoScale = hierarchyAutoScale(rows.length);
    if ($("ala-hierarchy-auto-scale")) {
      $("ala-hierarchy-auto-scale").textContent =
        "Auto scale " + Math.round(autoScale * 100) + "%";
    }
    var hierarchyData = state.rbacHierarchyData || {};
    var trail = hierarchyData.trail || [];
    var currentNode = trail.length ? trail[trail.length - 1] : null;
    var parentNode = trail.length > 1 ? trail[trail.length - 2] : null;
    var vertical = (hierarchyData.hierarchies || []).find(function (item) {
      return String(item.id) === String(state.rbacVerticalId);
    });
    var nextLevel = rows.length ? rows[0].levelName : "";
    var terminalAgent = !baseAvailableRows.length ?
      selectedHierarchyAgent(data, currentNode) : null;
    var currentName = currentNode ?
      compactHierarchyName(currentNode.name, currentNode.levelName) :
      (vertical ? vertical.name : "RBAC hierarchy");
    var contextHtml = '<div class="ala-hierarchy-context"><span class="fa fa-' +
      (terminalAgent ? "user" : "sitemap") + '"></span>' +
      '<span title="' + escapeHtml(currentNode ? currentNode.name : currentName) +
      '"><strong>' + escapeHtml(currentName) + '</strong><small>' +
      (nextLevel ? "Next level: " + escapeHtml(nextLevel) :
        (terminalAgent ? "Agent analytical summary for the selected period" :
          "The selected node has no lower hierarchy level")) +
      (availableRows.length ? " · Showing " + rows.length + " of " +
        availableRows.length : "") + "</small></span>" +
      (state.rbacNodeId ?
        '<button type="button" data-hierarchy-back><span class="fa fa-arrow-left"></span> Back</button>' :
        "") + "</div>";
    if (!shouldRenderVisual("hierarchy", {
      rows: rows,
      verticalId: state.rbacVerticalId,
      nodeId: state.rbacNodeId,
      limit: state.hierarchyLimit,
      search: state.hierarchySearch,
      autoScale: autoScale,
      terminalAgent: terminalAgent
    })) { return; }
    if (!rows.length) {
      target.innerHTML = contextHtml + (terminalAgent ?
        hierarchyAgentSummaryHtml(terminalAgent) :
        '<div class="ala-empty">' + (searchValue ?
          "No hierarchy records match this search." :
          "No lower-level hierarchy activity is available.") + "</div>");
      var emptyBack = target.querySelector("[data-hierarchy-back]");
      if (emptyBack) {
        emptyBack.addEventListener("click", function () {
          if (isAnalyticsLocked("ala-hierarchy-card")) { return; }
          selectRbacNode(parentNode ? parentNode.id : null,
            parentNode ? parentNode.name : "").catch(function () {});
        });
      }
      var agentDrawer = target.querySelector("[data-hierarchy-agent-drawer]");
      if (agentDrawer && terminalAgent && terminalAgent.drawerUrl) {
        agentDrawer.addEventListener("click", function () {
          openAgentDrawer(terminalAgent.id, terminalAgent.drawerUrl, agentDrawer);
        });
      }
      return;
    }
    var max = Math.max.apply(null, rows.map(function (row) {
      return Number(row.agents || 0);
    }).concat([1]));
    target.innerHTML = contextHtml + '<div class="ala-hierarchy-viewport">' +
      '<div class="ala-hierarchy-zoom-content" style="zoom:' +
      autoScale.toFixed(2) + '"><div class="ala-hierarchy-bars">' +
      rows.map(function (row) {
      var total = Number(row.agents || 0);
      var compactName = compactHierarchyName(row.name, row.levelName);
      var categories = [
        ["low", Number(row.low || 0)],
        ["medium", Number(row.medium || 0)],
        ["high", Number(row.high || 0)],
        ["critical", Number(row.critical || 0)],
        ["unclassified", Number(row.unclassified || 0)]
      ];
      return '<button type="button" class="ala-hierarchy-row" data-hierarchy-node="' +
        escapeHtml(row.nodeId) + '" data-hierarchy-name="' + escapeHtml(row.name) +
        '" data-chart-tooltip="' + escapeHtml(row.name) + " · " +
        fmt.format(total) + ' agents"><span title="' +
        escapeHtml(row.name) + '"><i class="fa fa-' +
        (row.hasChildren ? "sitemap" : "user") + '"></i>' + escapeHtml(compactName) +
        '</span><span class="ala-hierarchy-track" style="width:' +
        Math.max(8, 100 * total / max).toFixed(1) + '%">' +
        categories.map(function (entry) {
          return entry[1] ? '<i class="is-' + entry[0] + '" style="width:' +
            (100 * entry[1] / total).toFixed(1) + '%" title="' +
            entry[0] + ": " + fmt.format(entry[1]) + '"></i>' : "";
        }).join("") + '</span><b>' + fmt.format(total) + '</b></button>';
    }).join("") + '</div><div class="ala-mini-risk-key">' +
      ["Low", "Medium", "High", "Critical"].map(function (name) {
        return '<span><i class="is-' + name.toLowerCase() + '"></i>' + name + '</span>';
      }).join("") + "</div></div></div>";
    target.querySelectorAll("[data-hierarchy-node]").forEach(function (button) {
      button.addEventListener("click", function () {
        if (isAnalyticsLocked("ala-hierarchy-card")) { return; }
        selectRbacNode(
          button.dataset.hierarchyNode,
          button.dataset.hierarchyName
        ).catch(function () {});
      });
    });
    var back = target.querySelector("[data-hierarchy-back]");
    if (back) {
      back.addEventListener("click", function () {
        if (isAnalyticsLocked("ala-hierarchy-card")) { return; }
        selectRbacNode(parentNode ? parentNode.id : null,
          parentNode ? parentNode.name : "").catch(function () {});
      });
    }
  }
  function renderTrend(data) {
    var rows = data.trend || [];
    var target = $("ala-trend");
    if (!rows.length) {
      target.innerHTML = '<div class="ala-empty">No monthly trend for this filter.</div>';
      return;
    }
    if (!shouldRenderVisual("trend", rows)) { return; }
    var width = 520, height = 210, left = 42, right = 22, top = 28, bottom = 38;
    var plotWidth = width - left - right, plotHeight = height - top - bottom;
    var maxTransactions = Math.max.apply(null, rows.map(function (row) {
      return Number(row.transactions || 0);
    }).concat([1]));
    var maxRisk = Math.max.apply(null, rows.map(function (row) {
      return Number(row.riskScore || 0);
    }).concat([100]));
    function xAt(index) {
      return left + (rows.length === 1 ? plotWidth / 2 : plotWidth * index / (rows.length - 1));
    }
    function yTransactions(row) {
      return top + plotHeight * (1 - Number(row.transactions || 0) / maxTransactions);
    }
    function yRisk(row) {
      return top + plotHeight * (1 - Number(row.riskScore || 0) / maxRisk);
    }
    function line(points) {
      return points.map(function (point, index) {
        return (index ? "L" : "M") + point[0].toFixed(1) + " " + point[1].toFixed(1);
      }).join(" ");
    }
    var transactionPoints = rows.map(function (row, index) {
      return [xAt(index), yTransactions(row)];
    });
    var riskPoints = rows.map(function (row, index) {
      return [xAt(index), yRisk(row)];
    });
    target.innerHTML = '<div class="ala-trend-legend"><span><i class="is-transactions"></i>' +
      'Transactions</span><span><i class="is-risk"></i>Average risk score</span></div>' +
      '<svg class="ala-trend-svg" viewBox="0 0 ' + width + " " + height +
      '" role="img" aria-label="Transaction and risk trend">' +
      [0, 1, 2, 3].map(function (lineIndex) {
        var y = top + plotHeight * lineIndex / 3;
        return '<line x1="' + left + '" y1="' + y + '" x2="' + (width - right) +
          '" y2="' + y + '" class="ala-chart-grid"></line>';
      }).join("") +
      '<path d="' + line(transactionPoints) + '" class="ala-trend-line is-transactions"></path>' +
      '<path d="' + line(riskPoints) + '" class="ala-trend-line is-risk"></path>' +
      rows.map(function (row, index) {
        var x = xAt(index);
        return '<g class="ala-trend-point" data-trend-month="' +
          escapeHtml(row.month) + '" data-chart-tooltip="' +
          escapeHtml(row.month) + " · " + fmt.format(row.transactions || 0) +
          " transactions · average risk " +
          Number(row.riskScore || 0).toFixed(2) + '"><circle cx="' + x + '" cy="' +
          yTransactions(row) + '" r="4" class="is-transactions"><title>' +
          escapeHtml(row.month) + ": " + fmt.format(row.transactions || 0) +
          ' transactions</title></circle><circle cx="' + x + '" cy="' +
          yRisk(row) + '" r="4" class="is-risk"><title>' +
          escapeHtml(row.month) + ": risk " + Number(row.riskScore || 0).toFixed(2) +
          '</title></circle><text x="' + x + '" y="' + (height - 14) +
          '" text-anchor="middle">' + escapeHtml(row.month.slice(5)) + '</text></g>';
      }).join("") + "</svg>";
    target.querySelectorAll("[data-trend-month]").forEach(function (point) {
      point.addEventListener("click", function () {
        if (isAnalyticsLocked("ala-trend-card")) { return; }
        $("ala-mode").value = "MONTHLY";
        $("ala-date").value = point.dataset.trendMonth + "-01";
        updateAnalyticsContext();
        load(false).catch(function () {});
      });
    });
  }
  function renderServices(data) {
    var rows = data.services || [];
    var max = Math.max.apply(null, [1].concat(rows.map(function (row) { return Number(row.transactions || 0); })));
    var target = $("ala-services");
    if (!shouldRenderVisual("services", {
      rows: rows,
      selected: $("ala-service-name").value
    })) { return; }
    target.innerHTML = rows.length ? '<div class="ala-service-bars">' +
      rows.slice(0, 8).map(function (row) {
        return '<button type="button" class="ala-service-row ' +
          ($("ala-service-name").value === row.name ? "is-selected" : "") +
          '" data-service-drill="' + escapeHtml(row.name) +
          '" data-chart-tooltip="' + escapeHtml(row.name) + " · " +
          fmt.format(row.transactions || 0) + ' transactions"><span title="' +
          escapeHtml(row.name) + '">' + escapeHtml(row.name) +
          '</span><span class="ala-service-track"><span class="ala-service-fill" style="width:' +
          Math.round(100 * row.transactions / max) + '%"></span></span><strong>' +
          fmt.format(row.transactions) + "</strong></button>";
      }).join("") + "</div>" +
      ($("ala-service-name").value ?
        '<button type="button" class="ala-chart-clear" data-clear-service-drill>' +
        '<span class="fa fa-times"></span> Clear service drill</button>' : "") :
      '<div class="ala-empty">No service activity in this period.</div>';
    target.querySelectorAll("[data-service-drill]").forEach(function (button) {
      button.addEventListener("click", function () {
        if (isAnalyticsLocked("ala-services-card")) { return; }
        $("ala-service-name").value = $("ala-service-name").value === button.dataset.serviceDrill ?
          "" : button.dataset.serviceDrill;
        load(false).catch(function () {});
      });
    });
    var clear = target.querySelector("[data-clear-service-drill]");
    if (clear) {
      clear.addEventListener("click", function () {
        if (isAnalyticsLocked("ala-services-card")) { return; }
        $("ala-service-name").value = "";
        load(false).catch(function () {});
      });
    }
  }
  function renderAgents(data) {
    var count = Number((data.kpis || {}).agents || 0);
    if ($("ala-agent-count")) {
      $("ala-agent-count").textContent = fmt.format(count) + " matching agents";
    }
    if ($("ala-agent-tab-count")) {
      $("ala-agent-tab-count").textContent = fmt.format(count);
    }
    state.agentReportDirty = true;
    $("ala-analytics-view-agents-tab").classList.add("is-dirty");
    setAgentReportStatus(
      state.activeAnalyticsView === "agents" && state.agentReportLoaded ?
        "Filters changed — click Agent Details again to refresh" :
        "Latest filters ready — open this tab to load agents",
      false
    );
  }
  function openAgentDrawer(id, drawerUrl, trigger) {
    if (!drawerUrl) {
      showError("The secure drawer URL for this agent is unavailable. Refresh the analysis and try again.");
      return;
    }
    try {
      global.sessionStorage.setItem("alaAgentDrawerContext", JSON.stringify({
        agentId: String(id == null ? "" : id),
        mode: $("ala-mode") ? $("ala-mode").value : "DAILY",
        asOfDate: $("ala-date") ? $("ala-date").value : ""
      }));
    } catch (ignore) {}
    apex.navigation.dialog(
      drawerUrl,
      {title: "Agent " + id + " — Complete Statistics", width: "90vw", maxWidth: "90vw", modal: true},
      "t-Drawer-page--standard t-Drawer--pullOutEnd t-Drawer--xl t-Drawer--noPadding",
      trigger
    );
  }
  function showAgent(id, trigger) {
    var row = (((state.data || {}).agents) || []).find(function (agent) {
      return String(agent.id) === String(id);
    });
    openAgentDrawer(id, row && row.drawerUrl, trigger);
  }
  function openAgentReportLink(button) {
    var id = button && button.dataset.agentId;
    var row = (((state.data || {}).agents) || []).find(function (agent) {
      return String(agent.id) === String(id);
    });
    openAgentDrawer(
      id,
      (row && row.drawerUrl) || (button && button.dataset.drawerUrl),
      button
    );
  }
  function positionChartTooltip(event, element) {
    var tooltip = $("ala-chart-tooltip");
    if (!tooltip || !element) { return; }
    tooltip.textContent = element.dataset.chartTooltip || "";
    tooltip.hidden = !tooltip.textContent;
    if (tooltip.hidden) { return; }
    var width = tooltip.offsetWidth;
    var height = tooltip.offsetHeight;
    var x = event && isFinite(event.clientX) ? event.clientX + 12 :
      element.getBoundingClientRect().left + 12;
    var y = event && isFinite(event.clientY) ? event.clientY + 12 :
      element.getBoundingClientRect().top + 12;
    tooltip.style.left = Math.max(8, Math.min(global.innerWidth - width - 8, x)) + "px";
    tooltip.style.top = Math.max(8, Math.min(global.innerHeight - height - 8, y)) + "px";
  }
  function bindAnalyticsDelegates() {
    if (state.analyticsDelegatesBound) { return; }
    state.analyticsDelegatesBound = true;
    document.addEventListener("click", function (event) {
      var agentLink = event.target.closest(".ala-ir-agent-link");
      if (agentLink) {
        event.preventDefault();
        openAgentReportLink(agentLink);
        return;
      }
      var riskDrill = event.target.closest(
        "#ala-risk-distribution [data-risk-drill]"
      );
      if (riskDrill) {
        event.stopImmediatePropagation();
        if (isAnalyticsLocked("ala-hierarchy-card")) { return; }
        state.analyticsRiskBand =
          state.analyticsRiskBand === riskDrill.dataset.riskDrill ?
            "" : riskDrill.dataset.riskDrill;
        $("ala-hierarchy-card").dataset.activeRiskDrill = state.analyticsRiskBand;
        document.querySelectorAll(
          "#ala-risk-distribution [data-risk-drill]"
        ).forEach(function (item) {
          item.classList.toggle(
            "is-selected",
            Boolean(state.analyticsRiskBand) &&
              item.dataset.riskDrill === state.analyticsRiskBand
          );
        });
        updateAnalyticsContext();
        load(false).catch(function () {});
        return;
      }
      if (event.target.closest("#ala-risk-distribution [data-clear-risk-drill]")) {
        event.stopImmediatePropagation();
        if (isAnalyticsLocked("ala-hierarchy-card")) { return; }
        state.analyticsRiskBand = "";
        $("ala-hierarchy-card").dataset.activeRiskDrill = "";
        document.querySelectorAll(
          "#ala-risk-distribution [data-risk-drill].is-selected"
        ).forEach(function (item) { item.classList.remove("is-selected"); });
        updateAnalyticsContext();
        load(false).catch(function () {});
      }
    });
    document.addEventListener("keydown", function (event) {
      var riskDrill = event.target.closest(
        "#ala-risk-distribution [data-risk-drill]"
      );
      if (riskDrill && (event.key === "Enter" || event.key === " ")) {
        event.preventDefault();
        event.stopImmediatePropagation();
        riskDrill.click();
      }
    });
    document.addEventListener("pointerover", function (event) {
      var visual = event.target.closest("[data-chart-tooltip]");
      if (visual) { positionChartTooltip(event, visual); }
    });
    document.addEventListener("pointermove", function (event) {
      var visual = event.target.closest("[data-chart-tooltip]");
      if (visual && $("ala-chart-tooltip") && !$("ala-chart-tooltip").hidden) {
        positionChartTooltip(event, visual);
      }
    });
    document.addEventListener("pointerout", function (event) {
      var visual = event.target.closest("[data-chart-tooltip]");
      if (!visual || (event.relatedTarget && visual.contains(event.relatedTarget))) { return; }
      if ($("ala-chart-tooltip")) { $("ala-chart-tooltip").hidden = true; }
    });
    document.addEventListener("focusin", function (event) {
      var visual = event.target.closest("[data-chart-tooltip]");
      if (visual) { positionChartTooltip(null, visual); }
    });
    document.addEventListener("focusout", function (event) {
      if (event.target.closest("[data-chart-tooltip]") && $("ala-chart-tooltip")) {
        $("ala-chart-tooltip").hidden = true;
      }
    });
  }

  function normalizeName(value) {
    return String(value || "").toUpperCase().replace(/&/g, "AND").replace(/[^A-Z0-9]/g, "")
      .replace("CHHATTISGARH", "CHATTISGARH").replace("ODISHA", "ORISSA")
      .replace("JAMMUANDKASHMIR", "JAMMUKASHMIR").replace("BENGALURU", "BANGALORE");
  }
  function projection(features) {
    var points = [];
    (features || []).forEach(function (feature) {
      ((feature.geometry || {}).rings || []).forEach(function (ring) {
        ring.forEach(function (point) { points.push(point); });
      });
    });
    if (!points.length) { return null; }
    var xs = points.map(function (point) { return point[0]; });
    var ys = points.map(function (point) { return point[1]; });
    var padX = 30, topPad = 78, bottomPad = 24, width = 720, height = 570;
    var svg = $("ala-map");
    var legend = svg && svg.parentElement ?
      svg.parentElement.querySelector(".ala-map-legend") : null;
    var svgBounds = svg ? svg.getBoundingClientRect() : null;
    var legendBounds = legend ? legend.getBoundingClientRect() : null;
    var renderedScale = svgBounds && svgBounds.width && svgBounds.height ?
      Math.min(svgBounds.width / width, svgBounds.height / height) : 0;
    if (legendBounds && renderedScale > 0) {
      topPad = Math.max(
        topPad,
        Math.min(220, (legendBounds.bottom - svgBounds.top + 12) / renderedScale)
      );
    }
    var minX = Math.min.apply(null, xs), maxX = Math.max.apply(null, xs);
    var minY = Math.min.apply(null, ys), maxY = Math.max.apply(null, ys);
    var availableHeight = height - topPad - bottomPad;
    var scale = Math.min(
      (width - 2 * padX) / (maxX - minX || 1),
      availableHeight / (maxY - minY || 1)
    );
    var offsetX = (width - (maxX - minX) * scale) / 2;
    var offsetY = topPad + (availableHeight - (maxY - minY) * scale) / 2;
    return {
      point: function (point) {
        return [
          offsetX + (point[0] - minX) * scale,
          offsetY + (maxY - point[1]) * scale
        ];
      },
      latlon: function (lat, lon) {
        var x = lon * 20037508.34 / 180;
        var y = Math.log(Math.tan((90 + lat) * Math.PI / 360)) / (Math.PI / 180);
        y = y * 20037508.34 / 180;
        return this.point([x, y]);
      }
    };
  }
  function pathFor(feature, project) {
    var commands = [];
    ((feature.geometry || {}).rings || []).forEach(function (ring) {
      ring.forEach(function (point, index) {
        var projected = project.point(point);
        commands.push((index ? "L" : "M") + projected[0].toFixed(1) + " " + projected[1].toFixed(1));
      });
      commands.push("Z");
    });
    return commands.join(" ");
  }
  function featureCentroid(feature, project) {
    var points = [];
    ((feature.geometry || {}).rings || []).forEach(function (ring) {
      ring.forEach(function (point) { points.push(project.point(point)); });
    });
    if (!points.length) { return null; }
    return [
      points.reduce(function (sum, point) { return sum + point[0]; }, 0) / points.length,
      points.reduce(function (sum, point) { return sum + point[1]; }, 0) / points.length
    ];
  }
  function featureForAgent(features, row, level) {
    return (features || []).find(function (feature) {
      var attrs = feature.attributes || {};
      if (level === "state") {
        return String(row.stateCode || "") === String(attrs.lgd_statecode || attrs.code || "") ||
          normalizeName(row.state) === normalizeName(attrs.name);
      }
      if (level === "district" || level === "district-summary") {
        return String(row.districtCode || "") === String(attrs.lgd_districtcode || attrs.code || "") ||
          normalizeName(row.district) === normalizeName(attrs.name);
      }
      return String(row.subdistrictCode || "") ===
          String(attrs.lgd_subdistrictcode || attrs.code || "") ||
        normalizeName(row.subdistrict) === normalizeName(attrs.name);
    });
  }
  function boundaryData(districtCode) {
    if (!districtCode) { return Promise.resolve(null); }
    if (state.subdistrictCache[districtCode]) { return Promise.resolve(state.subdistrictCache[districtCode]); }
    return server("AGENT_LOCATION_BOUNDARIES", {x01: districtCode}).then(function (data) {
      state.subdistrictCache[districtCode] = data;
      return data;
    });
  }
  function areaMatch(feature, rows, level) {
    var attrs = feature.attributes || {};
    return (rows || []).find(function (row) {
      if (level === "state") { return normalizeName(row.name) === normalizeName(attrs.name); }
      if (level === "district" || level === "district-summary") {
        return String(row.code) === String(attrs.lgd_districtcode) ||
          normalizeName(row.name) === normalizeName(attrs.name);
      }
      return String(row.code) === String(attrs.lgd_subdistrictcode) ||
        normalizeName(row.name) === normalizeName(attrs.name);
    });
  }
  function showMapTooltip(event, name, row, options) {
    options = options || {};
    var tooltip = $("ala-map-tooltip"), wrap = tooltip.parentElement;
    var bounds = wrap.getBoundingClientRect();
    var metric = $("ala-metric").value;
    var transactions = Number(row && row.transactions || 0);
    var successRate = transactions ? 100 * Number(row.successCount || 0) / transactions : 0;
    tooltip.innerHTML = (options.agent ?
      '<span class="ala-tooltip-kicker">Agent</span>' : "") +
      "<strong>" + escapeHtml(name || "Area") + "</strong>" +
      '<div class="ala-tooltip-metric"><span>' + escapeHtml(metricLabels[metric] || "Selected metric") +
      "</span><b>" + escapeHtml(metricLabel(metricValue(row || {}, metric), metric)) + "</b></div>" +
      "<dl><dt>Agents</dt><dd>" + fmt.format(row && (row.count != null ? row.count : 1) || 0) + "</dd>" +
      "<dt>Transactions</dt><dd>" + fmt.format(transactions) + "</dd>" +
      "<dt>Amount</dt><dd>" + money.format(row && row.amount || 0) + "</dd>" +
      "<dt>Success</dt><dd>" + successRate.toFixed(2) + "%</dd>" +
      "<dt>Failures</dt><dd>" + fmt.format(row && row.failureCount || 0) + "</dd>" +
      "<dt>Reversals</dt><dd>" + fmt.format(row && row.reversalCount || 0) + "</dd>" +
      "<dt>Risk band</dt><dd><span class=\"ala-agent-risk-pill is-" +
      riskKey(row && (row.riskCategory || row.dominantRiskCategory)) + "\">" +
      escapeHtml(row && (row.riskCategory || row.dominantRiskCategory) || "Unclassified") +
      "</span></dd><dt>Risk score</dt><dd>" +
      Number(row && row.riskScore || 0).toFixed(2) + "</dd>" +
      "<dt>Geo anomalies</dt><dd>" + fmt.format(row && row.geoAnomalyCount || 0) + "</dd></dl>" +
      '<small>' + (options.agent ? "Click to open secured agent profile" :
        "Click to drill down") + '</small>';
    tooltip.hidden = false;
    var tooltipWidth = tooltip.offsetWidth || 220;
    var tooltipHeight = tooltip.offsetHeight || 230;
    tooltip.style.left = Math.min(
      bounds.width - tooltipWidth - 8,
      Math.max(8, event.clientX - bounds.left + 12)
    ) + "px";
    tooltip.style.top = Math.min(
      bounds.height - tooltipHeight - 8,
      Math.max(8, event.clientY - bounds.top + 12)
    ) + "px";
  }
  function applyMapTransform() {
    var viewport = $("ala-map-viewport");
    if (!viewport) { return; }
    viewport.setAttribute("transform", "translate(" +
      state.mapView.x.toFixed(2) + " " + state.mapView.y.toFixed(2) + ") scale(" +
      state.mapView.scale.toFixed(3) + ")");
    updateMapZoomControls();
  }
  function updateMapZoomControls() {
    var zoomIn = $("ala-map-zoom-in");
    var zoomOut = $("ala-map-zoom-out");
    var reset = $("ala-map-zoom-reset");
    var scale = Number(state.mapView.scale || 1);
    if (zoomIn) { zoomIn.disabled = scale >= 8; }
    if (zoomOut) { zoomOut.disabled = scale <= 1; }
    if (reset) { reset.disabled = scale <= 1; }
  }
  function resetMapView() {
    state.mapView = {scale: 1, x: 0, y: 0};
    applyMapTransform();
  }
  function zoomMapAt(factor, anchorX, anchorY) {
    var previous = state.mapView.scale;
    var next = Math.max(1, Math.min(8, previous * factor));
    if (next === previous) { return; }
    anchorX = anchorX == null ? 360 : anchorX;
    anchorY = anchorY == null ? 285 : anchorY;
    state.mapView.x = anchorX - (anchorX - state.mapView.x) * next / previous;
    state.mapView.y = anchorY - (anchorY - state.mapView.y) * next / previous;
    state.mapView.scale = next;
    applyMapTransform();
  }
  function bindMapNavigation() {
    var svg = $("ala-map");
    if (!svg || svg.dataset.navigationBound) { return; }
    svg.dataset.navigationBound = "true";
    var zoomIn = $("ala-map-zoom-in");
    var zoomOut = $("ala-map-zoom-out");
    var reset = $("ala-map-zoom-reset");
    if (zoomIn) {
      zoomIn.addEventListener("click", function () {
        zoomMapAt(1.25);
      });
    }
    if (zoomOut) {
      zoomOut.addEventListener("click", function () {
        zoomMapAt(0.8);
      });
    }
    if (reset) {
      reset.addEventListener("click", resetMapView);
    }
    updateMapZoomControls();
    svg.addEventListener("wheel", function (event) {
      event.preventDefault();
      var rect = svg.getBoundingClientRect();
      var anchorX = 720 * (event.clientX - rect.left) / rect.width;
      var anchorY = 570 * (event.clientY - rect.top) / rect.height;
      zoomMapAt(event.deltaY < 0 ? 1.22 : 0.82, anchorX, anchorY);
      $("ala-map-tooltip").hidden = true;
    }, {passive: false});
    svg.addEventListener("pointerdown", function (event) {
      if (state.mapView.scale <= 1 || (event.button != null && event.button !== 0)) {
        return;
      }
      state.mapPointer = {
        id: event.pointerId,
        startX: event.clientX,
        startY: event.clientY,
        originX: state.mapView.x,
        originY: state.mapView.y,
        moved: false
      };
    });
    svg.addEventListener("pointermove", function (event) {
      var pointer = state.mapPointer;
      if (!pointer || pointer.id !== event.pointerId) { return; }
      var dx = event.clientX - pointer.startX;
      var dy = event.clientY - pointer.startY;
      if (Math.abs(dx) + Math.abs(dy) > 5 && !pointer.moved) {
        pointer.moved = true;
        svg.setPointerCapture(event.pointerId);
      }
      if (!pointer.moved) { return; }
      var rect = svg.getBoundingClientRect();
      state.mapView.x = pointer.originX + dx * 720 / rect.width;
      state.mapView.y = pointer.originY + dy * 570 / rect.height;
      svg.classList.add("is-panning");
      applyMapTransform();
    });
    function finishPan(event) {
      var pointer = state.mapPointer;
      if (!pointer || pointer.id !== event.pointerId) { return; }
      state.suppressMapClick = pointer.moved;
      state.mapPointer = null;
      svg.classList.remove("is-panning");
      if (svg.hasPointerCapture(event.pointerId)) { svg.releasePointerCapture(event.pointerId); }
    }
    svg.addEventListener("pointerup", finishPan);
    svg.addEventListener("pointercancel", finishPan);
    svg.addEventListener("click", function (event) {
      if (!state.suppressMapClick) { return; }
      event.preventDefault();
      event.stopPropagation();
      state.suppressMapClick = false;
    }, true);
  }
  function renderMap(data) {
    var renderGeneration = ++state.mapGeneration;
    var selectedState = $("ala-state").value;
    var selectedDistrict = $("ala-district").value;
    $("ala-map").dataset.renderRequestedState = selectedState || "";
    Promise.all([
      state.states ? Promise.resolve(state.states) : fetchJson("/ords/r/sas/310/files/static/latest/india-states.json"),
      state.districts ? Promise.resolve(state.districts) : fetchJson("/ords/r/sas/310/files/static/latest/india-districts.json"),
      boundaryData(selectedDistrict)
    ]).then(function (payload) {
      if (renderGeneration !== state.mapGeneration) { return; }
      state.states = payload[0];
      state.districts = payload[1];
      var stateItem = (data.states || []).find(function (row) { return String(row.code) === String(selectedState); });
      var selectedStateOption = $("ala-state").selectedOptions &&
        $("ala-state").selectedOptions[0];
      var selectedStateName = (stateItem && stateItem.name) ||
        state.mapSelectedStateName ||
        (selectedStateOption ?
          selectedStateOption.textContent.replace(/\s*\([\d,]+\)\s*$/, "") : "");
      var selectedDistrictItem = (data.districts || []).find(function (row) {
        return String(row.code) === String(selectedDistrict);
      });
      var level, features, rows, virtualSubdistricts = false;
      if (selectedDistrict && payload[2] && (payload[2].features || []).length) {
        level = "subdistrict";
        features = payload[2].features;
        rows = data.subdistricts || [];
      } else if (selectedDistrict) {
        level = "district-summary";
        virtualSubdistricts = true;
        features = (state.districts.features || []).filter(function (feature) {
          var attrs = feature.attributes || {};
          return String(selectedDistrict) === String(attrs.lgd_districtcode || "") ||
            (selectedDistrictItem &&
              normalizeName(selectedDistrictItem.name) === normalizeName(attrs.name));
        });
        rows = data.districts || [];
      } else if (selectedState) {
        level = "district";
        features = (state.districts.features || []).filter(function (feature) {
          var attrs = feature.attributes || {};
          return (state.mapSelectedStateCode &&
              String(attrs.lgd_statecode || "") ===
                String(state.mapSelectedStateCode)) ||
            String(attrs.lgd_statecode || "") === String(selectedState) ||
            (selectedStateName &&
              normalizeName(attrs.state) === normalizeName(selectedStateName));
        });
        rows = data.districts || [];
      } else {
        level = "state";
        features = state.states.features || [];
        rows = data.states || [];
      }
      var svg = $("ala-map");
      state.mapLayoutWidth = Math.round(svg.getBoundingClientRect().width);
      svg.dataset.selectedStateCode = String(state.mapSelectedStateCode || "");
      svg.dataset.selectedStateName = selectedStateName || "";
      svg.dataset.candidateFeatureCount = String(features.length);
      if (!features.length) {
        level = "state"; features = state.states.features || []; rows = data.states || [];
      }
      var project = projection(features);
      svg.innerHTML = "";
      if (!project) { throw new Error("No usable polygon geometry was returned."); }
      var viewport = document.createElementNS("http://www.w3.org/2000/svg", "g");
      viewport.setAttribute("id", "ala-map-viewport");
      svg.appendChild(viewport);
      var metric = $("ala-metric").value;
      features.forEach(function (feature) {
        var path = document.createElementNS("http://www.w3.org/2000/svg", "path");
        var attrs = feature.attributes || {}, match = areaMatch(feature, rows, level);
        var areaRisk = dominantAreaRisk(match);
        var intensity = areaRiskIntensity(match);
        path.setAttribute("d", pathFor(feature, project));
        path.setAttribute("class", "ala-boundary" +
          (match && (
            (level === "district" && String(match.code) === String(selectedDistrict)) ||
            (level === "subdistrict" && String(match.code) === String($("ala-subdistrict").value))
          ) ? " is-selected" : ""));
        path.dataset.riskBand = riskKey(areaRisk);
        path.dataset.mapDrillLevel = level;
        path.dataset.riskIntensity = intensity == null ? "" : intensity.toFixed(1);
        path.style.fill = gradientRiskColour(match);
        path.setAttribute("aria-label", (attrs.name || (match && match.name) || "Area") +
          (match ? ", risk intensity " +
            (intensity == null ? "unclassified" : intensity.toFixed(1)) : ", outside current scope"));
        path.addEventListener("mouseenter", function (event) {
          showMapTooltip(event, attrs.name, Object.assign({
            dominantRiskCategory: areaRisk
          }, match || {}));
        });
        path.addEventListener("mousemove", function (event) {
          showMapTooltip(event, attrs.name, Object.assign({
            dominantRiskCategory: areaRisk
          }, match || {}));
        });
        path.addEventListener("mouseleave", function () { $("ala-map-tooltip").hidden = true; });
        if (match && level !== "district-summary") {
          path.setAttribute("tabindex", "0");
          path.setAttribute("role", "button");
          path.addEventListener("click", function (event) {
            event.stopPropagation();
            if (isAnalyticsLocked("ala-map-card")) { return; }
            $("ala-map-tooltip").hidden = true;
            resetMapView();
            if (level === "state") {
              $("ala-state").value = match.code;
              state.mapSelectedStateName = attrs.name || match.name || "";
              state.mapSelectedStateCode = attrs.lgd_statecode || "";
              $("ala-map").dataset.clickedStateCode =
                String(state.mapSelectedStateCode || "");
              $("ala-map").dataset.clickedStateName =
                state.mapSelectedStateName;
              $("ala-district").value = "";
              $("ala-subdistrict").value = "";
            } else if (level === "district") {
              $("ala-district").value = match.code;
              $("ala-subdistrict").value = "";
            } else {
              $("ala-subdistrict").value = match.code;
            }
            synchronizeMapWithRbacAnalytics().catch(function () {});
          });
          path.addEventListener("keydown", function (event) {
            if (event.key === "Enter" || event.key === " ") {
              event.preventDefault();
              path.dispatchEvent(new MouseEvent("click", {bubbles: true}));
            }
          });
        } else {
          path.classList.add("is-out-of-scope");
        }
        viewport.appendChild(path);
      });
      if (virtualSubdistricts && features.length) {
        var districtCentroid = featureCentroid(features[0], project);
        (data.subdistricts || []).slice(0, 30).forEach(function (row, index) {
          var count = Math.max(1, Math.min(30, (data.subdistricts || []).length));
          var angle = count === 1 ? 0 : -Math.PI / 2 + 2 * Math.PI * index / count;
          var ring = count === 1 ? 0 : 24 + 7 * Math.floor(index / 12);
          var x = districtCentroid[0] + Math.cos(angle) * ring;
          var y = districtCentroid[1] + Math.sin(angle) * ring;
          var node = document.createElementNS("http://www.w3.org/2000/svg", "g");
          node.setAttribute("class", "ala-subdistrict-drill-node" +
            (String(row.code) === String($("ala-subdistrict").value) ? " is-selected" : ""));
          node.setAttribute("role", "button");
          node.setAttribute("tabindex", "0");
          node.dataset.mapDrillLevel = "subdistrict";
          node.dataset.subdistrictCode = row.code;
          node.setAttribute("aria-label", "Drill into subdistrict " + row.name);
          node.innerHTML = '<circle cx="' + x.toFixed(1) + '" cy="' + y.toFixed(1) +
            '" r="10" style="fill:' + gradientRiskColour(row) + '"></circle>' +
            '<text x="' + x.toFixed(1) + '" y="' + (y + 2.8).toFixed(1) +
            '" text-anchor="middle">' + String(index + 1) + '</text><title>' +
            escapeHtml(row.name) + " — " + fmt.format(row.count || 0) +
            " agents — click to drill</title>";
          node.addEventListener("mouseenter", function (event) {
            showMapTooltip(event, row.name, Object.assign({
              dominantRiskCategory: dominantAreaRisk(row)
            }, row));
          });
          node.addEventListener("mousemove", function (event) {
            showMapTooltip(event, row.name, Object.assign({
              dominantRiskCategory: dominantAreaRisk(row)
            }, row));
          });
          node.addEventListener("mouseleave", function () {
            $("ala-map-tooltip").hidden = true;
          });
          node.addEventListener("click", function (event) {
            event.stopPropagation();
            if (isAnalyticsLocked("ala-map-card")) { return; }
            $("ala-subdistrict").value = row.code;
            resetMapView();
            synchronizeMapWithRbacAnalytics().catch(function () {});
          });
          node.addEventListener("keydown", function (event) {
            if (event.key === "Enter" || event.key === " ") {
              event.preventDefault();
              node.dispatchEvent(new MouseEvent("click", {bubbles: true}));
            }
          });
          viewport.appendChild(node);
        });
      }
      (data.transactionPoints || []).slice(0, 500).forEach(function (row) {
        var point = project.latlon(row.latitude, row.longitude);
        if (point[0] < 0 || point[0] > 720 || point[1] < 0 || point[1] > 570) { return; }
        var circle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
        circle.setAttribute("cx", point[0]); circle.setAttribute("cy", point[1]);
        circle.setAttribute("r", Math.min(8, 2 + Math.sqrt(row.transactions || 1)));
        circle.setAttribute("class", "ala-transaction-dot");
        viewport.appendChild(circle);
      });
      var pointOccupancy = {};
      var markerLimit = selectedDistrict ? 300 : (selectedState ? 160 : 80);
      var renderedMarkerCount = 0;
      var availableAgents = data.agents || [];
      var markerRows = availableAgents.length <= markerLimit ?
        availableAgents : Array.from({length: markerLimit}, function (_, index) {
          return availableAgents[
            Math.min(
              availableAgents.length - 1,
              Math.floor(index * availableAgents.length / markerLimit)
            )
          ];
        });
      markerRows.forEach(function (row) {
        var hasCoordinates = isFinite(Number(row.latitude)) && isFinite(Number(row.longitude)) &&
          Number(row.latitude) >= 6 && Number(row.latitude) <= 38 &&
          Number(row.longitude) >= 68 && Number(row.longitude) <= 98;
        var point = hasCoordinates ? project.latlon(row.latitude, row.longitude) : null;
        if (!point || point[0] < 0 || point[0] > 720 || point[1] < 0 || point[1] > 570) {
          var fallbackFeature = featureForAgent(features, row, level);
          point = fallbackFeature ? featureCentroid(fallbackFeature, project) : null;
          if (!point) { return; }
          hasCoordinates = false;
        }
        var occupancyKey = (hasCoordinates ? "exact:" : "area:") +
          point[0].toFixed(hasCoordinates ? 1 : 0) + ":" +
          point[1].toFixed(hasCoordinates ? 1 : 0);
        var occupancy = pointOccupancy[occupancyKey] || 0;
        pointOccupancy[occupancyKey] = occupancy + 1;
        if (occupancy || !hasCoordinates) {
          var angle = occupancy * 2.3999632297;
          var spread = Math.min(18, 2.5 + 2.2 * Math.sqrt(occupancy));
          point = [
            point[0] + Math.cos(angle) * spread,
            point[1] + Math.sin(angle) * spread
          ];
        }
        var circle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
        circle.setAttribute("cx", point[0]); circle.setAttribute("cy", point[1]);
        circle.setAttribute("r", Math.min(2.2, 1.7 +
          Math.sqrt(Math.max(0, metricValue(row, metric))) / 45));
        circle.setAttribute("class", "ala-agent-dot is-" + riskKey(row.riskCategory));
        circle.setAttribute("tabindex", "0");
        circle.setAttribute("role", "button");
        circle.setAttribute("aria-label", "Agent " + (row.name || row.id) +
          ", " + (row.riskCategory || "Unclassified") + " risk");
        circle.dataset.agentId = row.id;
        circle.dataset.drawerUrl = row.drawerUrl || "";
        circle.dataset.coordinateSource = hasCoordinates ? "exact" : "area-centroid";
        circle.style.fill = row.bucketColour || riskColour(row.riskCategory);
        circle.style.stroke = "#fff";
        var nativeTitle = document.createElementNS("http://www.w3.org/2000/svg", "title");
        nativeTitle.textContent = (row.name || "Unnamed agent") + " — " + row.id +
          " — " + (row.riskCategory || "Unclassified") + " risk";
        circle.appendChild(nativeTitle);
        circle.addEventListener("mouseenter", function (event) {
          showMapTooltip(event, (row.name || "Unnamed agent") + " — " + row.id +
            (row.bucketRiskBand ? " · " + row.bucketRiskBand +
              " (" + Number(row.bucketNormalizedScore || 0).toFixed(2) + ")" : ""), {
            count: 1, transactions: row.transactions, amount: row.amount,
            successCount: row.successCount, failureCount: row.failureCount,
            reversalCount: row.reversalCount, financialCount: row.financialCount,
            uniqueCustomers: row.uniqueCustomers, uniqueDevices: row.uniqueDevices,
            riskCategory: row.riskCategory, riskScore: row.riskScore,
            geoAnomalyCount: row.geoAnomaly === "Y" ? 1 : 0
          }, {agent: true});
        });
        circle.addEventListener("mousemove", function (event) {
          showMapTooltip(event, (row.name || "Unnamed agent") + " — " + row.id, {
            count: 1, transactions: row.transactions, amount: row.amount,
            successCount: row.successCount, failureCount: row.failureCount,
            reversalCount: row.reversalCount, riskCategory: row.riskCategory,
            riskScore: row.riskScore, geoAnomalyCount: row.geoAnomaly === "Y" ? 1 : 0
          }, {agent: true});
        });
        circle.addEventListener("mouseleave", function () { $("ala-map-tooltip").hidden = true; });
        circle.addEventListener("click", function (event) {
          event.stopPropagation();
          if (!isAnalyticsLocked("ala-map-card")) {
            openAgentDrawer(circle.dataset.agentId, circle.dataset.drawerUrl, circle);
          }
        });
        circle.addEventListener("keydown", function (event) {
          if (event.key === "Enter" || event.key === " ") {
            event.preventDefault();
            circle.dispatchEvent(new MouseEvent("click", {bubbles: true}));
          }
        });
        viewport.appendChild(circle);
        renderedMarkerCount += 1;
      });
      if ($("ala-map-marker-summary")) {
        $("ala-map-marker-summary").textContent = fmt.format(renderedMarkerCount) +
          " of " + fmt.format((data.kpis || {}).agents || 0) + " agents shown";
      }
      applyMapTransform();
      var districtItem = (data.districts || []).find(function (row) {
        return String(row.code) === String(selectedDistrict);
      });
      var subdistrictItem = (data.subdistricts || []).find(function (row) {
        return String(row.code) === String($("ala-subdistrict").value);
      });
      $("ala-map-level").textContent = [
        stateItem && stateItem.name,
        districtItem && districtItem.name,
        subdistrictItem && subdistrictItem.name
      ].filter(Boolean).join(" › ") || "India";
      $("ala-map-back").hidden = !selectedState;
    }).catch(function (error) {
      showError("Map assets could not be loaded: " + error.message);
    });
  }

  function fieldMeta(fieldKey) {
    return state.fieldCatalog.find(function (item) { return item.key === fieldKey; });
  }
  function operatorsFor(fieldKey) {
    var item = fieldMeta(fieldKey);
    if (item && item.operators && item.operators.length) { return item.operators; }
    var legacyCode = String(fieldKey || "").replace(/^.*:/, "");
    return fieldTypes[legacyCode] === "NUMBER" ?
      ["EQ", "NE", "GT", "GE", "LT", "LE", "BETWEEN"] : ["EQ", "NE", "CONTAINS"];
  }
  function pickerCatalog() {
    if (state.fieldCatalog.length) { return state.fieldCatalog; }
    return Object.keys(fieldLabels).map(function (key) {
      return {
        key: key, code: key, label: fieldLabels[key],
        sourceFamily: "LEGACY", sourceName: "Governed Fields",
        jsonPath: "", dataType: fieldTypes[key] || "STRING",
        operators: operatorsFor(key), availability: {}
      };
    });
  }

  function normalizedFieldPath(item) {
    var path = String(item && item.jsonPath || "")
      .replace(/^\$\./, "").replace(/^\$/, "")
      .replace(/"([^"]+)"/g, "$1");
    return path || String(item && (item.label || item.code) || "Field");
  }

  function fieldSourceLabel(item) {
    var family = String(item && item.sourceFamily || "");
    if (family.indexOf("PROFILE_") === 0) {
      var period = family === "PROFILE_DAILY" ? "Daily" :
        (family === "PROFILE_MONTHLY" ? "Monthly" : "360 Days");
      return "Agent Profile " + period +
        (item.profileVersion != null ? " · Active v" + item.profileVersion : "");
    }
    if (family === "AGENT_MASTER") { return "Agent Master"; }
    if (family === "TRANSACTION") { return "Transactions"; }
    return String(item && item.sourceName || "Governed Fields")
      .replace(/^SBOS_/, "").replace(/_/g, " ");
  }

  function fieldAvailability(item) {
    var badges = [];
    if (item && item.availability && item.availability.daily) { badges.push("D"); }
    if (item && item.availability && item.availability.monthly) { badges.push("M"); }
    if (item && item.availability && item.availability.days360) { badges.push("360"); }
    return badges.join("/");
  }

  function fieldPickerMarkup(selected) {
    return '<div class="ala-field-picker" data-field-picker>' +
      '<input type="hidden" data-role="field" value="' + escapeHtml(selected || "") + '">' +
      '<button type="button" class="ala-field-picker-trigger" data-role="field-trigger" ' +
      'aria-haspopup="tree" aria-expanded="false">' +
      '<span data-role="field-label">Choose a field</span>' +
      '<small data-role="field-path">Search active JSON fields and metrics</small>' +
      '<span class="fa fa-angle-down" aria-hidden="true"></span></button>' +
      '<section class="ala-field-picker-popover" data-role="field-popover" hidden>' +
      '<label class="ala-field-picker-search"><span class="fa fa-search" aria-hidden="true"></span>' +
      '<input type="search" data-role="field-search" placeholder="Search field, metric or JSON path" ' +
      'autocomplete="off" aria-label="Search condition fields"></label>' +
      '<div class="ala-field-picker-status" data-role="field-status"></div>' +
      '<div class="ala-field-picker-results" data-role="field-results" role="tree"></div>' +
      '</section></div>';
  }

  function updateFieldPickerDisplay(picker) {
    var valueInput = picker.querySelector("[data-role=field]");
    var item = fieldMeta(valueInput.value) || pickerCatalog().find(function (row) {
      return row.key === valueInput.value;
    });
    var label = picker.querySelector("[data-role=field-label]");
    var path = picker.querySelector("[data-role=field-path]");
    if (!item) {
      label.textContent = "Choose a field";
      path.textContent = "Search active JSON fields and metrics";
      return;
    }
    label.textContent = item.label || item.code;
    path.textContent = fieldSourceLabel(item) + " › " +
      normalizedFieldPath(item).split(".").join(" › ");
  }

  function closeFieldPickers(exceptPicker) {
    document.querySelectorAll(".ala-field-picker.is-open").forEach(function (picker) {
      if (picker === exceptPicker) { return; }
      var popover = picker._alaFieldPopover;
      picker.classList.remove("is-open");
      if (popover) { popover.hidden = true; }
      picker.querySelector("[data-role=field-trigger]").setAttribute("aria-expanded", "false");
    });
  }

  function treeBranch(name, path) {
    return {name: name, path: path, childOrder: [], children: {}, items: []};
  }

  function appendFieldTreeItem(root, item) {
    var segments = normalizedFieldPath(item).split(".").filter(Boolean);
    var branch = root;
    segments.forEach(function (segment, index) {
      if (!branch.children[segment]) {
        var nextPath = branch.path ? branch.path + "." + segment : segment;
        branch.children[segment] = treeBranch(segment, nextPath);
        branch.childOrder.push(segment);
      }
      branch = branch.children[segment];
      if (index === segments.length - 1) { branch.items.push(item); }
    });
  }

  function renderFieldTreeBranch(holder, branch, depth, picker) {
    branch.childOrder.forEach(function (name) {
      var child = branch.children[name];
      var hasChildren = child.childOrder.length > 0;
      if (hasChildren) {
        var objectRow = document.createElement("div");
        objectRow.className = "ala-field-tree-object";
        objectRow.style.setProperty("--ala-field-depth", depth);
        var objectIcon = document.createElement("span");
        objectIcon.className = "fa fa-folder-open-o";
        objectIcon.setAttribute("aria-hidden", "true");
        var objectName = document.createElement("strong");
        objectName.textContent = child.name;
        var objectPath = document.createElement("small");
        objectPath.textContent = "$." + child.path;
        objectRow.append(objectIcon, objectName, objectPath);
        holder.appendChild(objectRow);
      }
      child.items.forEach(function (item) {
        var button = document.createElement("button");
        button.type = "button";
        button.className = "ala-field-tree-leaf";
        button.style.setProperty("--ala-field-depth", depth + (hasChildren ? 1 : 0));
        button.setAttribute("role", "treeitem");
        button.dataset.fieldKey = item.key;
        var copy = document.createElement("span");
        var title = document.createElement("strong");
        title.textContent = item.label || child.name;
        var jsonPath = document.createElement("small");
        jsonPath.textContent = item.jsonPath ? "$." + normalizedFieldPath(item) :
          String(item.code || "");
        copy.append(title, jsonPath);
        var badges = document.createElement("span");
        badges.className = "ala-field-tree-badges";
        var type = document.createElement("em");
        type.textContent = String(item.dataType || "STRING").toUpperCase();
        badges.appendChild(type);
        var availability = fieldAvailability(item);
        if (availability) {
          var period = document.createElement("em");
          period.textContent = availability;
          badges.appendChild(period);
        }
        button.append(copy, badges);
        button.addEventListener("click", function () {
          var valueInput = picker.querySelector("[data-role=field]");
          valueInput.value = item.key;
          updateFieldPickerDisplay(picker);
          closeFieldPickers();
          valueInput.dispatchEvent(new Event("change", {bubbles: true}));
        });
        holder.appendChild(button);
      });
      renderFieldTreeBranch(holder, child, depth + 1, picker);
    });
  }

  function renderFieldPickerResults(picker, searchText) {
    var query = String(searchText || "").trim().toLowerCase();
    var items = pickerCatalog().filter(function (item) {
      if (!query) { return true; }
      return [
        item.label, item.code, item.jsonPath, item.sourceName,
        item.sourceFamily, fieldSourceLabel(item), item.dataType
      ].join(" ").toLowerCase().indexOf(query) >= 0;
    });
    var popover = picker._alaFieldPopover;
    var results = popover.querySelector("[data-role=field-results]");
    var status = popover.querySelector("[data-role=field-status]");
    results.replaceChildren();
    status.textContent = items.length + " selectable field" + (items.length === 1 ? "" : "s") +
      (query ? " matching “" + searchText.trim() + "”" : " from the active profile version");
    var groups = {};
    var groupOrder = [];
    items.forEach(function (item) {
      var groupName = fieldSourceLabel(item);
      if (!groups[groupName]) {
        groups[groupName] = treeBranch("", "");
        groupOrder.push(groupName);
      }
      appendFieldTreeItem(groups[groupName], item);
    });
    groupOrder.forEach(function (groupName) {
      var group = document.createElement("section");
      group.className = "ala-field-tree-group";
      var heading = document.createElement("header");
      var headingText = document.createElement("strong");
      headingText.textContent = groupName;
      var active = document.createElement("span");
      active.textContent = groupName.indexOf("Active v") >= 0 ? "ACTIVE VERSION" : "SOURCE";
      heading.append(headingText, active);
      group.appendChild(heading);
      renderFieldTreeBranch(group, groups[groupName], 0, picker);
      results.appendChild(group);
    });
    if (!items.length) {
      var empty = document.createElement("div");
      empty.className = "ala-field-picker-empty";
      empty.textContent = "No active field or JSON path matches this search.";
      results.appendChild(empty);
    }
  }

  function positionFieldPickerPopover(picker) {
    var trigger = picker.querySelector("[data-role=field-trigger]");
    var popover = picker._alaFieldPopover;
    var results = popover.querySelector("[data-role=field-results]");
    var rect = trigger.getBoundingClientRect();
    var portalHost = picker._alaFieldPortalHost || document.body;
    var isBodyPortal = portalHost === document.body;
    var hostRect = isBodyPortal ?
      {left: 0, top: 0, right: global.innerWidth} : portalHost.getBoundingClientRect();
    var viewportLeft = Math.max(12, hostRect.left + 8);
    var viewportRight = Math.min(global.innerWidth - 12, hostRect.right - 8);
    var width = Math.min(580, Math.max(280, viewportRight - viewportLeft));
    var targetLeft = Math.max(viewportLeft, Math.min(rect.left, viewportRight - width));
    var below = global.innerHeight - rect.bottom - 12;
    var above = rect.top - 12;
    var openBelow = below >= 300 || below >= above;
    var available = Math.max(220, Math.min(560, openBelow ? below : above));
    var targetTop = openBelow ? rect.bottom + 4 : rect.top - available - 4;
    var left = isBodyPortal ? targetLeft :
      targetLeft - hostRect.left + portalHost.scrollLeft - portalHost.clientLeft;
    var top = isBodyPortal ? targetTop :
      targetTop - hostRect.top + portalHost.scrollTop - portalHost.clientTop;
    popover.style.position = isBodyPortal ? "fixed" : "absolute";
    popover.style.width = width + "px";
    popover.style.left = left + "px";
    popover.style.top = top + "px";
    popover.style.bottom = "auto";
    popover.style.maxHeight = available + "px";
    results.style.maxHeight = Math.max(140, available - 92) + "px";
  }

  function initFieldPicker(picker) {
    var trigger = picker.querySelector("[data-role=field-trigger]");
    var popover = picker.querySelector("[data-role=field-popover]");
    var search = picker.querySelector("[data-role=field-search]");
    var portalHost = picker.closest(".ui-dialog") || document.body;
    picker._alaFieldPopover = popover;
    picker._alaFieldPortalHost = portalHost;
    popover._alaFieldPicker = picker;
    portalHost.appendChild(popover);
    updateFieldPickerDisplay(picker);
    trigger.addEventListener("click", function (event) {
      event.stopPropagation();
      var opening = !picker.classList.contains("is-open");
      if (opening) {
        portalHost = picker.closest(".ui-dialog") || document.body;
        picker._alaFieldPortalHost = portalHost;
        if (popover.parentElement !== portalHost) {
          portalHost.appendChild(popover);
        }
      }
      closeFieldPickers(opening ? picker : null);
      picker.classList.toggle("is-open", opening);
      popover.hidden = !opening;
      trigger.setAttribute("aria-expanded", opening ? "true" : "false");
      if (opening) {
        search.value = "";
        renderFieldPickerResults(picker, "");
        positionFieldPickerPopover(picker);
        global.setTimeout(function () { search.focus(); }, 0);
      }
    });
    popover.addEventListener("click", function (event) { event.stopPropagation(); });
    search.addEventListener("input", function () {
      renderFieldPickerResults(picker, search.value);
    });
    search.addEventListener("keydown", function (event) {
      if (event.key === "ArrowDown") {
        var first = popover.querySelector(".ala-field-tree-leaf");
        if (first) { event.preventDefault(); first.focus(); }
      } else if (event.key === "Escape") {
        event.preventDefault();
        closeFieldPickers();
        trigger.focus();
      }
    });
  }

  function addCondition(group, node) {
    var isNew = !node || (!node.fieldKey && !node.field);
    node = node || {};
    var selectedField = node.fieldKey || node.field || "";
    if (state.fieldCatalog.length && selectedField.indexOf(":") < 0) {
      var candidates = state.fieldCatalog.filter(function (item) { return item.code === selectedField; });
      selectedField = candidates.length === 1 ? candidates[0].key : selectedField;
    }
    if (!selectedField && pickerCatalog().length) {
      selectedField = pickerCatalog()[0].key;
    }
    var row = document.createElement("div");
    row.className = "ala-condition";
    row.dataset.conditionId = node.conditionId || newConditionId();
    row.innerHTML =
      '<span class="ala-condition-sequence" aria-label="Condition"></span>' +
      fieldPickerMarkup(selectedField) +
      '<select data-role="op" aria-label="Operator"></select>' +
      '<input data-role="value" aria-label="Value" placeholder="Value" value="' + escapeHtml(node.value || "") + '">' +
      '<input data-role="value2" aria-label="Second value" placeholder="Second value" value="' +
      escapeHtml(node.value2 || "") + '" hidden><button type="button" class="ala-icon-button ala-remove" title="Remove condition"><span class="fa fa-trash"></span></button>';
    var picker = row.querySelector("[data-field-picker]");
    var fieldSelect = row.querySelector("[data-role=field]");
    var opSelect = row.querySelector("[data-role=op]");
    var valueInput = row.querySelector("[data-role=value]");
    var value2 = row.querySelector("[data-role=value2]");
    initFieldPicker(picker);
    function refreshOperators() {
      var selectedOperator = node.operator || node.op;
      opSelect.innerHTML = operatorsFor(fieldSelect.value).map(function (operator) {
        return '<option value="' + operator + '"' + (selectedOperator === operator ? " selected" : "") + ">" +
          escapeHtml(operatorLabels[operator] || operator) + "</option>";
      }).join("");
      valueInput.hidden = opSelect.value === "IS_NULL" || opSelect.value === "IS_NOT_NULL";
      value2.hidden = opSelect.value !== "BETWEEN";
      updateConditionSummary();
    }
    fieldSelect.addEventListener("change", function () {
      node.op = null;
      node.operator = null;
      refreshOperators();
    });
    opSelect.addEventListener("change", function () {
      valueInput.hidden = opSelect.value === "IS_NULL" || opSelect.value === "IS_NOT_NULL";
      value2.hidden = opSelect.value !== "BETWEEN";
      updateConditionSummary();
    });
    [valueInput, value2].forEach(function (input) {
      input.addEventListener("input", updateConditionSummary);
    });
    row.querySelector(".ala-remove").addEventListener("click", function () {
      if (picker._alaFieldPopover) { picker._alaFieldPopover.remove(); }
      row.remove(); updateConditionSummary();
    });
    refreshOperators();
    group.querySelector(":scope > .ala-rule-children").appendChild(row);
    if (isNew) {
      row.classList.add("is-new");
      global.setTimeout(function () {
        picker.querySelector("[data-role=field-trigger]").focus();
        row.scrollIntoView({behavior: "smooth", block: "nearest"});
        row.classList.remove("is-new");
      }, 20);
    }
    return row;
  }
  function addGroup(parent, node, isRoot) {
    node = node || {operator: "AND", children: []};
    var group = document.createElement("section");
    group.className = "ala-rule-group" + (isRoot ? " is-root" : "");
    group.innerHTML =
      '<div class="ala-rule-group-head"><div class="ala-rule-match-choice">' +
      '<span class="ala-rule-join-label">' + (isRoot ? "Agent matches when" : "This group matches when") +
      '</span><select data-role="group-op" aria-label="How conditions are combined"><option value="AND"' +
      (node.operator !== "OR" ? " selected" : "") + '>All conditions (AND)</option><option value="OR"' +
      (node.operator === "OR" ? " selected" : "") + '>Any condition (OR)</option></select>' +
      '<small data-role="group-summary"></small></div>' +
      '<div><button type="button" data-role="add-condition" class="ala-icon-button" title="Add condition"><span class="fa fa-plus"></span> Condition</button>' +
      '<button type="button" data-role="add-group" class="ala-icon-button" title="Add nested group"><span class="fa fa-sitemap"></span> Group</button>' +
      (isRoot ? "" : '<button type="button" data-role="remove-group" class="ala-icon-button ala-remove" title="Remove group"><span class="fa fa-trash"></span></button>') +
      '</div></div><div class="ala-rule-children"></div>';
    group.querySelector("[data-role=group-op]").addEventListener("change", updateConditionSummary);
    group.querySelector("[data-role=add-condition]").addEventListener("click", function () {
      addCondition(group); updateConditionSummary();
    });
    group.querySelector("[data-role=add-group]").addEventListener("click", function () {
      var depth = 1;
      var ancestor = group.parentElement;
      while (ancestor) {
        if (ancestor.classList && ancestor.classList.contains("ala-rule-group")) { depth += 1; }
        ancestor = ancestor.parentElement;
      }
      if (depth >= 5) {
        showError("Nested conditions are limited to five levels for predictable performance.");
        return;
      }
      addGroup(group.querySelector(":scope > .ala-rule-children"), {operator: "AND", children: []}, false);
      updateConditionSummary();
    });
    if (!isRoot) {
      group.querySelector("[data-role=remove-group]").addEventListener("click", function () {
        group.remove(); updateConditionSummary();
      });
    }
    (node.children || []).forEach(function (child) {
      if (child && child.children) {
        addGroup(group.querySelector(":scope > .ala-rule-children"), child, false);
      } else if (child) {
        addCondition(group, child);
      }
    });
    parent.appendChild(group);
    return group;
  }
  function renderConditionTree(node) {
    document.querySelectorAll(".ala-field-picker-popover").forEach(function (popover) {
      popover.remove();
    });
    $("ala-condition-root").innerHTML = "";
    addGroup($("ala-condition-root"), node || {operator: "AND", children: []}, true);
    updateConditionSummary();
  }

  function switchTab(name) {
    $("ala-error").hidden = true;
    var mainName = name === "buckets" ? "conditions" : name;
    ["analytics", "conditions", "monitoring", "findings"].forEach(function (tab) {
      var active = tab === mainName;
      $("ala-tab-" + tab).classList.toggle("is-active", active);
      $("ala-tab-" + tab).setAttribute("aria-selected", active ? "true" : "false");
    });
    $("ala-panel-analytics").hidden = mainName !== "analytics";
    $("ala-panel-conditions").hidden = name !== "conditions";
    $("ala-panel-buckets").hidden = name !== "buckets";
    $("ala-panel-monitoring").hidden = mainName !== "monitoring";
    $("ala-panel-findings").hidden = mainName !== "findings";
    document.querySelectorAll("[data-workflow-view]").forEach(function (button) {
      button.classList.toggle("is-active", button.dataset.workflowView === name);
    });
    if (name === "monitoring") { refreshMonitoring(); }
    if (name === "findings") { refreshFindingsRuns(); }
  }
  function applyContext(context) {
    var mapping = {
      mode: "ala-mode", asOfDate: "ala-date", metric: "ala-metric",
      stateCode: "ala-state", districtCode: "ala-district", subdistrictCode: "ala-subdistrict",
      villageCode: "ala-village", search: "ala-search", agentStatus: "ala-status",
      riskCategory: "ala-risk", platform: "ala-platform",
      applicationVersion: "ala-application-version",
      serviceFamily: "ala-service-family", serviceName: "ala-service-name",
      transactionType: "ala-transaction-type", isOnus: "ala-is-onus",
      isOriginal: "ala-is-original", responseCode: "ala-response-code",
      isFinancial: "ala-is-financial"
    };
    Object.keys(mapping).forEach(function (key) {
      $(mapping[key]).value = context[key] == null ? "" : context[key];
    });
    renderConditionTree(context.conditions);
  }
  function newFilter() {
    state.selectedFilterId = null;
    state.selectedFilterVersion = null;
    state.recommendations = [];
    state.recommendationPreviews = {};
    state.selectedRecommendationConditionId = null;
    $("ala-filter-name").value = "";
    $("ala-filter-description").value = "";
    $("ala-sharing-mode").value = "PRIVATE";
    $("ala-config-priority").value = "100";
    $("ala-config-criticality").value = "MEDIUM";
    $("ala-config-risk").value = "MEDIUM";
    $("ala-config-risk-points").value = "0";
    $("ala-config-output").value = "BOOLEAN";
    setWindowScope({mode: "RUNTIME"});
    $("ala-builder-status").textContent = "New draft";
    $("ala-builder-version").textContent = "Not saved";
    $("ala-retire-filter").hidden = true;
    $("ala-filter-badge").textContent = "Unsaved configuration";
    renderConditionTree({operator: "AND", children: []});
    renderSavedList();
  }
  function renderSavedList() {
    var term = normalizeName($("ala-saved-search").value);
    var rows = state.savedFilters.filter(function (row) {
      return !term || normalizeName(row.name + " " + row.code + " " + row.owner).indexOf(term) >= 0;
    });
    $("ala-saved-list").innerHTML = rows.length ? rows.map(function (row) {
      return '<button type="button" class="ala-saved-item ' +
        (String(row.id) === String(state.selectedFilterId) ? "is-active" : "") +
        '" data-filter-id="' + row.id + '"><span><strong>' + escapeHtml(row.name) +
        '</strong><small>' + escapeHtml(row.code) + " · v" + row.version + " · " +
        escapeHtml(row.owner) + '</small></span><em class="ala-status-badge ala-status-' +
        row.status.toLowerCase() + '">' + escapeHtml(row.status) + "</em></button>";
    }).join("") : '<div class="ala-empty">No Advanced Agent Configurations match.</div>';
    $("ala-saved-list").querySelectorAll("[data-filter-id]").forEach(function (button) {
      button.addEventListener("click", function () { loadSavedFilter(button.dataset.filterId); });
    });
  }
  function refreshSavedFilters() {
    return server("AGENT_ADV_CONFIG_LIST").then(function (data) {
      state.savedFilters = data.configurations || [];
      renderSavedList();
      renderBucketConfigurations();
      renderAnalysisRuleTree();
    }).catch(function (error) { showError("Advanced configurations could not be loaded: " + error.message); });
  }
  function loadSavedFilter(id) {
    return server("AGENT_ADV_CONFIG_LOAD", {x01: id}).then(function (data) {
      if (data.error) { throw new Error(data.error); }
      state.selectedFilterId = data.id;
      state.selectedFilterVersion = data.version;
      $("ala-filter-name").value = data.name || "";
      $("ala-filter-description").value = data.description || "";
      $("ala-sharing-mode").value = data.sharingMode || "PRIVATE";
      $("ala-builder-status").textContent = data.status;
      $("ala-builder-version").textContent = "Version " + data.version;
      $("ala-retire-filter").hidden = false;
      $("ala-filter-badge").textContent = data.name + " · v" + data.version;
      $("ala-config-priority").value = (data.classification && data.classification.priority) || 100;
      $("ala-config-criticality").value = (data.classification && data.classification.criticality) || "MEDIUM";
      $("ala-config-risk").value = (data.classification && data.classification.riskClass) || "MEDIUM";
      $("ala-config-risk-points").value = (data.classification && data.classification.riskPoints) || 0;
      $("ala-config-output").value = data.outputType || "BOOLEAN";
      setWindowScope(data.dateScope || {mode: "RUNTIME"});
      state.recommendations = data.recommendations || [];
      state.recommendationPreviews = {};
      state.selectedRecommendationConditionId = null;
      renderConditionTree(data.rule || {operator: "AND", children: []});
      if ($("ala-recommendation-editor")) { renderRecommendationEditor(); }
      renderSavedList();
    }).catch(function (error) { showError("Advanced configuration could not be loaded: " + error.message); });
  }
  function saveFilter(activate) {
    var name = $("ala-filter-name").value.trim();
    if (!name) {
      showError("Enter an Advanced Agent Configuration name before saving.");
      $("ala-filter-name").focus();
      return Promise.resolve(false);
    }
    if ($("ala-recommendation-editor") &&
        !$("ala-recommendation-editor").querySelector("[data-recommendation-detail]")) {
      renderRecommendationEditor();
    }
    state.recommendations = collectRecommendationRows();
    var conditionIds = leafConditions(collectConditions()).map(function (row) {
      return row.conditionId;
    });
    var invalidRecommendation = state.recommendations.find(function (row) {
      return conditionIds.indexOf(row.conditionId) >= 0 &&
        !recommendationIsComplete(row);
    });
    if (state.recommendations.length !== conditionIds.length || invalidRecommendation) {
      showError("Complete the recommendation, expected-value strategy, module route, workflow action, and SLA for every condition.");
      showInlineConfigurationTab("recommendations");
      return Promise.resolve(false);
    }
    var payload = {
      configId: state.selectedFilterId,
      name: name,
      description: $("ala-filter-description").value,
      sharingMode: $("ala-sharing-mode").value,
      rule: collectConditions(),
      dateScope: collectWindowScope(),
      threshold: {},
      classification: {
        priority: Number($("ala-config-priority").value || 100),
        criticality: $("ala-config-criticality").value,
        riskClass: $("ala-config-risk").value,
        riskPoints: Number($("ala-config-risk-points").value || 0)
      },
      outputType: $("ala-config-output").value,
      recommendations: state.recommendations
    };
    return server("AGENT_ADV_CONFIG_SAVE", {
      x01: JSON.stringify(payload), x02: activate ? "Y" : "N"
    }).then(function (result) {
      state.selectedFilterId = result.id;
      state.selectedFilterVersion = result.version;
      $("ala-builder-status").textContent = result.status;
      $("ala-builder-version").textContent = "Version " + result.version;
      $("ala-retire-filter").hidden = false;
      $("ala-filter-badge").textContent = name + " · v" + result.version;
      notify(result.message);
      return refreshSavedFilters().then(function () {
        if (!state.configEditorFromBucket) {
          state.configEditorBaseline = configurationEditorSnapshot();
          return true;
        }
        var replaced = state.bucketConfigurations.find(function (item) {
          return String(item.configId) === String(result.id);
        }) || {};
        state.bucketConfigurations = state.bucketConfigurations.filter(function (item) {
          return String(item.configId) !== String(result.id);
        });
        var saved = state.savedFilters.find(function (item) {
          return String(item.id) === String(result.id);
        });
        state.bucketConfigurations.push({
          configId: Number(result.id),
          configVersionId: Number(result.versionId),
          code: saved ? saved.code : "",
          name: saved ? saved.name : name,
          version: Number(result.version),
          weight: replaced.weight == null ? 1 : replaced.weight,
          mandatory: !!replaced.mandatory,
          enabled: true,
          priority: saved ? saved.priority : Number($("ala-config-priority").value || 100),
          criticality: saved ? saved.criticality : $("ala-config-criticality").value,
          riskClass: saved ? saved.riskClass : $("ala-config-risk").value,
          riskPoints: saved ? saved.riskPoints : Number($("ala-config-risk-points").value || 0),
          outputType: saved ? saved.outputType : $("ala-config-output").value
        });
        state.configEditorReplaceId = Number(result.id);
        state.inlineConfigEditorVersionId = Number(result.versionId);
        delete state.configSummaryCache[String(result.versionId)];
        renderBucketConfigurations();
        state.configEditorBaseline = configurationEditorSnapshot();
        forceCloseConfigurationEditor();
        switchTab("buckets");
        switchBucketEditorTab("configurations");
        notify("Configuration saved and attached to this Subbucket. Save the Subbucket to version the complete setup.");
        return true;
      });
    }).catch(function (error) {
      showError("Advanced configuration save failed: " + error.message);
      return false;
    });
  }
  function retireFilter() {
    if (!state.selectedFilterId || !global.confirm("Retire this Advanced Agent Configuration? Existing bucket versions and run history remain auditable.")) { return; }
    server("AGENT_ADV_CONFIG_RETIRE", {x01: state.selectedFilterId}).then(function (result) {
      notify(result.message);
      forceCloseConfigurationEditor();
      newFilter();
      return refreshSavedFilters();
    }).catch(function (error) { showError("Advanced configuration could not be retired: " + error.message); });
  }

  function validateConfiguration() {
    var button = $("ala-test-filter");
    $("ala-test-result").hidden = true;
    button.disabled = true;
    button.innerHTML = '<span class="fa fa-spinner fa-spin"></span> Validating &amp; executing';
    server("AGENT_ADV_CONFIG_VALIDATE", {x01: JSON.stringify(collectConditions())}).then(function () {
      return load(
        true,
        {kind: "CONFIG"},
        null,
        {authorizedDefinitionScope: true}
      );
    }).then(function (data) {
      if (!data) { return null; }
      if ($("ala-inline-config-editor")) {
        $("ala-inline-config-results-empty").hidden = true;
        showInlineConfigurationTab("results");
      }
      return data;
    }).catch(function (error) {
      showError("Configuration validation failed: " + error.message);
    }).finally(function () {
      button.disabled = false;
      button.innerHTML = '<span class="fa fa-check-circle"></span> Validate &amp; Test';
    });
  }
  function applyConfigurationToAnalytics() {
    var button = $("ala-apply-conditions");
    $("ala-error").hidden = true;
    button.disabled = true;
    button.innerHTML = '<span class="fa fa-spinner fa-spin"></span> Applying';
    server("AGENT_ADV_CONFIG_VALIDATE", {x01: JSON.stringify(collectConditions())})
      .then(function () {
        state.appliedClassBucket = null;
        state.appliedBucket = null;
        state.appliedConfiguration = currentConfigurationViewModel();
        return load(false, {kind: "CONFIG"});
      })
      .then(function (data) {
        if (!data) { return null; }
        forceCloseConfigurationEditor();
        switchTab("analytics");
        $("ala-kpi-rail").scrollIntoView({behavior: "smooth", block: "nearest"});
        if (Number((data.kpis || {}).agents || 0) === 0) {
          notify("Configuration applied successfully. No agents match the current rule and analysis period.");
        } else {
          notify("Configuration applied to " + fmt.format(data.kpis.agents) + " matching agents.");
        }
        return data;
      }).catch(function (error) {
        showError("Configuration could not be applied: " + error.message);
      }).finally(function () {
        button.disabled = false;
        button.innerHTML = '<span class="fa fa-play"></span> Apply to Analytics';
      });
  }

  function supportsInteractiveAnalytics(node) {
    return (node.children || []).every(function (child) {
      if (child.children) { return supportsInteractiveAnalytics(child); }
      return Object.prototype.hasOwnProperty.call(fieldLabels, child.field);
    });
  }

  function loadFieldCatalog() {
    return server("AGENT_ADV_FIELD_CATALOG").then(function (data) {
      state.fieldCatalog = data.fields || [];
      var profileOptions = state.fieldCatalog.filter(function (item) {
        return String(item.sourceFamily || "").indexOf("PROFILE_") === 0;
      });
      var uniqueFields = {};
      profileOptions.forEach(function (item) { uniqueFields[item.code] = true; });
      var daily = profileOptions.filter(function (item) { return item.sourceFamily === "PROFILE_DAILY"; }).length;
      var monthly = profileOptions.filter(function (item) { return item.sourceFamily === "PROFILE_MONTHLY"; }).length;
      var days360 = profileOptions.filter(function (item) { return item.sourceFamily === "PROFILE_360"; }).length;
      $("ala-catalog-summary").textContent = Object.keys(uniqueFields).length +
        " governed Agent JSON fields available — Daily " + daily +
        ", Monthly " + monthly + ", 360 Days " + days360 + ".";
      renderConditionTree(collectConditions());
    }).catch(function (error) {
      showError("Governed field catalogue could not be loaded: " + error.message);
      throw error;
    });
  }

  function navigateToSubbucket(id) {
    if (String(id) === String(state.selectedBucketId)) {
      return Promise.resolve(true);
    }
    return guardSubbucketNavigation().then(function (allowed) {
      if (!allowed) { return false; }
      state.subbucketEditorBaseline = null;
      return loadBucket(id).then(function () { return true; });
    });
  }

  function navigateToClassBucket(id) {
    if (String(id) === String(state.selectedClassBucketId) &&
        state.selectedBucketId == null) {
      return Promise.resolve(true);
    }
    return guardSubbucketNavigation().then(function (allowed) {
      if (!allowed) { return false; }
      forceCloseConfigurationEditor();
      state.subbucketEditorBaseline = null;
      return loadClassBucket(id).then(function () { return true; });
    });
  }

  function createSubbucketSafely(parentId) {
    return guardSubbucketNavigation().then(function (allowed) {
      if (!allowed) { return false; }
      state.subbucketEditorBaseline = null;
      newBucket(parentId);
      return true;
    });
  }

  function renderBucketList() {
    var term = normalizeName($("ala-bucket-search").value);
    var rows = state.buckets.filter(function (row) {
      return !term ||
        normalizeName(row.name + " " + row.code + " " + row.owner).indexOf(term) >= 0 ||
        (row.subbuckets || []).some(function (item) {
          return normalizeName(item.name + " " + item.code).indexOf(term) >= 0;
        });
    });
    $("ala-bucket-list").innerHTML = rows.length ? rows.map(function (row) {
      var children = (row.subbuckets || []).filter(function (item) {
        return !term ||
          normalizeName(row.name + " " + row.code + " " + row.owner).indexOf(term) >= 0 ||
          normalizeName(item.name + " " + item.code).indexOf(term) >= 0;
      });
      var expanded = !!term || !!state.expandedClassBuckets[String(row.id)];
      return '<section class="ala-tree-bucket ' + (expanded ? "is-expanded" : "") + '">' +
        '<div class="ala-tree-bucket-head ' +
        (String(row.id) === String(state.selectedClassBucketId) &&
         state.selectedBucketId == null ? "is-active" : "") +
        '"><button type="button" class="ala-tree-toggle" data-tree-toggle="' + row.id +
        '" aria-expanded="' + (expanded ? "true" : "false") +
        '" title="' + (expanded ? "Collapse" : "Expand") + ' ' + escapeHtml(row.name) +
        '"><span class="fa fa-chevron-right"></span></button>' +
        '<button type="button" class="ala-tree-bucket-select" data-class-bucket-id="' + row.id +
        '"><span class="fa ' + (expanded ? "fa-folder-open" : "fa-folder") +
        '"></span><span><strong>' + escapeHtml(row.name) +
        '</strong><small>' + fmt.format(children.length) + " classifications</small></span></button>" +
        '<i class="ala-tree-status ala-tree-status--' + row.status.toLowerCase() +
        '" title="' + escapeHtml(row.status) + '"></i></div>' +
        '<div class="ala-tree-children"' + (expanded ? "" : " hidden") + ">" +
        (children.length ? children.map(function (item) {
          return '<button type="button" class="ala-tree-subbucket ' +
            (String(item.id) === String(state.selectedBucketId) ? "is-active" : "") +
            '" data-bucket-id="' + item.id + '"><i style="--classification-colour:' +
            escapeHtml(item.colour || "#6F42C1") + '"></i><span><strong>' +
            escapeHtml(item.name) + '</strong><small>' + fmt.format(item.configurationCount || 0) +
            " configurations · P" + escapeHtml(item.priority || 100) +
            '</small></span><i class="ala-tree-status ala-tree-status--' +
            item.status.toLowerCase() + '" title="' + escapeHtml(item.status) +
            '"></i></button>';
        }).join("") : '<div class="ala-tree-empty">No Subbucket classifications</div>') +
        "</div></section>";
    }).join("") : '<div class="ala-empty">No buckets or classifications match.</div>';
    $("ala-bucket-list").querySelectorAll("[data-tree-toggle]").forEach(function (button) {
      button.addEventListener("click", function () {
        var id = String(button.dataset.treeToggle);
        state.expandedClassBuckets = state.expandedClassBuckets[id] ?
          {} : (function () {
            var expanded = {};
            expanded[id] = true;
            return expanded;
          })();
        renderBucketList();
      });
    });
    $("ala-bucket-list").querySelectorAll("[data-class-bucket-id]").forEach(function (button) {
      button.addEventListener("click", function () {
        state.expandedClassBuckets = {};
        state.expandedClassBuckets[String(button.dataset.classBucketId)] = true;
        navigateToClassBucket(button.dataset.classBucketId);
      });
    });
    $("ala-bucket-list").querySelectorAll("[data-bucket-id]").forEach(function (button) {
      button.addEventListener("click", function () {
        navigateToSubbucket(button.dataset.bucketId);
      });
    });
  }

  function refreshBuckets() {
    return server("AGENT_CLASS_BUCKET_LIST").then(function (data) {
      state.buckets = data.buckets || [];
      if (!Object.keys(state.expandedClassBuckets).length && state.buckets.length) {
        state.expandedClassBuckets[String(state.buckets[0].id)] = true;
      }
      if (!Object.keys(state.expandedAnalysisBuckets).length && state.buckets.length) {
        state.expandedAnalysisBuckets[String(state.buckets[0].id)] = true;
      }
      renderBucketList();
      renderAnalysisRuleTree();
    }).catch(function (error) {
      showError("Bucket hierarchy could not be loaded: " + error.message);
    });
  }

  function switchAnalysisSideTab(name) {
    state.activeAnalysisSideTab = name === "rules" ? "rules" : "facets";
    if (state.analysisRailCollapsed) { setAnalysisRailCollapsed(false); }
    ["facets", "rules"].forEach(function (tab) {
      var active = tab === state.activeAnalysisSideTab;
      if ($("ala-side-tab-" + tab)) {
        $("ala-side-tab-" + tab).classList.toggle("is-active", active);
        $("ala-side-tab-" + tab).setAttribute("aria-selected", active ? "true" : "false");
      }
      if ($("ala-side-panel-" + tab)) {
        $("ala-side-panel-" + tab).hidden = !active;
      }
    });
    if (state.activeAnalysisSideTab === "rules") { renderAnalysisRuleTree(); }
  }

  function setAnalysisRailCollapsed(collapsed) {
    state.analysisRailCollapsed = !!collapsed;
    var workspace = $("ala-workspace");
    var side = $("ala-analysis-side");
    var toggle = $("ala-collapse-analysis-side");
    if (!workspace || !side || !toggle) { return; }
    workspace.classList.toggle("is-side-collapsed", state.analysisRailCollapsed);
    side.classList.toggle("is-collapsed", state.analysisRailCollapsed);
    toggle.setAttribute("aria-expanded", state.analysisRailCollapsed ? "false" : "true");
    toggle.title = state.analysisRailCollapsed ?
      "Expand analytics rail" : "Collapse analytics rail";
    toggle.innerHTML = '<span class="fa fa-angle-double-' +
      (state.analysisRailCollapsed ? "right" : "left") + '"></span>';
  }

  function toggleAnalysisRail() {
    setAnalysisRailCollapsed(!state.analysisRailCollapsed);
  }

  function setFacetGroupOpen(group, open) {
    var body = group && group.querySelector(".ala-facet-group-body");
    var button = group && group.querySelector("[data-facet-toggle]");
    if (!group || !body || !button) { return; }
    group.classList.toggle("is-open", open);
    body.hidden = !open;
    button.setAttribute("aria-expanded", open ? "true" : "false");
    var icon = button.querySelector(".fa-chevron-down,.fa-chevron-right");
    if (icon) {
      icon.classList.toggle("fa-chevron-down", open);
      icon.classList.toggle("fa-chevron-right", !open);
    }
  }

  function toggleFacetGroup(button) {
    var group = button.closest(".ala-facet-group");
    if (!group) { return; }
    var open = !group.classList.contains("is-open");
    var accordion = group.closest(".ala-facet-accordions");
    if (open && accordion) {
      accordion.querySelectorAll(".ala-facet-group").forEach(function (peer) {
        if (peer !== group) { setFacetGroupOpen(peer, false); }
      });
    }
    setFacetGroupOpen(group, open);
  }

  function appliedRuleIdentity() {
    if (state.appliedClassBucket) {
      return {
        kind: "Bucket",
        name: state.appliedClassBucket.name,
        detail: state.appliedClassBucket.assignmentMode === "SINGLE" ?
          "Single winner · " + state.appliedClassBucket.winnerStrategy :
          "Multiple classifications"
      };
    }
    if (state.appliedBucket) {
      return {
        kind: "Subbucket",
        name: state.appliedBucket.name || "Subbucket classification",
        detail: (state.appliedBucket.configurations || []).length + " configurations"
      };
    }
    if (state.appliedConfiguration) {
      return {
        kind: "Configuration",
        name: state.appliedConfiguration.name,
        detail: conditionCount(state.appliedConfiguration.rule || {children: []}) + " conditions"
      };
    }
    return null;
  }

  function renderAppliedRuleCard(data) {
    if (!$("ala-applied-rule-card")) { return; }
    var identity = appliedRuleIdentity();
    if (!identity) {
      $("ala-applied-rule-card").classList.remove("is-applied");
      $("ala-applied-rule-card").innerHTML =
        '<span class="fa fa-info-circle"></span><div><strong>No governed rule applied</strong>' +
        '<small>The map currently uses analytics filters only.</small></div>';
      return;
    }
    var agents = data && data.kpis ? Number(data.kpis.agents || 0) :
      Number(state.data && state.data.kpis ? state.data.kpis.agents || 0 : 0);
    $("ala-applied-rule-card").classList.add("is-applied");
    $("ala-applied-rule-card").innerHTML =
      '<span class="fa fa-check-circle"></span><div><em>' + escapeHtml(identity.kind) +
      ' applied</em><strong>' + escapeHtml(identity.name) + '</strong><small>' +
      escapeHtml(identity.detail) + ' · ' + fmt.format(agents) +
      ' matching agents</small></div><button type="button" data-clear-applied ' +
      'title="Remove governed rule from analytics"><span class="fa fa-times"></span></button>';
    $("ala-applied-rule-card").querySelector("[data-clear-applied]")
      .addEventListener("click", function () {
        state.appliedClassBucket = null;
        state.appliedBucket = null;
        state.appliedConfiguration = null;
        load(false).catch(function () {});
      });
  }

  function analysisTreeButton(kind, id) {
    return '<button type="button" class="ala-rule-tree-action is-hot" data-rule-kind="' +
      kind + '" data-rule-id="' + id + '" data-rule-action="APPLY" ' +
      'title="Play — run this rule on analytics" aria-label="Run on analytics">' +
      '<span class="fa fa-play"></span><span>Run</span></button>';
  }

  function analysisTreeLabel(kind, id, name, meta, expandAttribute) {
    var content = '<strong>' + escapeHtml(name) + '</strong><small>' + meta + "</small>";
    if (!expandAttribute) {
      return '<div class="ala-rule-tree-view ala-rule-tree-label">' + content + "</div>";
    }
    return '<button type="button" class="ala-rule-tree-view ala-rule-tree-label" ' +
      expandAttribute + '="' + id + '" title="Expand or collapse ' + escapeHtml(name) +
      '">' + content + "</button>";
  }

  function analysisTreeInspectButton(kind, id, name) {
    return '<button type="button" class="ala-rule-tree-action" data-rule-view-kind="' +
      kind + '" data-rule-view-id="' + id + '" title="View ' + escapeHtml(name) +
      ' in read-only drawer" aria-label="View ' + escapeHtml(name) + '">' +
      '<span class="fa fa-eye"></span><span>View</span></button>';
  }

  function toggleOnlyAnalysisBucket(id) {
    var key = String(id);
    var wasOpen = !!state.expandedAnalysisBuckets[key];
    state.expandedAnalysisBuckets = {};
    state.analysisTreeSubbuckets = {};
    if (!wasOpen) { state.expandedAnalysisBuckets[key] = true; }
    renderAnalysisRuleTree();
  }

  function toggleOnlyAnalysisSubbucket(id) {
    var key = String(id);
    if (state.analysisTreeSubbuckets[key]) {
      delete state.analysisTreeSubbuckets[key];
      renderAnalysisRuleTree();
      return;
    }
    var parent = state.buckets.find(function (bucket) {
      return (bucket.subbuckets || []).some(function (subbucket) {
        return String(subbucket.id) === key;
      });
    });
    if (parent) {
      state.expandedAnalysisBuckets = {};
      state.expandedAnalysisBuckets[String(parent.id)] = true;
    }
    state.analysisTreeSubbuckets = {};
    server("AGENT_ADV_BUCKET_LOAD", {x01: key}).then(function (data) {
      if (data.error) { throw new Error(data.error); }
      state.analysisTreeSubbuckets[key] = data;
      renderAnalysisRuleTree();
    }).catch(function (error) {
      showError("Subbucket details could not be loaded: " + error.message);
    });
  }

  function renderAnalysisRuleTree() {
    if (!$("ala-analysis-rule-tree")) { return; }
    var rows = state.buckets || [];
    $("ala-analysis-rule-tree").innerHTML = rows.length ? rows.map(function (bucket) {
      var bucketId = String(bucket.id);
      var bucketExpanded = !!state.expandedAnalysisBuckets[bucketId];
      var loadedChildren = (bucket.subbuckets || []).map(function (subbucket) {
        var cache = state.analysisTreeSubbuckets[String(subbucket.id)];
        var configurations = cache ? (cache.configurations || []) : [];
        return '<div class="ala-rule-tree-sub" data-analysis-subbucket="' + subbucket.id +
          '"><div class="ala-rule-tree-row" data-row-toggle-subbucket="' + subbucket.id +
          '"><i style="--rule-colour:' +
          escapeHtml(subbucket.colour || "#6F42C1") + '"></i><button type="button" ' +
          'class="ala-rule-tree-toggle" data-load-subbucket="' + subbucket.id +
          '" aria-expanded="' + (cache ? "true" : "false") +
          '" aria-label="Expand configuration list"><span class="fa fa-chevron-' +
          (cache ? "down" : "right") + '"></span></button>' +
          analysisTreeLabel(
            "SUBBUCKET", subbucket.id, subbucket.name,
            fmt.format(subbucket.configurationCount || 0) + " configurations · P" +
              escapeHtml(subbucket.priority || 100),
            "data-load-subbucket"
          ) + '<div class="ala-rule-tree-actions">' +
          analysisTreeInspectButton("SUBBUCKET", subbucket.id, subbucket.name) +
          analysisTreeButton("SUBBUCKET", subbucket.id) + "</div></div>" +
          (cache ? '<div class="ala-rule-tree-configs">' +
            (configurations.length ? configurations.map(function (config) {
              var configId = config.configId || config.id;
              return '<div class="ala-rule-tree-row ala-rule-tree-config">' +
                '<span class="fa fa-sliders"></span><span class="ala-rule-tree-leaf-spacer"></span>' +
                analysisTreeLabel(
                  "CONFIG", configId, config.name,
                  escapeHtml(config.code || "") + " · v" + escapeHtml(config.version || "")
                ) + '<div class="ala-rule-tree-actions">' +
                analysisTreeInspectButton("CONFIG", configId, config.name) +
                analysisTreeButton("CONFIG", configId) + "</div></div>";
            }).join("") : '<div class="ala-tree-empty">No configurations attached</div>') +
            "</div>" : "") + "</div>";
      }).join("");
      return '<section class="ala-rule-tree-bucket ' +
        (bucketExpanded ? "is-expanded" : "") +
        '"><div class="ala-rule-tree-row ala-rule-tree-root" data-row-toggle-bucket="' +
        bucket.id + '">' +
        '<span class="fa fa-folder"></span><button type="button" class="ala-rule-tree-toggle" ' +
        'data-toggle-analysis-bucket="' + bucket.id + '" aria-expanded="' +
        (bucketExpanded ? "true" : "false") +
        '" aria-label="Expand Subbucket classifications"><span class="fa fa-chevron-' +
        (bucketExpanded ? "down" : "right") + '"></span></button>' +
        analysisTreeLabel(
          "CLASS_BUCKET", bucket.id, bucket.name,
          fmt.format((bucket.subbuckets || []).length) +
            " Subbucket classifications · " +
            (bucket.assignmentMode === "SINGLE" ? "Single winner" : "Multiple"),
          "data-toggle-analysis-bucket"
        ) + '<div class="ala-rule-tree-actions">' +
        analysisTreeInspectButton("CLASS_BUCKET", bucket.id, bucket.name) +
        analysisTreeButton("CLASS_BUCKET", bucket.id) +
        '</div></div><div class="ala-rule-tree-children" ' +
        (bucketExpanded ? "" : "hidden") + ">" + loadedChildren +
        "</div></section>";
    }).join("") : '<div class="ala-empty">No active Buckets are available.</div>';
    $("ala-analysis-rule-tree").querySelectorAll("[data-toggle-analysis-bucket]")
      .forEach(function (button) {
        button.addEventListener("click", function () {
          toggleOnlyAnalysisBucket(button.dataset.toggleAnalysisBucket);
        });
      });
    $("ala-analysis-rule-tree").querySelectorAll("[data-load-subbucket]")
      .forEach(function (button) {
        button.addEventListener("click", function () {
          toggleOnlyAnalysisSubbucket(button.dataset.loadSubbucket);
        });
      });
    $("ala-analysis-rule-tree").querySelectorAll("[data-row-toggle-bucket]")
      .forEach(function (row) {
        row.addEventListener("click", function (event) {
          if (event.target.closest("button")) { return; }
          toggleOnlyAnalysisBucket(row.dataset.rowToggleBucket);
        });
      });
    $("ala-analysis-rule-tree").querySelectorAll("[data-row-toggle-subbucket]")
      .forEach(function (row) {
        row.addEventListener("click", function (event) {
          if (event.target.closest("button")) { return; }
          toggleOnlyAnalysisSubbucket(row.dataset.rowToggleSubbucket);
        });
      });
    $("ala-analysis-rule-tree").querySelectorAll("[data-rule-view-kind]")
      .forEach(function (button) {
        button.addEventListener("click", function () {
          executeAnalysisTreeAction(
            button.dataset.ruleViewKind, button.dataset.ruleViewId, "VIEW", button
          );
        });
      });
    $("ala-analysis-rule-tree").querySelectorAll("[data-rule-action]")
      .forEach(function (button) {
        button.addEventListener("click", function () {
          executeAnalysisTreeAction(
            button.dataset.ruleKind, button.dataset.ruleId, button.dataset.ruleAction, button
          );
        });
      });
  }

  function showRuleExplorerTest(data, label) {
    var panel = $("ala-applied-rule-card");
    panel.classList.remove("is-applied");
    panel.innerHTML = '<span class="fa fa-check-circle"></span><div><em>Test completed</em>' +
      '<strong>' + escapeHtml(label) + '</strong><small>' +
      fmt.format((data.kpis || {}).agents || 0) + " matching agents · " +
      fmt.format((data.kpis || {}).transactions || 0) + " transactions · " +
      money.format((data.kpis || {}).totalAmount || 0) + "</small></div>";
  }

  function configViewModelFromData(data) {
    return {
      id: data.id, code: data.code, name: data.name,
      description: data.description, version: data.version, status: data.status,
      sharingMode: data.sharingMode, outputType: data.outputType,
      dateScope: data.dateScope || {mode: "RUNTIME"},
      classification: data.classification || {}, rule: data.rule || {operator: "AND", children: []}
    };
  }

  function executeAnalysisTreeAction(kind, id, action, button) {
    var original = button.innerHTML;
    button.disabled = true;
    button.innerHTML = '<span class="fa fa-spinner fa-spin"></span>';
    var promise;
    if (kind === "CLASS_BUCKET") {
      var parent = state.buckets.find(function (row) { return String(row.id) === String(id); });
      if (action === "VIEW") {
        promise = openClassBucketHierarchyViewer(
          parent || {id: Number(id), name: "Bucket", subbuckets: []}
        );
      } else {
        promise = load(action === "TEST", {kind: "CLASS_BUCKET", classBucketId: Number(id)})
          .then(function (data) {
            if (!data) { return null; }
            if (action === "TEST") {
              showRuleExplorerTest(data, parent ? parent.name : "Bucket");
            } else {
              state.appliedClassBucket = parent || {id: Number(id), name: "Bucket"};
              state.appliedBucket = null;
              state.appliedConfiguration = null;
              renderAppliedRuleOutcome(data);
              renderAppliedRuleCard(data);
              notify("Bucket applied to " + fmt.format((data.kpis || {}).agents || 0) +
                " matching agents.");
            }
            return data;
          });
      }
    } else if (kind === "SUBBUCKET") {
      if (action === "VIEW") {
        promise = openSubbucketHierarchyViewer(id);
      } else {
        promise = server("AGENT_ADV_BUCKET_LOAD", {x01: id}).then(function (data) {
          if (data.error) { throw new Error(data.error); }
          return load(action === "TEST", {kind: "BUCKET", bucket: data}).then(function (result) {
            if (!result) { return null; }
            if (action === "TEST") {
              showRuleExplorerTest(result, data.name);
            } else {
              state.appliedClassBucket = null;
              state.appliedBucket = data;
              state.appliedConfiguration = null;
              renderAppliedRuleOutcome(result);
              renderAppliedRuleCard(result);
              notify("Subbucket applied to " + fmt.format((result.kpis || {}).agents || 0) +
                " matching agents.");
            }
            return result;
          });
        });
      }
    } else {
      promise = server("AGENT_ADV_CONFIG_LOAD", {x01: id}).then(function (data) {
        if (data.error) { throw new Error(data.error); }
        var view = configViewModelFromData(data);
        if (action === "VIEW") {
          openConfigurationViewer(view, false);
          return data;
        }
        return load(action === "TEST", {
          kind: "CONFIG", conditions: view.rule, configDateScope: view.dateScope
        }).then(function (result) {
          if (!result) { return null; }
          if (action === "TEST") {
            showRuleExplorerTest(result, view.name);
          } else {
            state.appliedClassBucket = null;
            state.appliedBucket = null;
            state.appliedConfiguration = view;
            renderAppliedRuleOutcome(result);
            renderAppliedRuleCard(result);
            notify("Configuration applied to " + fmt.format((result.kpis || {}).agents || 0) +
              " matching agents.");
          }
          return result;
        });
      });
    }
    Promise.resolve(promise).catch(function (error) {
      showError("Rule action failed: " + error.message);
    }).finally(function () {
      button.disabled = false;
      button.innerHTML = original;
    });
  }

  function selectedClassBucket() {
    return state.buckets.find(function (row) {
      return String(row.id) === String(state.selectedClassBucketId);
    });
  }

  function renderClassBucketSubbuckets() {
    var parent = selectedClassBucket();
    var rows = parent ? (parent.subbuckets || []) : [];
    $("ala-class-bucket-subbucket-count").textContent = rows.length + " classification" +
      (rows.length === 1 ? "" : "s");
    $("ala-class-bucket-subbuckets").innerHTML = rows.length ? rows.map(function (row) {
      return '<button type="button" class="ala-classification-row" data-classification-id="' +
        row.id + '"><i style="--classification-colour:' +
        escapeHtml(row.colour || "#6F42C1") + '"></i><span><strong>' +
        escapeHtml(row.name) + '</strong><small>' + fmt.format(row.configurationCount || 0) +
        " configurations · Priority " + escapeHtml(row.priority || 100) +
        " · " + (row.finalizerEnabled ? escapeHtml(row.finalizerType) : "No final scoring") +
        '</small></span><em class="ala-status-badge ala-status-' +
        row.status.toLowerCase() + '">' + escapeHtml(row.status) +
        '</em><span class="fa fa-chevron-right"></span></button>';
    }).join("") : '<div class="ala-empty">No Subbucket classifications yet. Use New Subbucket to create the first one.</div>';
    $("ala-class-bucket-subbuckets").querySelectorAll("[data-classification-id]")
      .forEach(function (button) {
        button.addEventListener("click", function () {
          navigateToSubbucket(button.dataset.classificationId);
        });
      });
  }

  function showClassBucketEditor() {
    $("ala-class-bucket-editor").hidden = false;
    $("ala-subbucket-editor").hidden = true;
    state.subbucketEditorBaseline = null;
  }

  function showSubbucketEditor() {
    $("ala-class-bucket-editor").hidden = true;
    $("ala-subbucket-editor").hidden = false;
  }

  function updateWinnerStrategyVisibility() {
    var selected = document.querySelector("input[name=ala-assignment-mode]:checked");
    $("ala-winner-strategy-control").hidden = !selected || selected.value !== "SINGLE";
  }

  function validateClassBucketReady() {
    var parent = selectedClassBucket();
    if (!state.selectedClassBucketId || !parent) {
      showError("Save the Bucket before testing it.");
      return null;
    }
    var active = (parent.subbuckets || []).filter(function (row) {
      return row.status === "ACTIVE" && Number(row.configurationCount || 0) > 0;
    });
    if (!active.length) {
      showError("Activate at least one Subbucket with a complete configuration.");
      return null;
    }
    return parent;
  }

  function validateClassBucket() {
    var parent = validateClassBucketReady();
    var button = $("ala-test-class-bucket");
    if (!parent) { return; }
    $("ala-class-bucket-test-result").hidden = true;
    button.disabled = true;
    button.innerHTML = '<span class="fa fa-spinner fa-spin"></span> Testing Bucket';
    load(true, {
      kind: "CLASS_BUCKET", classBucketId: Number(parent.id)
    }, "ala-class-bucket-test-result", {
      authorizedDefinitionScope: true
    }).then(function (data) {
      if (!data) { return null; }
      showRuleExplorerTest(data, parent.name);
      return data;
    }).catch(function (error) {
      showError("Bucket validation failed: " + error.message);
    }).finally(function () {
      button.disabled = false;
      button.innerHTML = '<span class="fa fa-check-circle"></span> Validate &amp; Test';
    });
  }

  function applyClassBucketToAnalytics() {
    var parent = validateClassBucketReady();
    var button = $("ala-apply-class-bucket");
    if (!parent) { return; }
    button.disabled = true;
    button.innerHTML = '<span class="fa fa-spinner fa-spin"></span> Applying';
    load(false, {kind: "CLASS_BUCKET", classBucketId: Number(parent.id)})
      .then(function (data) {
        if (!data) { return null; }
        state.appliedClassBucket = parent;
        state.appliedBucket = null;
        state.appliedConfiguration = null;
        renderAppliedRuleOutcome(data);
        renderAppliedRuleCard(data);
        switchTab("analytics");
        switchAnalysisSideTab("rules");
        notify("Bucket applied to " + fmt.format((data.kpis || {}).agents || 0) +
          " matching agents.");
        return data;
      }).catch(function (error) {
        showError("Bucket could not be applied: " + error.message);
      }).finally(function () {
        button.disabled = false;
        button.innerHTML = '<span class="fa fa-play"></span> Apply to Analytics';
      });
  }

  function newClassBucket() {
    state.selectedClassBucketId = null;
    state.selectedClassBucketVersion = null;
    state.selectedBucketId = null;
    $("ala-class-bucket-name").value = "";
    $("ala-class-bucket-description").value = "";
    $("ala-class-bucket-sharing").value = "PRIVATE";
    $("ala-class-bucket-title").textContent = "New Bucket";
    $("ala-class-bucket-status").textContent = "New draft";
    $("ala-class-bucket-version").textContent = "Not saved";
    $("ala-retire-class-bucket").hidden = true;
    document.querySelector("input[name=ala-assignment-mode][value=MULTIPLE]").checked = true;
    $("ala-winner-strategy").value = "PRIORITY_THEN_SCORE";
    updateWinnerStrategyVisibility();
    renderClassBucketSubbuckets();
    showClassBucketEditor();
    renderBucketList();
  }

  function loadClassBucket(id) {
    return server("AGENT_CLASS_BUCKET_LOAD", {x01: id}).then(function (data) {
      if (data.error) { throw new Error(data.error); }
      state.selectedClassBucketId = data.id;
      state.expandedClassBuckets = {};
      state.expandedClassBuckets[String(data.id)] = true;
      state.selectedClassBucketVersion = data.versionId;
      state.selectedBucketId = null;
      $("ala-class-bucket-name").value = data.name || "";
      $("ala-class-bucket-description").value = data.description || "";
      $("ala-class-bucket-sharing").value = data.sharingMode || "PRIVATE";
      $("ala-class-bucket-title").textContent = data.name || "Bucket";
      $("ala-class-bucket-status").textContent = data.status || "DRAFT";
      $("ala-class-bucket-version").textContent = "Version " + (data.version || 1);
      $("ala-retire-class-bucket").hidden = !data.canEdit;
      var assignment = document.querySelector(
        "input[name=ala-assignment-mode][value=" + (data.assignmentMode || "MULTIPLE") + "]"
      );
      if (assignment) { assignment.checked = true; }
      $("ala-winner-strategy").value = data.winnerStrategy || "PRIORITY_THEN_SCORE";
      updateWinnerStrategyVisibility();
      renderClassBucketSubbuckets();
      showClassBucketEditor();
      renderBucketList();
    }).catch(function (error) {
      showError("Bucket could not be loaded: " + error.message);
    });
  }

  function saveClassBucket(activate) {
    var name = $("ala-class-bucket-name").value.trim();
    var assignment = document.querySelector("input[name=ala-assignment-mode]:checked");
    if (!name) {
      showError("Enter a Bucket name.");
      $("ala-class-bucket-name").focus();
      return;
    }
    server("AGENT_CLASS_BUCKET_SAVE", {
      x01: JSON.stringify({
        bucketId: state.selectedClassBucketId,
        name: name,
        description: $("ala-class-bucket-description").value,
        sharingMode: $("ala-class-bucket-sharing").value,
        assignmentMode: assignment ? assignment.value : "MULTIPLE",
        winnerStrategy: $("ala-winner-strategy").value
      }),
      x02: activate ? "Y" : "N"
    }).then(function (result) {
      state.selectedClassBucketId = result.id;
      state.selectedClassBucketVersion = result.versionId;
      notify(result.message);
      return refreshBuckets().then(function () { return loadClassBucket(result.id); });
    }).catch(function (error) {
      showError("Bucket save failed: " + error.message);
    });
  }

  function retireClassBucket() {
    if (!state.selectedClassBucketId ||
        !global.confirm("Retire this Bucket? Its version history and prior classifications remain auditable.")) {
      return;
    }
    server("AGENT_CLASS_BUCKET_RETIRE", {x01: state.selectedClassBucketId})
      .then(function (result) {
        notify(result.message);
        newClassBucket();
        return refreshBuckets();
      }).catch(function (error) {
        showError("Bucket could not be retired: " + error.message);
      });
  }

  function selectedBucketConfiguration(configVersionId) {
    return state.bucketConfigurations.find(function (item) {
      return String(item.configVersionId) === String(configVersionId);
    });
  }

  function isConfigurationSelected(row) {
    return state.bucketConfigurations.some(function (item) {
      return (item.configId != null && row.id != null &&
        String(item.configId) === String(row.id)) ||
        String(item.configVersionId) === String(row.versionId);
    });
  }

  function bucketConfigurationMetadata(item) {
    var catalog = state.savedFilters.find(function (row) {
      return String(row.versionId) === String(item.configVersionId);
    });
    return Object.assign({}, catalog || {}, item || {});
  }

  function configurationRuleSummary(node) {
    if (!node) { return '<div class="ala-empty">No rule definition is available.</div>'; }
    if (node.fieldKey || node.field) {
      var key = node.fieldKey || node.field;
      var meta = fieldMeta(key);
      var code = node.field || String(key).replace(/^.*:/, "");
      var label = meta ? meta.label : (fieldLabels[code] || code.replace(/_/g, " "));
      var operator = node.operator || node.op || "EQ";
      var value = "";
      if (operator !== "IS_NULL" && operator !== "IS_NOT_NULL") {
        value = '<b>' + escapeHtml(node.value == null ? "" : node.value) + '</b>';
        if (operator === "BETWEEN") {
          value += '<span>and</span><b>' + escapeHtml(node.value2 == null ? "" : node.value2) + '</b>';
        }
      }
      return '<li class="ala-config-rule-leaf"><span>' + escapeHtml(label) +
        '</span><em>' + escapeHtml(operatorLabels[operator] || operator) + '</em>' + value + '</li>';
    }
    var join = String(node.operator || "AND").toUpperCase();
    return '<li class="ala-config-rule-group"><strong>' +
      (join === "OR" ? "ANY (OR)" : "ALL (AND)") +
      ' of the following</strong><ul>' + (node.children || []).map(configurationRuleSummary).join("") +
      "</ul></li>";
  }

  function configurationSummaryHtml(data) {
    var classification = data.classification || {};
    var dateScope = data.dateScope || {};
    return '<div class="ala-config-summary-head"><div><strong>' +
      escapeHtml(data.name || "Configuration") + '</strong><small>' +
      escapeHtml(data.code || "") + " · Version " + escapeHtml(data.version || "") +
      '</small></div><div class="ala-header-actions"><span>' +
      escapeHtml(data.outputType || "BOOLEAN") +
      '</span><span class="ala-inline-workspace-label"><span class="fa fa-pencil"></span> Workspace open below</span></div></div>' +
      (data.description ? '<p class="ala-config-summary-description">' +
        escapeHtml(data.description) + "</p>" : "") +
      '<div class="ala-config-summary-meta"><span><em>Priority</em><b>' +
      escapeHtml(classification.priority == null ? "—" : classification.priority) +
      '</b></span><span><em>Criticality</em><b>' +
      escapeHtml(classification.criticality || "—") +
      '</b></span><span><em>Risk class</em><b>' +
      escapeHtml(classification.riskClass || "—") +
      '</b></span><span><em>Risk points</em><b>' +
      escapeHtml(classification.riskPoints == null ? "—" : classification.riskPoints) +
      '</b></span><span><em>Date scope</em><b>' +
      escapeHtml(dateScope.mode || "Scheduler period") +
      '</b></span></div><div class="ala-config-summary-rules"><h4>Condition summary</h4><ul>' +
      configurationRuleSummary(data.rule || {operator: "AND", children: []}) +
      "</ul></div>";
  }

  function currentConfigurationViewModel() {
    var saved = state.savedFilters.find(function (item) {
      return String(item.id) === String(state.selectedFilterId);
    }) || {};
    return {
      id: state.selectedFilterId,
      code: saved.code || "",
      name: $("ala-filter-name").value.trim() || saved.name || "Advanced Configuration",
      description: $("ala-filter-description").value.trim(),
      version: state.selectedFilterVersion || saved.version || "Draft",
      status: $("ala-builder-status").textContent.trim() || saved.status || "DRAFT",
      sharingMode: $("ala-sharing-mode").value,
      outputType: $("ala-config-output").value,
      dateScope: collectWindowScope(),
      classification: {
        priority: Number($("ala-config-priority").value || 100),
        criticality: $("ala-config-criticality").value,
        riskClass: $("ala-config-risk").value,
        riskPoints: Number($("ala-config-risk-points").value || 0)
      },
      rule: collectConditions()
    };
  }

  function dateScopeSummary(scope) {
    var labels = {
      RUNTIME: "Runtime selected range",
      CURRENT_DAY: "Current day",
      PREVIOUS_DAY: "Previous day",
      LAST_N_DAYS: "Last N days",
      MONTH_TO_DATE: "Month to date",
      PREVIOUS_MONTH: "Previous complete month",
      LAST_N_COMPLETE_MONTHS: "Last N complete months",
      YEAR_TO_DATE: "Year to date",
      ROLLING_360: "Rolling 360 days",
      CUSTOM_RELATIVE: "Custom relative range"
    };
    var text = labels[scope.mode] || scope.mode || "Runtime selected range";
    if (scope.mode === "LAST_N_DAYS" || scope.mode === "LAST_N_COMPLETE_MONTHS") {
      text += " · " + Number(scope.value || 1);
    } else if (scope.mode === "CUSTOM_RELATIVE") {
      text += " · day " + Number(scope.startOffset || 0) + " to " +
        Number(scope.endOffset || 0);
    }
    return text;
  }

  function appliedConfigurationViewerHtml(config, applied) {
    var eyebrow = applied ? "Applied analytics filter" : "Configuration summary";
    var description = applied ?
      "Read-only summary of the configuration currently filtering Map & Analytics." :
      "Read-only governed definition. Use Apply when you want this rule to filter analytics.";
    var classification = config.classification || {};
    return '<section class="ala-applied-config-view" aria-labelledby="ala-applied-config-title">' +
      '<header class="ala-native-drawer-header"><div><p class="ala-eyebrow">' + eyebrow + '</p>' +
      '<h2 id="ala-applied-config-title">' + escapeHtml(config.name) + '</h2>' +
      '<p>' + description + '</p></div>' +
      '<button id="ala-close-applied-config" type="button" ' +
      'class="t-Button t-Button--icon t-Button--noLabel t-Button--small" ' +
      'title="Close" aria-label="Close applied configuration"><span class="t-Icon fa fa-times"></span></button>' +
      '</header><div class="ala-applied-config-scroll">' +
      '<div class="ala-applied-config-identity"><div><span>Status</span><b>' +
      escapeHtml(config.status || "DRAFT") + '</b></div><div><span>Version</span><b>' +
      escapeHtml(config.version || "Draft") + '</b></div><div><span>Visibility</span><b>' +
      escapeHtml(config.sharingMode || "PRIVATE") + '</b></div><div><span>Output</span><b>' +
      escapeHtml(config.outputType || "BOOLEAN") + '</b></div></div>' +
      (config.description ? '<p class="ala-applied-config-description">' +
        escapeHtml(config.description) + '</p>' : "") +
      '<section class="ala-applied-config-section"><h3>Evaluation &amp; classification</h3>' +
      '<div class="ala-applied-config-meta"><div><span>Evaluation window</span><b>' +
      escapeHtml(dateScopeSummary(config.dateScope || {})) +
      '</b></div><div><span>Priority</span><b>' +
      escapeHtml(classification.priority == null ? "—" : classification.priority) +
      '</b></div><div><span>Criticality</span><b>' +
      escapeHtml(classification.criticality || "—") +
      '</b></div><div><span>Risk class</span><b>' +
      escapeHtml(classification.riskClass || "—") +
      '</b></div><div><span>Risk points</span><b>' +
      escapeHtml(classification.riskPoints == null ? "—" : classification.riskPoints) +
      '</b></div></div></section>' +
      '<section class="ala-applied-config-section"><div class="ala-applied-config-section-head">' +
      '<h3>Condition logic</h3><span>' +
      conditionCount(config.rule || {operator: "AND", children: []}) +
      ' condition(s)</span></div><ul class="ala-applied-config-rule">' +
      configurationRuleSummary(config.rule || {operator: "AND", children: []}) +
      '</ul></section></div><footer class="ala-native-drawer-footer">' +
      '<span class="ala-native-drawer-footnote"><span class="fa fa-lock"></span> Read-only applied definition</span>' +
      '<div class="ala-native-drawer-actions"><button id="ala-done-applied-config" type="button" ' +
      'class="t-Button t-Button--hot t-Button--small">Done</button></div></footer></section>';
  }

  function readableCode(value, fallback) {
    var text = String(value || fallback || "").replace(/_/g, " ").toLowerCase();
    return text.replace(/\b\w/g, function (letter) { return letter.toUpperCase(); });
  }

  function governedViewerShell(eyebrow, title, description, body) {
    return '<section class="ala-applied-config-view ala-governed-view" ' +
      'aria-labelledby="ala-governed-view-title" data-drawer-title="' +
      escapeHtml(title) + '"><h2 id="ala-governed-view-title" class="u-vh">' +
      escapeHtml(title) + '</h2><div class="ala-governed-native-intro">' +
      '<p class="ala-eyebrow">' + escapeHtml(eyebrow) + '</p><p>' +
      escapeHtml(description) + '</p></div>' +
      '<div class="ala-applied-config-scroll">' + body + '</div>' +
      '<footer class="ala-native-drawer-footer"><span class="ala-native-drawer-footnote">' +
      '<span class="fa fa-lock"></span> Read-only governed definition</span>' +
      '<div class="ala-native-drawer-actions"><button type="button" ' +
      'class="t-Button t-Button--hot t-Button--small" data-close-governed-viewer>' +
      'Done</button></div></footer></section>';
  }

  function governedIdentityHtml(items) {
    return '<div class="ala-governed-identity" aria-label="Governed definition metadata">' +
      items.map(function (item) {
        return '<span><em>' + escapeHtml(item.label) + '</em><b>' +
          escapeHtml(item.value == null || item.value === "" ? "—" : item.value) +
          "</b></span>";
      }).join("") + "</div>";
  }

  function governedCriterionValue(node, operator) {
    if (operator === "IS_NULL" || operator === "IS_NOT_NULL") { return "Not required"; }
    var value = node.value == null || node.value === "" ? "—" : String(node.value);
    if (operator === "BETWEEN") {
      value += " to " + (node.value2 == null || node.value2 === "" ? "—" : node.value2);
    }
    return value;
  }

  function governedCriteriaHtml(node) {
    if (!node) {
      return '<div class="ala-governed-empty">No criteria are configured.</div>';
    }
    if (node.fieldKey || node.field) {
      var key = node.fieldKey || node.field;
      var meta = fieldMeta(key);
      var code = node.field || String(key).replace(/^.*:/, "");
      var label = meta ? meta.label : (fieldLabels[code] || code.replace(/_/g, " "));
      var operator = node.operator || node.op || "EQ";
      return '<div class="ala-governed-criterion">' +
        '<span><em>Field</em><b>' + escapeHtml(label) + '</b></span>' +
        '<span><em>Operator</em><b>' +
        escapeHtml(operatorLabels[operator] || readableCode(operator)) + '</b></span>' +
        '<span><em>Value</em><b>' +
        escapeHtml(governedCriterionValue(node, operator)) + '</b></span></div>';
    }
    var join = String(node.operator || "AND").toUpperCase();
    var count = conditionCount(node);
    return '<section class="ala-governed-criteria-group"><header><span class="fa fa-bullseye">' +
      '</span><strong>' + (join === "OR" ? "ANY criterion may match" : "ALL criteria must match") +
      '</strong><em>' + count + " " + (count === 1 ? "criterion" : "criteria") +
      '</em></header><div class="ala-governed-criteria-children">' +
      (node.children || []).map(governedCriteriaHtml).join("") + "</div></section>";
  }

  function governedResultHtml(config) {
    var classification = config.classification || {};
    var risk = classification.riskClass ?
      readableCode(classification.riskClass) + " risk" :
      readableCode(config.outputType, "Match");
    var points = classification.riskPoints;
    var detail = points == null ? "Configuration matched" :
      "Add " + Number(points || 0) + " points";
    return '<section class="ala-governed-result"><span class="ala-governed-result-icon">' +
      '<span class="fa fa-flag"></span></span><span><em>Result</em><strong>' +
      escapeHtml(risk) + '</strong><small>' + escapeHtml(detail) +
      '</small></span></section><p class="ala-governed-result-help">' +
      "Agents matching these criteria receive the classification outcome.</p>";
  }

  function governedConfigurationNodeHtml(config, open) {
    var classification = config.classification || {};
    var rule = config.rule || {operator: "AND", children: []};
    return '<details class="ala-governed-tree-node ala-governed-config-node" ' +
      (open ? "open" : "") + '><summary><span class="ala-governed-node-icon">' +
      '<span class="fa fa-sliders"></span></span><span><strong>' +
      escapeHtml(config.name || "Advanced Configuration") + '</strong><small>' +
      "Advanced Agent Configuration · " + conditionCount(rule) +
      " " + (conditionCount(rule) === 1 ? "criterion" : "criteria") +
      '</small></span><span class="ala-status-badge">' +
      escapeHtml(config.outputType || "BOOLEAN") + '</span></summary>' +
      '<div class="ala-governed-node-body">' +
      (config.description ? '<p class="ala-governed-description">' +
        escapeHtml(config.description) + "</p>" : "") +
      governedCriteriaHtml(rule) + governedResultHtml(config) +
      '<details class="ala-governed-supporting"><summary><span class="fa fa-info-circle">' +
      '</span><strong>Supporting information</strong><span class="fa fa-chevron-down">' +
      '</span></summary><div class="ala-governed-supporting-body">' +
      governedIdentityHtml([
        {label: "Window", value: dateScopeSummary(config.dateScope || {})},
        {label: "Priority", value: classification.priority},
        {label: "Criticality", value: classification.criticality},
        {label: "Output", value: config.outputType || "BOOLEAN"}
      ]) + '</div></details></div></details>';
  }

  function governedRiskBandsHtml(bands) {
    if (!(bands || []).length) {
      return '<div class="ala-governed-empty">No Subbucket risk bands are configured.</div>';
    }
    return '<div class="ala-governed-risk-bands">' + bands.map(function (band) {
      return '<div style="--band-colour:' + escapeHtml(band.colour || "#7b8b97") +
        '"><i></i><span><strong>' + escapeHtml(band.name || band.code || "Band") +
        '</strong><small>' + escapeHtml(band.minimum) + "–" +
        escapeHtml(band.maximum) + "</small></span></div>";
    }).join("") + "</div>";
  }

  function governedSubbucketNodeHtml(subbucket, open) {
    var finalizer = subbucket.finalizer || {};
    var classification = subbucket.classification || {};
    var configurations = subbucket.configurationDetails || [];
    return '<details class="ala-governed-tree-node ala-governed-subbucket-node" ' +
      (open ? "open" : "") + '><summary style="--node-colour:' +
      escapeHtml(subbucket.colour || "#6f42c1") + '"><span class="ala-governed-node-icon">' +
      '<i></i></span><span><strong>' + escapeHtml(subbucket.name || "Subbucket") +
      '</strong><small>Subbucket classification · ' + configurations.length +
      ' configuration(s)</small></span><span class="ala-status-badge ala-status-active">' +
      escapeHtml(subbucket.status || "ACTIVE") + '</span></summary>' +
      '<div class="ala-governed-node-body">' +
      (subbucket.description ? '<p class="ala-governed-description">' +
        escapeHtml(subbucket.description) + "</p>" : "") +
      '<div class="ala-governed-tree-children">' +
      (configurations.length ? configurations.map(function (config) {
        return governedConfigurationNodeHtml(config, config === configurations[0]);
      }).join("") : '<div class="ala-governed-empty">No configurations are attached.</div>') +
      '</div><details class="ala-governed-supporting ala-governed-classification-info">' +
      '<summary><span class="fa fa-info-circle"></span>' +
      '<strong>Classification information</strong><span class="fa fa-chevron-down">' +
      '</span></summary><div class="ala-governed-supporting-body">' +
      governedIdentityHtml([
        {label: "Priority", value: classification.priority},
        {label: "Scoring", value: finalizer.enabled ?
          readableCode(finalizer.type, "Enabled") : "Independent outcomes"},
        {label: "Threshold", value: finalizer.enabled ? finalizer.value : "Not applied"},
        {label: "Criticality", value: classification.criticality}
      ]) + '<div class="ala-governed-risk-caption">Risk colour bands</div>' +
      governedRiskBandsHtml(subbucket.riskBands || []) +
      '</div></details></div></details>';
  }

  function hydrateSubbucketForViewer(subbucket) {
    var sourcePromise = subbucket && subbucket.configurations ?
      Promise.resolve(subbucket) :
      server("AGENT_ADV_BUCKET_LOAD", {x01: subbucket.id || subbucket});
    return sourcePromise.then(function (data) {
      if (data.error) { throw new Error(data.error); }
      var configurations = (data.configurations || []).filter(function (config) {
        return config.enabled !== false;
      });
      return Promise.all(configurations.map(function (config) {
        return server("AGENT_ADV_CONFIG_LOAD", {x01: config.configId || config.id})
          .then(function (detail) {
            if (detail.error) { throw new Error(detail.error); }
            return Object.assign(configViewModelFromData(detail), {
              weight: config.weight, mandatory: config.mandatory
            });
          }).catch(function () {
            return {
              id: config.configId || config.id, code: config.code, name: config.name,
              version: config.version, outputType: config.outputType,
              classification: {
                priority: config.priority, criticality: config.criticality,
                riskClass: config.riskClass, riskPoints: config.riskPoints
              },
              dateScope: {mode: "RUNTIME"},
              rule: {operator: "AND", children: []}
            };
          });
      })).then(function (configurationDetails) {
        data.configurationDetails = configurationDetails;
        return data;
      });
    });
  }

  function setNativeDrawerTitle(title) {
    var region = $("ala-native-drawer");
    if (!region) { return; }
    var text = title || "Governed Definition";
    region.setAttribute("title", text);
    if (global.apex && apex.jQuery) {
      var drawer = apex.jQuery(region);
      if (drawer.hasClass("ui-dialog-content") &&
          typeof drawer.dialog === "function") {
        drawer.dialog("option", "title", text);
      }
    }
  }

  function fixNativeDrawerFrame() {
    var region = $("ala-native-drawer");
    if (!region || !global.apex || !apex.jQuery) { return; }
    var frame = apex.jQuery(region).closest(".ui-dialog");
    if (!frame.length) { return; }
    frame.addClass("ala-agent-native-drawer-frame is-open");
    region.classList.add("ala-agent-native-drawer-region");
  }

  function openNativeDrawer(title) {
    state.nativeDrawerCloseRequested = false;
    state.nativeDrawerClosePending = false;
    setNativeDrawerTitle(title);
    apex.theme.openRegion("ala-native-drawer");
    fixNativeDrawerFrame();
    global.requestAnimationFrame(fixNativeDrawerFrame);
  }

  function closeNativeDrawer() {
    var region = $("ala-native-drawer");
    if (!region) { return; }
    if (global.apex && apex.jQuery) {
      apex.jQuery(region).closest(".ui-dialog").removeClass("is-open");
    }
    apex.theme.closeRegion("ala-native-drawer");
  }

  function enableGovernedAccordions(viewer) {
    viewer.querySelectorAll(
      "details.ala-governed-subbucket-node,details.ala-governed-config-node"
    ).forEach(function (detail) {
      detail.addEventListener("toggle", function () {
        if (!detail.open) { return; }
        var className = detail.classList.contains("ala-governed-subbucket-node") ?
          "ala-governed-subbucket-node" : "ala-governed-config-node";
        Array.prototype.forEach.call(detail.parentElement.children, function (peer) {
          if (peer !== detail && peer.matches &&
              peer.matches("details." + className)) {
            peer.open = false;
          }
        });
      });
    });
  }

  function openGovernedViewer(html) {
    var editor = $("ala-inline-config-editor");
    var viewer = $("ala-applied-config-viewer");
    editor.hidden = true;
    viewer.hidden = false;
    viewer.innerHTML = html;
    $("ala-inline-config-workspace").setAttribute("aria-labelledby", "ala-governed-view-title");
    state.configurationDrawerOpen = true;
    state.configurationDrawerMode = "summary";
    enableGovernedAccordions(viewer);
    openNativeDrawer(
      viewer.querySelector(".ala-governed-view").dataset.drawerTitle
    );
    viewer.querySelectorAll("[data-close-governed-viewer]").forEach(function (button) {
      button.addEventListener("click", forceCloseConfigurationEditor);
    });
    var done = viewer.querySelector("[data-close-governed-viewer]");
    if (done) { done.focus(); }
  }

  function openSubbucketHierarchyViewer(id) {
    return hydrateSubbucketForViewer({id: Number(id)}).then(function (subbucket) {
      openGovernedViewer(governedViewerShell(
        "Subbucket classification", subbucket.name,
        "Read-only explanation of how agents receive this classification.",
        governedIdentityHtml([
          {label: "Code", value: subbucket.code},
          {label: "Status", value: subbucket.status},
          {label: "Version", value: subbucket.version},
          {label: "Visibility", value: subbucket.sharingMode}
        ]) + '<div class="ala-governed-hierarchy-label">' +
        "Subbucket → Configuration → Criteria → Result</div>" +
        '<div class="ala-governed-tree ala-governed-tree--root">' +
        governedSubbucketNodeHtml(subbucket, true) + "</div>"
      ));
      return subbucket;
    });
  }

  function openClassBucketHierarchyViewer(bucket) {
    var children = bucket && bucket.subbuckets ? bucket.subbuckets : [];
    return Promise.all(children.map(hydrateSubbucketForViewer)).then(function (subbuckets) {
      var assignment = bucket.assignmentMode === "SINGLE" ?
        "Select one winning classification" : "Allow multiple classifications";
      openGovernedViewer(governedViewerShell(
        "Business classification bucket", bucket.name,
        "Read-only explanation of how agents are classified.",
        governedIdentityHtml([
          {label: "Code", value: bucket.code},
          {label: "Status", value: bucket.status},
          {label: "Version", value: bucket.version},
          {label: "Visibility", value: bucket.sharingMode}
        ]) + (bucket.description ? '<p class="ala-applied-config-description">' +
          escapeHtml(bucket.description) + "</p>" : "") +
        '<section class="ala-governed-assignment"><span class="fa fa-info-circle"></span>' +
        '<div><strong>Assignment: ' + escapeHtml(assignment) + '</strong><small>' +
        (bucket.assignmentMode === "SINGLE" ?
          escapeHtml(readableCode(bucket.winnerStrategy)) :
          "Every matching Subbucket classification is retained.") +
        '</small></div></section><div class="ala-governed-hierarchy-label">' +
        'Bucket → Subbucket → Configuration → Criteria → Result</div>' +
        '<div class="ala-governed-root-node"><header><span class="ala-governed-node-icon">' +
        '<span class="fa fa-folder-o"></span></span><span><strong>' +
        escapeHtml(bucket.name || "Bucket") + '</strong><small>Business classification bucket</small>' +
        '</span></header><div class="ala-governed-tree">' +
        (subbuckets.length ? subbuckets.map(function (subbucket, index) {
          return governedSubbucketNodeHtml(subbucket, index === 0);
        }).join("") : '<div class="ala-governed-empty">No active Subbuckets are configured.</div>') +
        "</div></div>"
      ));
      return bucket;
    });
  }

  function toggleBucketConfigurationSummary(card) {
    var expanding = String(state.inlineConfigEditorVersionId) !==
      String(card.dataset.configVersionId);
    if (expanding) {
      openBucketConfigurationEditor(
        card.dataset.configId || null,
        card.dataset.configVersionId || null,
        card
      );
    } else {
      closeInlineConfigurationEditor(false);
    }
  }

  function renderBucketConfigurations() {
    if (!$("ala-bucket-configurations")) { return; }
    var rows = state.bucketConfigurations.map(bucketConfigurationMetadata);
    $("ala-bucket-configurations").innerHTML = rows.length ? rows.map(function (row) {
      var versionId = row.configVersionId || row.versionId;
      var editorOpen = state.configurationDrawerOpen &&
        String(state.inlineConfigEditorVersionId) === String(versionId);
      return '<article class="ala-config-card is-selected ala-config-card--picked ' +
        (editorOpen ? "is-inline-editing" : "") + '" ' +
        'data-config-version-id="' + versionId + '" data-config-id="' +
        escapeHtml(row.configId || row.id || "") + '">' +
        '<label class="ala-bucket-config-check" title="Uncheck to remove from this bucket">' +
        '<input data-role="bucket-selected" type="checkbox" checked aria-label="Selected ' +
        escapeHtml(row.name) + '"></label>' +
        '<button type="button" class="ala-config-card-body ala-config-summary-toggle" ' +
        'data-role="summary-toggle" aria-expanded="' + (editorOpen ? "true" : "false") +
        '"><strong>' + escapeHtml(row.name) +
        '</strong><small>' +
        escapeHtml(row.code) + " · Version " + row.version + " · " +
        escapeHtml(row.outputType || "BOOLEAN") +
        '</small><em>Click to open the configuration drawer</em></button>' +
        '<div class="ala-config-card-actions"><label class="ala-config-weight">Weight ' +
        '<input data-role="weight" type="number" min="0" step="0.1" value="' +
        escapeHtml(row.weight == null ? 1 : row.weight) + '"></label>' +
        '<label class="ala-config-mandatory"><input data-role="mandatory" type="checkbox" ' +
        (row.mandatory ? "checked" : "") + '> Mandatory</label>' +
        '<span class="ala-status-badge">' +
        escapeHtml("P" + (row.priority || 100)) + '</span><span class="ala-status-badge ala-risk-' +
        String(row.criticality || "MEDIUM").toLowerCase() + '">' +
        escapeHtml(row.criticality || "MEDIUM") + '</span><span data-role="summary-chevron" ' +
        'class="fa fa-chevron-' + (editorOpen ? "up" : "down") +
        '" aria-hidden="true"></span></div>' +
        '<div class="ala-config-summary" data-role="config-summary" hidden></div></article>';
    }).join("") : '<div class="ala-empty">No configurations selected. Use <strong>Add Configurations</strong> to pick one or more active definitions.</div>';
    $("ala-bucket-configurations").querySelectorAll("[data-role=bucket-selected]").forEach(function (checkbox) {
      checkbox.addEventListener("change", function () {
        if (checkbox.checked) { return; }
        syncBucketConfigurationsFromDom();
        renderBucketConfigurations();
        renderConfigPicker();
      });
    });
    $("ala-bucket-configurations").querySelectorAll("[data-role=summary-toggle]").forEach(function (button) {
      button.addEventListener("click", function () {
        toggleBucketConfigurationSummary(button.closest(".ala-config-card"));
      });
    });
    $("ala-bucket-configurations").querySelectorAll(".ala-config-card").forEach(function (card) {
      card.addEventListener("click", function (event) {
        if (event.target.closest("button,input,label,select")) { return; }
        toggleBucketConfigurationSummary(card);
      });
    });
    updateBucketConfigurationCount();
    updateFinalizerValueControl();
  }

  function updateBucketConfigurationCount() {
    var count = state.bucketConfigurations.length;
    $("ala-bucket-config-count").textContent = count + " selected";
    if ($("ala-config-picker-summary")) {
      $("ala-config-picker-summary").textContent = count + " configuration" +
        (count === 1 ? "" : "s") + " selected for this bucket";
    }
  }

  function syncBucketConfigurationsFromDom() {
    state.bucketConfigurations = Array.prototype.filter.call(
      $("ala-bucket-configurations").querySelectorAll(".ala-config-card"),
      function (card) {
        var checkbox = card.querySelector("[data-role=bucket-selected]");
        return !checkbox || checkbox.checked;
      }
    ).map(
      function (card) {
        var existing = selectedBucketConfiguration(card.dataset.configVersionId) || {};
        return Object.assign({}, existing, {
          configVersionId: Number(card.dataset.configVersionId),
          weight: Number(card.querySelector("[data-role=weight]").value || 1),
          mandatory: card.querySelector("[data-role=mandatory]").checked,
          metrics: [],
          enabled: true
        });
      }
    );
    updateBucketConfigurationCount();
    return state.bucketConfigurations;
  }

  function collectBucketConfigurations() {
    return syncBucketConfigurationsFromDom().map(function (item) {
      return {
        configVersionId: Number(item.configVersionId),
        weight: Number(item.weight == null ? 1 : item.weight),
        mandatory: !!item.mandatory,
        metrics: item.metrics || [],
        enabled: true
      };
    });
  }

  function renderConfigPicker() {
    if (!$("ala-config-picker-list")) { return; }
    var term = normalizeName($("ala-config-picker-search").value);
    var available = state.savedFilters.filter(function (row) {
      return row.status === "ACTIVE" && !isConfigurationSelected(row);
    });
    var rows = available.filter(function (row) {
      return !term || normalizeName(
        row.name + " " + row.code + " " + row.outputType + " " + row.riskClass
      ).indexOf(term) >= 0;
    });
    $("ala-config-picker-list").innerHTML = rows.length ? rows.map(function (row) {
      return '<article class="ala-config-pick-row" data-picker-version-id="' +
        row.versionId + '"><div><strong>' +
        escapeHtml(row.name) + '</strong><small>' + escapeHtml(row.code) + " · Version " +
        row.version + " · " + escapeHtml(row.outputType || "BOOLEAN") + " · " +
        escapeHtml(row.riskClass || "MEDIUM") + '</small></div><button type="button" ' +
        'class="ala-button ala-button--small"><span class="fa fa-plus"></span> Add</button></article>';
    }).join("") : '<div class="ala-empty">' +
      (available.length ? "No available configurations match this search." :
        "All active configurations are already selected for this bucket.") + "</div>";
    $("ala-config-picker-list").querySelectorAll("[data-picker-version-id] button")
      .forEach(function (button) {
        button.addEventListener("click", function () {
          syncBucketConfigurationsFromDom();
          var versionId = button.closest("[data-picker-version-id]").dataset.pickerVersionId;
          var row = state.savedFilters.find(function (item) {
            return String(item.versionId) === String(versionId);
          });
          if (row && !isConfigurationSelected(row)) {
            state.bucketConfigurations.push(Object.assign({}, row, {
              configId: Number(row.id),
              configVersionId: Number(row.versionId),
              weight: 1,
              mandatory: false,
              metrics: [],
              enabled: true
            }));
          }
          renderBucketConfigurations();
          renderConfigPicker();
        });
      });
    updateBucketConfigurationCount();
  }

  function openConfigPicker() {
    syncBucketConfigurationsFromDom();
    $("ala-config-picker-search").value = "";
    $("ala-config-picker").hidden = false;
    renderConfigPicker();
    setTimeout(function () { $("ala-config-picker-search").focus(); }, 0);
  }

  function closeConfigPicker() {
    $("ala-config-picker").hidden = true;
  }

  function leafConditions(node, rows) {
    rows = rows || [];
    (node && node.children || []).forEach(function (child) {
      if (child.children) {
        leafConditions(child, rows);
      } else {
        rows.push(child);
      }
    });
    return rows;
  }

  function conditionLabel(condition) {
    var field = state.fieldCatalog.find(function (item) {
      return item.key === condition.fieldKey;
    });
    var operator = condition.operator || condition.op || "";
    return (field ? field.label : condition.field || condition.fieldKey || "Condition") +
      " " + (operatorLabels[operator] || operator) +
      (condition.value !== "" && condition.value != null ? " " + condition.value : "") +
      (operator === "BETWEEN" && condition.value2 ? " and " + condition.value2 : "");
  }

  function shortConditionLabel(condition) {
    var field = state.fieldCatalog.find(function (item) {
      return item.key === condition.fieldKey;
    });
    var fieldName = field ? field.label :
      (condition.field || condition.fieldKey || "Condition");
    var operator = condition.operator || condition.op || "";
    var symbols = {
      EQ: "=", NE: "≠", GT: ">", GE: "≥", LT: "<", LE: "≤",
      IN: "in", NOT_IN: "not in", CONTAINS: "contains",
      STARTS_WITH: "starts", ENDS_WITH: "ends"
    };
    if (operator === "IS_NULL") { return fieldName + " is empty"; }
    if (operator === "IS_NOT_NULL") { return fieldName + " has value"; }
    if (operator === "BETWEEN") {
      return fieldName + " " + (condition.value == null ? "—" : condition.value) +
        "–" + (condition.value2 == null ? "—" : condition.value2);
    }
    var value = condition.value;
    if (Array.isArray(value)) { value = value.join(", "); }
    return fieldName + " " + (symbols[operator] || operatorLabels[operator] || operator) +
      (value !== "" && value != null ? " " + value : "");
  }

  function syncSelectedRecommendationFromDom() {
    var detail = document.querySelector(
      "#ala-recommendation-editor [data-recommendation-detail]"
    );
    if (!detail) { return; }
    var rec = state.recommendations.find(function (row) {
      return String(row.conditionId) === String(detail.dataset.recommendationDetail);
    });
    if (!rec) { return; }
    rec.findingType = detail.querySelector("[data-rec=finding-type]").value.trim();
    rec.template = detail.querySelector("[data-rec=template]").value.trim();
    rec.moduleCode = detail.querySelector("[data-rec=module]").value;
    rec.workflowAction = detail.querySelector("[data-rec=action]").value.trim();
    rec.slaMode = detail.querySelector("[data-rec=sla-mode]").value;
    rec.slaValue = detail.querySelector("[data-rec=sla-value]") ?
      Number(detail.querySelector("[data-rec=sla-value]").value) : null;
    rec.slaUnit = detail.querySelector("[data-rec=sla-unit]") ?
      detail.querySelector("[data-rec=sla-unit]").value : "MINUTE";
    rec.slaDeadline = detail.querySelector("[data-rec=sla-deadline]") ?
      detail.querySelector("[data-rec=sla-deadline]").value : "";
    rec.slaTimezone = "Asia/Kolkata";
    rec.slaMinutes = rec.slaMode === "DURATION" ?
      Number(rec.slaValue || 0) * {
        MINUTE: 1, HOUR: 60, DAY: 1440, WEEK: 10080
      }[rec.slaUnit] : 1;
    rec.escalationRole = detail.querySelector("[data-rec=escalation]").value.trim();
    rec.approvalRequired = detail.querySelector("[data-rec=approval]").checked;
    rec.enabled = detail.querySelector("[data-rec=enabled]").checked;
    rec.expectedValueMode = detail.querySelector("[data-rec=expected-mode]") ?
      detail.querySelector("[data-rec=expected-mode]").value : "OUTCOME";
    rec.expectedFixedValue = detail.querySelector("[data-rec=expected-fixed]") ?
      detail.querySelector("[data-rec=expected-fixed]").value.trim() : "";
    rec.expectedBaseSource = detail.querySelector("[data-rec=expected-base]") ?
      detail.querySelector("[data-rec=expected-base]").value : "BASELINE";
    rec.expectedOperator = detail.querySelector("[data-rec=expected-operator]") ?
      detail.querySelector("[data-rec=expected-operator]").value : "PERCENT_INCREASE";
    rec.expectedOperand = detail.querySelector("[data-rec=expected-operand]") ?
      Number(detail.querySelector("[data-rec=expected-operand]").value) : null;
  }

  function collectRecommendationRows() {
    syncSelectedRecommendationFromDom();
    return state.recommendations || [];
  }

  function workflowActionAllowed(action, moduleCode) {
    if (!action) { return false; }
    var modules = String(action.moduleCodes || "").split(",").map(function (code) {
      return code.trim();
    }).filter(Boolean);
    return !modules.length || modules.indexOf(moduleCode) >= 0;
  }

  function recommendationIsComplete(rec) {
    var catalog = state.recommendationCatalog || {};
    var validFindingType = (catalog.findingTypes || []).some(function (row) {
      return row.value === rec.findingType;
    });
    var validAction = (catalog.workflowActions || []).some(function (row) {
      return row.value === rec.workflowAction && workflowActionAllowed(row, rec.moduleCode);
    });
    var validRole = (catalog.escalationRoles || []).some(function (row) {
      return row.name === rec.escalationRole;
    });
    var validSla = rec.slaMode === "FIXED_DATETIME" ?
      !!rec.slaDeadline :
      (Number(rec.slaValue) > 0 && ["MINUTE","HOUR","DAY","WEEK"].indexOf(rec.slaUnit) >= 0);
    return !!(
      validFindingType && rec.template && rec.moduleCode && validAction && validRole &&
      validSla &&
      (rec.conditionId === "OUTCOME:MATCH" ||
      (rec.expectedValueMode !== "FIXED" || rec.expectedFixedValue) &&
      (rec.expectedValueMode !== "CALCULATED" ||
        (rec.expectedBaseSource && rec.expectedOperator &&
         rec.expectedOperand != null && rec.expectedOperand !== "")))
    );
  }

  function expectedValueControls(rec, condition) {
    var mode = rec.expectedValueMode || "CONDITION_VALUE";
    var threshold = condition.value2 != null && condition.value2 !== "" ?
      String(condition.value) + " to " + String(condition.value2) :
      String(condition.value == null ? "" : condition.value);
    var html =
      '<div class="ala-control"><label>Expected value strategy</label>' +
      '<select data-rec="expected-mode"><option value="CONDITION_VALUE"' +
      (mode === "CONDITION_VALUE" ? " selected" : "") +
      '>Condition threshold</option><option value="BASELINE"' +
      (mode === "BASELINE" ? " selected" : "") +
      '>Evidence baseline</option><option value="FIXED"' +
      (mode === "FIXED" ? " selected" : "") +
      '>Fixed value</option><option value="CALCULATED"' +
      (mode === "CALCULATED" ? " selected" : "") +
      '>Controlled calculation</option></select></div>';
    if (mode === "CONDITION_VALUE") {
      html += '<div class="ala-expected-summary"><span>Resolved from this condition</span><strong>' +
        escapeHtml(threshold || "Not yet entered") + "</strong></div>";
    } else if (mode === "BASELINE") {
      html += '<div class="ala-expected-summary"><span>Runtime source</span><strong>' +
        'Condition evidence baseline</strong><small>Falls back to the condition threshold when evidence has no baseline.</small></div>';
    } else if (mode === "FIXED") {
      html += '<div class="ala-control"><label>Fixed expected value</label>' +
        '<input data-rec="expected-fixed" maxlength="4000" value="' +
        escapeHtml(rec.expectedFixedValue || "") + '" placeholder="e.g. 95"></div>';
    } else {
      html += '<div class="ala-control"><label>Calculation base</label>' +
        '<select data-rec="expected-base"><option value="BASELINE"' +
        (rec.expectedBaseSource === "BASELINE" || !rec.expectedBaseSource ? " selected" : "") +
        '>Evidence baseline</option><option value="CONDITION_VALUE"' +
        (rec.expectedBaseSource === "CONDITION_VALUE" ? " selected" : "") +
        '>Condition threshold</option><option value="ACTUAL_VALUE"' +
        (rec.expectedBaseSource === "ACTUAL_VALUE" ? " selected" : "") +
        '>Actual detected value</option></select></div>' +
        '<div class="ala-control"><label>Operation</label><select data-rec="expected-operator">' +
        [
          ["PERCENT_INCREASE", "Increase by %"],
          ["PERCENT_DECREASE", "Decrease by %"],
          ["ADD", "Add"],
          ["SUBTRACT", "Subtract"],
          ["MULTIPLY", "Multiply by"],
          ["DIVIDE", "Divide by"]
        ].map(function (option) {
          return '<option value="' + option[0] + '"' +
            (rec.expectedOperator === option[0] ? " selected" : "") + ">" +
            option[1] + "</option>";
        }).join("") + '</select></div><div class="ala-control"><label>Operand</label>' +
        '<input data-rec="expected-operand" type="number" step="any" value="' +
        escapeHtml(rec.expectedOperand == null ? 10 : rec.expectedOperand) + '"></div>';
    }
    return html;
  }

  function slaControls(rec) {
    var mode = rec.slaMode || "DURATION";
    var html =
      '<div class="ala-control"><label>SLA mode</label><select data-rec="sla-mode">' +
      '<option value="DURATION"' + (mode === "DURATION" ? " selected" : "") +
      '>Duration after finding</option><option value="FIXED_DATETIME"' +
      (mode === "FIXED_DATETIME" ? " selected" : "") +
      '>Specific date &amp; time</option></select></div>';
    if (mode === "FIXED_DATETIME") {
      html += '<div class="ala-control ala-control--sla-wide"><label>Deadline</label>' +
        '<input data-rec="sla-deadline" type="datetime-local" value="' +
        escapeHtml(rec.slaDeadline || "") + '"><small>Asia/Kolkata</small></div>';
    } else {
      html += '<div class="ala-control"><label>Duration</label><input data-rec="sla-value" ' +
        'type="number" min="1" step="1" value="' + escapeHtml(rec.slaValue || 1) +
        '"></div><div class="ala-control"><label>Unit</label><select data-rec="sla-unit">' +
        ["MINUTE","HOUR","DAY","WEEK"].map(function (unit) {
          return '<option value="' + unit + '"' +
            (rec.slaUnit === unit ? " selected" : "") + ">" +
            unit.charAt(0) + unit.slice(1).toLowerCase() + (unit === "DAY" ? "s" : "s") +
            "</option>";
        }).join("") + "</select></div>";
    }
    return html;
  }

  function numericPreviewValue(value) {
    var result = Number(value);
    return value !== "" && value != null && Number.isFinite(result) ? result : null;
  }

  function runtimePreviewPeriod(mode, toDate) {
    var end = new Date(String(toDate) + "T00:00:00Z");
    var start = new Date(end.getTime());
    if (mode === "MONTHLY") {
      start.setUTCDate(1);
    } else if (mode === "YEAR_360") {
      start.setUTCDate(start.getUTCDate() - 359);
    }
    function iso(date) { return date.toISOString().slice(0, 10); }
    return {from: iso(start), to: iso(end)};
  }

  function defaultRecommendationValueMappings() {
    return {
      agent_id: "RBAC_MATCHED_AGENT",
      actual_value: "CONDITION_FIELD",
      condition_value: "RULE_THRESHOLD",
      baseline_value: "CONDITION_EVIDENCE_BASELINE",
      expected_value: "EXPECTED_VALUE_STRATEGY",
      variance_value: "ACTUAL_MINUS_EXPECTED",
      period: "EVALUATION_WINDOW"
    };
  }

  function defaultOutcomeRecommendationValueMappings() {
    return {
      agent_id: "RBAC_MATCHED_AGENT",
      outcome: "RULE_OUTCOME",
      condition_summary: "RULE_DEFINITION",
      matched_condition_count: "MATCHED_CONDITION_COUNT",
      evidence_summary: "MATCHED_CONDITION_EVIDENCE",
      period: "EVALUATION_WINDOW"
    };
  }

  function outcomeRuleSummary(ruleDefinition) {
    var conditions = leafConditions(ruleDefinition);
    var join = ruleDefinition && ruleDefinition.operator === "OR" ? "ANY" : "ALL";
    if (conditions.length === 1) {
      return "The configured condition matched";
    }
    return join + " of " + conditions.length + " configured conditions matched";
  }

  function compactRecommendationValue(value, fallback) {
    if (value == null || value === "") { return fallback; }
    var text = String(value);
    if (text.length < 120 && !/^[\[{]/.test(text.trim())) { return text; }
    try {
      var parsed = JSON.parse(text);
      if (Array.isArray(parsed)) {
        return "JSON array · " + parsed.length + " item" + (parsed.length === 1 ? "" : "s");
      }
      if (parsed && typeof parsed === "object") {
        var keys = Object.keys(parsed);
        return "JSON object · " + keys.slice(0,3).join(", ") +
          (keys.length > 3 ? " +" + (keys.length - 3) : "");
      }
    } catch (ignore) {
      return text.length > 116 ? text.slice(0,113) + "…" : text;
    }
    return text.length > 116 ? text.slice(0,113) + "…" : text;
  }

  function recommendationValueMappingHtml(condition, recommendation) {
    var preview = state.recommendationPreviews[recommendation.conditionId] || {};
    function shown(value, fallback) {
      return value == null || value === "" ? fallback : String(value);
    }
    if (recommendation.conditionId === "OUTCOME:MATCH") {
      var outcomeRows = [
        ["agent_id", "Complete rule match → RBAC-authorized agent",
          shown(preview.agentId, "Resolved after matching")],
        ["outcome", "Configuration result → result_state",
          shown(preview.outcome, "MATCH")],
        ["condition_summary", "Saved rule definition → AND/OR outcome",
          shown(preview.conditionSummary, outcomeRuleSummary(condition))],
        ["matched_condition_count", "Matched condition evidence → count",
          shown(preview.matchedConditionCount, "Resolved at runtime")],
        ["evidence_summary", "Matched condition evidence → consolidated summary",
          shown(preview.evidenceSummary, "Stored with the finding")],
        ["period", "Configuration window → resolved from / to",
          shown(preview.period, "Resolved at runtime")]
      ];
      return '<section class="ala-value-mapping"><header><div><strong>Outcome value mapping</strong>' +
        '<small>Tokens come from the complete rule result and its stored condition evidence.</small>' +
        '</div><span class="ala-status-badge"><span class="fa fa-lock"></span> Governed</span>' +
        '</header><div class="ala-value-mapping-table"><div class="ala-mapping-head">' +
        '<span>Template token</span><span>Mapped source</span><span>Current matched value</span>' +
        '</div>' + outcomeRows.map(function (row) {
          return '<div class="ala-mapping-row"><button type="button" data-insert-token="{{' +
            row[0] + '}}" title="Insert this mapped token"><code>{{' + row[0] +
            '}}</code></button><span>' + escapeHtml(row[1]) + '</span><strong>' +
            escapeHtml(row[2]) + '</strong></div>';
        }).join("") + '</div></section>';
    }
    var actualSource = [
      preview.sourceFamily, preview.sourceName, preview.jsonPath
    ].filter(Boolean).join(" · ");
    var strategyLabels = {
      CONDITION_VALUE: "Condition threshold",
      BASELINE: "Evidence baseline",
      FIXED: "Configured fixed value",
      CALCULATED: "Controlled calculation"
    };
    var rows = [
      ["agent_id", "RBAC matched result → agent_id",
        shown(preview.agentId, "Resolved after matching")],
      ["actual_value", actualSource || "Selected condition → governed field",
        compactRecommendationValue(preview.actualValue, "Resolved after matching")],
      ["condition_value", "Selected condition → value / value2",
        shown(preview.conditionValue, condition.value == null ? "Not configured" : condition.value)],
      ["baseline_value", "Condition evidence → baseline_value",
        shown(preview.baselineValue, "Not produced")],
      ["expected_value", "Expected strategy → " +
        (strategyLabels[recommendation.expectedValueMode] || "Condition threshold"),
        shown(preview.expectedValue, "Resolved after matching")],
      ["variance_value", "Formula → actual_value − expected_value",
        shown(preview.varianceValue, "Requires numeric values")],
      ["period", "Configuration window → resolved from / to",
        shown(preview.period, "Resolved at runtime")]
    ];
    return '<section class="ala-value-mapping"><header><div><strong>Template value mapping</strong>' +
      '<small>Every token is bound to an approved source—no inferred or typed sample values.</small>' +
      '</div><span class="ala-status-badge"><span class="fa fa-lock"></span> Governed</span>' +
      '</header><div class="ala-value-mapping-table"><div class="ala-mapping-head">' +
      '<span>Template token</span><span>Mapped source</span><span>Current matched value</span>' +
      '</div>' + rows.map(function (row) {
        return '<div class="ala-mapping-row"><button type="button" data-insert-token="{{' +
          row[0] + '}}" title="Insert this mapped token"><code>{{' + row[0] +
          '}}</code></button><span>' + escapeHtml(row[1]) + '</span><strong>' +
          escapeHtml(row[2]) + '</strong></div>';
      }).join("") + '</div></section>';
  }

  function bindRecommendationTokenButtons(root) {
    root.querySelectorAll("[data-insert-token]").forEach(function (button) {
      button.addEventListener("click", function () {
        var panel = $("ala-recommendation-editor");
        var textarea = panel && panel.querySelector("[data-rec=template]");
        if (!textarea) { return; }
        var token = button.dataset.insertToken;
        var start = textarea.selectionStart == null ? textarea.value.length : textarea.selectionStart;
        var end = textarea.selectionEnd == null ? start : textarea.selectionEnd;
        textarea.value = textarea.value.slice(0,start) + token + textarea.value.slice(end);
        textarea.focus();
        textarea.setSelectionRange(start + token.length,start + token.length);
        updateRecommendationPreview();
      });
    });
  }

  function recommendationPreviewContent(conditionId) {
    var preview = state.recommendationPreviews[conditionId] || {status: "loading"};
    if (preview.status === "loading") {
      return '<div class="ala-match-preview-state"><span class="fa fa-spinner fa-spin"></span>' +
        '<strong>Finding an actual matched case…</strong><small>The current condition is being ' +
        'evaluated against RBAC-authorized agents.</small></div>';
    }
    if (preview.status === "error") {
      return '<div class="ala-match-preview-state is-error"><span class="fa fa-warning"></span>' +
        '<strong>Matched-case preview could not be loaded</strong><small>' +
        escapeHtml(preview.message || "Preview request failed.") +
        '</small><button type="button" class="t-Button t-Button--small" data-refresh-match-preview>' +
        '<span class="fa fa-refresh"></span> Retry</button></div>';
    }
    if (!preview.matched) {
      return '<div class="ala-match-preview-state"><span class="fa fa-info-circle"></span>' +
        '<strong>No actual case matches this condition</strong><small>' +
        escapeHtml(preview.message || "Validate the condition or evaluation window.") +
        '</small><button type="button" class="t-Button t-Button--small" data-refresh-match-preview>' +
        '<span class="fa fa-refresh"></span> Recheck</button></div>';
    }
    function value(value, fallback) {
      return compactRecommendationValue(value,fallback);
    }
    if (preview.outcomeMode) {
      return '<header><div><strong>Actual complete-rule match</strong><small>' +
        escapeHtml("Case " + (Number(preview.caseIndex || 0) + 1) + " · " +
          value(preview.agentName, preview.agentId) + " (" + preview.agentId + ")") +
        '</small></div><div class="ala-preview-actions"><span class="ala-status-badge">' +
        fmt.format(preview.matchedAgents || 0) + ' complete-rule matches</span>' +
        '<button type="button" class="t-Button t-Button--small" data-refresh-match-preview ' +
        'title="Refresh from the matching engine"><span class="fa fa-refresh"></span></button>' +
        '<button type="button" class="t-Button t-Button--small" data-next-match-preview ' +
        (preview.hasNext ? "" : "disabled") + '>Next case <span class="fa fa-chevron-right"></span>' +
        '</button></div></header><div class="ala-preview-evidence-source">' +
        '<span class="fa fa-check-circle"></span><div><strong>Overall outcome: MATCH</strong>' +
        '<small>' + escapeHtml(preview.conditionSummary) +
        '</small></div></div><p class="ala-rec-preview-message">' +
        escapeHtml(preview.message) + '</p><div class="ala-rec-values ala-rec-values--outcome">' +
        '<span>Outcome<strong>MATCH</strong></span><span>Conditions<strong>' +
        escapeHtml(value(preview.matchedConditionCount, "Resolved at runtime")) +
        '</strong></span><span>Evidence<strong>' +
        escapeHtml(value(preview.evidenceSummary, "Stored with finding")) +
        '</strong></span><span>Period<strong>' +
        escapeHtml(value(preview.period, "Not resolved")) + '</strong></span></div>';
    }
    var source = [
      preview.sourceFamily, preview.sourceName, preview.jsonPath
    ].filter(Boolean).join(" · ");
    var previewMessage = String(preview.message || "");
    if (preview.actualValue && String(preview.actualValue).length > 120) {
      previewMessage = previewMessage.replace(
        String(preview.actualValue),
        compactRecommendationValue(preview.actualValue,"Matched JSON evidence")
      );
    }
    return '<header><div><strong>Actual matched-case preview</strong><small>' +
      escapeHtml("Case " + (Number(preview.caseIndex || 0) + 1) + " · " +
        value(preview.agentName, preview.agentId) + " (" + preview.agentId + ")") +
      '</small></div><div class="ala-preview-actions"><span class="ala-status-badge">' +
      fmt.format(preview.matchedAgents || 0) + ' matches</span>' +
      '<button type="button" class="t-Button t-Button--small" data-refresh-match-preview ' +
      'title="Refresh from the matching engine"><span class="fa fa-refresh"></span></button>' +
      '<button type="button" class="t-Button t-Button--small" data-next-match-preview ' +
      (preview.hasNext ? "" : "disabled") + '>Next case <span class="fa fa-chevron-right"></span>' +
      '</button></div></header><div class="ala-preview-evidence-source">' +
      '<span class="fa fa-database"></span><div><strong>' +
      escapeHtml(preview.fieldName || preview.fieldKey || "Governed field") +
      '</strong><small>' + escapeHtml(source || "Governed analytics source") +
      '</small></div></div><p class="ala-rec-preview-message">' +
      escapeHtml(previewMessage) + '</p><div class="ala-rec-values">' +
      '<span>Actual<strong>' + escapeHtml(value(preview.actualValue, "Not available")) +
      '</strong></span><span>Condition<strong>' +
      escapeHtml(value(preview.conditionValue, "Not configured")) +
      '</strong></span><span>Baseline<strong>' +
      escapeHtml(value(preview.baselineValue, "Not produced")) +
      '</strong></span><span>Expected<strong>' +
      escapeHtml(value(preview.expectedValue, "Not available")) +
      '</strong></span><span>Variance<strong>' +
      escapeHtml(value(preview.varianceValue, "Not numeric")) +
      '</strong></span><span>Period<strong>' +
      escapeHtml(value(preview.period, "Not resolved")) + '</strong></span></div>';
  }

  function bindRecommendationPreviewActions(condition, recommendation) {
    var previewKey = recommendation.conditionId;
    var preview = document.querySelector(
      '.ala-recommendation-preview[data-preview-condition="' +
      cssEscape(previewKey) + '"]'
    );
    if (!preview) { return; }
    var refresh = preview.querySelector("[data-refresh-match-preview]");
    var next = preview.querySelector("[data-next-match-preview]");
    if (refresh) {
      refresh.addEventListener("click", function () {
        requestRecommendationPreview(condition,recommendation,true,0);
      });
    }
    if (next) {
      next.addEventListener("click", function () {
        var current = state.recommendationPreviews[previewKey] || {};
        requestRecommendationPreview(
          condition,recommendation,true,Number(current.caseIndex || 0) + 1
        );
      });
    }
  }

  function paintRecommendationPreview(condition, recommendation) {
    var previewKey = recommendation.conditionId;
    var preview = document.querySelector(
      '.ala-recommendation-preview[data-preview-condition="' +
      cssEscape(previewKey) + '"]'
    );
    if (!preview) { return; }
    preview.innerHTML = recommendationPreviewContent(previewKey);
    var detail = preview.closest("[data-recommendation-detail]");
    var mapping = detail && detail.querySelector(".ala-value-mapping");
    if (mapping) {
      mapping.outerHTML = recommendationValueMappingHtml(condition,recommendation);
      bindRecommendationTokenButtons(detail.querySelector(".ala-value-mapping"));
    }
    bindRecommendationPreviewActions(condition,recommendation);
  }

  function requestRecommendationPreview(condition, recommendation, force, caseIndex) {
    var conditionId = recommendation.conditionId;
    var existing = state.recommendationPreviews[conditionId];
    if (!force && existing && existing.status !== "error") {
      paintRecommendationPreview(condition,recommendation);
      return;
    }
    var generation = Number((existing || {}).generation || 0) + 1;
    state.recommendationPreviews[conditionId] = {
      status: "loading", generation: generation,
      caseIndex: caseIndex == null ? Number((existing || {}).caseIndex || 0) : caseIndex
    };
    paintRecommendationPreview(condition,recommendation);
    var outcomeMode = recommendation.conditionId === "OUTCOME:MATCH";
    var outcomeConditions = outcomeMode ? condition : {operator: "AND", children: [condition]};
    var previewCondition = outcomeMode ? leafConditions(condition)[0] : condition;
    var dashboardPayload = filterPayload({
      kind: "CONFIG",
      conditions: outcomeConditions,
      configDateScope: collectWindowScope()
    }, {authorizedDefinitionScope: true});
    dashboardPayload.reportOnly = "Y";
    server("AGENT_LOCATION_DASHBOARD", {x01: JSON.stringify(dashboardPayload)})
      .then(function (matchResult) {
        var period = runtimePreviewPeriod(dashboardPayload.mode,matchResult.toDate);
        return server("AGENT_ADV_RECOMMENDATION_PREVIEW", {
          x01: JSON.stringify({
            condition: previewCondition,
            conditions: outcomeConditions,
            recommendation: recommendation,
            configDateScope: collectWindowScope(),
            runtimeFrom: period.from,
            runtimeTo: period.to,
            caseIndex: state.recommendationPreviews[conditionId].caseIndex
          })
        }).then(function (previewResult) {
          previewResult.matchedAgents = Number(matchResult.agents || 0);
          if (outcomeMode) {
            var outcomeLeaves = leafConditions(outcomeConditions);
            var completeSummary = outcomeRuleSummary(outcomeConditions);
            var matchedCount = outcomeConditions.operator === "OR" ?
              "1 or more of " + outcomeLeaves.length :
              outcomeLeaves.length + " of " + outcomeLeaves.length;
            var evidenceSummary = outcomeLeaves.map(function (row, index) {
              return (index + 1) + ". " + shortConditionLabel(row);
            }).join("; ");
            previewResult.outcomeMode = true;
            previewResult.outcome = "MATCH";
            previewResult.conditionSummary = completeSummary;
            previewResult.matchedConditionCount = matchedCount;
            previewResult.evidenceSummary = evidenceSummary;
            previewResult.message = String(recommendation.template || "")
              .replace(/\{\{agent_id\}\}/g,previewResult.agentId || "")
              .replace(/\{\{outcome\}\}/g,"MATCH")
              .replace(/\{\{condition_summary\}\}/g,completeSummary)
              .replace(/\{\{matched_condition_count\}\}/g,matchedCount)
              .replace(/\{\{evidence_summary\}\}/g,evidenceSummary)
              .replace(/\{\{period\}\}/g,previewResult.period || "");
          }
          return previewResult;
        });
      })
      .then(function (previewResult) {
        var current = state.recommendationPreviews[conditionId];
        if (!current || current.generation !== generation) { return; }
        state.recommendationPreviews[conditionId] = Object.assign(
          {status: "ready", generation: generation},previewResult
        );
        paintRecommendationPreview(condition,recommendation);
      })
      .catch(function (error) {
        var current = state.recommendationPreviews[conditionId];
        if (!current || current.generation !== generation) { return; }
        state.recommendationPreviews[conditionId] = {
          status: "error", generation: generation, message: error.message
        };
        paintRecommendationPreview(condition,recommendation);
      });
  }

  function updateRecommendationPreview() {
    global.clearTimeout(recommendationPreviewTimer);
    recommendationPreviewTimer = global.setTimeout(function () {
      syncSelectedRecommendationFromDom();
      var detail = document.querySelector(
        "#ala-recommendation-editor [data-recommendation-detail]"
      );
      if (!detail) { return; }
      var ruleDefinition = collectConditions();
      var condition = detail.dataset.recommendationDetail === "OUTCOME:MATCH" ?
        ruleDefinition : leafConditions(ruleDefinition).find(function (row) {
          return String(row.conditionId) === String(detail.dataset.recommendationDetail);
        });
      var recommendation = state.recommendations.find(function (row) {
        return String(row.conditionId) === String(detail.dataset.recommendationDetail);
      });
      if (condition && recommendation) {
        requestRecommendationPreview(condition,recommendation,true,0);
      }
    },450);
  }

  function durationParts(minutes) {
    minutes = Number(minutes || 1440);
    if (minutes % 10080 === 0) { return {value: minutes / 10080, unit: "WEEK"}; }
    if (minutes % 1440 === 0) { return {value: minutes / 1440, unit: "DAY"}; }
    if (minutes % 60 === 0) { return {value: minutes / 60, unit: "HOUR"}; }
    return {value: minutes, unit: "MINUTE"};
  }

  function preferredEscalationRole(moduleCode) {
    var preferred = {
      AAM: "Auditor",
      ARM: "Supervisor",
      ADRM: "CO Manager",
      SPM: "Supervisor",
      TCM: "CO Manager"
    }[moduleCode];
    var roles = (state.recommendationCatalog || {}).escalationRoles || [];
    return (roles.find(function (row) { return row.name === preferred; }) ||
      roles[0] || {}).name || "";
  }

  function renderRecommendationEditor() {
    var panel = $("ala-recommendation-editor");
    if (!panel) { return; }
    syncSelectedRecommendationFromDom();
    var ruleDefinition = collectConditions();
    var conditions = leafConditions(ruleDefinition);
    var existing = {};
    (state.recommendations || []).forEach(function (row) {
      existing[row.conditionId] = row;
    });
    var defaultModule = state.modules.find(function (row) { return row.active; }) ||
      {code: "ARM", defaultSlaMinutes: 240, escalationRole: "Risk Operations Lead"};
    var defaultDuration = durationParts(defaultModule.defaultSlaMinutes || 1440);
    state.recommendations = conditions.map(function (condition, index) {
      var current = existing[condition.conditionId] || {};
      var label = conditionLabel(condition);
      var generatedTemplate = "Review agent {{agent_id}} because " + label +
        " matched during {{period}}. Actual {{actual_value}}; expected {{expected_value}}.";
      var currentTemplate = String(current.template || "");
      if (/^Review agent \{\{agent_id\}\} because .+ matched during \{\{period\}\}\. Actual \{\{actual_value\}\}; expected \{\{expected_value\}\}\.$/.test(
        currentTemplate
      )) {
        current = Object.assign({},current,{template:generatedTemplate});
      }
      var merged = Object.assign({
        conditionId: condition.conditionId,
        sequence: index + 1,
        findingType: "Condition Finding",
        template: generatedTemplate,
        expectedValueMode: "CONDITION_VALUE",
        expectedFixedValue: "",
        expectedBaseSource: "BASELINE",
        expectedOperator: "PERCENT_INCREASE",
        expectedOperand: 10,
        moduleCode: defaultModule.code,
        workflowAction: "Create Investigation",
        slaMinutes: defaultModule.defaultSlaMinutes || 1440,
        slaMode: "DURATION",
        slaValue: defaultDuration.value,
        slaUnit: defaultDuration.unit,
        slaDeadline: "",
        slaTimezone: "Asia/Kolkata",
        escalationRole: preferredEscalationRole(defaultModule.code),
        approvalRequired: false,
        enabled: true
      }, current, {conditionId: condition.conditionId, sequence: index + 1});
      merged.expectedValueMode = merged.expectedValueMode || "CONDITION_VALUE";
      merged.valueMappings = Object.assign(
        defaultRecommendationValueMappings(), merged.valueMappings || {}
      );
      merged.expectedBaseSource = merged.expectedBaseSource || "BASELINE";
      merged.expectedOperator = merged.expectedOperator || "PERCENT_INCREASE";
      if (merged.expectedValueMode === "CALCULATED" &&
          merged.expectedOperand == null) {
        merged.expectedOperand = 10;
      }
      merged.slaMode = merged.slaMode || "DURATION";
      if (merged.slaMode === "DURATION" && merged.slaValue == null) {
        var duration = durationParts(merged.slaMinutes);
        merged.slaValue = duration.value;
        merged.slaUnit = duration.unit;
      }
      merged.slaUnit = merged.slaUnit || "MINUTE";
      merged.slaTimezone = merged.slaTimezone || "Asia/Kolkata";
      return merged;
    });
    if (!conditions.length) {
      state.selectedRecommendationConditionId = null;
      panel.innerHTML = '<div class="ala-empty ala-results-placeholder"><span class="fa fa-lightbulb-o"></span>' +
        '<strong>Add conditions first.</strong><small>Each condition receives its own personalized recommendation and module route.</small></div>';
      return;
    }
    if (!state.recommendations.some(function (row) {
      return String(row.conditionId) === String(state.selectedRecommendationConditionId);
    })) {
      state.selectedRecommendationConditionId = state.recommendations[0].conditionId;
    }
    var selectedIndex = state.recommendations.findIndex(function (row) {
      return String(row.conditionId) === String(state.selectedRecommendationConditionId);
    });
    var selected = state.recommendations[selectedIndex];
    var selectedCondition = conditions[selectedIndex];
    var completeCount = state.recommendations.filter(recommendationIsComplete).length;
    var overallJoin = ruleDefinition.operator === "OR" ? "ANY" : "ALL";
    var moduleOptions = state.modules.filter(function (item) { return item.active; })
      .map(function (item) {
        return '<option value="' + escapeHtml(item.code) + '"' +
          (item.code === selected.moduleCode ? " selected" : "") + ">" +
          escapeHtml(item.code + " — " + item.name) + "</option>";
      }).join("");
    var catalog = state.recommendationCatalog || {};
    function governedOptions(items, current, valueKey, labelBuilder) {
      var known = (items || []).some(function (item) {
        return item[valueKey] === current;
      });
      var html = '<option value="">Select governed value</option>';
      if (current && !known) {
        html += '<option value="' + escapeHtml(current) +
          '" selected>Legacy — remap required: ' + escapeHtml(current) + "</option>";
      }
      return html + (items || []).map(function (item) {
        var value = item[valueKey];
        return '<option value="' + escapeHtml(value) + '"' +
          (value === current ? " selected" : "") + ">" +
          escapeHtml(labelBuilder(item)) + "</option>";
      }).join("");
    }
    var findingTypeOptions = governedOptions(
      catalog.findingTypes || [],selected.findingType,"value",function (item) {
        return item.label;
      }
    );
    var allowedActions = (catalog.workflowActions || []).filter(function (item) {
      return workflowActionAllowed(item,selected.moduleCode);
    });
    var workflowActionOptions = governedOptions(
      allowedActions,selected.workflowAction,"value",function (item) {
        return item.label;
      }
    );
    var escalationRoleOptions = governedOptions(
      catalog.escalationRoles || [],selected.escalationRole,"name",function (item) {
        return item.groupName + " — " + item.name;
      }
    );
    panel.innerHTML =
      '<div class="ala-recommendation-heading"><div><h3>Recommendations &amp; Routing</h3>' +
      '<p>Configure one clear finding route for each condition.</p></div>' +
      '<span class="ala-status-badge">' + completeCount + ' of ' + conditions.length +
      ' ready</span></div><div class="ala-recommendation-rule-note">' +
      '<span class="fa fa-link"></span><div><strong>' +
      (conditions.length === 1 ? "Overall rule: one condition" :
        "Overall rule: " + overallJoin + " of " + conditions.length + " conditions") +
      '</strong><small>' + (overallJoin === "ALL" ?
        "The agent must satisfy every condition. Configure each condition’s finding and route below." :
        "The agent may satisfy any condition. Only matched conditions create their configured finding route.") +
      '</small></div></div>' +
      '<div class="ala-recommendation-master-detail"><aside class="ala-recommendation-master">' +
      '<div class="ala-recommendation-master-head"><strong>Condition routes</strong><b>' +
      fmt.format(state.recommendations.length) + '</b></div>' +
      state.recommendations.map(function (rec, index) {
        var complete = recommendationIsComplete(rec);
        return '<button type="button" data-select-recommendation="' +
          escapeHtml(rec.conditionId) + '" class="' +
          (index === selectedIndex ? "is-active" : "") + '"><span class="ala-rec-sequence ' +
          (complete ? "is-complete" : "is-incomplete") + '">' + (index + 1) +
          '</span><span><strong>' +
          escapeHtml(conditionLabel(conditions[index])) + '</strong><small>' +
          '<span class="ala-rec-module">' + escapeHtml(rec.moduleCode || "No module") +
          '</span><em class="' + (complete ? "is-complete" : "is-incomplete") + '">' +
          (rec.enabled === false ? "Off" : complete ? "Ready" : "Setup") +
          '</em></small></span><span class="fa fa-chevron-right"></span></button>';
      }).join("") + '</aside><article class="ala-recommendation-detail" data-recommendation-detail="' +
      escapeHtml(selected.conditionId) + '"><header><div class="ala-rec-selected-condition">' +
      '<small>Condition ' + (selectedIndex + 1) + ' of ' + conditions.length +
      '</small><strong>' + escapeHtml(conditionLabel(selectedCondition)) +
      '</strong></div><div class="ala-rec-header-actions"><div class="ala-rec-nav">' +
      '<button type="button" class="t-Button t-Button--small" data-rec-nav="-1" ' +
      (selectedIndex === 0 ? "disabled" : "") +
      '><span class="fa fa-chevron-left"></span> Previous</button>' +
      '<button type="button" class="t-Button t-Button--small" data-rec-nav="1" ' +
      (selectedIndex === conditions.length - 1 ? "disabled" : "") +
      '>Next <span class="fa fa-chevron-right"></span></button></div><div class="ala-rec-flags">' +
      '<label class="ala-inline-check"><input data-rec="enabled" type="checkbox" ' +
      (selected.enabled !== false ? "checked" : "") + '> Enabled</label>' +
      '<label class="ala-inline-check"><input data-rec="approval" type="checkbox" ' +
      (selected.approvalRequired ? "checked" : "") + '> Approval</label></div></div></header>' +
      '<div class="ala-recommendation-grid"><section class="ala-routing-card">' +
      '<div class="ala-section-compact-title"><strong>Finding route</strong>' +
      '<small>What is created, where it goes, and how work starts.</small></div>' +
      '<div class="ala-routing-controls"><div class="ala-control"><label>Finding type</label>' +
      '<select data-rec="finding-type">' + findingTypeOptions +
      '</select></div><div class="ala-control"><label>Route to module</label>' +
      '<select data-rec="module">' + moduleOptions + '</select></div>' +
      '<div class="ala-control"><label>Workflow action</label><select data-rec="action">' +
      workflowActionOptions + '</select></div></div><div class="ala-sla-inline">' +
      '<div class="ala-section-compact-title"><strong>SLA</strong>' +
      '<small>Asia/Kolkata</small></div><div class="ala-sla-controls">' +
      slaControls(selected) + '</div></div></section>' +
      '<section class="ala-expected-builder"><div class="ala-expected-builder-title"><strong>Expected value</strong>' +
      '<small>Governed strategy used at finding runtime.</small></div><div class="ala-expected-controls">' +
      expectedValueControls(selected, selectedCondition) + '</div></section>' +
      '<div class="ala-control ala-control--wide"><label>Personalized recommendation template</label>' +
      '<textarea data-rec="template" rows="3" maxlength="4000">' +
      escapeHtml(selected.template || "") + '</textarea></div>' +
      '<div class="ala-control ala-control--escalation"><label>RBAC escalation role</label><select data-rec="escalation">' +
      escalationRoleOptions + '</select><small>Active RBAC role master.</small></div>' +
      recommendationValueMappingHtml(selectedCondition,selected) +
      '<section class="ala-recommendation-preview" data-preview-condition="' +
      escapeHtml(selected.conditionId) + '">' +
      recommendationPreviewContent(selected.conditionId) +
      '</section></div></article></div>';
    panel.querySelectorAll("[data-select-recommendation]").forEach(function (button) {
      button.addEventListener("click", function () {
        syncSelectedRecommendationFromDom();
        state.selectedRecommendationConditionId = button.dataset.selectRecommendation;
        renderRecommendationEditor();
      });
    });
    panel.querySelectorAll("[data-rec-nav]").forEach(function (button) {
      button.addEventListener("click", function () {
        var nextIndex = selectedIndex + Number(button.dataset.recNav || 0);
        if (nextIndex < 0 || nextIndex >= state.recommendations.length) { return; }
        syncSelectedRecommendationFromDom();
        state.selectedRecommendationConditionId =
          state.recommendations[nextIndex].conditionId;
        renderRecommendationEditor();
      });
    });
    panel.querySelector("[data-rec=expected-mode]").addEventListener("change", function () {
      syncSelectedRecommendationFromDom();
      delete state.recommendationPreviews[selected.conditionId];
      renderRecommendationEditor();
    });
    panel.querySelector("[data-rec=sla-mode]").addEventListener("change", function () {
      syncSelectedRecommendationFromDom();
      renderRecommendationEditor();
    });
    panel.querySelector("[data-rec=module]").addEventListener("change", function () {
      syncSelectedRecommendationFromDom();
      var rec = state.recommendations[selectedIndex];
      var actions = (state.recommendationCatalog.workflowActions || []).filter(function (item) {
        return workflowActionAllowed(item,rec.moduleCode);
      });
      if (!actions.some(function (item) { return item.value === rec.workflowAction; })) {
        rec.workflowAction = (actions[0] || {}).value || "";
      }
      if (!(state.recommendationCatalog.escalationRoles || []).some(function (item) {
        return item.name === rec.escalationRole;
      })) {
        rec.escalationRole = preferredEscalationRole(rec.moduleCode);
      }
      renderRecommendationEditor();
    });
    panel.querySelectorAll(
      "[data-rec=template], [data-rec=expected-fixed], " +
      "[data-rec=expected-base], [data-rec=expected-operator], [data-rec=expected-operand]"
    ).forEach(function (control) {
      control.addEventListener("input", updateRecommendationPreview);
      control.addEventListener("change", updateRecommendationPreview);
    });
    bindRecommendationTokenButtons(panel);
    bindRecommendationPreviewActions(selectedCondition,selected);
    requestRecommendationPreview(selectedCondition,selected,false);
  }

  function renderRecommendationEditor() {
    var panel = $("ala-recommendation-editor");
    if (!panel) { return; }
    syncSelectedRecommendationFromDom();
    var ruleDefinition = collectConditions();
    var conditions = leafConditions(ruleDefinition);
    if (!conditions.length) {
      state.recommendations = [];
      state.selectedRecommendationConditionId = null;
      panel.innerHTML = '<div class="ala-empty ala-results-placeholder">' +
        '<span class="fa fa-lightbulb-o"></span><strong>Add conditions first.</strong>' +
        '<small>The complete rule outcome will receive one recommendation and route.</small></div>';
      return;
    }

    var current = (state.recommendations || []).find(function (row) {
      return row.conditionId === "OUTCOME:MATCH";
    }) || (state.recommendations || [])[0] || {};
    var defaultModule = state.modules.find(function (row) { return row.active; }) ||
      {code: "ARM", defaultSlaMinutes: 240, escalationRole: "Risk Operations Lead"};
    var defaultDuration = durationParts(defaultModule.defaultSlaMinutes || 1440);
    var generatedTemplate = "Review agent {{agent_id}} because {{condition_summary}} " +
      "during {{period}}. Outcome: {{outcome}}. Evidence: {{evidence_summary}}.";
    if (!current.conditionId || current.conditionId !== "OUTCOME:MATCH" ||
        /\{\{actual_value\}\}|\{\{expected_value\}\}|\{\{condition_value\}\}/.test(
          String(current.template || "")
        )) {
      current = Object.assign({},current,{template:generatedTemplate});
    }
    var selected = Object.assign({
      conditionId: "OUTCOME:MATCH",
      outcomeCode: "MATCH",
      sequence: 1,
      findingType: "Condition Finding",
      template: generatedTemplate,
      expectedValueMode: "OUTCOME",
      expectedFixedValue: "",
      expectedBaseSource: "BASELINE",
      expectedOperator: "PERCENT_INCREASE",
      expectedOperand: null,
      moduleCode: defaultModule.code,
      workflowAction: "Create Investigation",
      slaMinutes: defaultModule.defaultSlaMinutes || 1440,
      slaMode: "DURATION",
      slaValue: defaultDuration.value,
      slaUnit: defaultDuration.unit,
      slaDeadline: "",
      slaTimezone: "Asia/Kolkata",
      escalationRole: preferredEscalationRole(defaultModule.code),
      approvalRequired: false,
      enabled: true
    },current,{
      conditionId: "OUTCOME:MATCH",
      outcomeCode: "MATCH",
      sequence: 1,
      expectedValueMode: "OUTCOME",
      valueMappings: defaultOutcomeRecommendationValueMappings()
    });
    selected.slaMode = selected.slaMode || "DURATION";
    if (selected.slaMode === "DURATION" && selected.slaValue == null) {
      var duration = durationParts(selected.slaMinutes);
      selected.slaValue = duration.value;
      selected.slaUnit = duration.unit;
    }
    selected.slaUnit = selected.slaUnit || "MINUTE";
    selected.slaTimezone = "Asia/Kolkata";
    state.recommendations = [selected];
    state.selectedRecommendationConditionId = "OUTCOME:MATCH";

    var catalog = state.recommendationCatalog || {};
    function governedOptions(items, selectedValue, valueKey, labelBuilder) {
      var known = (items || []).some(function (item) {
        return item[valueKey] === selectedValue;
      });
      var html = '<option value="">Select governed value</option>';
      if (selectedValue && !known) {
        html += '<option value="' + escapeHtml(selectedValue) +
          '" selected>Legacy — remap required: ' + escapeHtml(selectedValue) + "</option>";
      }
      return html + (items || []).map(function (item) {
        var value = item[valueKey];
        return '<option value="' + escapeHtml(value) + '"' +
          (value === selectedValue ? " selected" : "") + ">" +
          escapeHtml(labelBuilder(item)) + "</option>";
      }).join("");
    }
    var moduleOptions = state.modules.filter(function (item) { return item.active; })
      .map(function (item) {
        return '<option value="' + escapeHtml(item.code) + '"' +
          (item.code === selected.moduleCode ? " selected" : "") + ">" +
          escapeHtml(item.code + " — " + item.name) + "</option>";
      }).join("");
    var findingTypeOptions = governedOptions(
      catalog.findingTypes || [],selected.findingType,"value",function (item) {
        return item.label;
      }
    );
    var allowedActions = (catalog.workflowActions || []).filter(function (item) {
      return workflowActionAllowed(item,selected.moduleCode);
    });
    var workflowActionOptions = governedOptions(
      allowedActions,selected.workflowAction,"value",function (item) {
        return item.label;
      }
    );
    var escalationRoleOptions = governedOptions(
      catalog.escalationRoles || [],selected.escalationRole,"name",function (item) {
        return item.groupName + " — " + item.name;
      }
    );
    var overallJoin = ruleDefinition.operator === "OR" ? "ANY" : "ALL";
    var complete = recommendationIsComplete(selected);

    panel.innerHTML =
      '<div class="ala-recommendation-heading"><div><h3>Outcome Recommendation &amp; Routing</h3>' +
      '<p>Configure one finding and journey for the complete rule outcome.</p></div>' +
      '<span class="ala-status-badge">' + (complete ? "Ready" : "Setup required") +
      '</span></div><div class="ala-recommendation-rule-note">' +
      '<span class="fa fa-check-circle"></span><div>' +
      '<strong>When the complete rule evaluates to MATCH</strong><small>' +
      (conditions.length === 1 ? "One configured condition" :
        overallJoin + " logic across " + conditions.length + " conditions") +
      '. Conditions are supporting evidence and do not create separate recommendations.' +
      '</small></div></div><section class="ala-outcome-condition-summary">' +
      '<header><strong>Rule evidence</strong><span>' + escapeHtml(overallJoin) +
      '</span></header><div>' + conditions.map(function (row,index) {
        return '<span><b>' + (index + 1) + '</b>' +
          escapeHtml(shortConditionLabel(row)) + '</span>';
      }).join("") + '</div></section>' +
      '<article class="ala-recommendation-detail ala-recommendation-detail--outcome" ' +
      'data-recommendation-detail="OUTCOME:MATCH"><header>' +
      '<div class="ala-rec-selected-condition"><small>Single outcome</small>' +
      '<strong>MATCH → one finding → one recommendation → one route</strong></div>' +
      '<div class="ala-rec-header-actions"><div class="ala-rec-flags">' +
      '<label class="ala-inline-check"><input data-rec="enabled" type="checkbox" ' +
      (selected.enabled !== false ? "checked" : "") + '> Enabled</label>' +
      '<label class="ala-inline-check"><input data-rec="approval" type="checkbox" ' +
      (selected.approvalRequired ? "checked" : "") + '> Approval</label>' +
      '</div></div></header><div class="ala-recommendation-grid">' +
      '<section class="ala-routing-card"><div class="ala-section-compact-title">' +
      '<strong>Finding route</strong><small>Created once after the overall MATCH outcome.</small>' +
      '</div><div class="ala-routing-controls"><div class="ala-control">' +
      '<label>Finding type</label><select data-rec="finding-type">' + findingTypeOptions +
      '</select></div><div class="ala-control"><label>Route to module</label>' +
      '<select data-rec="module">' + moduleOptions +
      '</select></div><div class="ala-control"><label>Workflow action</label>' +
      '<select data-rec="action">' + workflowActionOptions +
      '</select></div></div><div class="ala-sla-inline">' +
      '<div class="ala-section-compact-title"><strong>SLA</strong><small>Asia/Kolkata</small>' +
      '</div><div class="ala-sla-controls">' + slaControls(selected) +
      '</div></div></section><div class="ala-control ala-control--wide">' +
      '<label>Personalized outcome recommendation</label>' +
      '<textarea data-rec="template" rows="3" maxlength="4000">' +
      escapeHtml(selected.template || "") +
      '</textarea><small>Use the governed outcome tokens from the mapping below.</small></div>' +
      '<div class="ala-control ala-control--escalation">' +
      '<label>RBAC escalation role</label><select data-rec="escalation">' +
      escalationRoleOptions +
      '</select><small>Loaded from the active RBAC role and role-group master.</small></div>' +
      recommendationValueMappingHtml(ruleDefinition,selected) +
      '<section class="ala-recommendation-preview" data-preview-condition="OUTCOME:MATCH">' +
      recommendationPreviewContent("OUTCOME:MATCH") +
      '</section></div></article>';

    panel.querySelector("[data-rec=sla-mode]").addEventListener("change", function () {
      syncSelectedRecommendationFromDom();
      renderRecommendationEditor();
    });
    panel.querySelector("[data-rec=module]").addEventListener("change", function () {
      syncSelectedRecommendationFromDom();
      var rec = state.recommendations[0];
      var actions = (state.recommendationCatalog.workflowActions || []).filter(function (item) {
        return workflowActionAllowed(item,rec.moduleCode);
      });
      if (!actions.some(function (item) { return item.value === rec.workflowAction; })) {
        rec.workflowAction = (actions[0] || {}).value || "";
      }
      renderRecommendationEditor();
    });
    panel.querySelectorAll("[data-rec=template]").forEach(function (control) {
      control.addEventListener("input", updateRecommendationPreview);
      control.addEventListener("change", updateRecommendationPreview);
    });
    bindRecommendationTokenButtons(panel);
    bindRecommendationPreviewActions(ruleDefinition,selected);
    requestRecommendationPreview(ruleDefinition,selected,false);
  }

  function showInlineConfigurationTab(name) {
    var editor = $("ala-inline-config-editor");
    if (!editor) { return; }
    state.inlineConfigEditorActiveTab = name;
    editor.querySelectorAll("[data-inline-config-tab]").forEach(function (button) {
      var active = button.dataset.inlineConfigTab === name;
      button.classList.toggle("is-active", active);
      button.setAttribute("aria-selected", active ? "true" : "false");
    });
    editor.querySelectorAll("[data-inline-config-panel]").forEach(function (panel) {
      panel.hidden = panel.dataset.inlineConfigPanel !== name;
    });
    if (name === "recommendations") { renderRecommendationEditor(); }
  }

  function forceCloseConfigurationEditor() {
    var wasOpen = state.configurationDrawerOpen;
    var editor = $("ala-inline-config-editor");
    var viewer = $("ala-applied-config-viewer");
    if (editor) { editor.hidden = false; }
    if ($("ala-inline-config-workspace")) {
      $("ala-inline-config-workspace").setAttribute("aria-labelledby", "ala-inline-config-title");
    }
    if (viewer) {
      viewer.hidden = true;
      viewer.innerHTML = "";
    }
    state.configurationDrawerOpen = false;
    state.configurationDrawerMode = "editor";
    state.nativeDrawerClosePending = false;
    state.inlineConfigEditorVersionId = null;
    state.inlineConfigEditorActiveTab = "definition";
    state.configEditorBaseline = null;
    document.querySelectorAll("#ala-bucket-configurations .ala-config-card")
      .forEach(function (card) {
        card.classList.remove("is-inline-editing");
        card.querySelector("[data-role=summary-toggle]").setAttribute("aria-expanded", "false");
        card.querySelector("[data-role=summary-chevron]").className = "fa fa-chevron-down";
      });
    if (wasOpen) {
      state.nativeDrawerCloseRequested = true;
      closeNativeDrawer();
      global.setTimeout(function () {
        state.nativeDrawerCloseRequested = false;
      }, 1000);
    }
  }

  function requestNativeConfigurationDrawerClose() {
    if (!state.configurationDrawerOpen || state.nativeDrawerClosePending) { return; }
    state.nativeDrawerClosePending = true;
    var guard = state.configurationDrawerMode === "summary" ?
      Promise.resolve(true) : guardConfigurationChanges();
    guard.then(function (allowed) {
      state.nativeDrawerClosePending = false;
      if (!allowed || !state.configurationDrawerOpen) { return; }
      global.setTimeout(forceCloseConfigurationEditor, 0);
    }).catch(function (error) {
      state.nativeDrawerClosePending = false;
      showError("Drawer could not be closed: " + error.message);
    });
  }

  function openConfigurationViewer(config, applied) {
    if (!config) { return; }
    openGovernedViewer(governedViewerShell(
      applied ? "Applied analytics filter" : "Advanced agent configuration",
      config.name || "Advanced Agent Configuration",
      applied ? "Read-only explanation of the rule currently filtering Map & Analytics." :
        "Read-only explanation of how this governed rule classifies agents.",
      governedIdentityHtml([
        {label: "Code", value: config.code},
        {label: "Status", value: config.status},
        {label: "Version", value: config.version},
        {label: "Visibility", value: config.sharingMode}
      ]) + '<div class="ala-governed-hierarchy-label">' +
      "Configuration → Criteria → Result</div>" +
      '<div class="ala-governed-tree ala-governed-tree--root">' +
      governedConfigurationNodeHtml(config, true) + "</div>"
    ));
  }

  function openAppliedConfigurationViewer() {
    openConfigurationViewer(state.appliedConfiguration, true);
  }

  function closeInlineConfigurationEditor(force) {
    if (force) {
      forceCloseConfigurationEditor();
      return Promise.resolve(true);
    }
    return guardConfigurationChanges().then(function (allowed) {
      if (allowed) { forceCloseConfigurationEditor(); }
      return allowed;
    });
  }

  function prepareInlineConfigurationEditor() {
    var builder = document.querySelector("#ala-panel-conditions .ala-builder-panel");
    var mount = $("ala-inline-config-workspace");
    if (!builder || !mount || $("ala-inline-config-editor")) { return; }
    builder.id = "ala-inline-config-editor";
    builder.classList.add("ala-inline-config-editor");

    var header = builder.querySelector(".ala-builder-header");
    header.querySelector("h2").id = "ala-inline-config-title";

    var context = document.createElement("div");
    context.className = "ala-inline-config-context";
    context.innerHTML =
      '<span class="fa fa-info-circle"></span><div><strong id="ala-inline-config-context-title">' +
      'Configuration workspace</strong><small>Saving creates a new version and attaches that exact version to this Subbucket.</small></div>';
    header.insertAdjacentElement("afterend", context);

    var tabs = document.createElement("nav");
    tabs.className = "ala-inline-config-tabs";
    tabs.setAttribute("role", "tablist");
    tabs.setAttribute("aria-label", "Advanced configuration sections");
    tabs.innerHTML =
      '<button type="button" class="is-active" data-inline-config-tab="definition" role="tab" aria-selected="true">' +
      '<span>1</span><strong>Definition</strong><small>Window and classification</small></button>' +
      '<button type="button" data-inline-config-tab="conditions" role="tab" aria-selected="false">' +
      '<span>2</span><strong>Conditions</strong><small>Nested AND/OR rules</small></button>' +
      '<button type="button" data-inline-config-tab="recommendations" role="tab" aria-selected="false">' +
      '<span>3</span><strong>Recommendations &amp; Routing</strong><small>Guidance, module and SLA</small></button>' +
      '<button type="button" data-inline-config-tab="results" role="tab" aria-selected="false">' +
      '<span>4</span><strong>Test Results</strong><small>Matching statistics</small></button>';
    context.insertAdjacentElement("afterend", tabs);

    var definition = document.createElement("div");
    definition.className = "ala-inline-config-panel";
    definition.dataset.inlineConfigPanel = "definition";
    [
      builder.querySelector(".ala-catalog-note"),
      builder.querySelector(".ala-filter-properties"),
      builder.querySelector(".ala-window-section"),
      builder.querySelector(".ala-classification-grid")
    ].forEach(function (node) { if (node) { definition.appendChild(node); } });

    var conditions = document.createElement("div");
    conditions.className = "ala-inline-config-panel";
    conditions.dataset.inlineConfigPanel = "conditions";
    conditions.hidden = true;
    [
      builder.querySelector(".ala-builder-toolbar"),
      $("ala-condition-root")
    ].forEach(function (node) { if (node) { conditions.appendChild(node); } });

    var recommendations = document.createElement("div");
    recommendations.id = "ala-recommendation-editor";
    recommendations.className = "ala-inline-config-panel ala-recommendation-editor";
    recommendations.dataset.inlineConfigPanel = "recommendations";
    recommendations.hidden = true;

    var results = document.createElement("div");
    results.className = "ala-inline-config-panel ala-inline-config-results";
    results.dataset.inlineConfigPanel = "results";
    results.hidden = true;
    results.innerHTML =
      '<div id="ala-inline-config-results-empty" class="ala-empty ala-results-placeholder">' +
      '<span class="fa fa-flask"></span><strong>No configuration test has been run.</strong>' +
      '<small>Validate &amp; Test shows matching agents and transaction statistics here.</small></div>';
    results.appendChild($("ala-test-result"));

    var savebar = builder.querySelector(".ala-savebar");
    var retire = $("ala-retire-filter");
    var test = $("ala-test-filter");
    var apply = $("ala-apply-conditions");
    var draft = $("ala-save-draft");
    var activate = $("ala-save-active");
    var footerNote = document.createElement("span");
    footerNote.className = "ala-native-drawer-footnote";
    footerNote.innerHTML =
      '<span class="fa fa-info-circle"></span> Changes are versioned and auditable';
    var footerLeft = document.createElement("div");
    footerLeft.className = "ala-native-drawer-left";
    var footerActions = document.createElement("div");
    footerActions.className = "ala-native-drawer-actions";
    savebar.innerHTML = "";
    footerLeft.appendChild(retire);
    footerLeft.appendChild(footerNote);
    [
      [test, "t-Button t-Button--small"],
      [draft, "t-Button t-Button--small"],
      [activate, "t-Button t-Button--small t-Button--success"],
      [apply, "t-Button t-Button--small t-Button--hot"]
    ].forEach(function (entry) {
      entry[0].className = entry[1];
      footerActions.appendChild(entry[0]);
    });
    savebar.className = "ala-savebar ala-native-drawer-footer";
    savebar.appendChild(footerLeft);
    savebar.appendChild(footerActions);
    builder.insertBefore(definition, savebar);
    builder.insertBefore(conditions, savebar);
    builder.insertBefore(recommendations, savebar);
    builder.insertBefore(results, savebar);
    mount.appendChild(builder);
    var viewer = document.createElement("div");
    viewer.id = "ala-applied-config-viewer";
    viewer.className = "ala-applied-config-viewer";
    viewer.hidden = true;
    mount.appendChild(viewer);

    tabs.querySelectorAll("[data-inline-config-tab]").forEach(function (button) {
      button.addEventListener("click", function () {
        showInlineConfigurationTab(button.dataset.inlineConfigTab);
      });
    });
    if (global.apex && apex.jQuery) {
      apex.jQuery("#ala-native-drawer").on("dialogbeforeclose", function (event) {
        if (!state.configurationDrawerOpen || state.nativeDrawerCloseRequested) {
          return;
        }
        event.preventDefault();
        requestNativeConfigurationDrawerClose();
      }).on("dialogclose", function () {
        apex.jQuery(this).closest(".ui-dialog").removeClass("is-open");
        state.nativeDrawerCloseRequested = false;
        state.nativeDrawerClosePending = false;
      });
    }
  }

  function ensureSubbucketSavebar() {
    if ($("ala-save-bucket-draft")) { return; }
    var editor = $("ala-subbucket-editor");
    if (!editor) { return; }
    editor.insertAdjacentHTML("beforeend",
      '<div class="ala-savebar ala-entity-savebar">' +
      '<button id="ala-retire-bucket" type="button" ' +
      'class="ala-button ala-button--danger" hidden>Retire Subbucket</button>' +
      '<div class="ala-savebar-actions">' +
      '<button id="ala-save-bucket-draft" type="button" ' +
      'class="ala-button ala-button--secondary">Save Draft</button>' +
      '<button id="ala-save-bucket-active" type="button" class="ala-button">' +
      'Save &amp; Activate Subbucket</button></div></div>'
    );
  }

  function openBucketConfigurationEditor(configId, configVersionId, card) {
    var requestedVersion = configVersionId == null ? "NEW" : Number(configVersionId);
    var changingConfiguration = state.configurationDrawerOpen &&
      String(state.inlineConfigEditorVersionId) !== String(requestedVersion);
    var guard = changingConfiguration ? guardConfigurationChanges() : Promise.resolve(true);
    return guard.then(function (allowed) {
      if (!allowed) { return false; }
      syncBucketConfigurationsFromDom();
      switchBucketEditorTab("configurations");
      state.configEditorFromBucket = true;
      state.configEditorReplaceId = configId == null ? null : Number(configId);
      state.inlineConfigEditorVersionId = requestedVersion;
      state.configurationDrawerOpen = true;
      state.configurationDrawerMode = "editor";
      $("ala-inline-config-editor").hidden = false;
      $("ala-applied-config-viewer").hidden = true;
      $("ala-inline-config-workspace").setAttribute("aria-labelledby", "ala-inline-config-title");
      openNativeDrawer(
        configId == null ? "New Advanced Configuration" : "Advanced Configuration"
      );
      document.querySelectorAll("#ala-bucket-configurations .ala-config-card")
        .forEach(function (row) {
          var active = row === card;
          row.classList.toggle("is-inline-editing", active);
          row.querySelector("[data-role=summary-toggle]")
            .setAttribute("aria-expanded", active ? "true" : "false");
          row.querySelector("[data-role=summary-chevron]").className =
            "fa fa-chevron-" + (active ? "up" : "down");
        });
      $("ala-inline-config-context-title").textContent =
        ($("ala-bucket-name").value.trim() || "New Subbucket") +
        " › " + (configId == null ? "New Advanced Configuration" : "Advanced Configuration");
      $("ala-test-result").hidden = true;
      $("ala-test-result").innerHTML = "";
      $("ala-inline-config-results-empty").hidden = false;
      showInlineConfigurationTab(configId == null ? "definition" : "conditions");
      var request;
      if (configId == null) {
        newFilter();
        request = Promise.resolve();
      } else {
        request = loadSavedFilter(configId);
      }
      return request.then(function () {
        state.configEditorBaseline = configurationEditorSnapshot();
        var firstTab = $("ala-inline-config-editor")
          .querySelector("[data-inline-config-tab].is-active");
        if (firstTab) { firstTab.focus(); }
        return true;
      });
    });
  }

  function defaultRiskBands() {
    return [
      {code: "LOW", name: "Low", minimum: 0, maximum: 25, riskClass: "LOW",
        criticality: "LOW", priority: 400, colour: "#2E8B57", findingAction: "NONE"},
      {code: "MEDIUM", name: "Medium", minimum: 25, maximum: 50, riskClass: "MEDIUM",
        criticality: "MEDIUM", priority: 300, colour: "#E3A008", findingAction: "CREATE"},
      {code: "HIGH", name: "High", minimum: 50, maximum: 75, riskClass: "HIGH",
        criticality: "HIGH", priority: 200, colour: "#E67E22", findingAction: "CREATE"},
      {code: "CRITICAL", name: "Critical", minimum: 75, maximum: 100,
        riskClass: "CRITICAL", criticality: "CRITICAL", priority: 100,
        colour: "#C0392B", findingAction: "ESCALATE"}
    ];
  }
  function riskClassOptions(selected) {
    return ["LOW", "MEDIUM", "HIGH", "CRITICAL"].map(function (value) {
      return '<option value="' + value + '"' +
        (value === selected ? " selected" : "") + ">" + value + "</option>";
    }).join("");
  }
  function renderRiskBands() {
    var rows = state.bucketRiskBands || [];
    $("ala-risk-band-list").innerHTML = rows.length ? rows.map(function (band, index) {
      return '<article class="ala-risk-band-row" data-band-index="' + index +
        '" style="--band-colour:' + escapeHtml(band.colour || "#7B8794") + '">' +
        '<span class="ala-band-swatch"></span><div class="ala-control"><label>Band name</label>' +
        '<input data-role="band-name" value="' + escapeHtml(band.name || "") + '"></div>' +
        '<div class="ala-control"><label>From</label><input data-role="band-min" type="number" ' +
        'step="0.01" value="' + escapeHtml(band.minimum) + '"></div>' +
        '<div class="ala-control"><label>To</label><input data-role="band-max" type="number" ' +
        'step="0.01" value="' + escapeHtml(band.maximum) + '"></div>' +
        '<div class="ala-control"><label>Risk</label><select data-role="band-risk">' +
        riskClassOptions(band.riskClass || "MEDIUM") + '</select></div>' +
        '<div class="ala-control"><label>Criticality</label><select data-role="band-criticality">' +
        riskClassOptions(band.criticality || band.riskClass || "MEDIUM") + '</select></div>' +
        '<div class="ala-control"><label>Priority</label><input data-role="band-priority" ' +
        'type="number" min="1" value="' + escapeHtml(band.priority || 100) + '"></div>' +
        '<div class="ala-control"><label>Colour</label><input data-role="band-colour" type="color" ' +
        'value="' + escapeHtml(band.colour || "#7B8794") + '"></div>' +
        '<div class="ala-control"><label>Finding</label><select data-role="band-action">' +
        '<option value="NONE"' + (band.findingAction === "NONE" ? " selected" : "") +
        '>None</option><option value="CREATE"' +
        (band.findingAction === "CREATE" ? " selected" : "") +
        '>Create</option><option value="ESCALATE"' +
        (band.findingAction === "ESCALATE" ? " selected" : "") +
        '>Escalate</option></select></div><button type="button" class="ala-icon-button ' +
        'ala-band-remove" title="Remove risk band"><span class="fa fa-trash"></span></button></article>';
    }).join("") : '<div class="ala-empty">Add at least one continuous risk band.</div>';
    $("ala-risk-band-list").querySelectorAll(".ala-risk-band-row").forEach(function (row) {
      row.querySelector(".ala-band-remove").addEventListener("click", function () {
        syncRiskBands();
        state.bucketRiskBands.splice(Number(row.dataset.bandIndex), 1);
        renderRiskBands();
      });
      row.querySelector("[data-role=band-colour]").addEventListener("input", function (event) {
        row.style.setProperty("--band-colour", event.target.value);
      });
    });
  }

  function switchBucketEditorTab(tabName) {
    var selected = tabName || "setup";
    state.activeBucketEditorTab = selected;
    if (state.selectedBucketId != null) {
      state.subbucketTabs[String(state.selectedBucketId)] = selected;
    }
    document.querySelectorAll("[data-bucket-editor-tab]").forEach(function (button) {
      var active = button.dataset.bucketEditorTab === selected;
      button.classList.toggle("is-active", active);
      button.setAttribute("aria-selected", active ? "true" : "false");
    });
    ["setup", "configurations", "scoring", "results"].forEach(function (name) {
      $("ala-bucket-section-" + name).hidden = name !== selected;
    });
  }

  function updateFinalizerValueControl() {
    var type = $("ala-finalizer-type").value;
    var valueControl = $("ala-finalizer-value-control");
    var valueInput = $("ala-finalizer-value");
    var operationHelp = {
      ALL: "An agent qualifies only when every selected configuration matches.",
      ANY: "An agent qualifies when one or more selected configurations match.",
      N_OF_M: "An agent qualifies after the specified number of selected configurations match.",
      WEIGHTED_SCORE: "Each configuration score is multiplied by its weight, then the results are added.",
      SUM: "All configuration scores are added before applying the minimum qualifying score.",
      AVG: "The average of the available configuration scores must reach the minimum.",
      MIN: "Even the lowest configuration score must reach the minimum.",
      MAX: "At least the highest configuration score must reach the minimum."
    };
    $("ala-finalizer-operation-help").textContent = operationHelp[type] || "";
    valueControl.hidden = type === "ALL" || type === "ANY";
    if (type === "N_OF_M") {
      $("ala-finalizer-value-label").textContent = "Minimum configurations required";
      $("ala-finalizer-value-help").textContent =
        "Example: enter 2 to require any 2 selected configurations to match.";
      valueInput.min = "1";
      valueInput.step = "1";
      valueInput.max = String(Math.max(1, state.bucketConfigurations.length));
      valueInput.placeholder = "e.g. 2";
      if (valueInput.value !== "" && Number(valueInput.value) < 1) {
        valueInput.value = "1";
      }
    } else {
      $("ala-finalizer-value-label").textContent = "Minimum score to qualify";
      $("ala-finalizer-value-help").textContent =
        "Agents below this score do not qualify for the bucket result.";
      valueInput.removeAttribute("min");
      valueInput.removeAttribute("max");
      valueInput.step = "any";
      valueInput.placeholder = "e.g. 25";
    }
  }
  function syncRiskBands() {
    state.bucketRiskBands = Array.prototype.map.call(
      $("ala-risk-band-list").querySelectorAll(".ala-risk-band-row"),
      function (row, index) {
        var risk = row.querySelector("[data-role=band-risk]").value;
        var name = row.querySelector("[data-role=band-name]").value.trim();
        return {
          sequence: index + 1,
          code: (name || risk).toUpperCase().replace(/[^A-Z0-9]+/g, "_").slice(0, 40),
          name: name,
          minimum: Number(row.querySelector("[data-role=band-min]").value),
          maximum: Number(row.querySelector("[data-role=band-max]").value),
          riskClass: risk,
          criticality: row.querySelector("[data-role=band-criticality]").value,
          priority: Number(row.querySelector("[data-role=band-priority]").value || 100),
          colour: row.querySelector("[data-role=band-colour]").value.toUpperCase(),
          findingAction: row.querySelector("[data-role=band-action]").value
        };
      }
    );
    return state.bucketRiskBands;
  }
  function validateRiskBands() {
    var bands = syncRiskBands();
    if (!bands.length) {
      showError("Define at least one Subbucket risk band.");
      return false;
    }
    var domainMinimum = $("ala-score-normalize").checked ? 0 :
      Number($("ala-score-min").value);
    var domainMaximum = $("ala-score-normalize").checked ? 100 :
      Number($("ala-score-max").value);
    for (var i = 0; i < bands.length; i += 1) {
      if (!bands[i].name || bands[i].maximum <= bands[i].minimum) {
        showError("Every risk band requires a name and a maximum greater than its minimum.");
        return false;
      }
      if ((i === 0 && bands[i].minimum !== domainMinimum) ||
          (i > 0 && bands[i].minimum !== bands[i - 1].maximum)) {
        showError("Risk bands must be continuous, ordered, and non-overlapping.");
        return false;
      }
    }
    if (bands[bands.length - 1].maximum !== domainMaximum) {
      showError("Risk bands must cover the full Subbucket score range.");
      return false;
    }
    return true;
  }

  function newBucket(parentId) {
    forceCloseConfigurationEditor();
    var targetParent = parentId || state.selectedClassBucketId;
    if (!targetParent) {
      showError("Save or select a parent Bucket before creating a Subbucket classification.");
      newClassBucket();
      return;
    }
    state.selectedClassBucketId = Number(targetParent);
    state.selectedBucketId = null;
    state.selectedBucketVersion = null;
    state.bucketConfigurations = [];
    $("ala-bucket-name").value = "";
    $("ala-bucket-description").value = "";
    $("ala-bucket-sharing").value = "PRIVATE";
    $("ala-bucket-title").textContent = "New Subbucket Classification";
    $("ala-bucket-status").textContent = "New draft";
    $("ala-bucket-version").textContent = "Not saved";
    $("ala-subbucket-colour").value = "#6F42C1";
    $("ala-subbucket-priority").value = "100";
    var parent = selectedClassBucket();
    $("ala-subbucket-parent-name").textContent = parent ? parent.name : "Bucket";
    $("ala-retire-bucket").hidden = true;
    $("ala-finalizer-enabled").checked = false;
    $("ala-finalizer-type").value = "ALL";
    $("ala-finalizer-value").value = "";
    $("ala-finalizer-error").value = "FAIL_BUCKET";
    $("ala-score-min").value = "0";
    $("ala-score-max").value = "100";
    $("ala-score-normalize").checked = true;
    state.bucketRiskBands = defaultRiskBands();
    renderRiskBands();
    $("ala-finalizer-controls").hidden = true;
    $("ala-bucket-test-result").hidden = true;
    $("ala-bucket-results-empty").hidden = false;
    updateFinalizerValueControl();
    switchBucketEditorTab("setup");
    renderBucketConfigurations();
    showSubbucketEditor();
    renderBucketList();
    state.subbucketEditorBaseline = subbucketEditorSnapshot();
  }

  function loadBucket(id) {
    var rememberedTab = state.subbucketTabs[String(id)];
    var targetTab = rememberedTab ||
      (state.selectedBucketId == null ? "configurations" :
        (state.activeBucketEditorTab || "configurations"));
    forceCloseConfigurationEditor();
    $("ala-subbucket-editor").classList.add("is-loading");
    $("ala-subbucket-editor").setAttribute("aria-busy", "true");
    return server("AGENT_ADV_BUCKET_LOAD", {x01: id}).then(function (data) {
      if (data.error) { throw new Error(data.error); }
      state.selectedBucketId = data.id;
      state.selectedBucketVersion = data.version;
      state.selectedClassBucketId = data.parentBucketId;
      state.expandedClassBuckets = {};
      state.expandedClassBuckets[String(data.parentBucketId)] = true;
      state.bucketConfigurations = data.configurations || [];
      $("ala-bucket-name").value = data.name || "";
      $("ala-bucket-description").value = data.description || "";
      $("ala-bucket-sharing").value = data.sharingMode || "PRIVATE";
      $("ala-bucket-title").textContent = data.name || "Subbucket Classification";
      $("ala-bucket-status").textContent = data.status;
      $("ala-bucket-version").textContent = "Version " + data.version;
      $("ala-retire-bucket").hidden = !data.canEdit;
      $("ala-subbucket-colour").value = data.colour || "#6F42C1";
      $("ala-subbucket-priority").value =
        data.classification && data.classification.priority != null ?
          data.classification.priority : 100;
      var parent = selectedClassBucket();
      $("ala-subbucket-parent-name").textContent = parent ? parent.name : "Bucket";
      $("ala-finalizer-enabled").checked = !!(data.finalizer && data.finalizer.enabled);
      $("ala-finalizer-type").value = (data.finalizer && data.finalizer.type) || "ALL";
      $("ala-finalizer-value").value = data.finalizer && data.finalizer.value != null ?
        data.finalizer.value : "";
      $("ala-finalizer-error").value = (data.finalizer && data.finalizer.errorPolicy) || "FAIL_BUCKET";
      $("ala-score-min").value = data.finalizer && data.finalizer.scoreMin != null ?
        data.finalizer.scoreMin : 0;
      $("ala-score-max").value = data.finalizer && data.finalizer.scoreMax != null ?
        data.finalizer.scoreMax : 100;
      $("ala-score-normalize").checked =
        !data.finalizer || data.finalizer.normalize !== false;
      state.bucketRiskBands = (data.riskBands || []).length ?
        data.riskBands : defaultRiskBands();
      renderRiskBands();
      $("ala-finalizer-controls").hidden = !$("ala-finalizer-enabled").checked;
      $("ala-bucket-test-result").hidden = true;
      $("ala-bucket-results-empty").hidden = false;
      updateFinalizerValueControl();
      switchBucketEditorTab(targetTab);
      renderBucketConfigurations();
      showSubbucketEditor();
      renderBucketList();
      state.subbucketEditorBaseline = subbucketEditorSnapshot();
    }).catch(function (error) {
      showError("Subbucket could not be loaded: " + error.message);
    }).finally(function () {
      $("ala-subbucket-editor").classList.remove("is-loading");
      $("ala-subbucket-editor").removeAttribute("aria-busy");
    });
  }

  function bucketPayload() {
    return {
      bucketId: state.selectedBucketId,
      bucketVersionId: state.selectedBucketVersion,
      parentBucketId: state.selectedClassBucketId,
      name: $("ala-bucket-name").value.trim(),
      description: $("ala-bucket-description").value,
      sharingMode: $("ala-bucket-sharing").value,
      colour: $("ala-subbucket-colour").value,
      classification: {
        priority: Number($("ala-subbucket-priority").value || 100)
      },
      configurations: collectBucketConfigurations(),
      finalizer: {
        enabled: $("ala-finalizer-enabled").checked,
        type: $("ala-finalizer-enabled").checked ? $("ala-finalizer-type").value : "NONE",
        value: $("ala-finalizer-value").value === "" ? null : Number($("ala-finalizer-value").value),
        errorPolicy: $("ala-finalizer-error").value,
        normalize: $("ala-score-normalize").checked,
        scoreMin: Number($("ala-score-min").value || 0),
        scoreMax: Number($("ala-score-max").value || 100)
      },
      riskBands: syncRiskBands()
    };
  }

  function validateBucketSelection(payload) {
    if (!(payload.configurations || []).length) {
      showError("Select at least one complete Advanced Agent Configuration.");
      return false;
    }
    if (payload.finalizer.enabled &&
        ["N_OF_M", "WEIGHTED_SCORE", "SUM", "AVG", "MIN", "MAX"]
          .indexOf(payload.finalizer.type) >= 0 &&
        payload.finalizer.value == null) {
      showError(payload.finalizer.type === "N_OF_M" ?
        "Enter how many configurations must match." :
        "Enter the minimum score an agent must reach to qualify.");
      switchBucketEditorTab("scoring");
      $("ala-finalizer-value").focus();
      return false;
    }
    if (payload.finalizer.enabled && !validateRiskBands()) {
      return false;
    }
    if (payload.finalizer.enabled &&
        payload.finalizer.scoreMax <= payload.finalizer.scoreMin) {
      showError("Subbucket raw score maximum must be greater than its minimum.");
      return false;
    }
    return true;
  }

  function validateBucket() {
    var payload = bucketPayload();
    var button = $("ala-test-bucket");
    $("ala-bucket-test-result").hidden = true;
    if (!validateBucketSelection(payload)) { return; }
    button.disabled = true;
    button.innerHTML = '<span class="fa fa-spinner fa-spin"></span> Validating &amp; executing';
    load(
      true,
      {kind: "BUCKET", bucket: payload},
      "ala-bucket-test-result",
      {authorizedDefinitionScope: true}
    )
      .then(function (data) {
        if (!data) { return null; }
        $("ala-bucket-results-empty").hidden = true;
        switchBucketEditorTab("results");
        return data;
      })
      .catch(function (error) {
        showError("Subbucket validation failed: " + error.message);
      }).finally(function () {
        button.disabled = false;
        button.innerHTML = '<span class="fa fa-check-circle"></span> Validate &amp; Test';
      });
  }

  function applyBucketToAnalytics() {
    var payload = bucketPayload();
    var button = $("ala-apply-bucket");
    if (!validateBucketSelection(payload)) { return; }
    $("ala-error").hidden = true;
    button.disabled = true;
    button.innerHTML = '<span class="fa fa-spinner fa-spin"></span> Applying';
    load(false, {kind: "BUCKET", bucket: payload})
      .then(function (data) {
        if (!data) { return null; }
        state.appliedClassBucket = null;
        state.appliedBucket = payload;
        state.appliedConfiguration = null;
        renderAppliedRuleOutcome(data);
        switchTab("analytics");
        $("ala-kpi-rail").scrollIntoView({behavior: "smooth", block: "nearest"});
        if (Number((data.kpis || {}).agents || 0) === 0) {
          notify("Subbucket applied successfully. No agents match this classification and analysis period.");
        } else {
          notify("Subbucket classification applied to " + fmt.format(data.kpis.agents) + " matching agents.");
        }
        return data;
      }).catch(function (error) {
        showError("Subbucket could not be applied: " + error.message);
      }).finally(function () {
        button.disabled = false;
        button.innerHTML = '<span class="fa fa-play"></span> Apply to Analytics';
      });
  }

  function saveBucket(activate) {
    var name = $("ala-bucket-name").value.trim();
    var configurations = collectBucketConfigurations();
    if (!name) {
      showError("Enter a Subbucket classification name.");
      $("ala-bucket-name").focus();
      return Promise.resolve(false);
    }
    if (!configurations.length) {
      showError("Select at least one complete Advanced Agent Configuration.");
      return Promise.resolve(false);
    }
    var payload = {
      bucketId: state.selectedBucketId,
      parentBucketId: state.selectedClassBucketId,
      name: name,
      description: $("ala-bucket-description").value,
      sharingMode: $("ala-bucket-sharing").value,
      colour: $("ala-subbucket-colour").value,
      classification: {
        priority: Number($("ala-subbucket-priority").value || 100)
      },
      configurations: configurations,
      finalizer: {
        enabled: $("ala-finalizer-enabled").checked,
        type: $("ala-finalizer-enabled").checked ? $("ala-finalizer-type").value : "NONE",
        value: $("ala-finalizer-value").value === "" ? null : Number($("ala-finalizer-value").value),
        errorPolicy: $("ala-finalizer-error").value,
        normalize: $("ala-score-normalize").checked,
        scoreMin: Number($("ala-score-min").value || 0),
        scoreMax: Number($("ala-score-max").value || 100)
      },
      riskBands: syncRiskBands()
    };
    if (payload.finalizer.enabled && !validateRiskBands()) {
      return Promise.resolve(false);
    }
    return server("AGENT_ADV_BUCKET_SAVE", {
      x01: JSON.stringify(payload), x02: activate ? "Y" : "N"
    }).then(function (result) {
      state.selectedBucketId = result.id;
      state.selectedBucketVersion = result.version;
      $("ala-bucket-status").textContent = result.status;
      $("ala-bucket-version").textContent = "Version " + result.version;
      $("ala-retire-bucket").hidden = false;
      notify(result.message);
      state.subbucketEditorBaseline = JSON.stringify(payload);
      return refreshBuckets().then(function () {
        return loadBucket(result.id);
      }).then(function () { return true; });
    }).catch(function (error) {
      showError("Subbucket save failed: " + error.message);
      return false;
    });
  }

  function retireBucket() {
    if (!state.selectedBucketId ||
        !global.confirm("Retire this Subbucket? Existing versions, results, and findings remain auditable.")) {
      return;
    }
    server("AGENT_ADV_BUCKET_RETIRE", {x01: state.selectedBucketId}).then(function (result) {
      notify(result.message);
      var parentId = state.selectedClassBucketId;
      return refreshBuckets().then(function () { return loadClassBucket(parentId); });
    }).catch(function (error) {
      showError("Subbucket could not be retired: " + error.message);
    });
  }

  function renderMonitoring() {
    var data = state.monitoring;
    $("ala-policy-buckets").innerHTML = data.buckets.length ? data.buckets.map(function (row) {
      return '<label class="ala-pick-item"><input type="checkbox" data-policy-bucket="' +
        row.versionId + '"><span><strong>' + escapeHtml(row.name) + '</strong><small>Version ' +
        row.version + " · " + (row.finalizerEnabled ? escapeHtml(row.finalizerType) : "Independent results") +
        "</small></span></label>";
    }).join("") : '<div class="ala-empty">Activate at least one bucket before creating a policy.</div>';
    var options = data.policies.filter(function (row) { return row.status === "ACTIVE"; }).map(function (row) {
      return '<option value="' + row.versionId + '">' + escapeHtml(row.name) + " · v" +
        row.version + "</option>";
    }).join("");
    $("ala-schedule-policy").innerHTML = options || '<option value="">No active policies</option>';
    $("ala-run-policy").innerHTML = options || '<option value="">No active policies</option>';
    $("ala-schedule-list").innerHTML = data.schedules.length ? data.schedules.map(function (row) {
      return '<div class="ala-compact-item"><span><strong>' + escapeHtml(row.name) +
        '</strong><small>' + escapeHtml(row.policyName) + " · " + escapeHtml(row.calendarExpression) +
        '</small></span><span><em class="ala-status-badge ' +
        (row.enabled ? "ala-status-active" : "ala-status-draft") + '">' +
        (row.enabled ? "ENABLED" : "PAUSED") + '</em><small>Next: ' +
        escapeHtml(row.nextRunAt || "—") + '</small><span class="ala-row-actions">' +
        (row.canEdit === "Y" ? '<button type="button" class="ala-icon-button" data-schedule-edit="' +
          row.id + '">Edit</button><button type="button" class="ala-icon-button" data-schedule-action="' +
          (row.enabled ? "PAUSE" : "RESUME") + '" data-schedule-id="' + row.id + '">' +
          (row.enabled ? "Pause" : "Resume") + '</button><button type="button" class="ala-icon-button ala-remove" ' +
          'data-schedule-action="DELETE" data-schedule-id="' + row.id + '">Delete</button>' : "") +
        "</span></span></div>";
    }).join("") : '<div class="ala-empty">No schedules configured.</div>';
    document.querySelectorAll("[data-schedule-edit]").forEach(function (button) {
      button.addEventListener("click", function () { editSchedule(Number(button.dataset.scheduleEdit)); });
    });
    document.querySelectorAll("[data-schedule-action]").forEach(function (button) {
      button.addEventListener("click", function () {
        manageSchedule(Number(button.dataset.scheduleId), button.dataset.scheduleAction);
      });
    });
  }

  function refreshMonitoring() {
    return server("AGENT_ADV_MONITOR_SETUP").then(function (data) {
      state.monitoring = data;
      renderMonitoring();
      return data;
    }).catch(function (error) {
      showError("Monitoring setup could not be loaded: " + error.message);
      throw error;
    });
  }

  function savePolicy() {
    var bucketVersionIds = Array.prototype.map.call(
      document.querySelectorAll("[data-policy-bucket]:checked"),
      function (item) { return Number(item.dataset.policyBucket); }
    );
    if (!$("ala-policy-name").value.trim() || !bucketVersionIds.length) {
      showError("Enter a policy name and select at least one active bucket.");
      return;
    }
    server("AGENT_ADV_POLICY_SAVE", {
      x01: JSON.stringify({
        name: $("ala-policy-name").value.trim(),
        description: $("ala-policy-description").value,
        sharingMode: "PRIVATE",
        dateMode: $("ala-policy-date-mode").value,
        findingAction: $("ala-policy-finding-action").value,
        retentionMonths: Number($("ala-policy-retention").value || 24),
        bucketVersionIds: bucketVersionIds
      }),
      x02: "Y"
    }).then(function (result) {
      notify(result.message);
      return refreshMonitoring();
    }).catch(function (error) { showError(error.message); });
  }

  function buildCalendarExpression() {
    var frequency = $("ala-schedule-frequency").value;
    var time = ($("ala-schedule-time").value || "06:00").split(":");
    var hour = Number(time[0] || 0), minute = Number(time[1] || 0);
    var values = $("ala-schedule-days").value.split(",").map(function (value) {
      return value.trim().toUpperCase();
    }).filter(Boolean);
    var expression;
    if (frequency === "MONTHLY") {
      expression = "FREQ=MONTHLY;BYMONTHDAY=" + (values.join(",") || "1");
    } else if (frequency === "WEEKLY") {
      expression = "FREQ=WEEKLY;BYDAY=" + (values.join(",") || "MON");
    } else if (frequency === "DAILY") {
      expression = "FREQ=DAILY";
    } else {
      expression = $("ala-schedule-calendar").value.trim();
      $("ala-schedule-preview").textContent = expression ? "Custom expression" : "Enter an Oracle calendar expression";
      return expression;
    }
    expression += ";BYHOUR=" + hour + ";BYMINUTE=" + minute + ";BYSECOND=0";
    $("ala-schedule-calendar").value = expression;
    $("ala-schedule-preview").textContent = "Coordinator calendar ready";
    return expression;
  }

  function newSchedule() {
    state.selectedScheduleId = null;
    $("ala-schedule-editor-title").textContent = "New Schedule";
    $("ala-schedule-name").value = "";
    $("ala-schedule-frequency").value = "MONTHLY";
    $("ala-schedule-days").value = "7";
    $("ala-schedule-time").value = "06:00";
    $("ala-schedule-timezone").value = "Asia/Kolkata";
    $("ala-schedule-start").value = "";
    $("ala-schedule-end").value = "";
    $("ala-recheck-interval").value = "";
    $("ala-recheck-unit").value = "";
    $("ala-recheck-stop").value = "NONE";
    $("ala-max-rechecks").value = "";
    $("ala-cancel-schedule").hidden = true;
    $("ala-save-schedule").textContent = "Save Enabled Schedule";
    buildCalendarExpression();
  }

  function scheduleDays(row) {
    if (!row.runDays) { return ""; }
    if (Array.isArray(row.runDays)) { return row.runDays.join(","); }
    try { return JSON.parse(row.runDays).join(","); }
    catch (ignore) { return String(row.runDays).replace(/[[\\]\"]/g, ""); }
  }

  function editSchedule(id) {
    var row = state.monitoring.schedules.find(function (item) { return Number(item.id) === Number(id); });
    if (!row) { return; }
    state.selectedScheduleId = row.id;
    $("ala-schedule-editor-title").textContent = "Edit Schedule — " + row.name;
    $("ala-schedule-name").value = row.name || "";
    $("ala-schedule-policy").value = String(row.policyVersionId);
    $("ala-schedule-timezone").value = row.timezone || "Asia/Kolkata";
    $("ala-schedule-start").value = row.startsAt || "";
    $("ala-schedule-end").value = row.endsAt || "";
    $("ala-recheck-interval").value = row.recheckInterval == null ? "" : row.recheckInterval;
    $("ala-recheck-unit").value = row.recheckUnit || "";
    $("ala-recheck-stop").value = row.stopRule || "NONE";
    $("ala-max-rechecks").value = row.maxRechecks == null ? "" : row.maxRechecks;
    $("ala-schedule-calendar").value = row.calendarExpression || "";
    var expression = row.calendarExpression || "";
    $("ala-schedule-frequency").value = expression.indexOf("FREQ=MONTHLY") === 0 ? "MONTHLY" :
      expression.indexOf("FREQ=WEEKLY") === 0 ? "WEEKLY" :
      expression.indexOf("FREQ=DAILY") === 0 ? "DAILY" : "CUSTOM";
    $("ala-schedule-days").value = scheduleDays(row) ||
      ((expression.match(/BY(?:MONTHDAY|DAY)=([^;]+)/) || [])[1] || "");
    var hour = (expression.match(/BYHOUR=(\\d+)/) || [])[1] || "0";
    var minute = (expression.match(/BYMINUTE=(\\d+)/) || [])[1] || "0";
    $("ala-schedule-time").value = String(hour).padStart(2, "0") + ":" + String(minute).padStart(2, "0");
    $("ala-cancel-schedule").hidden = false;
    $("ala-save-schedule").textContent = row.enabled ? "Update Enabled Schedule" : "Update & Enable";
    $("ala-schedule-preview").textContent = "Editing schedule #" + row.id;
    $("ala-schedule-name").focus();
  }

  function manageSchedule(id, action) {
    if (action === "DELETE" && !global.confirm("Delete this schedule? Schedules with run history must be paused instead.")) {
      return;
    }
    server("AGENT_ADV_SCHEDULE_MANAGE", {x01: id, x02: action}).then(function (result) {
      notify(result.message);
      if (state.selectedScheduleId === id) { newSchedule(); }
      return refreshMonitoring();
    }).catch(function (error) { showError(error.message); });
  }

  function saveSchedule() {
    var expression = buildCalendarExpression();
    if (!$("ala-schedule-name").value.trim() || !$("ala-schedule-policy").value || !expression) {
      showError("Enter a schedule name, select an active policy, and provide a valid calendar.");
      return;
    }
    server("AGENT_ADV_SCHEDULE_SAVE", {
      x01: JSON.stringify({
        scheduleId: state.selectedScheduleId,
        name: $("ala-schedule-name").value.trim(),
        policyVersionId: Number($("ala-schedule-policy").value),
        scope: "POLICY",
        calendarExpression: expression,
        runDays: $("ala-schedule-days").value.split(",").map(function (value) { return value.trim(); }).filter(Boolean),
        timezone: $("ala-schedule-timezone").value || "Asia/Kolkata",
        startsAt: $("ala-schedule-start").value || null,
        endsAt: $("ala-schedule-end").value || null,
        invalidDayAction: "SKIP",
        recheckInterval: Number($("ala-recheck-interval").value) || null,
        recheckUnit: $("ala-recheck-unit").value || null,
        stopRule: $("ala-recheck-stop").value,
        maxRechecks: Number($("ala-max-rechecks").value) || null,
        enabled: true
      })
    }).then(function (result) {
      notify(result.message + " Next: " + result.nextRunAt);
      newSchedule();
      return refreshMonitoring();
    }).catch(function (error) { showError(error.message); });
  }

  function populateModuleRoleSelect(id, current) {
    var roles = (state.recommendationCatalog || {}).escalationRoles || [];
    var known = roles.some(function (row) { return row.name === current; });
    var html = '<option value="">Select active RBAC role</option>';
    if (current && !known) {
      html += '<option value="' + escapeHtml(current) +
        '" selected>Legacy — remap required: ' + escapeHtml(current) + "</option>";
    }
    html += roles.map(function (row) {
      return '<option value="' + escapeHtml(row.name) + '"' +
        (row.name === current ? " selected" : "") + ">" +
        escapeHtml(row.groupName + " — " + row.name) + "</option>";
    }).join("");
    $(id).innerHTML = html;
  }

  function updateModuleManagementActions(row) {
    $("ala-toggle-module").disabled = !row;
    $("ala-delete-module").disabled = !row || !row.canDelete;
    $("ala-toggle-module").textContent = row && row.active ? "Disable" : "Enable";
    $("ala-delete-module").title = row && !row.canDelete ?
      "This module has " + Number(row.referenceCount || 0) +
      " configuration/runtime references. Disable it instead." : "";
  }

  function selectModule(row) {
    if (!row) { newModule(); return; }
    state.selectedModuleCode = row.code;
    $("ala-module-code").value = row.code;
    $("ala-module-code").readOnly = true;
    $("ala-module-name").value = row.name || "";
    $("ala-module-description").value = row.description || "";
    populateModuleRoleSelect("ala-module-owner",row.ownerRole || "");
    $("ala-module-queue").value = row.queueCode || "";
    setModuleSlaControls(row.defaultSlaMinutes || 1440);
    populateModuleRoleSelect("ala-module-escalation",row.escalationRole || "");
    $("ala-module-dashboard").value = row.dashboardTarget || "";
    $("ala-module-active").checked = row.active !== false;
    $("ala-module-active").disabled = true;
    updateModuleManagementActions(row);
    renderModuleList();
  }

  function renderModuleList() {
    if (!$("ala-module-list")) { return; }
    var heading = '<div class="ala-module-list-head"><strong>Modules</strong><b>' +
      fmt.format(state.modules.length) + '</b></div>';
    $("ala-module-list").innerHTML = heading + (state.modules.length ? state.modules.map(function (row) {
      return '<button type="button" data-module-code="' + escapeHtml(row.code) +
        '" class="' + (state.selectedModuleCode === row.code ? "is-active" : "") +
        '"><span><strong>' + escapeHtml(row.name) + '</strong><small><b>' +
        escapeHtml(row.code) + '</b> · ' + escapeHtml(row.queueCode) +
        (row.referenceCount ? " · " + row.referenceCount + " routes" : "") +
        (row.active ? "" : " · Inactive") +
        '</small></span><span class="fa fa-chevron-right" aria-hidden="true"></span></button>';
    }).join("") : '<div class="ala-empty">No modules configured.</div>');
    $("ala-module-list").querySelectorAll("[data-module-code]").forEach(function (button) {
      button.addEventListener("click", function () {
        var row = state.modules.find(function (item) {
          return item.code === button.dataset.moduleCode;
        });
        if (!row) { return; }
        selectModule(row);
      });
    });
  }

  function newModule() {
    state.selectedModuleCode = null;
    $("ala-module-code").value = "";
    $("ala-module-name").value = "";
    $("ala-module-description").value = "";
    populateModuleRoleSelect("ala-module-owner","");
    $("ala-module-queue").value = "";
    populateModuleRoleSelect("ala-module-escalation","");
    $("ala-module-dashboard").value = "";
    $("ala-module-code").readOnly = false;
    $("ala-module-active").checked = true;
    $("ala-module-active").disabled = true;
    setModuleSlaControls(1440);
    updateModuleManagementActions(null);
    renderModuleList();
    $("ala-module-code").focus();
  }

  function refreshModules() {
    return server("AGENT_ADV_MODULE_LIST").then(function (data) {
      state.modules = data.modules || [];
      if ($("ala-module-list")) { renderModuleList(); }
      return data;
    }).catch(function (error) {
      showError("Module registry could not be loaded: " + error.message);
      throw error;
    });
  }

  function setModuleSlaControls(minutes) {
    var parts = durationParts(minutes || 1440);
    $("ala-module-sla").value = Number(minutes || 1440);
    $("ala-module-sla-value").value = parts.value;
    $("ala-module-sla-unit").value = parts.unit;
  }

  function moduleSlaMinutes() {
    var factors = {MINUTE: 1, HOUR: 60, DAY: 1440, WEEK: 10080};
    var value = Math.max(1, Number($("ala-module-sla-value").value || 1));
    var minutes = Math.round(value * (factors[$("ala-module-sla-unit").value] || 1));
    minutes = Math.min(525600, minutes);
    $("ala-module-sla").value = minutes;
    return minutes;
  }

  function refreshRecommendationCatalog() {
    return server("AGENT_ADV_RECOMMENDATION_CATALOG").then(function (data) {
      state.recommendationCatalog = {
        findingTypes: data.findingTypes || [],
        workflowActions: data.workflowActions || [],
        escalationRoles: data.escalationRoles || []
      };
      if ($("ala-recommendation-editor") &&
          !$("ala-recommendation-editor").hidden) {
        renderRecommendationEditor();
      }
      return data;
    }).catch(function (error) {
      showError("Recommendation governance catalogue could not be loaded: " + error.message);
      throw error;
    });
  }

  function openModuleRegistry() {
    var registry = $("ala-module-registry");
    var mount = $("ala-module-native-drawer-mount");
    var nativeRegion = $("ala-module-native-drawer");
    if (!mount || !nativeRegion) {
      showError("Oracle APEX Module Registry drawer is unavailable.");
      return Promise.reject(new Error("Module Registry drawer mount was not found."));
    }
    if (registry.parentElement !== mount) {
      mount.appendChild(registry);
    }
    registry.hidden = false;
    nativeRegion.setAttribute("title", "Module Registry");
    if (global.apex && apex.jQuery) {
      var drawerRegion = apex.jQuery(nativeRegion);
      if (drawerRegion.hasClass("ui-dialog-content") &&
          typeof drawerRegion.dialog === "function") {
        drawerRegion.dialog("option", "title", "Module Registry");
      }
    }
    apex.theme.openRegion("ala-module-native-drawer");
    fixModuleNativeDrawerFrame();
    global.requestAnimationFrame(fixModuleNativeDrawerFrame);
    document.body.classList.add("ala-overlay-open");
    return Promise.all([refreshModules(),refreshRecommendationCatalog()]).then(function () {
      if (state.modules.length) {
        var preferred = state.selectedModuleCode ?
          $("ala-module-list").querySelector(
            '[data-module-code="' + state.selectedModuleCode + '"]'
          ) : null;
        var first = preferred || $("ala-module-list").querySelector("[data-module-code]");
        if (first) { first.click(); }
      } else {
        newModule();
      }
    });
  }

  function closeModuleRegistry() {
    var registry = $("ala-module-registry");
    if (global.apex && apex.jQuery) {
      apex.jQuery("#ala-module-native-drawer").closest(".ui-dialog")
        .removeClass("is-open");
    }
    apex.theme.closeRegion("ala-module-native-drawer");
    document.body.classList.remove("ala-overlay-open");
    global.setTimeout(function () {
      registry.hidden = true;
    }, 220);
  }

  function fixModuleNativeDrawerFrame() {
    var nativeRegion = $("ala-module-native-drawer");
    if (!nativeRegion || !global.apex || !apex.jQuery) { return; }
    var frame = apex.jQuery(nativeRegion).closest(".ui-dialog");
    if (!frame.length) { return; }
    frame.addClass("ala-agent-native-drawer-frame ala-module-native-drawer-frame is-open");
    nativeRegion.classList.add("ala-agent-native-drawer-region");
  }

  function saveModule(event) {
    if (event) { event.preventDefault(); }
    if (!$("ala-module-owner").value || !$("ala-module-escalation").value) {
      showError("Select active RBAC owner and escalation roles.");
      return Promise.resolve(false);
    }
    return server("AGENT_ADV_MODULE_SAVE", {
      x01: JSON.stringify({
        code: $("ala-module-code").value.trim(),
        name: $("ala-module-name").value.trim(),
        description: $("ala-module-description").value.trim(),
        ownerRole: $("ala-module-owner").value.trim(),
        queueCode: $("ala-module-queue").value.trim(),
        defaultSlaMinutes: moduleSlaMinutes(),
        escalationRole: $("ala-module-escalation").value.trim(),
        dashboardTarget: $("ala-module-dashboard").value.trim(),
        active: $("ala-module-active").checked
      })
    }).then(function (result) {
      notify(result.message);
      state.selectedModuleCode = result.code;
      return refreshModules().then(function () {
        var button = $("ala-module-list").querySelector(
          '[data-module-code="' + result.code + '"]'
        );
        if (button) { button.click(); }
      });
    }).catch(function (error) { showError(error.message); });
  }

  function manageModule(action) {
    var row = state.modules.find(function (item) {
      return item.code === state.selectedModuleCode;
    });
    if (!row) { return; }
    if (action === "DELETE" && !global.confirm(
      "Delete module " + row.code + "? This is allowed only when it has no references."
    )) { return; }
    return server("AGENT_ADV_MODULE_MANAGE", {
      x01: row.code,
      x02: action
    }).then(function (result) {
      notify(result.message);
      if (action === "DELETE") { state.selectedModuleCode = null; }
      return refreshModules().then(function () {
        var next = state.selectedModuleCode && $("ala-module-list").querySelector(
          '[data-module-code="' + state.selectedModuleCode + '"]'
        );
        if (next) { next.click(); }
        else if (state.modules.length) {
          $("ala-module-list").querySelector("[data-module-code]").click();
        } else {
          newModule();
        }
      });
    }).catch(function (error) { showError(error.message); });
  }

  function findingAction(id, status) {
    var reason = status === "CLEARED" || status === "CLOSED" ?
      global.prompt("Reason for " + status.toLowerCase() + ":", "") : "";
    if ((status === "CLEARED" || status === "CLOSED") && reason === null) { return; }
    server("AGENT_ADV_FINDING_STATUS", {x01: id, x02: status, x03: reason || ""})
      .then(function (result) {
        notify(result.message);
        return refreshFindingsRuns();
      }).catch(function (error) { showError(error.message); });
  }

  function renderFindingsRuns() {
    var summary = state.findingSummary || {};
    $("ala-find-total").textContent = fmt.format(summary.totalFindings || 0);
    $("ala-find-open").textContent = fmt.format(summary.openFindings || 0);
    $("ala-find-critical").textContent = fmt.format(summary.criticalOpen || 0);

    var findingMeta = state.findingPageMeta || {};
    var findingStart = (state.findingPage - 1) *
      Number($("ala-finding-page-size").value || 25);
    $("ala-finding-range").textContent = state.findings.length ?
      (findingStart + 1) + "–" + (findingStart + state.findings.length) +
      (findingMeta.hasMore ? " · more available" : "") : "0 records";
    $("ala-finding-prev").disabled = !findingMeta.hasPrevious;
    $("ala-finding-next").disabled = !findingMeta.hasMore;
    $("ala-finding-body").innerHTML = state.findings.length ? state.findings.map(function (row) {
      return "<tr><td><strong>" + escapeHtml(row.agentId) + "</strong></td><td>" +
        escapeHtml(row.policyName) + "<br><small>" +
        escapeHtml(row.bucketName || row.configName || "—") + "</small></td><td>" +
        '<span class="ala-status-badge ala-status-' + String(row.status || "").toLowerCase() + '">' +
        escapeHtml(row.status) + "</span></td><td>" +
        escapeHtml((row.criticality || "—") + " / " + (row.riskClass || "—")) +
        "<br><small>Score " + escapeHtml(row.score == null ? "—" : row.score) +
        '</small></td><td><span class="ala-module-pills">' +
        (row.moduleCodes ? row.moduleCodes.split(",").map(function (code) {
          return '<em>' + escapeHtml(code) + '</em>';
        }).join("") : '<small>Not routed</small>') +
        "</span></td><td>" + fmt.format(row.recommendationCount || 0) +
        (row.nextSlaDue ? "<br><small>SLA " + escapeHtml(row.nextSlaDue) + "</small>" : "") +
        "</td><td>" + fmt.format(row.detectionCount || 0) +
        "</td><td>" + escapeHtml(row.lastDetected) +
        '</td><td><div class="ala-row-actions"><button type="button" class="ala-icon-button" data-finding-detail="' +
        row.id + '"><span class="fa fa-eye"></span> Details</button><select data-finding-action="' +
        row.id + '"><option value="">Action...</option><option>ACKNOWLEDGED</option><option>ESCALATED</option>' +
        '<option>CLEARED</option><option>CLOSED</option></select></div></td></tr>';
    }).join("") : '<tr><td colspan="9" class="ala-empty">No findings match the current filters.</td></tr>';
    document.querySelectorAll("[data-finding-detail]").forEach(function (button) {
      button.addEventListener("click", function () {
        openFindingDetail(button.dataset.findingDetail);
      });
    });
    document.querySelectorAll("[data-finding-action]").forEach(function (select) {
      select.addEventListener("change", function () {
        if (select.value) { findingAction(select.dataset.findingAction, select.value); }
      });
    });

    var runMeta = state.runPageMeta || {};
    var runStart = (state.runPage - 1) * Number($("ala-run-page-size").value || 25);
    $("ala-run-range").textContent = state.runs.length ?
      (runStart + 1) + "–" + (runStart + state.runs.length) +
      (runMeta.hasMore ? " · more available" : "") : "0 records";
    $("ala-run-prev").disabled = !runMeta.hasPrevious;
    $("ala-run-next").disabled = !runMeta.hasMore;
    $("ala-run-body").innerHTML = state.runs.length ? state.runs.map(function (row) {
      return "<tr><td><strong>#" + row.id + "</strong><br><small>" + escapeHtml(row.type) +
        "</small></td><td>" + escapeHtml(row.policyName) + "</td><td>" +
        '<span class="ala-status-badge ala-status-' + String(row.status || "").toLowerCase() + '">' +
        escapeHtml(row.status) + "</span></td><td>" + escapeHtml(row.evaluationFrom) + " to " +
        escapeHtml(row.evaluationTo) + "</td><td>" + fmt.format(row.agentsEvaluated || 0) +
        "</td><td>" + fmt.format(row.configMatches || 0) + "</td><td>" +
        fmt.format(row.bucketMatches || 0) + "</td><td>" +
        fmt.format(row.findingsCreated || 0) + "</td><td>" +
        fmt.format(row.findingsUpdated || 0) + "</td><td>" +
        escapeHtml(row.startedOn || "—") + "</td><td>" +
        escapeHtml(row.completedOn || "—") + "</td></tr>";
    }).join("") : '<tr><td colspan="11" class="ala-empty">No policy runs match the current filters.</td></tr>';
  }

  function renderFindingDetail(data) {
    var finding = data.finding || {};
    $("ala-finding-detail-title").textContent =
      "Finding #" + (finding.id || "") + " · " + (finding.agentId || "");
    var routes = data.routes || [];
    var recommendations = data.recommendations || [];
    var occurrences = data.occurrences || [];
    var events = data.events || [];
    $("ala-finding-detail-body").innerHTML =
      '<section class="ala-detail-summary"><div><span>Status</span><strong>' +
      escapeHtml(finding.status || "—") + '</strong></div><div><span>Risk</span><strong>' +
      escapeHtml((finding.criticality || "—") + " / " + (finding.riskClass || "—")) +
      '</strong></div><div><span>Score</span><strong>' +
      escapeHtml(finding.score == null ? "—" : finding.score) +
      '</strong></div><div><span>Detections</span><strong>' +
      fmt.format(finding.detectionCount || 0) + '</strong></div></section>' +
      '<section class="ala-detail-section"><h3>Module Routes</h3>' +
      (routes.length ? routes.map(function (row) {
        return '<article class="ala-route-card"><div><span class="ala-module-pill">' +
          escapeHtml(row.moduleCode) + '</span><strong>' + escapeHtml(row.moduleName) +
          '</strong><small>' + escapeHtml(row.queueCode) + '</small></div><div><span class="ala-status-badge">' +
          escapeHtml(row.status) + '</span><small>SLA ' + escapeHtml(row.slaDue) +
          '</small></div></article>';
      }).join("") : '<div class="ala-empty">No module route generated.</div>') + '</section>' +
      '<section class="ala-detail-section"><h3>Personalized Recommendations</h3>' +
      (recommendations.length ? recommendations.map(function (row) {
        return '<article class="ala-recommendation-card"><header><span class="ala-module-pill">' +
          escapeHtml(row.moduleCode) + '</span><strong>' + escapeHtml(row.findingType) +
          '</strong></header><p>' + escapeHtml(row.message) + '</p>' +
          '<div class="ala-rec-values"><span>Actual <strong>' +
          escapeHtml(row.actualValue || "—") + '</strong></span><span>Baseline <strong>' +
          escapeHtml(row.baselineValue || "—") + '</strong></span><span>Expected <strong>' +
          escapeHtml(row.expectedValue || "—") + '</strong></span><span>Variance <strong>' +
          escapeHtml(row.varianceValue || "—") + '</strong></span></div><small>' +
          escapeHtml(row.workflowAction) + ' · SLA ' + escapeHtml(row.slaDue) +
          (row.approvalRequired ? ' · Approval required' : '') + '</small></article>';
      }).join("") : '<div class="ala-empty">No personalized recommendation generated.</div>') +
      '</section><section class="ala-detail-section"><h3>Detection History</h3><div class="ala-timeline">' +
      (occurrences.length ? occurrences.map(function (row) {
        return '<div><i></i><span><strong>' + escapeHtml(row.type) + ' · Run #' +
          escapeHtml(row.runId) + '</strong><small>' + escapeHtml(row.detectedOn) +
          ' · ' + escapeHtml(row.evaluationFrom) + ' to ' + escapeHtml(row.evaluationTo) +
          '</small></span></div>';
      }).join("") : '<div class="ala-empty">No occurrence history in the retained window.</div>') +
      '</div></section><section class="ala-detail-section"><h3>Lifecycle Events</h3><div class="ala-timeline">' +
      (events.length ? events.map(function (row) {
        return '<div><i></i><span><strong>' + escapeHtml(row.type) + '</strong><small>' +
          escapeHtml(row.eventOn) + ' · ' + escapeHtml(row.eventBy) + '</small></span></div>';
      }).join("") : '<div class="ala-empty">No lifecycle events.</div>') + '</div></section>';
  }

  function openFindingDetail(id) {
    $("ala-finding-detail").hidden = false;
    $("ala-finding-detail-body").innerHTML =
      '<div class="ala-empty"><span class="fa fa-spinner fa-spin"></span> Loading finding journey...</div>';
    return server("AGENT_ADV_FINDING_DETAIL", {x01: id}).then(function (data) {
      if (data.error) { throw new Error(data.error); }
      renderFindingDetail(data);
    }).catch(function (error) {
      $("ala-finding-detail-body").innerHTML =
        '<div class="ala-empty">' + escapeHtml(error.message) + '</div>';
    });
  }

  function closeFindingDetail() {
    $("ala-finding-detail").hidden = true;
  }

  function refreshFindingsRuns() {
    return server("AGENT_ADV_FINDINGS_RUNS", {
      x01: JSON.stringify({
        findingPage: state.findingPage,
        findingPageSize: Number($("ala-finding-page-size").value || 25),
        findingStatus: $("ala-finding-status").value,
        findingSearch: $("ala-finding-search").value.trim(),
        runPage: state.runPage,
        runPageSize: Number($("ala-run-page-size").value || 25),
        runStatus: $("ala-run-status").value,
        runSearch: $("ala-run-search").value.trim()
      })
    }).then(function (data) {
      state.findingSummary = data.summary || {};
      state.findings = data.findings || [];
      state.runs = data.runs || [];
      state.findingPageMeta = data.findingPage || {};
      state.runPageMeta = data.runPage || {};
      renderFindingsRuns();
      return data;
    }).catch(function (error) {
      showError("Findings and runs could not be loaded: " + error.message);
      throw error;
    });
  }

  function runPolicyNow() {
    if (!$("ala-run-policy").value || !$("ala-run-from").value || !$("ala-run-to").value) {
      showError("Select a policy and evaluation date range.");
      return;
    }
    server("AGENT_ADV_POLICY_RUN", {
      x01: JSON.stringify({
        policyVersionId: Number($("ala-run-policy").value),
        evaluationFrom: $("ala-run-from").value,
        evaluationTo: $("ala-run-to").value
      })
    }).then(function (result) {
      notify(result.message + " Run #" + result.runId);
      return refreshFindingsRuns();
    }).catch(function (error) { showError(error.message); });
  }

  function reset() {
    [
      "ala-state", "ala-district", "ala-subdistrict", "ala-village", "ala-search",
      "ala-status", "ala-risk", "ala-platform", "ala-application-version",
      "ala-service-family",
      "ala-service-name", "ala-transaction-type", "ala-is-onus",
      "ala-is-original", "ala-response-code", "ala-is-financial"
    ].forEach(function (id) { $(id).value = ""; });
    $("ala-mode").value = "DAILY";
    $("ala-metric").value = "AGENT_COUNT";
    renderConditionTree({operator: "AND", children: []});
    state.selectedFilterId = null;
    state.selectedFilterVersion = null;
    state.appliedClassBucket = null;
    state.appliedBucket = null;
    state.appliedConfiguration = null;
    state.rbacVerticalId = null;
    state.rbacNodeId = null;
    state.rbacNodeName = "";
    state.rbacVerticalSelections = {};
    state.facetRbacVerticalId = null;
    state.facetRbacNodeId = null;
    state.facetRbacNodeName = "";
    state.facetRbacHierarchyData = null;
    state.facetRbacVerticalSelections = {};
    state.facetRbacActivated = false;
    state.analyticsRiskBand = "";
    state.mapSelectedStateName = "";
    state.mapSelectedStateCode = "";
    resetMapView();
    $("ala-filter-badge").textContent = "Unsaved analysis";
    updateAnalyticsContext();
    loadRbacHierarchy().then(function () {
      return load(false);
    }).catch(function () {});
  }
  function mapBack() {
    if (isAnalyticsLocked("ala-map-card")) { return; }
    resetMapView();
    if ($("ala-subdistrict").value) { $("ala-subdistrict").value = ""; }
    else if ($("ala-district").value) { $("ala-district").value = ""; }
    else {
      $("ala-state").value = "";
      state.mapSelectedStateName = "";
      state.mapSelectedStateCode = "";
    }
    synchronizeMapWithRbacAnalytics().catch(function () {});
  }
  function geographyFacetChanged(level) {
    resetMapView();
    if (level === "state") {
      $("ala-district").value = "";
      $("ala-subdistrict").value = "";
      state.mapSelectedStateCode = $("ala-state").value || "";
      state.mapSelectedStateName = $("ala-state").value ?
        selectedOptionLabel("ala-state", "").replace(/\s*\([\d,]+\)\s*$/, "") : "";
    } else if (level === "district") {
      $("ala-subdistrict").value = "";
    }
    loadFacets().catch(function () {});
  }
  function isAnalyticsLocked(cardId) {
    return Boolean(state.analyticsLocks[cardId]);
  }
  function toggleAnalyticsLock(cardId) {
    var card = $(cardId);
    if (!card) { return; }
    state.analyticsLocks[cardId] = !isAnalyticsLocked(cardId);
    card.classList.toggle("is-interaction-locked", state.analyticsLocks[cardId]);
    var button = document.querySelector('[data-analytics-lock="' + cardId + '"]');
    if (button) {
      var locked = state.analyticsLocks[cardId];
      button.classList.toggle("is-active", locked);
      button.setAttribute("aria-pressed", locked ? "true" : "false");
      button.title = locked ? "Unlock drill interactions" : "Lock drill interactions";
      button.setAttribute("aria-label", button.title);
      var icon = button.querySelector(".fa");
      if (icon) { icon.className = "fa fa-" + (locked ? "lock" : "unlock"); }
    }
  }
  function toggleAnalyticsFullscreen(cardId) {
    var card = $(cardId);
    if (!card) { return; }
    if (document.fullscreenElement === card) {
      document.exitFullscreen();
      return;
    }
    if (card.requestFullscreen) {
      card.requestFullscreen().catch(function (error) {
        showError("Full-screen view could not be opened: " + error.message);
      });
      return;
    }
    card.classList.toggle("ala-card-fallback-fullscreen");
  }
  function syncAnalyticsFullscreen() {
    document.querySelectorAll(".ala-control-card").forEach(function (card) {
      card.classList.toggle("is-fullscreen", document.fullscreenElement === card);
    });
    document.querySelectorAll("[data-analytics-fullscreen]").forEach(function (button) {
      var active = document.fullscreenElement &&
        document.fullscreenElement.id === button.dataset.analyticsFullscreen;
      button.title = active ? "Exit Full Screen" : "Full Screen";
      button.setAttribute("aria-label", button.title);
      var icon = button.querySelector(".fa");
      if (icon) { icon.className = "fa fa-" + (active ? "compress" : "expand"); }
      var label = button.querySelector(".fa+span");
      if (label) { label.textContent = active ? "Exit Full Screen" : "Full Screen"; }
    });
  }
  function init() {
    if (!$("ala-app") || $("ala-app").dataset.initialized) { return; }
    $("ala-app").dataset.initialized = "true";
    mountSubbucketSupportingPanels();
    renderConditionTree({operator: "AND", children: []});
    ensureSubbucketSavebar();
    prepareInlineConfigurationEditor();
    prepareAnalyticsControlPlane();
    bindMapNavigation();
    bindHierarchyControls();
    switchAnalyticsView("visuals");
    bindAnalyticsDelegates();
    document.querySelectorAll("#ala-panel-analytics input,#ala-panel-analytics select").forEach(function (control) {
      if (control.type !== "hidden" && control.id !== "ala-rbac-hierarchy" &&
          control.id !== "ala-hierarchy-limit" &&
          ["ala-state", "ala-district", "ala-subdistrict"].indexOf(control.id) < 0) {
        control.addEventListener(
          control.type === "search" || control.type === "text" ? "input" : "change",
          control.closest("#ala-side-panel-facets") ?
            debouncedFacetLoad : debouncedLoad
        );
      }
    });
    $("ala-state").addEventListener("change", function () {
      geographyFacetChanged("state");
    });
    $("ala-district").addEventListener("change", function () {
      geographyFacetChanged("district");
    });
    $("ala-subdistrict").addEventListener("change", function () {
      geographyFacetChanged("subdistrict");
    });
    $("ala-rbac-hierarchy").addEventListener("change", function () {
      selectFacetRbacVertical($("ala-rbac-hierarchy").value).catch(function () {});
    });
    $("ala-service-family").addEventListener("change", function () {
      $("ala-service-name").value = "";
    });
    document.querySelectorAll(".ala-tab").forEach(function (button) {
      button.addEventListener("click", function () {
        switchTab(button.dataset.tab === "conditions" ? "buckets" : button.dataset.tab);
      });
    });
    document.querySelectorAll("[data-workflow-view]").forEach(function (button) {
      button.addEventListener("click", function () { switchTab(button.dataset.workflowView); });
    });
    document.querySelectorAll("[data-side-tab]").forEach(function (button) {
      button.addEventListener("click", function () {
        switchAnalysisSideTab(button.dataset.sideTab);
      });
    });
    document.querySelectorAll("[data-open-facet-rail]").forEach(function (button) {
      button.addEventListener("click", function () {
        setAnalysisRailCollapsed(false);
        switchAnalysisSideTab("facets");
      });
    });
    document.querySelectorAll("[data-analytics-view]").forEach(function (button) {
      button.addEventListener("click", function () {
        switchAnalyticsView(button.dataset.analyticsView);
      });
    });
    document.querySelectorAll("[data-facet-toggle]").forEach(function (button) {
      button.addEventListener("click", function () { toggleFacetGroup(button); });
    });
    if ($("ala-collapse-analysis-side")) {
      $("ala-collapse-analysis-side").addEventListener("click", toggleAnalysisRail);
    }
    document.querySelectorAll("[data-open-filter-drawer]").forEach(function (button) {
      button.addEventListener("click", openFilterDrawer);
    });
    document.querySelectorAll("[data-close-filter-drawer]").forEach(function (button) {
      button.addEventListener("click", closeFilterDrawer);
    });
    document.querySelectorAll("[data-filter-drawer-tab]").forEach(function (button) {
      button.addEventListener("click", function () {
        switchFilterDrawerTab(button.dataset.filterDrawerTab);
      });
    });
    if ($("ala-toggle-kpis")) {
      $("ala-toggle-kpis").addEventListener("click", toggleKpis);
    }
    $("ala-rule-explorer-refresh").addEventListener("click", function () {
      state.analysisTreeSubbuckets = {};
      state.expandedAnalysisBuckets = {};
      Promise.all([refreshBuckets(), refreshSavedFilters()]).catch(function () {});
    });
    $("ala-apply").addEventListener("click", function () {
      loadFacets().catch(function () {});
    });
    $("ala-filter-clear").addEventListener("click", function () {
      reset();
    });
    if ($("ala-reset")) { $("ala-reset").addEventListener("click", reset); }
    $("ala-map-back").addEventListener("click", mapBack);
    document.querySelectorAll("[data-analytics-lock]").forEach(function (button) {
      button.addEventListener("click", function () {
        toggleAnalyticsLock(button.dataset.analyticsLock);
      });
    });
    document.querySelectorAll("[data-analytics-fullscreen]").forEach(function (button) {
      button.addEventListener("click", function () {
        toggleAnalyticsFullscreen(button.dataset.analyticsFullscreen);
      });
    });
    document.addEventListener("fullscreenchange", syncAnalyticsFullscreen);
    $("ala-edit-conditions").addEventListener("click", function () { switchTab("buckets"); });
    $("ala-back-to-bucket").addEventListener("click", function () {
      closeInlineConfigurationEditor(false).then(function (allowed) {
        if (!allowed) { return; }
        state.configEditorFromBucket = false;
        state.configEditorReplaceId = null;
        switchTab("buckets");
      });
    });
    $("ala-apply-conditions").addEventListener("click", applyConfigurationToAnalytics);
    $("ala-test-filter").addEventListener("click", validateConfiguration);
    $("ala-save-draft").addEventListener("click", function () { saveFilter(false); });
    $("ala-save-active").addEventListener("click", function () { saveFilter(true); });
    $("ala-retire-filter").addEventListener("click", retireFilter);
    $("ala-new-filter").addEventListener("click", newFilter);
    $("ala-saved-search").addEventListener("input", renderSavedList);
    $("ala-new-bucket").addEventListener("click", function () {
      guardSubbucketNavigation().then(function (allowed) {
        if (allowed) {
          forceCloseConfigurationEditor();
          state.subbucketEditorBaseline = null;
          newClassBucket();
        }
      });
    });
    $("ala-new-subbucket").addEventListener("click", function () {
      createSubbucketSafely(state.selectedClassBucketId);
    });
    $("ala-back-to-class-bucket").addEventListener("click", function () {
      navigateToClassBucket(state.selectedClassBucketId);
    });
    $("ala-save-class-bucket-draft").addEventListener("click", function () {
      saveClassBucket(false);
    });
    $("ala-save-class-bucket-active").addEventListener("click", function () {
      saveClassBucket(true);
    });
    $("ala-test-class-bucket").addEventListener("click", validateClassBucket);
    $("ala-apply-class-bucket").addEventListener("click", applyClassBucketToAnalytics);
    $("ala-retire-class-bucket").addEventListener("click", retireClassBucket);
    document.querySelectorAll("input[name=ala-assignment-mode]").forEach(function (control) {
      control.addEventListener("change", updateWinnerStrategyVisibility);
    });
    $("ala-create-bucket-config").addEventListener("click", function () {
      openBucketConfigurationEditor(null);
    });
    $("ala-bucket-search").addEventListener("input", renderBucketList);
    $("ala-open-config-picker").addEventListener("click", openConfigPicker);
    $("ala-config-picker-search").addEventListener("input", renderConfigPicker);
    document.querySelectorAll("[data-close-config-picker]").forEach(function (button) {
      button.addEventListener("click", closeConfigPicker);
    });
    document.addEventListener("click", function (event) {
      if (!event.target.closest(".ala-field-picker") &&
          !event.target.closest(".ala-field-picker-popover")) {
        closeFieldPickers();
      }
    });
    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape" && document.querySelector(".ala-field-picker.is-open")) {
        closeFieldPickers();
      } else if (event.key === "Escape" && !$("ala-config-picker").hidden) { closeConfigPicker(); }
      else if (event.key === "Escape" && state.configurationDrawerOpen) {
        closeInlineConfigurationEditor(false);
      } else if (event.key === "Escape" && state.filterDrawerOpen) {
        closeFilterDrawer();
      }
    });
    $("ala-finalizer-enabled").addEventListener("change", function () {
      $("ala-finalizer-controls").hidden = !$("ala-finalizer-enabled").checked;
      if ($("ala-finalizer-enabled").checked) { updateFinalizerValueControl(); }
    });
    $("ala-finalizer-type").addEventListener("change", updateFinalizerValueControl);
    document.querySelectorAll("[data-bucket-editor-tab]").forEach(function (button) {
      button.addEventListener("click", function () {
        switchBucketEditorTab(button.dataset.bucketEditorTab);
      });
    });
    $("ala-add-risk-band").addEventListener("click", function () {
      syncRiskBands();
      var last = state.bucketRiskBands[state.bucketRiskBands.length - 1];
      var minimum = last ? last.maximum : 0;
      state.bucketRiskBands.push({
        code: "BAND_" + (state.bucketRiskBands.length + 1),
        name: "New Band", minimum: minimum, maximum: minimum + 25,
        riskClass: "MEDIUM", criticality: "MEDIUM", priority: 100,
        colour: "#7B8794", findingAction: "CREATE"
      });
      renderRiskBands();
    });
    ["ala-config-window-mode", "ala-config-window-value",
      "ala-config-window-start", "ala-config-window-end"].forEach(function (id) {
      $(id).addEventListener("change", updateWindowControls);
    });
    $("ala-save-bucket-draft").addEventListener("click", function () { saveBucket(false); });
    $("ala-save-bucket-active").addEventListener("click", function () { saveBucket(true); });
    $("ala-test-bucket").addEventListener("click", validateBucket);
    $("ala-apply-bucket").addEventListener("click", applyBucketToAnalytics);
    $("ala-retire-bucket").addEventListener("click", retireBucket);
    $("ala-save-policy").addEventListener("click", savePolicy);
    $("ala-save-schedule").addEventListener("click", saveSchedule);
    $("ala-new-schedule").addEventListener("click", newSchedule);
    $("ala-cancel-schedule").addEventListener("click", newSchedule);
    ["ala-schedule-frequency", "ala-schedule-days", "ala-schedule-time"].forEach(function (id) {
      $(id).addEventListener("change", buildCalendarExpression);
    });
    $("ala-run-now").addEventListener("click", runPolicyNow);
    ["ala-finding-search", "ala-finding-status", "ala-finding-page-size"].forEach(function (id) {
      $(id).addEventListener(id === "ala-finding-search" ? "input" : "change", function () {
        state.findingPage = 1;
        global.clearTimeout(findingsRefreshTimer);
        findingsRefreshTimer = global.setTimeout(refreshFindingsRuns, id === "ala-finding-search" ? 300 : 0);
      });
    });
    ["ala-run-search", "ala-run-status", "ala-run-page-size"].forEach(function (id) {
      $(id).addEventListener(id === "ala-run-search" ? "input" : "change", function () {
        state.runPage = 1;
        global.clearTimeout(findingsRefreshTimer);
        findingsRefreshTimer = global.setTimeout(refreshFindingsRuns, id === "ala-run-search" ? 300 : 0);
      });
    });
    $("ala-finding-prev").addEventListener("click", function () {
      state.findingPage = Math.max(1, state.findingPage - 1); refreshFindingsRuns();
    });
    $("ala-finding-next").addEventListener("click", function () {
      state.findingPage += 1; refreshFindingsRuns();
    });
    $("ala-run-prev").addEventListener("click", function () {
      state.runPage = Math.max(1, state.runPage - 1); refreshFindingsRuns();
    });
    $("ala-run-next").addEventListener("click", function () {
      state.runPage += 1; refreshFindingsRuns();
    });
    if ($("ala-manage-modules")) {
      $("ala-manage-modules").addEventListener("click", openModuleRegistry);
    }
    if ($("ala-new-module")) {
      $("ala-new-module").addEventListener("click", newModule);
    }
    if ($("ala-save-module")) {
      $("ala-save-module").addEventListener("click", saveModule);
    }
    if ($("ala-toggle-module")) {
      $("ala-toggle-module").addEventListener("click", function () {
        var row = state.modules.find(function (item) {
          return item.code === state.selectedModuleCode;
        });
        if (row) { manageModule(row.active ? "DISABLE" : "ENABLE"); }
      });
    }
    if ($("ala-delete-module")) {
      $("ala-delete-module").addEventListener("click", function () {
        manageModule("DELETE");
      });
    }
    document.querySelectorAll("[data-close-module-registry]").forEach(function (button) {
      button.addEventListener("click", closeModuleRegistry);
    });
    if (global.apex && apex.jQuery && $("ala-module-native-drawer")) {
      apex.jQuery("#ala-module-native-drawer")
        .on("dialogopen", function () {
          document.body.classList.add("ala-overlay-open");
          fixModuleNativeDrawerFrame();
        })
        .on("dialogclose", function () {
          apex.jQuery(this).closest(".ui-dialog").removeClass("is-open");
          document.body.classList.remove("ala-overlay-open");
          $("ala-module-registry").hidden = true;
        });
    }
    document.querySelectorAll("[data-close-finding-detail]").forEach(function (button) {
      button.addEventListener("click", closeFindingDetail);
    });
    var today = new Date().toISOString().slice(0, 10);
    $("ala-run-from").value = today;
    $("ala-run-to").value = today;
    newSchedule();
    Promise.all([refreshModules(), refreshRecommendationCatalog()]).catch(function () {});
    loadFieldCatalog().then(refreshSavedFilters).catch(function () {});
    refreshBuckets().then(function () {
      if (state.buckets.length) {
        loadClassBucket(state.buckets[0].id);
      } else {
        newClassBucket();
      }
    });
    refreshMonitoring().catch(function () {});
    refreshFindingsRuns().catch(function () {});
    loadRbacHierarchy().then(function () {
      return load(false);
    }).catch(function () {});
  }

  global.AgentLocationAnalyser = {init: init, refresh: load};
  document.addEventListener("DOMContentLoaded", init);
})(window);
