(function (global, apex) {
  "use strict";

  var root;
  var state = {
    data: null,
    pipelineId: null,
    scriptType: "EXECUTION_PLAN",
    stage: "basics",
    loading: false,
    dirty: false,
    pollTimer: null,
    sourceCatalog: [],
    targetCatalog: [],
    columnCache: {},
    targetColumns: [],
    operation: null,
    operationConfig: null,
    operationEditIndex: null,
    operationEditKind: null,
    dashboardData: null,
    dashboardGranularity: "DAILY",
    dashboardPipelineId: null,
    dashboardBucket: "",
    dashboardFailureFilter: "",
    lastErrorMessage: "",
    lastErrorOn: 0,
    globalErrorsBound: false
  };

  function byId(id) {
    return document.getElementById(id);
  }

  function all(selector, context) {
    return Array.prototype.slice.call((context || document).querySelectorAll(selector));
  }

  function value(id, fallback) {
    var node = byId(id);
    return node && node.value !== "" ? node.value : (fallback == null ? "" : fallback);
  }

  function numberValue(id, fallback) {
    var parsed = Number(value(id, fallback));
    return Number.isFinite(parsed) ? parsed : Number(fallback || 0);
  }

  function checked(id) {
    var node = byId(id);
    return Boolean(node && node.checked);
  }

  function setValue(id, next) {
    var node = byId(id);
    if (node) {
      node.value = next == null ? "" : String(next);
    }
  }

  function setChecked(id, next) {
    var node = byId(id);
    if (node) {
      node.checked = Boolean(next);
    }
  }

  function clear(node) {
    while (node && node.firstChild) {
      node.removeChild(node.firstChild);
    }
  }

  function text(tag, className, content) {
    var node = document.createElement(tag);
    if (className) {
      node.className = className;
    }
    node.textContent = content == null ? "" : String(content);
    return node;
  }

  function option(valueText, label, selected) {
    var node = document.createElement("option");
    node.value = valueText == null ? "" : String(valueText);
    node.textContent = label == null ? "" : String(label);
    node.selected = Boolean(selected);
    return node;
  }

  function friendlyError(error) {
    var raw = error && error.message ? error.message : String(error || "");
    var applicationError = raw.match(/ORA-20\d{3}:\s*([^<\r\n]+)/i);
    if (applicationError) {
      return applicationError[1].trim();
    }
    if (/ORA-00001/i.test(raw)) {
      return "A record with the same code already exists.";
    }
    if (/ORA-02292|integrity constraint.*child record/i.test(raw)) {
      return "This record is still in use and cannot be deleted.";
    }
    if (/ORA-01017/i.test(raw)) {
      return "The database username or password is not valid.";
    }
    if (/ORA-12154|ORA-12514|ORA-12541|network adapter/i.test(raw)) {
      return "The configured database service could not be reached.";
    }
    if (/failed to fetch|networkerror|ajax call returned server error/i.test(raw)) {
      return "The server could not be reached. Check the connection and try again.";
    }
    if (
      /ReferenceError|TypeError|SyntaxError|is not defined|cannot read propert/i.test(raw)
    ) {
      return "The ETL page encountered an unexpected problem. Refresh the page and try again.";
    }
    raw = raw
      .replace(/^Error:\s*/i, "")
      .replace(/ORA-06512:[\s\S]*/i, "")
      .replace(/\s+/g, " ")
      .trim();
    if (!raw || /^error$/i.test(raw) || raw.length > 260) {
      return "The action could not be completed. Refresh the page and try again.";
    }
    return raw;
  }

  function notify(message, type) {
    var displayMessage = type === "error" ?
      friendlyError(message) : String(message || "");
    if (type === "error") {
      var now = Date.now();
      if (
        state.lastErrorMessage === displayMessage &&
        now - state.lastErrorOn < 1500
      ) {
        return;
      }
      state.lastErrorMessage = displayMessage;
      state.lastErrorOn = now;
      if (global.console && console.error) {
        console.error("[SBOS ETL]", message);
      }
    }
    if (apex && apex.message) {
      if (type === "error") {
        apex.message.clearErrors();
        apex.message.showErrors([{
          type: "error",
          location: ["page"],
          message: displayMessage,
          unsafe: false
        }]);
      } else {
        apex.message.showPageSuccess(displayMessage);
      }
    }
    var live = byId("sbos-etl-live");
    if (live) {
      live.textContent = displayMessage;
    }
  }

  function confirmAction(message, callback) {
    if (apex && apex.message && apex.message.confirm) {
      apex.message.confirm(message, function (confirmed) {
        if (confirmed) {
          callback();
        }
      });
      return;
    }
    if (global.confirm(message)) {
      callback();
    }
  }

  function refreshNativeReport(regionName) {
    if (apex && apex.region) {
      try {
        apex.region(regionName).refresh();
      } catch (ignore) {
        // The next bootstrap render will attach and refresh the report.
      }
    }
  }

  function server(processName, payload) {
    return new Promise(function (resolve, reject) {
      apex.server.process(
        processName,
        payload || {},
        {
          dataType: "json",
          success: function (result) {
            if (result && result.success !== false) {
              resolve(result);
            } else {
              reject(new Error((result && result.message) || "The server rejected the request."));
            }
          },
          error: function (request, status, error) {
            var message = error || status || "The server request failed.";
            if (request && request.responseJSON && request.responseJSON.error) {
              message = request.responseJSON.error;
            } else if (request && request.responseText) {
              var match = request.responseText.match(/ORA-\d+:[^<\n]+/);
              if (match) {
                message = match[0];
              }
            }
            reject(new Error(message));
          }
        }
      );
    });
  }

  function setBusy(isBusy, message) {
    state.loading = isBusy;
    root.classList.toggle("is-loading", isBusy);
    all("button,select,input,textarea", root).forEach(function (node) {
      if (node.dataset.keepEnabled !== "true") {
        if (isBusy) {
          node.dataset.sbosWasDisabled = node.disabled ? "true" : "false";
          node.disabled = true;
        } else if (node.dataset.sbosWasDisabled) {
          node.disabled = node.dataset.sbosWasDisabled === "true";
          delete node.dataset.sbosWasDisabled;
        }
      }
    });
    var label = byId("sbos-etl-loading-label");
    if (label) {
      label.textContent = message || "Working…";
    }
  }

  function withBusy(message, callback) {
    if (state.loading) {
      return Promise.resolve();
    }
    setBusy(true, message);
    return Promise.resolve()
      .then(callback)
      .catch(function (error) {
        notify(error, "error");
      })
      .finally(function () {
        setBusy(false);
        updateActionStates();
        switchStage(state.stage);
      });
  }

  function badgeClass(status) {
    var normalized = String(status || "DRAFT").toLowerCase().replace(/_/g, "-");
    return "sbos-badge sbos-badge--" + normalized;
  }

  function renderPipelineSelector() {
    var select = byId("sbos-etl-pipeline-select");
    if (!select) {
      return;
    }
    clear(select);
    if (!state.pipelineId) {
      select.appendChild(option("", "Unsaved new pipeline", true));
    }
    (state.data.pipelines || []).forEach(function (pipeline) {
      select.appendChild(option(
        pipeline.id,
        pipeline.code + " · " + pipeline.name,
        Number(pipeline.id) === Number(state.pipelineId)
      ));
    });
  }

  function renderPipelineManagement() {
    var body = byId("sbos-pipeline-body");
    if (!body) {
      attachNativeReports();
      return;
    }
    clear(body);
    var search = value("sbos-pipeline-search").trim().toUpperCase();
    var status = value("sbos-pipeline-status-filter").trim().toUpperCase();
    (state.data.pipelines || []).filter(function (pipeline) {
      var haystack = [
        pipeline.code, pipeline.name, pipeline.target
      ].join(" ").toUpperCase();
      return (!search || haystack.indexOf(search) >= 0) &&
        (!status || String(pipeline.status).toUpperCase() === status);
    }).forEach(function (pipeline) {
      var row = document.createElement("tr");
      var identity = document.createElement("td");
      identity.appendChild(text("strong", "", pipeline.code));
      identity.appendChild(text("small", "sbos-table-subtitle", pipeline.name));
      row.appendChild(identity);
      row.appendChild(text("td", "", pipeline.target || "Not configured"));
      var statusCell = document.createElement("td");
      statusCell.appendChild(text("span", badgeClass(pipeline.status), pipeline.status));
      row.appendChild(statusCell);
      row.appendChild(text("td", "", "v" + pipeline.version));
      row.appendChild(text("td", "", String(pipeline.sourceCount || 0)));
      row.appendChild(text("td", "sbos-schedule-summary", pipeline.schedule || "Not configured"));
      var lastRun = document.createElement("td");
      lastRun.appendChild(text(
        "span",
        pipeline.lastRunStatus ? badgeClass(pipeline.lastRunStatus) : "sbos-muted",
        pipeline.lastRunStatus || "No runs"
      ));
      lastRun.appendChild(text("small", "sbos-table-subtitle", pipeline.lastRunOn || ""));
      row.appendChild(lastRun);
      var actions = document.createElement("td");
      var edit = text("button", "sbos-btn sbos-btn--ghost", "Configure");
      edit.type = "button";
      edit.dataset.action = "open-pipeline";
      edit.dataset.pipelineId = String(pipeline.id);
      actions.appendChild(edit);
      var runs = text("button", "sbos-link-button", "Runs");
      runs.type = "button";
      runs.dataset.action = "open-runs";
      runs.dataset.pipelineId = String(pipeline.id);
      actions.appendChild(runs);
      row.appendChild(actions);
      body.appendChild(row);
    });
    if (!body.children.length) {
      var emptyRow = document.createElement("tr");
      var emptyCell = text("td", "sbos-empty-state", "No pipelines match the current filters.");
      emptyCell.colSpan = 8;
      emptyRow.appendChild(emptyCell);
      body.appendChild(emptyRow);
    }
  }

  function connectionOptions(select, selectedId) {
    clear(select);
    (state.data.connections || []).filter(function (connection) {
      return connection.enabled ||
        Number(connection.id) === Number(selectedId);
    }).forEach(function (connection) {
      select.appendChild(option(
        connection.id,
        connection.name + " · " + connection.type,
        Number(connection.id) === Number(selectedId)
      ));
    });
  }

  function connectionForId(connectionId) {
    return (state.data.connections || []).find(function (connection) {
      return Number(connection.id) === Number(connectionId);
    }) || {};
  }

  function configureConnectionFields() {
    var isRemote = value("sbos-connection-type") === "ORACLE_DB_LINK";
    var dbLink = byId("sbos-connection-dblink");
    if (dbLink) {
      dbLink.disabled = !isRemote;
      dbLink.required = isRemote;
      if (!isRemote) {
        dbLink.value = "";
      }
    }
    var username = byId("sbos-connection-username");
    var password = byId("sbos-connection-password");
    if (username) {
      username.required = isRemote;
    }
    if (password) {
      password.required = isRemote &&
        !value("sbos-connection-id") &&
        password.value === "";
    }
  }

  function openConnectionDialog(connectionId) {
    var connection = connectionId ?
      connectionForId(connectionId) : null;
    setValue("sbos-connection-id", connection ? connection.id : "");
    setValue("sbos-connection-code", connection ? connection.code : "");
    setValue("sbos-connection-name", connection ? connection.name : "");
    setValue("sbos-connection-type", connection ? connection.type : "LOCAL");
    setValue("sbos-connection-schema", connection ? connection.schema : "SAS");
    setValue("sbos-connection-dblink", connection ? connection.dbLink : "");
    setValue("sbos-connection-username", connection ? connection.username : "");
    setValue("sbos-connection-password", "");
    setValue("sbos-connection-workers", connection ? connection.maxWorkers : 4);
    setChecked(
      "sbos-connection-enabled",
      connection ? connection.enabled : true
    );
    byId("sbos-connection-password").type = "password";
    byId("sbos-connection-dialog-title").textContent =
      connection ? "Configure " + connection.name : "New Connection";
    byId("sbos-connection-password-help").textContent =
      connection && connection.hasPassword ?
        "Password configured. Leave blank to keep the current password." :
        "Set a password. It is encrypted and never displayed.";
    configureConnectionFields();
    var dialog = byId("sbos-connection-dialog");
    if (typeof dialog.showModal === "function") {
      dialog.showModal();
    } else {
      dialog.setAttribute("open", "open");
    }
    byId("sbos-connection-code").focus();
  }

  function closeConnectionDialog() {
    var dialog = byId("sbos-connection-dialog");
    byId("sbos-connection-password").value = "";
    if (typeof dialog.close === "function") {
      dialog.close();
    } else {
      dialog.removeAttribute("open");
    }
  }

  function saveConnection() {
    var configuration = {
      id: numberValue("sbos-connection-id", 0) || null,
      code: value("sbos-connection-code").trim().toUpperCase(),
      name: value("sbos-connection-name").trim(),
      type: value("sbos-connection-type"),
      schema: value("sbos-connection-schema").trim().toUpperCase(),
      dbLink: value("sbos-connection-dblink").trim().toUpperCase(),
      username: value("sbos-connection-username").trim(),
      password: value("sbos-connection-password"),
      maxWorkers: numberValue("sbos-connection-workers", 4),
      enabled: checked("sbos-connection-enabled")
    };
    if (!configuration.code || !configuration.name ||
        !configuration.schema) {
      throw new Error(
        "Connection code, connection name and default schema are required."
      );
    }
    if (configuration.type === "ORACLE_DB_LINK" &&
        (!configuration.dbLink || !configuration.username)) {
      throw new Error(
        "Database link and username are required for a remote connection."
      );
    }
    return server("SBOS_ETL_SAVE_CONNECTION", {
      p_clob_01: JSON.stringify(configuration)
    }).then(function (result) {
      closeConnectionDialog();
      notify(result.message);
      return bootstrap(state.pipelineId, true).then(function () {
        if (apex.region) {
          apex.region("sbos_connection_ir").refresh();
        }
      });
    });
  }

  function deletePipeline(pipelineId) {
    return server("SBOS_ETL_DELETE_PIPELINE", {
      x01: pipelineId
    }).then(function (result) {
      state.dirty = false;
      notify(result.message);
      return bootstrap(null, true).then(function () {
        refreshNativeReport("sbos_pipeline_ir");
      });
    });
  }

  function deleteConnection(connectionId) {
    return server("SBOS_ETL_DELETE_CONNECTION", {
      x01: connectionId
    }).then(function (result) {
      notify(result.message);
      return bootstrap(state.pipelineId, true).then(function () {
        refreshNativeReport("sbos_connection_ir");
      });
    });
  }

  function deleteRun(runId) {
    return server("SBOS_ETL_DELETE_RUN", {
      x01: runId
    }).then(function (result) {
      notify(result.message);
      return bootstrap(state.pipelineId, true).then(function () {
        refreshNativeReport("sbos_run_ir");
      });
    });
  }

  function formatMetric(valueToFormat) {
    return Number(valueToFormat || 0).toLocaleString();
  }

  function formatDuration(seconds) {
    var total = Number(seconds || 0);
    if (total >= 3600) {
      return Math.floor(total / 3600) + "h " +
        Math.floor((total % 3600) / 60) + "m";
    }
    if (total >= 60) {
      return Math.floor(total / 60) + "m " + Math.floor(total % 60) + "s";
    }
    return Math.floor(total) + "s";
  }

  function setText(id, content) {
    var node = byId(id);
    if (node) {
      node.textContent = content == null ? "" : String(content);
    }
  }

  function svgNode(tagName, attributes, content) {
    var node = document.createElementNS("http://www.w3.org/2000/svg", tagName);
    Object.keys(attributes || {}).forEach(function (name) {
      node.setAttribute(name, attributes[name]);
    });
    if (content != null) {
      node.textContent = String(content);
    }
    return node;
  }

  function renderTrendChart(trend) {
    var container = byId("sbos-sync-trend-chart");
    clear(container);
    var entries = trend || [];
    if (!entries.length) {
      container.appendChild(text("p", "sbos-empty-state", "No trend data is available."));
      return;
    }
    var width = 760;
    var height = 250;
    var plotLeft = 44;
    var plotTop = 18;
    var plotBottom = 204;
    var plotWidth = 694;
    var plotHeight = plotBottom - plotTop;
    var maxRuns = Math.max.apply(null, entries.map(function (entry) {
      return Number(entry.runs || 0);
    }).concat([1]));
    var slot = plotWidth / entries.length;
    var barWidth = Math.max(4, Math.min(19, slot * 0.62));
    var svg = svgNode("svg", {
      viewBox: "0 0 " + width + " " + height,
      role: "img",
      "aria-label": "Completed and failed sync runs over time"
    });
    [0, 0.5, 1].forEach(function (ratio) {
      var y = plotBottom - plotHeight * ratio;
      svg.appendChild(svgNode("line", {
        x1: plotLeft, y1: y, x2: plotLeft + plotWidth, y2: y,
        class: "sbos-chart-grid-line"
      }));
      svg.appendChild(svgNode("text", {
        x: plotLeft - 8, y: y + 4,
        class: "sbos-chart-axis-label", "text-anchor": "end"
      }, Math.round(maxRuns * ratio)));
    });
    entries.forEach(function (entry, index) {
      var x = plotLeft + index * slot + (slot - barWidth) / 2;
      var completedHeight =
        (Number(entry.completed || 0) / maxRuns) * plotHeight;
      var failedHeight =
        (Number(entry.failed || 0) / maxRuns) * plotHeight;
      var group = svgNode("g", {
        class: "sbos-chart-point" +
          (state.dashboardBucket === entry.key ? " is-selected" : ""),
        "data-action": "dashboard-bucket",
        "data-bucket": entry.key,
        tabindex: "0",
        role: "button",
        "aria-label": entry.label + ": " + entry.completed +
          " completed, " + entry.failed + " failed"
      });
      group.appendChild(svgNode("rect", {
        x: x, y: plotBottom - completedHeight,
        width: barWidth, height: Math.max(completedHeight, 1),
        rx: 2, class: "sbos-chart-bar sbos-chart-bar--success"
      }));
      group.appendChild(svgNode("rect", {
        x: x, y: plotBottom - completedHeight - failedHeight,
        width: barWidth, height: Math.max(failedHeight, entry.failed ? 2 : 0),
        rx: 2, class: "sbos-chart-bar sbos-chart-bar--danger"
      }));
      group.appendChild(svgNode("rect", {
        x: x - 2, y: plotTop,
        width: barWidth + 4, height: plotHeight,
        class: "sbos-chart-hit-area"
      }));
      group.appendChild(svgNode("title", {}, entry.label + " · " +
        formatMetric(entry.rows) + " rows · " +
        entry.completed + " completed · " + entry.failed + " failed"));
      svg.appendChild(group);
      var showLabel = entries.length <= 12 ||
        index % 5 === 0 || index === entries.length - 1;
      if (showLabel) {
        svg.appendChild(svgNode("text", {
          x: x + barWidth / 2, y: 226,
          class: "sbos-chart-axis-label", "text-anchor": "middle"
        }, entry.label));
      }
    });
    container.appendChild(svg);
  }

  function renderFailureChart(breakdown) {
    var container = byId("sbos-failure-chart");
    clear(container);
    var entries = breakdown || [];
    var maxValue = Math.max.apply(null, entries.map(function (entry) {
      return Number(entry.value || 0);
    }).concat([1]));
    var svg = svgNode("svg", {
      viewBox: "0 0 430 250",
      role: "img",
      "aria-label": "Failure and rejected row distribution"
    });
    entries.forEach(function (entry, index) {
      var y = 18 + index * 45;
      var barWidth = (Number(entry.value || 0) / maxValue) * 210;
      var group = svgNode("g", {
        class: "sbos-failure-bar" +
          (state.dashboardFailureFilter === entry.code ? " is-selected" : ""),
        "data-action": "dashboard-failure-filter",
        "data-failure-code": entry.code,
        tabindex: "0",
        role: "button"
      });
      group.appendChild(svgNode("text", {
        x: 8, y: y + 15, class: "sbos-failure-label"
      }, entry.label));
      group.appendChild(svgNode("rect", {
        x: 145, y: y, width: 220, height: 22, rx: 5,
        class: "sbos-failure-track"
      }));
      group.appendChild(svgNode("rect", {
        x: 145, y: y, width: Math.max(barWidth, entry.value ? 3 : 0),
        height: 22, rx: 5,
        class: "sbos-failure-fill sbos-failure-fill--" + entry.severity
      }));
      group.appendChild(svgNode("text", {
        x: 380, y: y + 16, class: "sbos-failure-value"
      }, formatMetric(entry.value)));
      svg.appendChild(group);
    });
    container.appendChild(svg);
  }

  function dashboardStatusBadge(status, className) {
    return text(
      "span",
      "sbos-native-badge sbos-native-badge--" + (className || "neutral"),
      status || "UNKNOWN"
    );
  }

  function renderPipelineHealth(pipelines) {
    var body = byId("sbos-pipeline-health-body");
    clear(body);
    (pipelines || []).forEach(function (pipeline) {
      var row = document.createElement("tr");
      var identity = document.createElement("td");
      identity.appendChild(text("strong", "", pipeline.code));
      identity.appendChild(text("small", "sbos-table-subtitle", pipeline.name));
      row.appendChild(identity);
      row.appendChild(text("td", "sbos-source-destination", pipeline.sources));
      row.appendChild(text("td", "sbos-source-destination", pipeline.destination));
      row.appendChild(text("td", "u-textEnd", formatMetric(pipeline.runs)));
      row.appendChild(text("td", "u-textEnd", formatMetric(pipeline.rows)));
      row.appendChild(text("td", "u-textEnd", pipeline.successRate + "%"));
      row.appendChild(text("td", "u-textEnd", formatMetric(pipeline.failures)));
      var lastSync = document.createElement("td");
      lastSync.appendChild(text("strong", "", pipeline.lastRunStatus));
      lastSync.appendChild(text(
        "small", "sbos-table-subtitle", pipeline.lastRunOn || "Never"
      ));
      row.appendChild(lastSync);
      var health = document.createElement("td");
      health.appendChild(dashboardStatusBadge(
        pipeline.health, pipeline.healthClass
      ));
      row.appendChild(health);
      var drill = document.createElement("td");
      var drillButton = text(
        "button", "sbos-action-btn sbos-action-btn--manage", "Drill"
      );
      drillButton.type = "button";
      drillButton.dataset.action = "dashboard-pipeline";
      drillButton.dataset.pipelineId = pipeline.id;
      drillButton.setAttribute("title", "Drill into pipeline runs");
      drillButton.prepend(text("span", "fa fa-level-down", ""));
      drill.appendChild(drillButton);
      row.appendChild(drill);
      body.appendChild(row);
    });
    if (!body.children.length) {
      var emptyRow = document.createElement("tr");
      var emptyCell = text(
        "td", "sbos-empty-state", "No pipeline sync data is available."
      );
      emptyCell.colSpan = 10;
      emptyRow.appendChild(emptyCell);
      body.appendChild(emptyRow);
    }
    setText(
      "sbos-pipeline-health-count",
      (pipelines || []).length + " pipelines"
    );
  }

  function filteredFailures(failures) {
    var code = state.dashboardFailureFilter;
    if (!code) {
      return failures || [];
    }
    return (failures || []).filter(function (failure) {
      if (code === "REJECTED_ROW") {
        return Number(failure.rejected || 0) > 0;
      }
      if (code === "FAILED_BATCH") {
        return failure.status === "FAILED" || failure.status === "PARTIAL";
      }
      return failure.status === code.replace("_RUN", "");
    });
  }

  function renderRecentFailures(failures) {
    var container = byId("sbos-recent-failures");
    clear(container);
    filteredFailures(failures).forEach(function (failure) {
      var item = document.createElement("article");
      item.className = "sbos-failure-item";
      var main = document.createElement("div");
      main.appendChild(dashboardStatusBadge(
        failure.status,
        failure.status === "FAILED" ? "danger" :
          (failure.status === "PARTIAL" ? "warning" : "neutral")
      ));
      var copy = document.createElement("div");
      copy.appendChild(text("strong", "", failure.pipelineCode));
      copy.appendChild(text("p", "", failure.message));
      copy.appendChild(text(
        "small", "", failure.requestedOn + " · " +
          formatMetric(failure.rejected) + " rejected rows"
      ));
      main.appendChild(copy);
      item.appendChild(main);
      var actions = document.createElement("div");
      var pipelineButton = text(
        "button", "sbos-action-btn sbos-action-btn--manage", "Pipeline"
      );
      pipelineButton.type = "button";
      pipelineButton.dataset.action = "dashboard-pipeline";
      pipelineButton.dataset.pipelineId = failure.pipelineId;
      actions.appendChild(pipelineButton);
      var runButton = text(
        "button", "sbos-action-btn sbos-action-btn--manage", "Run"
      );
      runButton.type = "button";
      runButton.dataset.action = "run-detail";
      runButton.dataset.runId = failure.runId;
      actions.appendChild(runButton);
      item.appendChild(actions);
      container.appendChild(item);
    });
    if (!container.children.length) {
      container.appendChild(text(
        "p", "sbos-empty-state",
        state.dashboardFailureFilter ?
          "No failure signals match this category." :
          "No failure signals in the selected period."
      ));
    }
  }

  function renderDashboardDrill(data) {
    var panel = byId("sbos-dashboard-drill");
    panel.parentNode.classList.toggle(
      "is-summary", !state.dashboardPipelineId
    );
    if (!state.dashboardPipelineId) {
      panel.hidden = true;
      return;
    }
    panel.hidden = false;
    var pipeline = (data.pipelines || []).find(function (entry) {
      return Number(entry.id) === Number(state.dashboardPipelineId);
    });
    setText(
      "sbos-drill-title",
      pipeline ? pipeline.code + " · Run Drill-down" : "Pipeline Run Drill-down"
    );
    setText(
      "sbos-drill-subtitle",
      pipeline ?
        pipeline.sources + " → " + pipeline.destination :
        "Run-level execution details."
    );
  }

  function setDashboardApexItem(name, next) {
    if (!apex || !apex.item) {
      return;
    }
    try {
      apex.item(name).setValue(next == null ? "" : String(next), null, true);
    } catch (ignore) {
      // Native reports will use their current session state until initialized.
    }
  }

  function syncDashboardNativeItems() {
    setDashboardApexItem(
      "P10_DASHBOARD_GRANULARITY", state.dashboardGranularity
    );
    setDashboardApexItem("P10_DASHBOARD_BUCKET", state.dashboardBucket);
    setDashboardApexItem(
      "P10_DASHBOARD_PIPELINE_ID", state.dashboardPipelineId || ""
    );
    setDashboardApexItem(
      "P10_DASHBOARD_FAILURE_FILTER", state.dashboardFailureFilter
    );
  }

  function refreshDashboardNativeReports() {
    attachNativeReports();
    refreshNativeReport("sbos_sync_health_ir");
    refreshNativeReport("sbos_dashboard_failure_ir");
    refreshNativeReport("sbos_dashboard_run_ir");
  }

  function renderDashboard() {
    var data = state.dashboardData;
    if (!data) {
      return;
    }
    var summary = data.summary || {};
    setText("sbos-kpi-runs", formatMetric(summary.runs));
    setText(
      "sbos-kpi-completed", formatMetric(summary.completed) + " completed"
    );
    setText("sbos-kpi-success", Number(summary.successRate || 0) + "%");
    setText("sbos-kpi-rows", formatMetric(summary.rows));
    setText("sbos-kpi-failures", formatMetric(summary.failed));
    setText("sbos-kpi-rejected", formatMetric(summary.rejected));
    setText(
      "sbos-kpi-duration",
      formatDuration(summary.averageDurationSeconds)
    );
    setText(
      "sbos-dashboard-scope",
      (data.selectedBucket ?
        "Focused period " + data.fromDate + " to " + data.toDate :
        (data.granularity === "MONTHLY" ?
          "Last 12 months" : "Last 30 days")) +
        " · Select chart points and pipeline rows to drill deeper."
    );
    setValue("sbos-dashboard-granularity", data.granularity);
    renderTrendChart(data.trend);
    renderFailureChart(data.failureBreakdown);
    setText(
      "sbos-pipeline-health-count",
      (data.pipelines || []).length + " pipelines"
    );
    renderDashboardDrill(data);
    syncDashboardNativeItems();
    refreshDashboardNativeReports();
  }

  function loadDashboard() {
    return server("SBOS_ETL_DASHBOARD", {
      x01: state.dashboardGranularity,
      x02: state.dashboardPipelineId || "",
      x03: state.dashboardBucket || ""
    }).then(function (result) {
      state.dashboardData = result;
      renderDashboard();
      return result;
    });
  }

  function renderConnectionMetadata(prefix, connection, selectedSchema) {
    var schema = byId("sbos-" + prefix + "-schema");
    var dbLink = byId("sbos-" + prefix + "-dblink");
    clear(schema);
    schema.appendChild(option(
      selectedSchema || connection.schema || "",
      selectedSchema || connection.schema || "No schema configured",
      true
    ));
    clear(dbLink);
    dbLink.appendChild(option(
      connection.dbLink || "",
      connection.dbLink || "LOCAL · No database link",
      true
    ));
    dbLink.disabled = !connection.dbLink;
  }

  function catalogKey(connectionId, owner, tableName) {
    return [connectionId, owner, tableName].join("|").toUpperCase();
  }

  function sourceKey(source) {
    return catalogKey(source.connectionId, source.owner, source.table);
  }

  function loadTableCatalog(connectionId, purpose) {
    if (!connectionId) {
      return Promise.resolve([]);
    }
    return server("SBOS_ETL_TABLES", {
      x01: connectionId,
      x02: purpose
    }).then(function (result) {
      if (purpose === "TARGET") {
        state.targetCatalog = result.tables || [];
      } else {
        state.sourceCatalog = result.tables || [];
      }
      return result.tables || [];
    });
  }

  function loadSourceColumns(source) {
    if (!source || !source.connectionId || !source.owner || !source.table) {
      return Promise.resolve([]);
    }
    var key = catalogKey(
      source.connectionId, source.owner, source.table
    );
    if (state.columnCache[key]) {
      return Promise.resolve(state.columnCache[key]);
    }
    return server("SBOS_ETL_COLUMNS", {
      x01: source.connectionId,
      x02: source.owner,
      x03: source.table
    }).then(function (result) {
      state.columnCache[key] = result.columns || [];
      return state.columnCache[key];
    });
  }

  function loadPipelineColumns(pipeline) {
    return Promise.all((pipeline.sources || []).map(loadSourceColumns));
  }

  function loadTargetColumns(pipeline) {
    if (!pipeline || !pipeline.targetConnectionId ||
        !pipeline.targetOwner || !pipeline.targetTable) {
      state.targetColumns = [];
      return Promise.resolve([]);
    }
    return loadSourceColumns({
      connectionId: pipeline.targetConnectionId,
      owner: pipeline.targetOwner,
      table: pipeline.targetTable
    }).then(function (columns) {
      state.targetColumns = columns;
      return columns;
    });
  }

  function targetColumn(name) {
    return state.targetColumns.find(function (column) {
      return column.name === name;
    });
  }

  function availableSourceColumns(pipeline) {
    var columns = [];
    (pipeline.sources || []).forEach(function (source) {
      var key = catalogKey(
        source.connectionId, source.owner, source.table
      );
      (state.columnCache[key] || []).forEach(function (column) {
        columns.push({
          expression: source.alias + "." + column.name,
          alias: source.alias,
          source: source,
          column: column
        });
      });
    });
    return columns;
  }

  function sourceForAlias(pipeline, alias) {
    return (pipeline.sources || []).find(function (source) {
      return source.alias === alias;
    });
  }

  function columnsForSource(source) {
    if (!source) {
      return [];
    }
    return state.columnCache[
      catalogKey(source.connectionId, source.owner, source.table)
    ] || [];
  }

  function deltaTypeForColumn(column) {
    var type = mappedOracleType(column && column.dataType);
    if (type === "TIMESTAMP" || type === "DATE" || type === "NUMBER") {
      return type;
    }
    return "VARCHAR2";
  }

  function tieTypeForColumn(column) {
    return deltaTypeForColumn(column) === "NUMBER" ? "NUMBER" : "VARCHAR2";
  }

  function ensureDeltaDefaults(pipeline) {
    pipeline.delta = pipeline.delta || {};
    var delta = pipeline.delta;
    var source = sourceForAlias(pipeline, delta.watermarkAlias) ||
      (pipeline.sources || []).find(function (item) {
        return item.primary;
      }) || (pipeline.sources || [])[0];
    if (!source) {
      delta.watermarkAlias = delta.watermarkAlias || "S1";
      delta.watermarkColumn = delta.watermarkColumn || "LAST_UPDATED_ON";
      delta.watermarkType = delta.watermarkType || "TIMESTAMP";
      delta.tiebreakerColumn = delta.tiebreakerColumn || "ID";
      delta.tiebreakerType = delta.tiebreakerType || "NUMBER";
      return delta;
    }

    delta.watermarkAlias = source.alias;
    var columns = columnsForSource(source);
    if (!columns.length) {
      return delta;
    }
    var eligibleWatermarks = columns.filter(function (column) {
      return ["TIMESTAMP", "DATE", "NUMBER"].indexOf(
        deltaTypeForColumn(column)
      ) >= 0;
    });
    var watermark = eligibleWatermarks.find(function (column) {
      return column.name === delta.watermarkColumn;
    }) || eligibleWatermarks.find(function (column) {
      return /(^|_)(LAST_)?UPDATED(_ON)?$|LAST_UPDATED_ON|MODIFIED/.test(
        column.name
      );
    }) || eligibleWatermarks.find(function (column) {
      return ["TIMESTAMP", "DATE"].indexOf(deltaTypeForColumn(column)) >= 0;
    }) || eligibleWatermarks[0];
    if (watermark) {
      delta.watermarkColumn = watermark.name;
      delta.watermarkType = deltaTypeForColumn(watermark);
    }

    var tiebreaker = columns.find(function (column) {
      return column.name === delta.tiebreakerColumn;
    }) || columns.find(function (column) {
      return column.name === "ID" || /_ID$/.test(column.name);
    }) || columns.find(function (column) {
      return deltaTypeForColumn(column) === "NUMBER";
    }) || columns[0];
    if (tiebreaker) {
      delta.tiebreakerColumn = tiebreaker.name;
      delta.tiebreakerType = tieTypeForColumn(tiebreaker);
    }
    return delta;
  }

  function renderCatalogOptions(select, catalog, selectedValue, emptyLabel) {
    clear(select);
    select.appendChild(option("", emptyLabel, !selectedValue));
    (catalog || []).slice().sort(function (left, right) {
      return (left.owner + "." + left.table).localeCompare(
        right.owner + "." + right.table
      );
    }).forEach(function (table) {
      var tableValue = table.owner + "." + table.table;
      select.appendChild(option(
        tableValue,
        table.table + " · " + table.columnCount + " columns",
        tableValue === selectedValue
      ));
    });
  }

  function renderHeader(pipeline) {
    setValue("sbos-etl-code", pipeline.code);
    setValue("sbos-etl-name", pipeline.name);
    setValue("sbos-etl-description", pipeline.description);
    var status = byId("sbos-etl-status");
    status.className = badgeClass(pipeline.status);
    status.textContent = pipeline.status;
    byId("sbos-etl-version").textContent = "Version " + pipeline.version;
    byId("sbos-etl-target-summary").textContent = pipeline.targetTable ?
      pipeline.targetOwner + "." + pipeline.targetTable :
      "Select an existing target";
  }

  function renderSources(pipeline) {
    var sourceConnection = byId("sbos-source-connection");
    var primary = (pipeline.sources || []).find(function (source) {
      return source.primary;
    }) || pipeline.sources[0] || {};
    connectionOptions(sourceConnection, primary.connectionId);
    renderConnectionMetadata(
      "source",
      connectionForId(primary.connectionId || sourceConnection.value),
      primary.owner
    );
    var catalog = byId("sbos-source-catalog");
    renderCatalogOptions(
      catalog,
      state.sourceCatalog.length ? state.sourceCatalog : state.data.sourceCatalog,
      "",
      "-- Select a source table --"
    );

    var list = byId("sbos-source-list");
    clear(list);
    (pipeline.sources || []).forEach(function (source, index) {
      var row = document.createElement("div");
      row.className = "sbos-source-row";
      row.dataset.sourceIndex = String(index);

      var check = document.createElement("input");
      check.type = "checkbox";
      check.checked = source.enabled !== false;
      check.className = "sbos-source-enabled";
      check.setAttribute("aria-label", "Enable " + source.table);
      row.appendChild(check);

      var icon = text("span", "sbos-table-icon", "▦");
      icon.setAttribute("aria-hidden", "true");
      row.appendChild(icon);

      var meta = document.createElement("span");
      meta.className = "sbos-source-meta";
      meta.appendChild(text("strong", "", source.alias));
      meta.appendChild(text(
        "small",
        "",
        source.table + (source.primary ? " · Main source" : " · Joined source")
      ));
      row.appendChild(meta);

      var remove = text("button", "sbos-icon-button", "×");
      remove.type = "button";
      remove.dataset.action = "remove-source";
      remove.dataset.index = String(index);
      remove.title = "Remove source";
      var up = text("button", "sbos-icon-button", "↑");
      up.type = "button";
      up.dataset.action = "move-source";
      up.dataset.index = String(index);
      up.dataset.direction = "-1";
      up.title = "Move source up";
      up.disabled = index === 0;
      row.appendChild(up);
      var down = text("button", "sbos-icon-button", "↓");
      down.type = "button";
      down.dataset.action = "move-source";
      down.dataset.index = String(index);
      down.dataset.direction = "1";
      down.title = "Move source down";
      down.disabled = index === pipeline.sources.length - 1;
      row.appendChild(down);
      row.appendChild(remove);
      list.appendChild(row);
    });

    var joinList = byId("sbos-join-list");
    clear(joinList);
    (pipeline.joins || []).forEach(function (join, index) {
      var row = document.createElement("div");
      row.className = "sbos-join-row";
      row.dataset.joinIndex = String(index);
      row.appendChild(text(
        "span",
        "sbos-join-pill",
        join.leftAlias + " " + join.type + " " + join.rightAlias
      ));
      var input = document.createElement("input");
      input.className = "sbos-join-condition";
      input.value = join.condition || "";
      input.setAttribute("aria-label", "Join condition");
      input.readOnly = true;
      input.title = "Use Edit on the JOIN chip to change nested conditions.";
      row.appendChild(input);
      joinList.appendChild(row);
    });
    byId("sbos-source-count").textContent =
      (pipeline.sources || []).length + " source tables selected";
    renderSorts(pipeline);
  }

  function renderSorts(pipeline) {
    var container = byId("sbos-sort-list");
    if (!container) {
      return;
    }
    clear(container);
    pipeline.sorts = pipeline.sorts || [];
    pipeline.sorts.forEach(function (sort, index) {
      var row = document.createElement("div");
      row.className = "sbos-sort-row";
      row.dataset.sortIndex = String(index);
      row.appendChild(text("span", "sbos-sort-sequence", String(index + 1)));

      var column = sourceExpressionPicker("sbos-sort-column-" + index);
      column.className = "sbos-sort-column";
      column.value = (sort.sourceAlias || "") + "." + (sort.sourceColumn || "");
      row.appendChild(column);

      var direction = operationSelect("", ["ASC", "DESC"]);
      direction.className = "sbos-sort-direction";
      direction.value = sort.direction || "ASC";
      row.appendChild(direction);

      var nulls = operationSelect("", [
        {value: "FIRST", label: "Nulls first"},
        {value: "LAST", label: "Nulls last"}
      ]);
      nulls.className = "sbos-sort-nulls";
      nulls.value = sort.nulls || "LAST";
      row.appendChild(nulls);

      [-1, 1].forEach(function (directionValue) {
        var move = text(
          "button", "sbos-icon-button", directionValue < 0 ? "↑" : "↓"
        );
        move.type = "button";
        move.dataset.action = "move-sort";
        move.dataset.index = String(index);
        move.dataset.direction = String(directionValue);
        move.disabled = directionValue < 0 ?
          index === 0 : index === pipeline.sorts.length - 1;
        row.appendChild(move);
      });
      var remove = text("button", "sbos-icon-button", "×");
      remove.type = "button";
      remove.dataset.action = "remove-sort";
      remove.dataset.index = String(index);
      row.appendChild(remove);
      container.appendChild(row);
    });
    if (!pipeline.sorts.length) {
      container.appendChild(text(
        "p", "sbos-helper", "No explicit processing order. Watermark order is used."
      ));
    }
  }

  function renderFlow(pipeline) {
    var canvas = byId("sbos-flow-canvas");
    clear(canvas);
    var sources = pipeline.sources || [];
    var transforms = pipeline.transforms || [];

    var sourceLane = document.createElement("section");
    sourceLane.className = "sbos-flow-lane sbos-flow-lane--source";
    var sourceHead = document.createElement("header");
    sourceHead.appendChild(text("strong", "", "Sources"));
    sourceHead.appendChild(text(
      "span", "sbos-flow-count", sources.length + " table" +
        (sources.length === 1 ? "" : "s")
    ));
    sourceLane.appendChild(sourceHead);

    var nodes = document.createElement("div");
    nodes.className = "sbos-flow-sources";
    sources.forEach(function (source, index) {
      var card = document.createElement("div");
      card.className = "sbos-flow-node";
      card.appendChild(text("span", "sbos-flow-node-index", String(index + 1)));
      var nodeText = document.createElement("span");
      nodeText.className = "sbos-flow-node-text";
      nodeText.appendChild(text("strong", "", source.alias + " · " + source.table));
      nodeText.appendChild(text(
        "small", "", source.primary ? "Primary source" : "Joined source"
      ));
      card.appendChild(nodeText);
      card.appendChild(text(
        "span",
        source.enabled === false ?
          "sbos-flow-state sbos-flow-state--off" : "sbos-flow-state",
        source.enabled === false ? "Off" : "Ready"
      ));
      nodes.appendChild(card);
    });
    if (!sources.length) {
      nodes.appendChild(text(
        "div", "sbos-flow-empty", "Choose a source table to begin."
      ));
    }
    sourceLane.appendChild(nodes);
    canvas.appendChild(sourceLane);

    var path = document.createElement("div");
    path.className = "sbos-flow-path";
    path.setAttribute("aria-hidden", "true");
    path.appendChild(text("span", "sbos-flow-line", ""));
    path.appendChild(text("span", "sbos-flow-arrow", "→"));
    var pathSummary = document.createElement("span");
    pathSummary.className = "sbos-flow-path-summary";
    pathSummary.appendChild(text(
      "b", "", (pipeline.joins || []).length + " joins"
    ));
    pathSummary.appendChild(text(
      "small", "", transforms.length + " transforms"
    ));
    path.appendChild(pathSummary);
    canvas.appendChild(path);

    var targetLane = document.createElement("section");
    targetLane.className = "sbos-flow-lane sbos-flow-lane--target";
    var targetHead = document.createElement("header");
    targetHead.appendChild(text("strong", "", "Existing target"));
    targetHead.appendChild(text(
      "span",
      pipeline.targetExists ?
        "sbos-flow-count sbos-flow-count--ready" : "sbos-flow-count",
      pipeline.targetExists ? "Verified" : "Required"
    ));
    targetLane.appendChild(targetHead);
    var target = document.createElement("div");
    target.className = "sbos-flow-node sbos-flow-node--target";
    target.appendChild(text("span", "sbos-flow-target-icon", "▦"));
    var targetText = document.createElement("span");
    targetText.className = "sbos-flow-node-text";
    targetText.appendChild(text(
      "strong", "", pipeline.targetTable || "Select an existing target"
    ));
    targetText.appendChild(text(
      "small", "",
      (pipeline.targetOwner ? pipeline.targetOwner + " · " : "") +
        pipeline.mappings.length + " mapped columns"
    ));
    target.appendChild(targetText);
    targetLane.appendChild(target);
    canvas.appendChild(targetLane);
  }

  function renderTransforms(pipeline) {
    var container = byId("sbos-transform-list");
    clear(container);
    (pipeline.joins || []).forEach(function (join, index) {
      var chip = document.createElement("span");
      chip.className = "sbos-operation-chip";
      chip.appendChild(text(
        "span", "", "JOIN · " + join.leftAlias + " " + join.type + " " + join.rightAlias
      ));
      var edit = text("button", "", "Edit");
      edit.type = "button";
      edit.dataset.action = "edit-join";
      edit.dataset.index = String(index);
      chip.appendChild(edit);
      container.appendChild(chip);
    });
    (pipeline.transforms || []).forEach(function (transform, index) {
      var chip = document.createElement("span");
      chip.className = "sbos-operation-chip sbos-operation-chip--" +
        String(transform.type || "").toLowerCase();
      chip.appendChild(text(
        "span", "", transform.type + " · " + transform.name
      ));
      var edit = text("button", "", "Edit");
      edit.type = "button";
      edit.dataset.action = "edit-transform";
      edit.dataset.index = String(index);
      chip.appendChild(edit);
      var remove = text("button", "", "×");
      remove.type = "button";
      remove.dataset.action = "remove-transform";
      remove.dataset.index = String(index);
      remove.setAttribute("aria-label", "Remove " + transform.name);
      chip.appendChild(remove);
      container.appendChild(chip);
    });
    if (!container.children.length) {
      container.appendChild(text(
        "span", "sbos-muted", "No joins or transformations configured."
      ));
    }
  }

  function renderTarget(pipeline) {
    connectionOptions(byId("sbos-target-connection"), pipeline.targetConnectionId);
    renderConnectionMetadata(
      "target",
      connectionForId(pipeline.targetConnectionId),
      pipeline.targetOwner
    );
    renderCatalogOptions(
      byId("sbos-target-catalog"),
      state.targetCatalog,
      pipeline.targetTable ?
        pipeline.targetOwner + "." + pipeline.targetTable : "",
      "-- Select an existing target --"
    );
    setValue("sbos-target-table", pipeline.targetTable);
    var check = byId("sbos-target-check");
    check.textContent = pipeline.targetExists ?
      "Target check: Exists" :
      "Target check: Not found";
    check.className = pipeline.targetExists ?
      "sbos-check sbos-check--exists" :
      "sbos-check sbos-check--missing";
    byId("sbos-target-helper").textContent = pipeline.targetExists ?
      "Existing table selected. Every mapped target column will be validated." :
      "Select an existing target table. Automatic table creation is disabled.";
    setValue("sbos-load-strategy", pipeline.loadStrategy);
  }

  function inputFor(valueText, className, label, type) {
    var input = document.createElement("input");
    input.type = type || "text";
    input.className = className || "";
    input.value = valueText == null ? "" : String(valueText);
    input.setAttribute("aria-label", label);
    return input;
  }

  function selectFor(values, selected, className, label) {
    var select = document.createElement("select");
    select.className = className || "";
    select.setAttribute("aria-label", label);
    values.forEach(function (entry) {
      select.appendChild(option(entry, entry, entry === selected));
    });
    return select;
  }

  function mappedOracleType(sourceType) {
    var normalized = String(sourceType || "VARCHAR2").toUpperCase();
    if (normalized.indexOf("TIMESTAMP") === 0) {
      return normalized.indexOf("TIME ZONE") >= 0 ?
        "TIMESTAMP WITH TIME ZONE" : "TIMESTAMP";
    }
    if (normalized === "DATE") {
      return "DATE";
    }
    if (normalized.indexOf("NUMBER") === 0 ||
        normalized === "FLOAT" ||
        normalized === "BINARY_FLOAT" ||
        normalized === "BINARY_DOUBLE") {
      return "NUMBER";
    }
    if (normalized.indexOf("CLOB") >= 0) {
      return "CLOB";
    }
    return "VARCHAR2";
  }

  function transformationPreset(expression, preset) {
    if (!expression || !preset || preset === "DIRECT") {
      return "";
    }
    if (preset === "UPPER") {
      return "UPPER(" + expression + ")";
    }
    if (preset === "TRIM") {
      return "TRIM(" + expression + ")";
    }
    if (preset === "ROUND2") {
      return "ROUND(" + expression + ", 2)";
    }
    if (preset === "NVL") {
      return "NVL(" + expression + ", 'UNKNOWN')";
    }
    if (preset === "TO_DATE") {
      return "TO_DATE(" + expression + ", 'YYYY-MM-DD')";
    }
    return "";
  }

  function renderMappings(pipeline) {
    var body = byId("sbos-mapping-body");
    clear(body);
    var available = availableSourceColumns(pipeline).slice().sort(
      function (left, right) {
        return left.expression.localeCompare(right.expression);
      }
    );
    (pipeline.mappings || []).forEach(function (mapping, index) {
      var row = document.createElement("tr");
      row.dataset.mappingIndex = String(index);
      row.dataset.targetDataType = mapping.dataType || "VARCHAR2";

      var sourceCell = document.createElement("td");
      var sourceSelect = document.createElement("select");
      sourceSelect.className = "sbos-map-source";
      sourceSelect.setAttribute("aria-label", "Source column");
      sourceSelect.appendChild(option("", "-- Select column --", !mapping.sourceExpression));
      if (mapping.sourceExpression &&
          !available.some(function (entry) {
            return entry.expression === mapping.sourceExpression;
          })) {
        sourceSelect.appendChild(option(
          mapping.sourceExpression,
          mapping.sourceExpression + " · custom",
          true
        ));
      }
      available.forEach(function (entry) {
        sourceSelect.appendChild(option(
          entry.expression,
          entry.alias + "." + entry.column.name +
            " · " + entry.column.dataType,
          entry.expression === mapping.sourceExpression
        ));
      });
      sourceCell.appendChild(sourceSelect);
      row.appendChild(sourceCell);

      var transformCell = document.createElement("td");
      var preset = selectFor(
        ["DIRECT", "UPPER", "TRIM", "ROUND2", "NVL", "TO_DATE", "CUSTOM"],
        mapping.transformation ? "CUSTOM" : "DIRECT",
        "sbos-map-preset",
        "Transformation preset"
      );
      Array.prototype.forEach.call(preset.options, function (item) {
        var labels = {
          DIRECT: "Direct mapping",
          UPPER: "Uppercase",
          TRIM: "Trim spaces",
          ROUND2: "Round to 2 decimals",
          NVL: "Default missing value",
          TO_DATE: "Convert to date",
          CUSTOM: "Custom expression"
        };
        item.textContent = labels[item.value] || item.value;
      });
      transformCell.appendChild(preset);
      transformCell.appendChild(inputFor(
        mapping.transformation,
        "sbos-map-transform",
        "Custom transformation expression"
      ));
      row.appendChild(transformCell);

      var targetCell = document.createElement("td");
      var targetSelect = document.createElement("select");
      targetSelect.className = "sbos-map-target";
      targetSelect.setAttribute("aria-label", "Existing target column");
      targetSelect.appendChild(option(
        "", "-- Select target column --", !mapping.targetColumn
      ));
      if (mapping.targetColumn && !targetColumn(mapping.targetColumn)) {
        targetSelect.appendChild(option(
          mapping.targetColumn,
          mapping.targetColumn + " · not found",
          true
        ));
      }
      state.targetColumns.slice().sort(function (left, right) {
        return left.name.localeCompare(right.name);
      }).forEach(function (column) {
        targetSelect.appendChild(option(
          column.name,
          column.name + " · " + column.dataType,
          column.name === mapping.targetColumn
        ));
      });
      targetCell.appendChild(targetSelect);
      row.appendChild(targetCell);

      var sizeCell = document.createElement("td");
      sizeCell.appendChild(inputFor(
        mapping.dataType === "NUMBER" ?
          mapping.precision : mapping.dataLength,
        "sbos-map-size",
        "Length or precision",
        "number"
      ));
      sizeCell.firstChild.readOnly = true;
      row.appendChild(sizeCell);

      var scaleCell = document.createElement("td");
      scaleCell.appendChild(inputFor(
        mapping.scale,
        "sbos-map-scale",
        "Numeric scale",
        "number"
      ));
      scaleCell.firstChild.readOnly = true;
      row.appendChild(scaleCell);

      var keyCell = document.createElement("td");
      var key = document.createElement("input");
      key.type = "checkbox";
      key.className = "sbos-map-key";
      key.checked = Boolean(mapping.key);
      key.setAttribute("aria-label", "Merge key");
      keyCell.appendChild(key);
      row.appendChild(keyCell);

      var nullableCell = document.createElement("td");
      var nullable = document.createElement("input");
      nullable.type = "checkbox";
      nullable.className = "sbos-map-nullable";
      nullable.checked = mapping.nullable !== false;
      nullable.setAttribute("aria-label", "Nullable target column");
      nullableCell.appendChild(nullable);
      row.appendChild(nullableCell);

      var actionCell = document.createElement("td");
      [-1, 1].forEach(function (direction) {
        var move = text(
          "button", "sbos-icon-button", direction < 0 ? "↑" : "↓"
        );
        move.type = "button";
        move.dataset.action = "move-mapping";
        move.dataset.index = String(index);
        move.dataset.direction = String(direction);
        move.title = direction < 0 ? "Move mapping up" : "Move mapping down";
        move.disabled = direction < 0 ?
          index === 0 : index === pipeline.mappings.length - 1;
        actionCell.appendChild(move);
      });
      var remove = text("button", "sbos-icon-button", "×");
      remove.type = "button";
      remove.dataset.action = "remove-mapping";
      remove.dataset.index = String(index);
      remove.title = "Remove mapping";
      actionCell.appendChild(remove);
      row.appendChild(actionCell);
      body.appendChild(row);
    });
    byId("sbos-mapping-count").textContent =
      pipeline.mappings.length + " mappings";
  }

  function renderDelta(pipeline) {
    var delta = ensureDeltaDefaults(pipeline);
    var sourceSelect = byId("sbos-watermark-source");
    clear(sourceSelect);
    var selectedSource = sourceForAlias(pipeline, delta.watermarkAlias) ||
      (pipeline.sources || []).find(function (source) {
        return source.primary;
      }) || (pipeline.sources || [])[0];
    sourceSelect.appendChild(option(
      "", "-- Select source table --", !selectedSource
    ));
    (pipeline.sources || []).forEach(function (source) {
      sourceSelect.appendChild(option(
        source.alias,
        source.alias,
        selectedSource && source.alias === selectedSource.alias
      ));
    });

    var sourceColumns = columnsForSource(selectedSource);
    var watermark = byId("sbos-watermark-column");
    var tiebreaker = byId("sbos-tiebreaker-column");
    clear(watermark);
    clear(tiebreaker);
    watermark.appendChild(option(
      "", "-- Select last-changed column --", !delta.watermarkColumn
    ));
    tiebreaker.appendChild(option(
      "", "-- Select unique tie-breaker --", !delta.tiebreakerColumn
    ));
    sourceColumns.forEach(function (column) {
      var label = column.name + " · " + column.dataType;
      if (["TIMESTAMP", "DATE", "NUMBER"].indexOf(
        deltaTypeForColumn(column)
      ) >= 0) {
        watermark.appendChild(option(
          column.name, label, column.name === delta.watermarkColumn
        ));
      }
      tiebreaker.appendChild(option(
        column.name, label, column.name === delta.tiebreakerColumn
      ));
    });
    setValue("sbos-watermark-source", delta.watermarkAlias);
    setValue("sbos-watermark-column", delta.watermarkColumn);
    setValue("sbos-tiebreaker-column", delta.tiebreakerColumn);
    setValue("sbos-watermark-type", delta.watermarkType || "TIMESTAMP");
    setValue("sbos-tiebreaker-type", delta.tiebreakerType || "NUMBER");
    setValue("sbos-delete-mode", delta.deleteMode || "IGNORE");
    setValue("sbos-batch-size", delta.batchSize || 10000);
    setValue("sbos-workers", delta.parallelWorkers || 4);
    setValue("sbos-max-batches", delta.maxConcurrentBatches || 4);
    setValue("sbos-overlap", delta.overlapMode || "SKIP");
    setValue("sbos-retries", delta.retryCount == null ? 3 : delta.retryCount);
    setValue("sbos-retry-delay", delta.retryDelaySeconds == null ? 30 : delta.retryDelaySeconds);
    renderWorkers(Number(delta.parallelWorkers || 4));

    var schedule = pipeline.schedule || {};
    setChecked("sbos-schedule-enabled", schedule.enabled);
    setValue("sbos-frequency", schedule.repeatInterval || "FREQ=MINUTELY;INTERVAL=5");
    setValue("sbos-timezone", schedule.timezone || "Asia/Kolkata");
    byId("sbos-next-run").textContent = schedule.nextRun || "Available after activation";
    byId("sbos-job-state").textContent = schedule.jobState || "Not scheduled";
  }

  function renderWorkers(count) {
    var container = byId("sbos-worker-grid");
    clear(container);
    var capped = Math.min(Math.max(count, 1), 16);
    for (var i = 1; i <= capped; i += 1) {
      var chip = document.createElement("span");
      chip.className = "sbos-worker-chip";
      chip.appendChild(text("strong", "", "W" + i));
      chip.appendChild(text("small", "", i === 1 ? "Coordinator" : "Ready"));
      container.appendChild(chip);
    }
  }

  function selectedScript(pipeline) {
    var scripts = pipeline.scripts || [];
    return scripts.find(function (script) {
      return script.type === state.scriptType;
    }) || scripts.find(function (script) {
      return script.type === "EXECUTION_PLAN";
    }) || null;
  }

  function renderScripts(pipeline) {
    all("[data-script-type]", root).forEach(function (button) {
      button.classList.toggle("is-active", button.dataset.scriptType === state.scriptType);
    });
    var script = selectedScript(pipeline);
    var code = byId("sbos-script-code");
    code.textContent = script ? script.text : "Generate the execution plan to preview the exact DDL and MERGE SQL.";
    byId("sbos-script-hash").textContent = script ? "SHA-256 " + script.hash : "No generated script";
    var review = byId("sbos-review-check");
    review.checked = script && script.status === "APPROVED";
    review.disabled = !script || script.type !== "EXECUTION_PLAN" || script.status === "APPROVED";
    var stateBadge = byId("sbos-script-status");
    stateBadge.textContent = script ? script.status : "NOT GENERATED";
    stateBadge.className = badgeClass(script ? script.status : "DRAFT");
  }

  function renderRuns(pipeline) {
    var body = byId("sbos-run-body");
    if (body) {
      clear(body);
    }
    var latest = (pipeline.runs || [])[0];
    byId("sbos-last-run-status").textContent = latest ? latest.status : "No runs";
    byId("sbos-last-run-rows").textContent = latest ?
      Number(latest.rowsExtracted || 0).toLocaleString() : "0";
    byId("sbos-last-run-batches").textContent = latest ?
      latest.completedBatches + "/" + latest.totalBatches : "0/0";
    attachNativeReports();
    if (pipeline.id && apex.item && apex.region) {
      try {
        apex.item("P10_ETL_PIPELINE_ID").setValue(String(pipeline.id));
        apex.region("sbos_run_ir").refresh();
      } catch (ignore) {
        // The report may still be initializing during the first APEX render.
      }
    }
  }

  function attachNativeReports() {
    [
      {region: "sbos_pipeline_ir", slot: "sbos-pipeline-ir-slot"},
      {region: "sbos_connection_ir", slot: "sbos-connection-ir-slot"},
      {region: "sbos_run_ir", slot: "sbos-run-ir-slot"},
      {region: "sbos_sync_health_ir", slot: "sbos-sync-health-ir-slot"},
      {
        region: "sbos_dashboard_failure_ir",
        slot: "sbos-dashboard-failure-ir-slot"
      },
      {
        region: "sbos_dashboard_run_ir",
        slot: "sbos-dashboard-run-ir-slot"
      }
    ].forEach(function (entry) {
      var region = document.getElementById(entry.region);
      var slot = byId(entry.slot);
      if (region && slot && region.parentNode !== slot) {
        slot.appendChild(region);
      }
    });
  }

  function renderValidation(pipeline) {
    var message = byId("sbos-validation-message");
    message.textContent =
      "Configuration " + (["VALIDATED", "APPROVED", "ACTIVE"].indexOf(pipeline.status) >= 0 ? "valid" : "requires validation") +
      " · existing target required · " +
      (pipeline.delta.parallelWorkers || 1) + " parallel workers";
  }

  function render() {
    if (!state.data || !state.data.pipeline) {
      return;
    }
    var pipeline = state.data.pipeline;
    state.pipelineId = pipeline.id;
    renderPipelineSelector();
    renderPipelineManagement();
    renderHeader(pipeline);
    renderSources(pipeline);
    renderFlow(pipeline);
    renderTransforms(pipeline);
    renderTarget(pipeline);
    renderMappings(pipeline);
    renderDelta(pipeline);
    renderScripts(pipeline);
    renderRuns(pipeline);
    renderValidation(pipeline);
    switchStage(state.stage);
    updateActionStates();
  }

  function updateActionStates() {
    if (!state.data || !state.data.pipeline || state.loading) {
      return;
    }
    var pipeline = state.data.pipeline;
    var plan = (pipeline.scripts || []).find(function (script) {
      return script.type === "EXECUTION_PLAN";
    });
    var review = checked("sbos-review-check");
    byId("sbos-review-check").disabled =
      !plan || plan.status === "APPROVED";
    byId("sbos-approve").disabled = !plan || plan.status === "APPROVED" || !review;
    byId("sbos-activate").disabled =
      !plan || plan.status !== "APPROVED" || pipeline.status === "ACTIVE";
    byId("sbos-pause").disabled = pipeline.status !== "ACTIVE";
    byId("sbos-run-now").disabled =
      !plan || plan.status !== "APPROVED";
  }

  function bootstrap(pipelineId, silent) {
    return server("SBOS_ETL_BOOTSTRAP", {
      x01: pipelineId || ""
    }).then(function (result) {
      state.data = result;
      state.pipelineId = result.pipeline ? result.pipeline.id : null;
      state.dirty = false;
      state.sourceCatalog = result.sourceCatalog || [];
      state.targetColumns = [];
      var pipeline = result.pipeline;
      if (!pipeline) {
        renderPipelineSelector();
        renderPipelineManagement();
        return result;
      }
      var primary = (pipeline.sources || []).find(function (source) {
        return source.primary;
      }) || pipeline.sources[0] || {};
      var firstConnection = (result.connections || []).find(function (connection) {
        return connection.enabled;
      }) || {};
      return Promise.all([
        loadTableCatalog(
          primary.connectionId || firstConnection.id,
          "SOURCE"
        ).catch(function () {
          return state.sourceCatalog;
        }),
        loadTableCatalog(
          pipeline.targetConnectionId || firstConnection.id,
          "TARGET"
        ).catch(function () {
          return [];
        }),
        loadPipelineColumns(pipeline),
        loadTargetColumns(pipeline)
      ]).then(function () {
        render();
        if (!silent) {
          notify("ETL Workbench loaded.");
        }
        return result;
      });
    });
  }

  function collectSources() {
    var pipeline = state.data.pipeline;
    return all(".sbos-source-row", root).map(function (row) {
      var source = pipeline.sources[Number(row.dataset.sourceIndex)];
      return {
        connectionId: source.connectionId,
        owner: source.owner,
        table: source.table,
        alias: source.alias,
        primary: source.primary,
        filter: source.filter || "",
        enabled: row.querySelector(".sbos-source-enabled").checked
      };
    });
  }

  function collectJoins() {
    var pipeline = state.data.pipeline;
    return all(".sbos-join-row", root).map(function (row) {
      var join = pipeline.joins[Number(row.dataset.joinIndex)];
      return {
        leftAlias: join.leftAlias,
        rightAlias: join.rightAlias,
        type: join.type,
        condition: row.querySelector(".sbos-join-condition").value.trim(),
        configurationJson: join.configurationJson || ""
      };
    });
  }

  function collectSorts() {
    return all(".sbos-sort-row", root).map(function (row) {
      var expression = row.querySelector(".sbos-sort-column").value.split(".");
      return {
        sourceAlias: String(expression.shift() || "").toUpperCase(),
        sourceColumn: String(expression.join(".") || "").toUpperCase(),
        direction: row.querySelector(".sbos-sort-direction").value,
        nulls: row.querySelector(".sbos-sort-nulls").value,
        enabled: true
      };
    }).filter(function (sort) {
      return sort.sourceAlias && sort.sourceColumn;
    });
  }

  function collectMappings() {
    var pipeline = state.data.pipeline;
    return all("#sbos-mapping-body tr", root).map(function (row) {
      var original = pipeline.mappings[Number(row.dataset.mappingIndex)] || {};
      var selectedTarget = targetColumn(
        row.querySelector(".sbos-map-target").value.trim().toUpperCase()
      );
      var dataType = selectedTarget ?
        mappedOracleType(selectedTarget.dataType) :
        (row.dataset.targetDataType || original.dataType || "VARCHAR2");
      var size = Number(row.querySelector(".sbos-map-size").value) || null;
      return {
        sourceExpression: row.querySelector(".sbos-map-source").value.trim(),
        transformation: row.querySelector(".sbos-map-transform").value.trim(),
        targetColumn: row.querySelector(".sbos-map-target").value.trim().toUpperCase(),
        dataType: dataType,
        dataLength: dataType === "VARCHAR2" ? (size || 4000) :
          (dataType === "CLOB" ? null : original.dataLength || null),
        precision: dataType === "NUMBER" ? size : null,
        scale: dataType === "NUMBER" ?
          (Number(row.querySelector(".sbos-map-scale").value) || 0) : null,
        key: row.querySelector(".sbos-map-key").checked,
        nullable: row.querySelector(".sbos-map-nullable").checked,
        enabled: original.enabled !== false
      };
    });
  }

  function collectConfiguration() {
    var pipeline = state.data.pipeline;
    var delta = ensureDeltaDefaults(pipeline);
    return {
      id: pipeline.id,
      expectedVersion: pipeline.version,
      code: value("sbos-etl-code").trim().toUpperCase(),
      name: value("sbos-etl-name").trim(),
      description: value("sbos-etl-description").trim(),
      loadStrategy: value("sbos-load-strategy", "DELTA"),
      target: {
        connectionId: numberValue("sbos-target-connection", pipeline.targetConnectionId),
        owner: value("sbos-target-schema").trim().toUpperCase(),
        table: value("sbos-target-table").trim().toUpperCase(),
        createIfMissing: false
      },
      sources: collectSources(),
      joins: collectJoins(),
      mappings: collectMappings(),
      sorts: collectSorts(),
      transforms: (pipeline.transforms || []).map(function (transform) {
        return {
          name: transform.name,
          type: transform.type,
          expression: transform.expression,
          configurationJson: transform.configurationJson || "",
          enabled: transform.enabled !== false
        };
      }),
      delta: {
        watermarkAlias: value(
          "sbos-watermark-source", delta.watermarkAlias
        ).trim().toUpperCase(),
        watermarkColumn: value(
          "sbos-watermark-column", delta.watermarkColumn
        ).trim().toUpperCase(),
        watermarkType: value(
          "sbos-watermark-type", delta.watermarkType || "TIMESTAMP"
        ),
        tiebreakerColumn: value(
          "sbos-tiebreaker-column", delta.tiebreakerColumn
        ).trim().toUpperCase(),
        tiebreakerType: value(
          "sbos-tiebreaker-type", delta.tiebreakerType || "NUMBER"
        ),
        deleteMode: value("sbos-delete-mode", "IGNORE"),
        batchSize: numberValue("sbos-batch-size", 10000),
        parallelWorkers: numberValue("sbos-workers", 4),
        maxConcurrentBatches: numberValue("sbos-max-batches", 4),
        overlapMode: value("sbos-overlap", "SKIP"),
        retryCount: numberValue("sbos-retries", 3),
        retryDelaySeconds: numberValue("sbos-retry-delay", 30)
      },
      schedule: {
        enabled: checked("sbos-schedule-enabled"),
        repeatInterval: value("sbos-frequency", "FREQ=MINUTELY;INTERVAL=5"),
        timezone: value("sbos-timezone", "Asia/Kolkata")
      }
    };
  }

  function saveConfiguration() {
    var configuration = collectConfiguration();
    if (!configuration.code || !configuration.name) {
      throw new Error("Pipeline code and pipeline name are required.");
    }
    if (!configuration.target.connectionId ||
        !configuration.target.owner ||
        !configuration.target.table) {
      throw new Error("Target connection, schema and table are required.");
    }
    return server("SBOS_ETL_SAVE", {
      p_clob_01: JSON.stringify(configuration)
    }).then(function (result) {
      notify(result.message);
      return bootstrap(result.pipelineId, true);
    });
  }

  function validateConfiguration() {
    if (!state.pipelineId) {
      throw new Error("Save the new pipeline draft before validation.");
    }
    return server("SBOS_ETL_VALIDATE", {
      x01: state.pipelineId
    }).then(function (result) {
      notify(result.message);
      return bootstrap(state.pipelineId, true);
    });
  }

  function generatePlan() {
    if (!state.pipelineId) {
      throw new Error("Save and validate the pipeline before generating scripts.");
    }
    return server("SBOS_ETL_GENERATE", {
      x01: state.pipelineId
    }).then(function (result) {
      state.scriptType = "EXECUTION_PLAN";
      notify(result.message);
      return bootstrap(state.pipelineId, true);
    });
  }

  function approvePlan() {
    var plan = (state.data.pipeline.scripts || []).find(function (script) {
      return script.type === "EXECUTION_PLAN";
    });
    if (!plan) {
      throw new Error("Generate the execution plan first.");
    }
    return server("SBOS_ETL_APPROVE", {
      x01: plan.id
    }).then(function (result) {
      notify(result.message);
      return bootstrap(state.pipelineId, true);
    });
  }

  function activatePipeline() {
    return server("SBOS_ETL_ACTIVATE", {
      x01: state.pipelineId
    }).then(function (result) {
      notify(result.message);
      return bootstrap(state.pipelineId, true);
    });
  }

  function pausePipeline() {
    return server("SBOS_ETL_PAUSE", {
      x01: state.pipelineId
    }).then(function (result) {
      notify(result.message);
      return bootstrap(state.pipelineId, true);
    });
  }

  function runNow() {
    return server("SBOS_ETL_RUN_NOW", {
      x01: state.pipelineId
    }).then(function (result) {
      notify(result.message + " Run #" + result.runId + ".");
      switchView("monitor");
      return bootstrap(state.pipelineId, true);
    });
  }

  function switchView(name) {
    all("[data-view]", root).forEach(function (panel) {
      panel.hidden = panel.dataset.view !== name;
    });
    all("[data-view-target]", root).forEach(function (button) {
      button.classList.toggle("is-active", button.dataset.viewTarget === name);
      button.setAttribute(
        "aria-selected",
        button.dataset.viewTarget === name ? "true" : "false"
      );
    });
  }

  function switchStage(name) {
    var order = ["basics", "source", "mapping", "delta", "script", "schedule"];
    if (order.indexOf(name) < 0) {
      name = "basics";
    }
    state.stage = name;
    all("[data-stage-panel]", root).forEach(function (panel) {
      panel.hidden = panel.dataset.stagePanel !== name;
    });
    all("[data-stage-target]", root).forEach(function (button, index) {
      var selected = button.dataset.stageTarget === name;
      button.classList.toggle("is-current", selected);
      button.classList.toggle("is-done", index < order.indexOf(name));
      button.setAttribute("aria-selected", selected ? "true" : "false");
    });
    var current = order.indexOf(name);
    byId("sbos-stage-prev").disabled = current === 0;
    byId("sbos-stage-next").disabled = current === order.length - 1;
  }

  function moveStage(direction) {
    var order = ["basics", "source", "mapping", "delta", "script", "schedule"];
    var current = Math.max(0, order.indexOf(state.stage));
    switchStage(order[Math.min(order.length - 1, Math.max(0, current + direction))]);
  }

  function operationField(label, control) {
    var wrapper = document.createElement("label");
    wrapper.className = "sbos-field";
    wrapper.appendChild(text("span", "", label));
    wrapper.appendChild(control);
    return wrapper;
  }

  function operationSelect(id, entries) {
    var select = document.createElement("select");
    select.id = id;
    entries.forEach(function (entry) {
      select.appendChild(option(
        entry.value == null ? entry : entry.value,
        entry.label == null ? entry : entry.label,
        Boolean(entry.selected)
      ));
    });
    return select;
  }

  function sourceExpressionPicker(id, predicate) {
    var entries = availableSourceColumns(state.data.pipeline).filter(
      predicate || function () { return true; }
    ).map(function (entry) {
      return {
        value: entry.expression,
        label: entry.expression + " · " + entry.column.dataType
      };
    });
    return operationSelect(id, entries);
  }

  function targetColumnPicker(id) {
    return operationSelect(id, state.targetColumns.map(function (column) {
      return {
        value: column.name,
        label: column.name + " · " + column.dataType
      };
    }));
  }

  function aliasPicker(id, sources, selectedAlias) {
    return operationSelect(id, sources.map(function (source) {
      return {
        value: source.alias,
        label: source.alias + " · " + source.table,
        selected: source.alias === selectedAlias
      };
    }));
  }

  function replaceAliasColumnPicker(select, alias) {
    clear(select);
    availableSourceColumns(state.data.pipeline).filter(function (entry) {
      return entry.alias === alias;
    }).forEach(function (entry) {
      select.appendChild(option(
        entry.expression,
        entry.expression + " · " + entry.column.dataType,
        false
      ));
    });
  }

  function parseOperationConfig(serialized, fallback) {
    if (!serialized) {
      return fallback;
    }
    try {
      return typeof serialized === "string" ?
        JSON.parse(serialized) : serialized;
    } catch (ignore) {
      return fallback;
    }
  }

  function conditionLeaf(rightMode) {
    return {
      kind: "condition",
      left: "",
      operator: "=",
      rightMode: rightMode || "VALUE",
      right: "",
      second: ""
    };
  }

  function conditionGroup(rightMode) {
    return {
      kind: "group",
      logic: "AND",
      negate: false,
      children: [conditionLeaf(rightMode)]
    };
  }

  function conditionNodeAt(rootGroup, path) {
    var node = rootGroup;
    if (!path) {
      return node;
    }
    path.split(".").forEach(function (part) {
      node = node.children[Number(part)];
    });
    return node;
  }

  function conditionParentAt(rootGroup, path) {
    var parts = path.split(".");
    var index = Number(parts.pop());
    return {
      parent: conditionNodeAt(rootGroup, parts.join(".")),
      index: index
    };
  }

  function sourceColumnEntries() {
    return availableSourceColumns(state.data.pipeline).slice().sort(
      function (left, right) {
        return left.expression.localeCompare(right.expression);
      }
    ).map(function (entry) {
      return {
        value: entry.expression,
        label: entry.expression + " · " + entry.column.dataType
      };
    });
  }

  function conditionSelect(entries, selected, label) {
    var select = operationSelect("", entries);
    select.setAttribute("aria-label", label);
    select.value = selected || "";
    return select;
  }

  function rerenderConditionBuilder() {
    var holder = byId("sbos-condition-builder");
    if (!holder || !state.operationConfig) {
      return;
    }
    clear(holder);
    renderConditionGroup(
      holder,
      state.operationConfig.conditions,
      "",
      0,
      state.operation === "JOIN" ? "COLUMN" : "VALUE"
    );
  }

  function renderConditionGroup(container, group, path, depth, defaultRightMode) {
    var card = document.createElement("section");
    card.className = "sbos-condition-group";
    card.dataset.depth = String(depth);
    var header = document.createElement("header");
    header.className = "sbos-condition-group-head";
    header.appendChild(text(
      "strong", "", depth ? "Nested condition group" : "Condition logic"
    ));

    var logic = conditionSelect(["AND", "OR"], group.logic || "AND", "Group logic");
    logic.addEventListener("change", function () {
      group.logic = logic.value;
      state.dirty = true;
    });
    header.appendChild(logic);
    var notLabel = text("label", "sbos-inline-check", " NOT");
    var negate = document.createElement("input");
    negate.type = "checkbox";
    negate.checked = Boolean(group.negate);
    negate.addEventListener("change", function () {
      group.negate = negate.checked;
      state.dirty = true;
    });
    notLabel.insertBefore(negate, notLabel.firstChild);
    header.appendChild(notLabel);

    var addCondition = text("button", "sbos-btn sbos-btn--tiny", "+ Condition");
    addCondition.type = "button";
    addCondition.addEventListener("click", function () {
      group.children.push(conditionLeaf(defaultRightMode));
      rerenderConditionBuilder();
    });
    header.appendChild(addCondition);
    var addGroup = text("button", "sbos-btn sbos-btn--tiny", "+ Group");
    addGroup.type = "button";
    addGroup.disabled = depth >= 4;
    addGroup.addEventListener("click", function () {
      group.children.push(conditionGroup(defaultRightMode));
      rerenderConditionBuilder();
    });
    header.appendChild(addGroup);
    if (depth) {
      var removeGroup = text("button", "sbos-icon-button", "×");
      removeGroup.type = "button";
      removeGroup.title = "Remove nested group";
      removeGroup.addEventListener("click", function () {
        var location = conditionParentAt(
          state.operationConfig.conditions, path
        );
        location.parent.children.splice(location.index, 1);
        rerenderConditionBuilder();
      });
      header.appendChild(removeGroup);
    }
    card.appendChild(header);

    var body = document.createElement("div");
    body.className = "sbos-condition-group-body";
    (group.children || []).forEach(function (child, index) {
      var childPath = path ? path + "." + index : String(index);
      if (child.kind === "group") {
        renderConditionGroup(body, child, childPath, depth + 1, defaultRightMode);
        return;
      }
      var row = document.createElement("div");
      row.className = "sbos-condition-row";
      var left = conditionSelect(
        [{value: "", label: "-- Left column --"}].concat(sourceColumnEntries()),
        child.left,
        "Left column"
      );
      left.addEventListener("change", function () {
        child.left = left.value;
      });
      row.appendChild(left);

      var operator = conditionSelect([
        "=", "<>", ">", ">=", "<", "<=", "LIKE", "NOT LIKE",
        "IN", "NOT IN", "BETWEEN", "IS NULL", "IS NOT NULL"
      ], child.operator, "Operator");
      operator.addEventListener("change", function () {
        child.operator = operator.value;
        rerenderConditionBuilder();
      });
      row.appendChild(operator);

      if (["IS NULL", "IS NOT NULL"].indexOf(child.operator) < 0) {
        var rightMode = conditionSelect([
          {value: "VALUE", label: "Value"},
          {value: "COLUMN", label: "Column"}
        ], child.rightMode || defaultRightMode, "Comparison type");
        rightMode.addEventListener("change", function () {
          child.rightMode = rightMode.value;
          child.right = "";
          rerenderConditionBuilder();
        });
        row.appendChild(rightMode);
        if (child.rightMode === "COLUMN") {
          var rightColumn = conditionSelect(
            [{value: "", label: "-- Right column --"}].concat(sourceColumnEntries()),
            child.right,
            "Right column"
          );
          rightColumn.addEventListener("change", function () {
            child.right = rightColumn.value;
          });
          row.appendChild(rightColumn);
        } else {
          var rightValue = inputFor(child.right, "", "Comparison value");
          rightValue.placeholder = child.operator.indexOf("IN") >= 0 ?
            "Comma-separated values" : "Comparison value";
          rightValue.addEventListener("input", function () {
            child.right = rightValue.value;
          });
          row.appendChild(rightValue);
          if (child.operator === "BETWEEN") {
            var second = inputFor(child.second, "", "Second comparison value");
            second.placeholder = "Second value";
            second.addEventListener("input", function () {
              child.second = second.value;
            });
            row.appendChild(second);
          }
        }
      }
      var remove = text("button", "sbos-icon-button", "×");
      remove.type = "button";
      remove.title = "Remove condition";
      remove.disabled = group.children.length === 1;
      remove.addEventListener("click", function () {
        group.children.splice(index, 1);
        rerenderConditionBuilder();
      });
      row.appendChild(remove);
      body.appendChild(row);
    });
    card.appendChild(body);
    container.appendChild(card);
  }

  function sqlLiteral(raw) {
    return "'" + String(raw == null ? "" : raw).replace(/'/g, "''") + "'";
  }

  function compileConditionLeaf(condition) {
    if (!condition.left) {
      throw new Error("Select a left column for every condition.");
    }
    var operator = String(condition.operator || "=").toUpperCase();
    if (operator === "IS NULL" || operator === "IS NOT NULL") {
      return condition.left + " " + operator;
    }
    if (!condition.right) {
      throw new Error("Enter or select the comparison value for every condition.");
    }
    if (condition.rightMode === "COLUMN") {
      return condition.left + " " + operator + " " + condition.right;
    }
    if (operator === "IN" || operator === "NOT IN") {
      var values = String(condition.right).split(",").map(function (entry) {
        return sqlLiteral(entry.trim());
      }).join(", ");
      return condition.left + " " + operator + " (" + values + ")";
    }
    if (operator === "BETWEEN") {
      if (!condition.second) {
        throw new Error("Both values are required for BETWEEN.");
      }
      return condition.left + " BETWEEN " +
        sqlLiteral(condition.right) + " AND " + sqlLiteral(condition.second);
    }
    return condition.left + " " + operator + " " + sqlLiteral(condition.right);
  }

  function compileConditionGroup(group) {
    if (!group || !(group.children || []).length) {
      throw new Error("Add at least one condition.");
    }
    var expression = group.children.map(function (child) {
      return child.kind === "group" ?
        compileConditionGroup(child) : compileConditionLeaf(child);
    }).join(" " + (group.logic || "AND") + " ");
    return (group.negate ? "NOT " : "") + "(" + expression + ")";
  }

  function conditionBuilderSection(label) {
    var wrapper = document.createElement("div");
    wrapper.className = "sbos-condition-builder-wrap";
    wrapper.appendChild(text("h3", "", label));
    var holder = document.createElement("div");
    holder.id = "sbos-condition-builder";
    wrapper.appendChild(holder);
    return wrapper;
  }

  function multiSourcePicker(id, selectedValues) {
    var select = operationSelect(id, sourceColumnEntries());
    select.multiple = true;
    select.size = Math.min(6, Math.max(3, select.options.length));
    Array.prototype.forEach.call(select.options, function (item) {
      item.selected = (selectedValues || []).indexOf(item.value) >= 0;
    });
    return select;
  }

  function selectedValues(id) {
    var select = byId(id);
    return select ? Array.prototype.filter.call(select.options, function (item) {
      return item.selected;
    }).map(function (item) {
      return item.value;
    }) : [];
  }

  function openTransform(operation, editIndex, editKind) {
    var pipeline = state.data.pipeline;
    var form = byId("sbos-transform-form");
    var title = byId("sbos-transform-title");
    var help = byId("sbos-transform-help");
    var existing = editKind === "join" ?
      pipeline.joins[editIndex] : pipeline.transforms[editIndex];
    clear(form);
    state.operation = operation;
    state.operationEditIndex = Number.isFinite(editIndex) ? editIndex : null;
    state.operationEditKind = editKind || null;
    title.textContent = operation === "DERIVE" ?
      "Configure f(x) Derive" : "Configure " + operation.toLowerCase();
    var sourceColumns = availableSourceColumns(pipeline);
    if (operation !== "JOIN" && !sourceColumns.length) {
      throw new Error("Add a source table before configuring " + operation + ".");
    }
    if (["DERIVE","LOOKUP","AGGREGATE"].indexOf(operation) >= 0 &&
        !state.targetColumns.length) {
      throw new Error("Select an existing target table before configuring " + operation + ".");
    }
    if (operation === "JOIN") {
      if ((pipeline.sources || []).length < 2) {
        throw new Error("Add at least two source tables before configuring a join.");
      }
      help.textContent =
        "Build nested AND/OR groups. Each group and the full join can be negated.";
      var leftSource = pipeline.sources[0];
      var rightSource = pipeline.sources[pipeline.sources.length - 1];
      state.operationConfig = parseOperationConfig(
        existing && existing.configurationJson,
        {
          leftAlias: existing ? existing.leftAlias : leftSource.alias,
          rightAlias: existing ? existing.rightAlias : rightSource.alias,
          joinType: existing ? existing.type : "INNER",
          conditions: conditionGroup("COLUMN")
        }
      );
      var leftAlias = aliasPicker(
        "sbos-op-left-alias", pipeline.sources, state.operationConfig.leftAlias
      );
      var rightAlias = aliasPicker(
        "sbos-op-right-alias", pipeline.sources, state.operationConfig.rightAlias
      );
      form.appendChild(operationField("Left source", leftAlias));
      var joinType = operationSelect(
        "sbos-op-join-type", ["INNER","LEFT","RIGHT","FULL"]
      );
      joinType.value = state.operationConfig.joinType || "INNER";
      form.appendChild(operationField("Join type", joinType));
      form.appendChild(operationField("Right source", rightAlias));
      form.appendChild(conditionBuilderSection("Advanced join conditions"));
    } else if (operation === "FILTER") {
      help.textContent =
        "Build nested AND/OR/NOT filter groups with column or literal comparisons.";
      state.operationConfig = parseOperationConfig(
        existing && existing.configurationJson,
        {conditions: conditionGroup("VALUE")}
      );
      form.appendChild(conditionBuilderSection("Advanced filter conditions"));
    } else if (operation === "DERIVE") {
      help.textContent =
        "Use a function, custom expression, or conditional CASE derivation.";
      state.operationConfig = parseOperationConfig(
        existing && existing.configurationJson,
        {mode: "FUNCTION", conditions: conditionGroup("VALUE")}
      );
      var deriveSourcePicker = sourceExpressionPicker("sbos-op-source");
      deriveSourcePicker.value = state.operationConfig.source || "";
      form.appendChild(operationField("Source column", deriveSourcePicker));
      var deriveMode = operationSelect("sbos-op-derive-mode", [
        {value: "FUNCTION", label: "Function preset"},
        {value: "CUSTOM", label: "Custom SQL expression"},
        {value: "CASE", label: "Conditional CASE"}
      ]);
      deriveMode.value = state.operationConfig.mode || "FUNCTION";
      form.appendChild(operationField("Derive mode", deriveMode));
      var deriveFunction = operationSelect(
        "sbos-op-function",
        [
          {value:"UPPER",label:"Uppercase"},
          {value:"TRIM",label:"Trim spaces"},
          {value:"ROUND2",label:"Round to 2 decimals"},
          {value:"NVL",label:"Default missing value"},
          {value:"TO_DATE",label:"Convert to date"}
        ]
      );
      deriveFunction.value = state.operationConfig.function || "UPPER";
      form.appendChild(operationField("Function", deriveFunction));
      var customExpression = inputFor(
        state.operationConfig.expression || "", "", "Custom derive expression"
      );
      customExpression.id = "sbos-op-expression";
      form.appendChild(operationField("Custom expression", customExpression));
      var thenValue = inputFor(
        state.operationConfig.thenValue || "", "", "Value when conditions match"
      );
      thenValue.id = "sbos-op-then";
      form.appendChild(operationField("CASE result when true", thenValue));
      var elseValue = inputFor(
        state.operationConfig.elseValue || "", "", "Value when conditions do not match"
      );
      elseValue.id = "sbos-op-else";
      form.appendChild(operationField("CASE result otherwise", elseValue));
      var deriveTarget = targetColumnPicker("sbos-op-target");
      deriveTarget.value = state.operationConfig.target || "";
      form.appendChild(operationField("Existing target column", deriveTarget));
      form.appendChild(conditionBuilderSection("CASE conditions (used in CASE mode)"));
    } else if (operation === "LOOKUP") {
      if (!(pipeline.sources || []).some(function (source) {
        return !source.primary;
      })) {
        throw new Error("Add and join a lookup source before configuring Lookup.");
      }
      help.textContent =
        "Select a joined lookup value, fallback value and optional nested eligibility rules.";
      state.operationConfig = parseOperationConfig(
        existing && existing.configurationJson,
        {conditions: conditionGroup("VALUE")}
      );
      var lookupSource = sourceExpressionPicker("sbos-op-source", function (entry) {
          var source = pipeline.sources.find(function (item) {
            return item.alias === entry.alias;
          });
          return source && !source.primary;
        });
      lookupSource.value = state.operationConfig.source || "";
      form.appendChild(operationField("Lookup result column", lookupSource));
      var lookupDefault = inputFor(
        state.operationConfig.defaultValue || "", "", "Fallback value"
      );
      lookupDefault.id = "sbos-op-default";
      form.appendChild(operationField("Fallback when not matched", lookupDefault));
      var lookupTarget = targetColumnPicker("sbos-op-target");
      lookupTarget.value = state.operationConfig.target || "";
      form.appendChild(operationField("Existing target column", lookupTarget));
      form.appendChild(conditionBuilderSection("Optional lookup eligibility conditions"));
    } else if (operation === "AGGREGATE") {
      help.textContent =
        "Configure filtered analytics, multiple partitions, window order and frame.";
      state.operationConfig = parseOperationConfig(
        existing && existing.configurationJson,
        {conditions: conditionGroup("VALUE"), partitions: []}
      );
      var aggregate = operationSelect(
        "sbos-op-aggregate", ["SUM","COUNT","AVG","MIN","MAX"]
      );
      aggregate.value = state.operationConfig.aggregate || "SUM";
      form.appendChild(operationField("Function", aggregate));
      var aggregateSource = sourceExpressionPicker("sbos-op-source");
      aggregateSource.value = state.operationConfig.source || "";
      form.appendChild(operationField("Value column", aggregateSource));
      form.appendChild(operationField(
        "Partition by (select multiple)",
        multiSourcePicker("sbos-op-partitions", state.operationConfig.partitions)
      ));
      var orderColumn = sourceExpressionPicker("sbos-op-order-column");
      orderColumn.insertBefore(option("", "-- No window ordering --", false), orderColumn.firstChild);
      orderColumn.value = state.operationConfig.orderColumn || "";
      form.appendChild(operationField("Window order column", orderColumn));
      var orderDirection = operationSelect("sbos-op-order-direction", ["ASC", "DESC"]);
      orderDirection.value = state.operationConfig.orderDirection || "ASC";
      form.appendChild(operationField("Window direction", orderDirection));
      var frame = operationSelect("sbos-op-frame", [
        {value: "", label: "Default window"},
        {value: "ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW", label: "Running window"},
        {value: "ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING", label: "Entire partition"},
        {value: "ROWS BETWEEN 1 PRECEDING AND CURRENT ROW", label: "Current + previous row"}
      ]);
      frame.value = state.operationConfig.frame || "";
      form.appendChild(operationField("Window frame", frame));
      var distinctLabel = text("label", "sbos-inline-check", " Distinct values");
      var distinct = document.createElement("input");
      distinct.type = "checkbox";
      distinct.id = "sbos-op-distinct";
      distinct.checked = Boolean(state.operationConfig.distinct);
      distinctLabel.insertBefore(distinct, distinctLabel.firstChild);
      form.appendChild(distinctLabel);
      var aggregateTarget = targetColumnPicker("sbos-op-target");
      aggregateTarget.value = state.operationConfig.target || "";
      form.appendChild(operationField("Existing target column", aggregateTarget));
      form.appendChild(conditionBuilderSection("Optional filtered aggregate conditions"));
    }
    if (byId("sbos-condition-builder")) {
      rerenderConditionBuilder();
    }
    var dialog = byId("sbos-transform-dialog");
    if (typeof dialog.showModal === "function") {
      dialog.showModal();
    } else {
      dialog.setAttribute("open", "open");
    }
  }

  function appendOperationMapping(sourceExpression, expression, targetName) {
    var target = targetColumn(targetName);
    if (!target) {
      throw new Error("Select an existing target column.");
    }
    var targetType = mappedOracleType(target.dataType);
    var existing = state.data.pipeline.mappings.find(function (mapping) {
      return mapping.targetColumn === targetName;
    });
    var mapping = existing || {};
    mapping.sourceExpression = sourceExpression;
    mapping.transformation = expression || "";
    mapping.targetColumn = targetName;
    mapping.dataType = targetType;
    mapping.dataLength = targetType === "VARCHAR2" ? target.dataLength : null;
    mapping.precision = targetType === "NUMBER" ? target.precision : null;
    mapping.scale = targetType === "NUMBER" ? target.scale : null;
    mapping.key = Boolean(mapping.key);
    mapping.nullable = target.nullable !== false;
    mapping.enabled = true;
    if (!existing) {
      state.data.pipeline.mappings.push(mapping);
    }
  }

  function addTransformMetadata(type, name, expression, configuration) {
    state.data.pipeline.transforms = state.data.pipeline.transforms || [];
    var transform = {
      name: name,
      type: type,
      expression: expression,
      configurationJson: JSON.stringify(configuration || {}),
      enabled: true
    };
    if (state.operationEditKind === "transform" &&
        Number.isFinite(state.operationEditIndex)) {
      state.data.pipeline.transforms[state.operationEditIndex] = transform;
    } else {
      state.data.pipeline.transforms.push(transform);
    }
  }

  function applyTransform() {
    var pipeline = state.data.pipeline;
    pipeline.transforms = pipeline.transforms || [];
    var operation = state.operation;
    if (operation === "JOIN") {
      var leftAlias = value("sbos-op-left-alias");
      var rightAlias = value("sbos-op-right-alias");
      if (leftAlias === rightAlias) {
        throw new Error("Join aliases must be different.");
      }
      state.operationConfig.leftAlias = leftAlias;
      state.operationConfig.rightAlias = rightAlias;
      state.operationConfig.joinType = value("sbos-op-join-type");
      var condition = compileConditionGroup(state.operationConfig.conditions);
      var existingJoin = state.operationEditKind === "join" ?
        pipeline.joins[state.operationEditIndex] :
        pipeline.joins.find(function (join) {
          return join.rightAlias === rightAlias;
        });
      var join = existingJoin || {};
      join.leftAlias = leftAlias;
      join.rightAlias = rightAlias;
      join.type = value("sbos-op-join-type");
      join.condition = condition;
      join.configurationJson = JSON.stringify(state.operationConfig);
      if (!existingJoin) {
        pipeline.joins.push(join);
      }
    } else if (operation === "FILTER") {
      var filterExpression = compileConditionGroup(
        state.operationConfig.conditions
      );
      addTransformMetadata(
        "FILTER",
        state.operationEditKind === "transform" ?
          pipeline.transforms[state.operationEditIndex].name :
          "Filter " + (pipeline.transforms.length + 1),
        filterExpression,
        state.operationConfig
      );
    } else if (operation === "DERIVE") {
      var deriveSource = value("sbos-op-source");
      var deriveMode = value("sbos-op-derive-mode");
      var deriveExpression;
      state.operationConfig.mode = deriveMode;
      state.operationConfig.source = deriveSource;
      state.operationConfig.function = value("sbos-op-function");
      state.operationConfig.expression = value("sbos-op-expression").trim();
      state.operationConfig.thenValue = value("sbos-op-then");
      state.operationConfig.elseValue = value("sbos-op-else");
      state.operationConfig.target = value("sbos-op-target");
      if (deriveMode === "CUSTOM") {
        deriveExpression = state.operationConfig.expression;
      } else if (deriveMode === "CASE") {
        deriveExpression = "CASE WHEN " +
          compileConditionGroup(state.operationConfig.conditions) +
          " THEN " + sqlLiteral(state.operationConfig.thenValue) +
          " ELSE " + sqlLiteral(state.operationConfig.elseValue) + " END";
      } else {
        deriveExpression = transformationPreset(
          deriveSource, state.operationConfig.function
        );
      }
      if (!deriveExpression) {
        throw new Error("Enter a derive expression.");
      }
      appendOperationMapping(
        deriveSource, deriveExpression, value("sbos-op-target")
      );
      addTransformMetadata(
        "DERIVE", "Derive " + value("sbos-op-target"), deriveExpression,
        state.operationConfig
      );
    } else if (operation === "LOOKUP") {
      var lookupSource = value("sbos-op-source");
      if (!lookupSource) {
        throw new Error("Add and join a lookup source before selecting Lookup.");
      }
      state.operationConfig.source = lookupSource;
      state.operationConfig.target = value("sbos-op-target");
      state.operationConfig.defaultValue = value("sbos-op-default");
      var firstLookupCondition =
        state.operationConfig.conditions.children[0];
      var lookupExpression = firstLookupCondition &&
        firstLookupCondition.left ?
        "CASE WHEN " + compileConditionGroup(state.operationConfig.conditions) +
          " THEN " + lookupSource +
          " ELSE " + sqlLiteral(state.operationConfig.defaultValue) + " END" :
        "NVL(" + lookupSource + ", " +
          sqlLiteral(state.operationConfig.defaultValue) + ")";
      appendOperationMapping(lookupSource, lookupExpression, value("sbos-op-target"));
      addTransformMetadata(
        "LOOKUP", "Lookup " + value("sbos-op-target"), lookupExpression,
        state.operationConfig
      );
    } else if (operation === "AGGREGATE") {
      var aggregateSource = value("sbos-op-source");
      state.operationConfig.aggregate = value("sbos-op-aggregate");
      state.operationConfig.source = aggregateSource;
      state.operationConfig.partitions = selectedValues("sbos-op-partitions");
      state.operationConfig.orderColumn = value("sbos-op-order-column");
      state.operationConfig.orderDirection = value("sbos-op-order-direction");
      state.operationConfig.frame = value("sbos-op-frame");
      state.operationConfig.distinct = checked("sbos-op-distinct");
      state.operationConfig.target = value("sbos-op-target");
      if (!state.operationConfig.partitions.length) {
        throw new Error("Select at least one partition column.");
      }
      var aggregateValue = aggregateSource;
      if (state.operationConfig.conditions &&
          state.operationConfig.conditions.children &&
          state.operationConfig.conditions.children[0].left) {
        aggregateValue = "CASE WHEN " +
          compileConditionGroup(state.operationConfig.conditions) +
          " THEN " + aggregateSource + " END";
      }
      var aggregateExpression = state.operationConfig.aggregate + "(" +
        (state.operationConfig.distinct ? "DISTINCT " : "") +
        aggregateValue + ") OVER (PARTITION BY " +
        state.operationConfig.partitions.join(", ");
      if (state.operationConfig.orderColumn) {
        aggregateExpression += " ORDER BY " +
          state.operationConfig.orderColumn + " " +
          state.operationConfig.orderDirection;
      }
      if (state.operationConfig.frame) {
        aggregateExpression += " " + state.operationConfig.frame;
      }
      aggregateExpression += ")";
      appendOperationMapping(
        aggregateSource, aggregateExpression, value("sbos-op-target")
      );
      addTransformMetadata(
        "AGGREGATE", "Aggregate " + value("sbos-op-target"),
        aggregateExpression, state.operationConfig
      );
    }
    state.dirty = true;
    renderSources(pipeline);
    renderFlow(pipeline);
    renderTransforms(pipeline);
    renderMappings(pipeline);
    byId("sbos-transform-dialog").close();
    state.operationConfig = null;
    state.operationEditIndex = null;
    state.operationEditKind = null;
    notify(operation + " operation configured.");
  }

  function removeTransform(index) {
    var transform = state.data.pipeline.transforms[index];
    if (transform && transform.type !== "FILTER") {
      state.data.pipeline.mappings = state.data.pipeline.mappings.filter(
        function (mapping) {
          return mapping.transformation !== transform.expression &&
            !(transform.type === "LOOKUP" &&
              mapping.sourceExpression === transform.expression);
        }
      );
    }
    state.data.pipeline.transforms.splice(index, 1);
    state.dirty = true;
    renderTransforms(state.data.pipeline);
    renderMappings(state.data.pipeline);
  }

  function switchScript(type) {
    state.scriptType = type;
    renderScripts(state.data.pipeline);
  }

  function addMapping() {
    state.dirty = true;
    var used = state.data.pipeline.mappings.map(function (mapping) {
      return mapping.sourceExpression;
    });
    var available = availableSourceColumns(state.data.pipeline);
    var candidate = available.find(function (entry) {
      return used.indexOf(entry.expression) < 0;
    });
    var usedTargets = state.data.pipeline.mappings.map(function (mapping) {
      return mapping.targetColumn;
    });
    var target = candidate && targetColumn(candidate.column.name);
    if (!target) {
      target = state.targetColumns.find(function (column) {
        return usedTargets.indexOf(column.name) < 0;
      });
    }
    var column = candidate ? candidate.column : {};
    var targetType = mappedOracleType(target ? target.dataType : column.dataType);
    state.data.pipeline.mappings.push({
      sourceExpression: candidate ? candidate.expression : "",
      transformation: "",
      targetColumn: target ? target.name : "",
      dataType: targetType,
      dataLength: targetType === "VARCHAR2" ?
        Math.min(Number((target && target.dataLength) || 4000), 32767) : null,
      precision: targetType === "NUMBER" && target ? target.precision : null,
      scale: targetType === "NUMBER" && target ? target.scale : null,
      key: false,
      nullable: target ? target.nullable !== false : true,
      enabled: true
    });
    renderMappings(state.data.pipeline);
  }

  function autoMapSource() {
    var pipeline = state.data.pipeline;
    var primary = (pipeline.sources || []).find(function (source) {
      return source.primary;
    }) || pipeline.sources[0];
    if (!primary) {
      throw new Error("Add a source table before creating column mappings.");
    }
    var key = catalogKey(primary.connectionId, primary.owner, primary.table);
    var columns = state.columnCache[key] || [];
    if (!columns.length) {
      throw new Error("No source columns were returned for " + primary.table + ".");
    }
    var matching = columns.filter(function (column) {
      return Boolean(targetColumn(column.name));
    });
    if (!matching.length) {
      throw new Error(
        "No source columns match the selected target columns by name."
      );
    }
    pipeline.mappings = matching.map(function (column, index) {
      var target = targetColumn(column.name);
      var targetType = mappedOracleType(target.dataType);
      return {
        sourceExpression: primary.alias + "." + column.name,
        transformation: "",
        targetColumn: target.name,
        dataType: targetType,
        dataLength: targetType === "VARCHAR2" ?
          Math.min(Number(target.dataLength || 4000), 32767) : null,
        precision: targetType === "NUMBER" ? target.precision : null,
        scale: targetType === "NUMBER" ? target.scale : null,
        key: index === 0,
        nullable: index === 0 ? false : target.nullable !== false,
        enabled: true
      };
    });
    state.dirty = true;
    renderMappings(pipeline);
    renderFlow(pipeline);
    notify(matching.length + " matching columns mapped. Confirm the merge key.");
  }

  function removeMapping(index) {
    state.dirty = true;
    state.data.pipeline.mappings.splice(index, 1);
    renderMappings(state.data.pipeline);
  }

  function moveArrayItem(items, index, direction) {
    var target = index + direction;
    if (target < 0 || target >= items.length) {
      return;
    }
    var item = items.splice(index, 1)[0];
    items.splice(target, 0, item);
    state.dirty = true;
  }

  function moveMapping(index, direction) {
    state.data.pipeline.mappings = collectMappings();
    moveArrayItem(state.data.pipeline.mappings, index, direction);
    renderMappings(state.data.pipeline);
  }

  function moveSource(index, direction) {
    state.data.pipeline.sources = collectSources();
    moveArrayItem(state.data.pipeline.sources, index, direction);
    renderSources(state.data.pipeline);
    renderFlow(state.data.pipeline);
    renderDelta(state.data.pipeline);
  }

  function addSort() {
    var first = availableSourceColumns(state.data.pipeline)[0];
    if (!first) {
      throw new Error("Add a source table before configuring processing order.");
    }
    state.data.pipeline.sorts = collectSorts();
    state.data.pipeline.sorts.push({
      sourceAlias: first.alias,
      sourceColumn: first.column.name,
      direction: "ASC",
      nulls: "LAST",
      enabled: true
    });
    state.dirty = true;
    renderSorts(state.data.pipeline);
  }

  function removeSort(index) {
    state.data.pipeline.sorts = collectSorts();
    state.data.pipeline.sorts.splice(index, 1);
    state.dirty = true;
    renderSorts(state.data.pipeline);
  }

  function moveSort(index, direction) {
    state.data.pipeline.sorts = collectSorts();
    moveArrayItem(state.data.pipeline.sorts, index, direction);
    renderSorts(state.data.pipeline);
  }

  function addSource() {
    var available = state.sourceCatalog.length ?
      state.sourceCatalog : state.data.sourceCatalog || [];
    var used = state.data.pipeline.sources.map(function (source) {
      return source.table;
    });
    var selectedCatalog = value("sbos-source-catalog");
    var candidate = available.find(function (table) {
      return table.owner + "." + table.table === selectedCatalog &&
        used.indexOf(table.table) < 0;
    }) || available.find(function (table) {
      return used.indexOf(table.table) < 0;
    });
    if (!candidate) {
      notify("No additional source table is available in the catalog.", "error");
      return;
    }
    state.dirty = true;
    var alias = "S" + (state.data.pipeline.sources.length + 1);
    state.data.pipeline.sources.push({
      connectionId: Number(value("sbos-source-connection")),
      connectionName: "",
      connectionType: "LOCAL",
      owner: candidate.owner,
      table: candidate.table,
      alias: alias,
      primary: state.data.pipeline.sources.length === 0,
      filter: "",
      enabled: true
    });
    if (state.data.pipeline.sources.length > 1) {
      var left = state.data.pipeline.sources[state.data.pipeline.sources.length - 2].alias;
      state.data.pipeline.joins.push({
        leftAlias: left,
        rightAlias: alias,
        type: "INNER",
        condition: ""
      });
    }
    return loadSourceColumns(
      state.data.pipeline.sources[state.data.pipeline.sources.length - 1]
    ).then(function () {
      if (state.data.pipeline.sources.length > 1) {
        var rightSource =
          state.data.pipeline.sources[state.data.pipeline.sources.length - 1];
        var leftSource =
          state.data.pipeline.sources[state.data.pipeline.sources.length - 2];
        var leftColumns = state.columnCache[sourceKey(leftSource)] || [];
        var rightColumns = state.columnCache[sourceKey(rightSource)] || [];
        var common = leftColumns.find(function (leftColumn) {
          return rightColumns.some(function (rightColumn) {
            return rightColumn.name === leftColumn.name;
          });
        });
        var join = state.data.pipeline.joins.find(function (item) {
          return item.rightAlias === rightSource.alias;
        });
        if (join && common) {
          join.condition = leftSource.alias + "." + common.name + " = " +
            rightSource.alias + "." + common.name;
        }
      }
      renderSources(state.data.pipeline);
      renderFlow(state.data.pipeline);
      renderMappings(state.data.pipeline);
      renderDelta(state.data.pipeline);
    });
  }

  function removeSource(index) {
    var source = state.data.pipeline.sources[index];
    if (source.primary && state.data.pipeline.sources.length > 1) {
      notify("Select another primary source before removing this table.", "error");
      return;
    }
    state.dirty = true;
    state.data.pipeline.sources.splice(index, 1);
    state.data.pipeline.joins = state.data.pipeline.joins.filter(function (join) {
      return join.leftAlias !== source.alias && join.rightAlias !== source.alias;
    });
    renderSources(state.data.pipeline);
    renderFlow(state.data.pipeline);
    renderDelta(state.data.pipeline);
  }

  function newPipeline() {
    var firstConnection = (state.data.connections || [])[0] || {};
    var stamp = new Date().toISOString()
      .replace(/[-:TZ.]/g, "")
      .slice(0, 14);
    state.dirty = true;
    state.pipelineId = null;
    state.data.pipeline = {
      id: null,
      code: "ETL_" + stamp,
      name: "",
      description: "",
      status: "DRAFT",
      version: 1,
      targetConnectionId: firstConnection.id || null,
      targetOwner: firstConnection.schema || "SAS",
      targetTable: "",
      targetExists: false,
      createTarget: false,
      loadStrategy: "DELTA",
      sources: [],
      joins: [],
      sorts: [],
      mappings: [],
      transforms: [],
      delta: {
        watermarkAlias: "S1",
        watermarkColumn: "LAST_UPDATED_ON",
        watermarkType: "TIMESTAMP",
        tiebreakerColumn: "ID",
        tiebreakerType: "NUMBER",
        deleteMode: "IGNORE",
        batchSize: 10000,
        parallelWorkers: 4,
        maxConcurrentBatches: 4,
        overlapMode: "SKIP",
        retryCount: 3,
        retryDelaySeconds: 30
      },
      schedule: {
        enabled: true,
        repeatInterval: "FREQ=MINUTELY;INTERVAL=5",
        timezone: "Asia/Kolkata",
        jobState: "Not scheduled",
        nextRun: ""
      },
      scripts: [],
      runs: []
    };
    render();
    state.dirty = true;
    switchView("builder");
    switchStage("basics");
    byId("sbos-etl-name").focus();
    notify("New pipeline draft prepared. Complete Basics, then save the draft.");
  }

  function copyScript() {
    var script = selectedScript(state.data.pipeline);
    if (!script) {
      return;
    }
    navigator.clipboard.writeText(script.text).then(function () {
      notify("Generated script copied.");
    }).catch(function () {
      notify("The browser could not copy the generated script.", "error");
    });
  }

  function downloadScript() {
    var script = selectedScript(state.data.pipeline);
    if (!script) {
      return;
    }
    var blob = new Blob([script.text], { type: "text/plain;charset=utf-8" });
    var url = URL.createObjectURL(blob);
    var link = document.createElement("a");
    link.href = url;
    link.download = state.data.pipeline.code + "-" + script.type.toLowerCase() + ".sql";
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  }

  function showRunDetail(runId) {
    return server("SBOS_ETL_RUN_DETAIL", {
      x01: runId
    }).then(function (result) {
      var dialog = byId("sbos-run-dialog");
      byId("sbos-run-dialog-title").textContent =
        "Run #" + result.run.id + " · " + result.run.status;
      byId("sbos-run-watermark").textContent =
        (result.run.lowWatermark || "Beginning") + " → " +
        (result.run.highWatermark || "No high watermark");
      var batchList = byId("sbos-run-batches");
      clear(batchList);
      (result.batches || []).forEach(function (batch) {
        var row = document.createElement("div");
        row.className = "sbos-batch-detail";
        row.appendChild(text("strong", "", "Batch " + batch.number));
        row.appendChild(text("span", badgeClass(batch.status), batch.status));
        row.appendChild(text(
          "span",
          "",
          batch.fromRow + "–" + batch.toRow + " · " +
          batch.rowsAffected + " affected · " + (batch.worker || "Waiting")
        ));
        batchList.appendChild(row);
      });
      var logs = byId("sbos-run-logs");
      clear(logs);
      (result.logs || []).forEach(function (entry) {
        var row = document.createElement("div");
        row.className = "sbos-log-line sbos-log-line--" + entry.level.toLowerCase();
        row.appendChild(text("time", "", entry.time));
        row.appendChild(text("strong", "", entry.event));
        row.appendChild(text("span", "", entry.message));
        logs.appendChild(row);
      });
      if (typeof dialog.showModal === "function") {
        dialog.showModal();
      } else {
        dialog.setAttribute("open", "open");
      }
    });
  }

  function bindEvents() {
    root.addEventListener("click", function (event) {
      var button = event.target.closest("[data-action]");
      if (!button || state.loading) {
        return;
      }
      var action = button.dataset.action;
      if (action === "save") {
        withBusy("Saving configuration…", saveConfiguration);
      } else if (action === "validate") {
        withBusy("Validating metadata…", validateConfiguration);
      } else if (action === "generate") {
        withBusy("Generating execution plan…", generatePlan);
      } else if (action === "approve") {
        withBusy("Approving exact script hash…", approvePlan);
      } else if (action === "activate") {
        withBusy("Activating five-minute schedule…", activatePipeline);
      } else if (action === "pause") {
        withBusy("Pausing schedule…", pausePipeline);
      } else if (action === "run-now") {
        withBusy("Queuing asynchronous run…", runNow);
      } else if (action === "refresh") {
        withBusy("Refreshing runtime status…", function () {
          return bootstrap(state.pipelineId, true);
        });
      } else if (action === "refresh-dashboard") {
        withBusy("Refreshing sync analytics…", loadDashboard);
      } else if (action === "dashboard-bucket") {
        state.dashboardBucket =
          state.dashboardBucket === button.dataset.bucket ?
            "" : button.dataset.bucket;
        state.dashboardPipelineId = null;
        withBusy("Loading selected sync period…", loadDashboard);
      } else if (action === "dashboard-failure-filter") {
        state.dashboardFailureFilter =
          state.dashboardFailureFilter === button.dataset.failureCode ?
            "" : button.dataset.failureCode;
        renderFailureChart(state.dashboardData.failureBreakdown);
        setDashboardApexItem(
          "P10_DASHBOARD_FAILURE_FILTER", state.dashboardFailureFilter
        );
        refreshNativeReport("sbos_dashboard_failure_ir");
      } else if (action === "dashboard-pipeline") {
        state.dashboardPipelineId = Number(button.dataset.pipelineId);
        withBusy("Drilling into pipeline runs…", loadDashboard);
      } else if (action === "dashboard-drill-back") {
        state.dashboardPipelineId = null;
        withBusy("Returning to all pipelines…", loadDashboard);
      } else if (action === "new-pipeline") {
        newPipeline();
      } else if (action === "new-connection") {
        openConnectionDialog();
      } else if (action === "edit-connection") {
        openConnectionDialog(Number(button.dataset.connectionId));
      } else if (action === "delete-pipeline") {
        var pipelineId = Number(button.dataset.pipelineId);
        var pipeline = (state.data.pipelines || []).find(function (entry) {
          return Number(entry.id) === pipelineId;
        });
        confirmAction(
          "Delete pipeline \"" +
            (pipeline ? pipeline.name : "#" + pipelineId) +
            "\"? This cannot be undone.",
          function () {
            withBusy("Deleting pipeline…", function () {
              return deletePipeline(pipelineId);
            });
          }
        );
      } else if (action === "delete-connection") {
        var connectionId = Number(button.dataset.connectionId);
        var connection = connectionForId(connectionId);
        if (connection.system) {
          notify(
            "This retained baseline connection can be managed but cannot be deleted.",
            "error"
          );
          return;
        }
        confirmAction(
          "Delete connection \"" +
            (connection.name || "#" + connectionId) +
            "\"? Connections used by pipelines will be protected.",
          function () {
            withBusy("Deleting connection…", function () {
              return deleteConnection(connectionId);
            });
          }
        );
      } else if (action === "delete-run") {
        var runId = Number(button.dataset.runId);
        confirmAction(
          "Delete run #" + runId +
            " and its batches, logs and rejected-row history?",
          function () {
            withBusy("Deleting run history…", function () {
              return deleteRun(runId);
            });
          }
        );
      } else if (action === "save-connection") {
        withBusy("Saving protected connection configuration…", saveConnection);
      } else if (action === "close-connection") {
        closeConnectionDialog();
      } else if (action === "toggle-connection-password") {
        var passwordInput = byId("sbos-connection-password");
        var showPassword = passwordInput.type === "password";
        passwordInput.type = showPassword ? "text" : "password";
        button.textContent = showPassword ? "Hide" : "Show";
        button.setAttribute(
          "aria-label",
          showPassword ? "Hide password" : "Show password"
        );
      } else if (action === "open-pipeline") {
        withBusy("Opening pipeline configuration…", function () {
          return bootstrap(Number(button.dataset.pipelineId), true).then(function () {
            switchView("builder");
            switchStage("basics");
          });
        });
      } else if (action === "open-runs") {
        withBusy("Loading pipeline runs…", function () {
          return bootstrap(Number(button.dataset.pipelineId), true).then(function () {
            switchView("monitor");
          });
        });
      } else if (action === "add-mapping") {
        addMapping();
      } else if (action === "auto-map") {
        withBusy("Reading source columns…", function () {
          return loadPipelineColumns(state.data.pipeline).then(autoMapSource);
        });
      } else if (action === "remove-mapping") {
        removeMapping(Number(button.dataset.index));
      } else if (action === "move-mapping") {
        moveMapping(
          Number(button.dataset.index), Number(button.dataset.direction)
        );
      } else if (action === "add-source") {
        withBusy("Adding source table…", addSource);
      } else if (action === "remove-source") {
        removeSource(Number(button.dataset.index));
      } else if (action === "move-source") {
        moveSource(
          Number(button.dataset.index), Number(button.dataset.direction)
        );
      } else if (action === "add-sort") {
        try {
          addSort();
        } catch (error) {
          notify(error, "error");
        }
      } else if (action === "remove-sort") {
        removeSort(Number(button.dataset.index));
      } else if (action === "move-sort") {
        moveSort(Number(button.dataset.index), Number(button.dataset.direction));
      } else if (action === "open-transform") {
        try {
          openTransform(button.dataset.operation);
        } catch (error) {
          notify(error, "error");
        }
      } else if (action === "edit-join") {
        try {
          openTransform("JOIN", Number(button.dataset.index), "join");
        } catch (error) {
          notify(error, "error");
        }
      } else if (action === "edit-transform") {
        try {
          var transformIndex = Number(button.dataset.index);
          openTransform(
            state.data.pipeline.transforms[transformIndex].type,
            transformIndex,
            "transform"
          );
        } catch (error) {
          notify(error, "error");
        }
      } else if (action === "apply-transform") {
        try {
          applyTransform();
        } catch (error) {
          notify(error, "error");
        }
      } else if (action === "remove-transform") {
        removeTransform(Number(button.dataset.index));
      } else if (action === "close-transform") {
        byId("sbos-transform-dialog").close();
      } else if (action === "previous-stage") {
        moveStage(-1);
      } else if (action === "next-stage") {
        moveStage(1);
      } else if (action === "copy-script") {
        copyScript();
      } else if (action === "download-script") {
        downloadScript();
      } else if (action === "run-detail") {
        withBusy("Loading run detail…", function () {
          return showRunDetail(Number(button.dataset.runId));
        });
      } else if (action === "close-dialog") {
        byId("sbos-run-dialog").close();
      }
    });

    root.addEventListener("change", function (event) {
      if (event.target.id === "sbos-etl-pipeline-select") {
        if (!event.target.value) {
          return;
        }
        withBusy("Loading pipeline…", function () {
          return bootstrap(Number(event.target.value), true).then(function () {
            switchView("builder");
            switchStage("basics");
          });
        });
      } else if (event.target.id === "sbos-dashboard-granularity") {
        state.dashboardGranularity = event.target.value;
        state.dashboardBucket = "";
        state.dashboardPipelineId = null;
        state.dashboardFailureFilter = "";
        withBusy("Loading " +
          state.dashboardGranularity.toLowerCase() +
          " sync analytics…", loadDashboard);
      } else if (event.target.id === "sbos-connection-type") {
        configureConnectionFields();
      } else if (event.target.id === "sbos-source-connection") {
        var sourceConnectionId = Number(event.target.value);
        var sourceConnection = connectionForId(sourceConnectionId);
        renderConnectionMetadata(
          "source", sourceConnection, sourceConnection.schema
        );
        withBusy("Loading source tables…", function () {
          return loadTableCatalog(sourceConnectionId, "SOURCE").then(function () {
            renderCatalogOptions(
              byId("sbos-source-catalog"),
              state.sourceCatalog,
              "",
              "-- Select a source table --"
            );
          });
        });
      } else if (event.target.id === "sbos-target-connection") {
        var targetConnectionId = Number(event.target.value);
        var targetConnection = connectionForId(targetConnectionId);
        state.data.pipeline.targetConnectionId = targetConnectionId;
        state.data.pipeline.targetOwner = targetConnection.schema || "";
        state.data.pipeline.targetTable = "";
        state.data.pipeline.targetExists = false;
        state.targetColumns = [];
        renderConnectionMetadata(
          "target", targetConnection, targetConnection.schema
        );
        setValue("sbos-target-table", "");
        withBusy("Loading target tables…", function () {
          return loadTableCatalog(targetConnectionId, "TARGET").then(function () {
            renderCatalogOptions(
              byId("sbos-target-catalog"),
              state.targetCatalog,
              "",
              "-- Select an existing target --"
            );
          });
        });
      } else if (event.target.id === "sbos-target-catalog") {
        if (event.target.value) {
          var targetParts = event.target.value.split(".");
          state.data.pipeline.targetConnectionId =
            Number(value("sbos-target-connection"));
          state.data.pipeline.targetOwner = targetParts.shift();
          state.data.pipeline.targetTable = targetParts.join(".");
          state.data.pipeline.targetExists = true;
          setValue("sbos-target-schema", state.data.pipeline.targetOwner);
          setValue("sbos-target-table", state.data.pipeline.targetTable);
          withBusy("Loading existing target columns…", function () {
            return loadTargetColumns(state.data.pipeline).then(function () {
              renderTarget(state.data.pipeline);
              renderMappings(state.data.pipeline);
              renderFlow(state.data.pipeline);
            });
          });
        }
        state.dirty = true;
      } else if (event.target.classList.contains("sbos-map-source")) {
        var mappingRow = event.target.closest("tr");
        var selectedColumn = availableSourceColumns(state.data.pipeline).find(
          function (entry) {
            return entry.expression === event.target.value;
          }
        );
        if (selectedColumn) {
          var targetInput = mappingRow.querySelector(".sbos-map-target");
          if (!targetInput.value || /^NEW_COLUMN_/.test(targetInput.value)) {
            targetInput.value = selectedColumn.column.name;
          }
          var selectedMappedTarget = targetColumn(targetInput.value);
          var targetDataType = selectedMappedTarget ?
            mappedOracleType(selectedMappedTarget.dataType) :
            mappedOracleType(selectedColumn.column.dataType);
          var typeMetadata = selectedMappedTarget || selectedColumn.column;
          mappingRow.dataset.targetDataType = targetDataType;
          mappingRow.querySelector(".sbos-map-size").value =
            targetDataType === "NUMBER" ?
              (typeMetadata.precision || "") :
              (targetDataType === "VARCHAR2" ?
                Math.min(Number(typeMetadata.dataLength || 4000), 32767) : "");
          mappingRow.querySelector(".sbos-map-scale").value =
            targetDataType === "NUMBER" ?
              (typeMetadata.scale || 0) : "";
        }
        state.dirty = true;
      } else if (event.target.classList.contains("sbos-map-target")) {
        var targetRow = event.target.closest("tr");
        var selectedTarget = targetColumn(event.target.value);
        if (selectedTarget) {
          var selectedType = mappedOracleType(selectedTarget.dataType);
          targetRow.dataset.targetDataType = selectedType;
          targetRow.querySelector(".sbos-map-size").value =
            selectedType === "NUMBER" ?
              (selectedTarget.precision || "") :
              (selectedType === "VARCHAR2" ?
                Math.min(Number(selectedTarget.dataLength || 4000), 32767) : "");
          targetRow.querySelector(".sbos-map-scale").value =
            selectedType === "NUMBER" ? (selectedTarget.scale || 0) : "";
          targetRow.querySelector(".sbos-map-nullable").checked =
            selectedTarget.nullable !== false;
        }
        state.dirty = true;
      } else if (event.target.classList.contains("sbos-map-preset")) {
        var presetRow = event.target.closest("tr");
        var expression = presetRow.querySelector(".sbos-map-source").value;
        var transformInput = presetRow.querySelector(".sbos-map-transform");
        if (event.target.value !== "CUSTOM") {
          transformInput.value = transformationPreset(
            expression, event.target.value
          );
        }
        transformInput.focus();
        state.dirty = true;
      } else if (event.target.classList.contains("sbos-sort-column") ||
                 event.target.classList.contains("sbos-sort-direction") ||
                 event.target.classList.contains("sbos-sort-nulls")) {
        state.data.pipeline.sorts = collectSorts();
        state.dirty = true;
      } else if (event.target.id === "sbos-watermark-source") {
        state.data.pipeline.delta.watermarkAlias =
          event.target.value.toUpperCase();
        state.data.pipeline.delta.watermarkColumn = "";
        state.data.pipeline.delta.tiebreakerColumn = "";
        renderDelta(state.data.pipeline);
        state.dirty = true;
      } else if (event.target.id === "sbos-watermark-column") {
        var watermarkSource = sourceForAlias(
          state.data.pipeline, value("sbos-watermark-source")
        );
        var watermarkColumn = columnsForSource(watermarkSource).find(
          function (column) {
            return column.name === event.target.value;
          }
        );
        setValue("sbos-watermark-type", deltaTypeForColumn(watermarkColumn));
        state.data.pipeline.delta.watermarkColumn = event.target.value;
        state.data.pipeline.delta.watermarkType =
          deltaTypeForColumn(watermarkColumn);
        state.dirty = true;
      } else if (event.target.id === "sbos-tiebreaker-column") {
        var tieSource = sourceForAlias(
          state.data.pipeline, value("sbos-watermark-source")
        );
        var tieColumn = columnsForSource(tieSource).find(function (column) {
          return column.name === event.target.value;
        });
        setValue("sbos-tiebreaker-type", tieTypeForColumn(tieColumn));
        state.data.pipeline.delta.tiebreakerColumn = event.target.value;
        state.data.pipeline.delta.tiebreakerType =
          tieTypeForColumn(tieColumn);
        state.dirty = true;
      } else if (event.target.id === "sbos-pipeline-status-filter") {
        renderPipelineManagement();
      } else if (event.target.id === "sbos-workers") {
        renderWorkers(Number(event.target.value));
      } else if (event.target.id === "sbos-review-check") {
        updateActionStates();
      } else if (event.target.closest("#sbos-connection-dialog")) {
        return;
      } else {
        state.dirty = true;
      }
    });
    root.addEventListener("input", function (event) {
      if (event.target.id === "sbos-pipeline-search") {
        renderPipelineManagement();
      } else if (event.target.closest("#sbos-connection-dialog")) {
        return;
      } else if (event.target.id !== "sbos-review-check") {
        state.dirty = true;
      }
    });

    all("[data-view-target]", root).forEach(function (button) {
      button.addEventListener("click", function () {
        switchView(button.dataset.viewTarget);
      });
    });
    all("[data-script-type]", root).forEach(function (button) {
      button.addEventListener("click", function () {
        switchScript(button.dataset.scriptType);
      });
    });
    all("[data-stage-target]", root).forEach(function (button) {
      button.addEventListener("click", function () {
        switchStage(button.dataset.stageTarget);
      });
    });
  }

  function startPolling() {
    if (state.pollTimer) {
      global.clearInterval(state.pollTimer);
    }
    state.pollTimer = global.setInterval(function () {
      if (!state.loading && !state.dirty && state.pipelineId && !document.hidden) {
        bootstrap(state.pipelineId, true).catch(function () {
          return null;
        });
      }
    }, 5000);
  }

  function init() {
    root = byId("sbos-etl-app");
    if (!root || !apex || !apex.server) {
      return;
    }
    bindEvents();
    if (!state.globalErrorsBound) {
      global.addEventListener("error", function (event) {
        if (event && event.error) {
          notify(event.error, "error");
        }
      });
      global.addEventListener("unhandledrejection", function (event) {
        if (event && event.reason) {
          notify(event.reason, "error");
        }
      });
      state.globalErrorsBound = true;
    }
    switchView("dashboard");
    switchStage("basics");
    setBusy(true, "Loading ETL metadata…");
    bootstrap(null, true)
      .then(loadDashboard)
      .catch(function (error) {
        notify(error, "error");
      })
      .finally(function () {
        setBusy(false);
        startPolling();
      });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init, { once: true });
  } else {
    init();
  }
})(window, window.apex);
