(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var fmt = new Intl.NumberFormat("en-IN");
  var money = new Intl.NumberFormat("en-IN", {style: "currency", currency: "INR", maximumFractionDigits: 0});
  function esc(value) {
    return String(value == null ? "" : value).replace(/[&<>"']/g, function (c) {
      return {"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"}[c];
    });
  }
  function kpi(label, value) {
    return '<div class="ald-kpi"><span>' + esc(label) + "</span><strong>" + esc(value) + "</strong></div>";
  }
  function detail(label, value) {
    return '<div class="ald-detail"><span>' + esc(label) + "</span><strong>" + esc(value == null || value === "" ? "—" : value) + "</strong></div>";
  }
  function table(headers, rows) {
    return '<div class="ald-table-wrap"><table class="ald-table"><thead><tr>' +
      headers.map(function (header) { return "<th>" + esc(header) + "</th>"; }).join("") +
      "</tr></thead><tbody>" + rows.join("") + "</tbody></table></div>";
  }
  function shellMarkup() {
    return '<section id="ald-app" class="ald-shell">' +
      '<div id="ald-loading" class="ald-loading"><span class="fa fa-spinner fa-spin"></span> ' +
      'Loading complete agent statistics...</div>' +
      '<div id="ald-error" class="ald-error" hidden></div>' +
      '<div id="ald-content" hidden>' +
      '<header class="ald-profile"><div class="ald-avatar"><span class="fa fa-user"></span></div>' +
      '<div><p class="ald-eyebrow">Agent drill-through</p><h1 id="ald-name">Agent</h1>' +
      '<p id="ald-location"></p></div><div class="ald-profile-status">' +
      '<span id="ald-status" class="ald-badge"></span>' +
      '<span id="ald-risk" class="ald-badge ald-badge--risk"></span></div></header>' +
      '<div id="ald-period-label" class="ald-period-label"></div>' +
      '<div id="ald-selected-kpis" class="ald-kpis"></div>' +
      '<section class="ald-section"><div class="ald-section-head">' +
      '<h2>Daily / Month / 360-Day Profile</h2><span>Profile serving tables</span></div>' +
      '<div id="ald-period-profiles" class="ald-profile-grid"></div></section>' +
      '<section class="ald-section"><div class="ald-section-head"><h2>Agent &amp; Risk Profile</h2>' +
      '<span id="ald-profile-updated"></span></div><div id="ald-agent-profile" ' +
      'class="ald-detail-grid"></div></section>' +
      '<section class="ald-section"><div class="ald-section-head"><h2>Month-wise Trend</h2>' +
      '<span>Last 12 months</span></div><div id="ald-trend" class="ald-chart"></div></section>' +
      '<section class="ald-section"><div class="ald-section-head"><h2>Selected-period Services</h2>' +
      '<span>Summary table</span></div><div id="ald-services"></div></section>' +
      '<section class="ald-section"><div class="ald-section-head">' +
      '<h2>Base vs Transaction Locations</h2><span>Selected date range only</span></div>' +
      '<div id="ald-locations"></div></section></div></section>';
  }
  function ensureShell() {
    var root = $("ald-app");
    if (root) { return root; }
    var host = document.querySelector(
      ".t-Dialog-body, .t-Drawer-body, .t-Body-contentInner, #wwvFlowForm"
    );
    if (!host) { return null; }
    host.insertAdjacentHTML("afterbegin", shellMarkup());
    return $("ald-app");
  }
  function showFailure(message) {
    var root = ensureShell();
    if (!root) { return; }
    if ($("ald-loading")) { $("ald-loading").hidden = true; }
    if ($("ald-content")) { $("ald-content").hidden = true; }
    $("ald-error").hidden = false;
    $("ald-error").textContent = message;
  }
  function render(data) {
    var agent = data.agent || {}, selected = data.selectedPeriod || {};
    if (!agent.id) {
      throw new Error("No Agent Master record was returned for the selected agent.");
    }
    $("ald-name").textContent = (agent.id || "") + " — " + (agent.name || "Unknown agent");
    $("ald-location").textContent = [agent.village, agent.subdistrict, agent.district, agent.state].filter(Boolean).join(", ");
    $("ald-status").textContent = agent.status || "Unknown";
    $("ald-risk").textContent = (agent.riskCategory || "Unscored") + " risk";
    $("ald-period-label").textContent = (data.mode || "DAILY") + " analysis · " +
      (data.fromDate || "—") + " to " + (data.toDate || "—");
    $("ald-selected-kpis").innerHTML =
      kpi("Transactions", fmt.format(selected.transactions || 0)) +
      kpi("Amount", money.format(selected.amount || 0)) +
      kpi("Success rate", Number(selected.successRate || 0).toFixed(2) + "%") +
      kpi("Failures", fmt.format(selected.failureCount || 0)) +
      kpi("Reversals", fmt.format(selected.reversalCount || 0)) +
      kpi("Unique customers", fmt.format(selected.uniqueCustomers || 0));

    $("ald-period-profiles").innerHTML = (data.periodProfiles || []).map(function (row) {
      return '<article class="ald-profile-card"><h3>' + esc(row.label) + '</h3><strong>' +
        fmt.format(row.transactions || 0) + '</strong><span>transactions</span><dl><dt>Amount</dt><dd>' +
        money.format(row.amount || 0) + '</dd><dt>Success / Failure</dt><dd>' +
        fmt.format(row.successCount || 0) + " / " + fmt.format(row.failureCount || 0) +
        "</dd><dt>Reversals</dt><dd>" + fmt.format(row.reversalCount || 0) + "</dd></dl></article>";
    }).join("");

    $("ald-profile-updated").textContent = "Profile as of " + (agent.profileUpdatedOn || "—");
    $("ald-agent-profile").innerHTML =
      detail("Agent type", agent.type) + detail("Operation mode", agent.operationMode) +
      detail("Authentication", agent.authType) + detail("Branch", agent.branch) +
      detail("Vendor", agent.vendor) + detail("Bank", agent.bank) +
      detail("Base latitude", agent.latitude) + detail("Base longitude", agent.longitude) +
      detail("Risk score", Number(agent.riskScore || 0).toFixed(2)) +
      detail("Active days", fmt.format(agent.activeDays || 0)) +
      detail("Transaction velocity", Number(agent.transactionVelocity || 0).toFixed(2)) +
      detail("Platform", agent.platform) + detail("Application version", agent.applicationVersion) +
      detail("Current device", agent.deviceId) + detail("Most-used service", agent.mostUsedService) +
      detail("Response code", agent.mostUsedResponseCode);

    var trend = data.trend || [];
    var max = Math.max.apply(null, [1].concat(trend.map(function (row) { return Number(row.transactions || 0); })));
    $("ald-trend").innerHTML = trend.length ? '<div class="ald-bars">' + trend.map(function (row) {
      return '<div class="ald-bar-group" title="' + esc(row.month) + " — " +
        fmt.format(row.transactions || 0) + ' transactions"><span class="ald-bar" style="height:' +
        Math.max(2, Math.round(130 * Number(row.transactions || 0) / max)) +
        'px"></span><small>' + esc(row.month.slice(5)) + "<br>" + esc(row.month.slice(0, 4)) +
        "</small></div>";
    }).join("") + "</div>" : '<div class="ald-empty">No monthly trend.</div>';

    var services = (data.services || []).map(function (row) {
      return "<tr><td>" + esc(row.name) + "</td><td>" + fmt.format(row.transactions || 0) +
        "</td><td>" + money.format(row.amount || 0) + "</td></tr>";
    });
    $("ald-services").innerHTML = services.length ?
      table(["Service", "Transactions", "Amount"], services) :
      '<div class="ald-empty">No services in this selected period.</div>';

    var locations = [];
    locations.push("<tr><td><span class=\"ald-location-type\">Agent base</span></td><td>" +
      esc(agent.latitude) + "</td><td>" + esc(agent.longitude) +
      "</td><td>—</td><td>Master location</td></tr>");
    (data.transactionLocations || []).forEach(function (row) {
      locations.push('<tr><td><span class="ald-location-type ald-location-type--tx">Transaction</span></td><td>' +
        esc(row.latitude) + "</td><td>" + esc(row.longitude) + "</td><td>" +
        fmt.format(row.transactions || 0) + "</td><td>" + esc(row.lastTransaction) + "</td></tr>");
    });
    $("ald-locations").innerHTML = table(["Location type", "Latitude", "Longitude", "Transactions", "Last seen"], locations);
    $("ald-loading").hidden = true;
    $("ald-content").hidden = false;
  }
  function init() {
    var root = ensureShell();
    if (!root || !globalThis.apex || !apex.server) { return false; }
    if (root.dataset.initialized === "true") { return true; }
    root.dataset.initialized = "true";
    var context = {};
    try {
      context = JSON.parse(globalThis.sessionStorage.getItem("alaAgentDrawerContext") || "{}");
    } catch (ignore) {}
    var agentId = String($v("P71_AGENT_ID") || context.agentId || "").trim();
    var mode = String($v("P71_MODE") || "").toUpperCase();
    if (["DAILY", "MONTHLY", "YEAR_360"].indexOf(mode) < 0) {
      mode = String(context.mode || "DAILY").toUpperCase();
    }
    if (["DAILY", "MONTHLY", "YEAR_360"].indexOf(mode) < 0) { mode = "DAILY"; }
    var asOfDate = String($v("P71_AS_OF_DATE") || context.asOfDate || "").trim();
    if (!agentId) {
      showFailure("Agent statistics could not be loaded: the selected agent ID was not received.");
      return true;
    }
    apex.server.process("AGENT_LOCATION_AGENT_DETAIL", {
      x01: agentId, x02: mode, x03: asOfDate
    }, {dataType: "json"}).done(function (data) {
      try {
        render(data || {});
      } catch (error) {
        showFailure("Agent statistics could not be rendered: " + error.message);
      }
    }).fail(function (xhr) {
      showFailure("Agent statistics could not be loaded: " +
        (xhr.responseText || xhr.statusText || "Unknown error"));
    });
    return true;
  }
  function boot(attempt) {
    if (init()) { return; }
    if (attempt < 40) {
      globalThis.setTimeout(function () { boot(attempt + 1); }, 100);
    }
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", function () { boot(0); }, {once: true});
  } else {
    boot(0);
  }
  document.addEventListener("apexreadyend", function () { boot(0); });
  globalThis.setTimeout(function () { boot(0); }, 0);
})();
