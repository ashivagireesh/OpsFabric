(function (global) {
  "use strict";

  function init() {
    var byId = function (id) { return document.getElementById(id); };
    var map = byId("india-map");
    if (!map || map.dataset.districtMapInitialized === "true") { return; }
    map.dataset.districtMapInitialized = "true";

    var svgNS = "http://www.w3.org/2000/svg";
    var selectedPath = null;
    var boundaryPaths = {};
    var statePayload = null;
    var districtPayloadPromise = null;
    var renderGeneration = 0;
    var width = 720;
    var height = 720;
    var stateAsset = "/ords/r/sas/310/files/static/latest/india-states.json";
    var districtAsset = "/ords/r/sas/310/files/static/latest/india-districts.json";

    var statePlaces = {
      "Andaman And Nicobar Islands": ["Sri Vijaya Puram", 11.6234, 92.7265], "Andhra Pradesh": ["Amaravati", 16.5730, 80.3575], "Arunachal Pradesh": ["Itanagar", 27.0844, 93.6053], "Assam": ["Dispur", 26.1433, 91.7898], "Bihar": ["Patna", 25.5941, 85.1376], "Chandigarh": ["Chandigarh", 30.7333, 76.7794], "Chhattisgarh": ["Raipur", 21.2514, 81.6296], "Delhi": ["New Delhi", 28.6139, 77.2090], "Goa": ["Panaji", 15.4909, 73.8278],
      "Gujarat": ["Gandhinagar", 23.2156, 72.6369], "Haryana": ["Chandigarh", 30.7333, 76.7794], "Himachal Pradesh": ["Shimla", 31.1048, 77.1734], "Jammu And Kashmir": ["Srinagar", 34.0837, 74.7973], "Jharkhand": ["Ranchi", 23.3441, 85.3096], "Karnataka": ["Bengaluru", 12.9716, 77.5946], "Kerala": ["Thiruvananthapuram", 8.5241, 76.9366], "Ladakh": ["Leh", 34.1526, 77.5771], "Lakshadweep": ["Kavaratti", 10.5593, 72.6358],
      "Madhya Pradesh": ["Bhopal", 23.2599, 77.4126], "Maharashtra": ["Mumbai", 19.0760, 72.8777], "Manipur": ["Imphal", 24.8170, 93.9368], "Meghalaya": ["Shillong", 25.5788, 91.8933], "Mizoram": ["Aizawl", 23.7271, 92.7176], "Nagaland": ["Kohima", 25.6751, 94.1086], "Odisha": ["Bhubaneswar", 20.2961, 85.8245], "Puducherry": ["Puducherry", 11.9416, 79.8083], "Punjab": ["Chandigarh", 30.7333, 76.7794],
      "Rajasthan": ["Jaipur", 26.9124, 75.7873], "Sikkim": ["Gangtok", 27.3389, 88.6065], "Tamil Nadu": ["Chennai", 13.0827, 80.2707], "Telangana": ["Hyderabad", 17.3850, 78.4867], "The Dadra And Nagar Haveli And Daman And Diu": ["Daman", 20.3974, 72.8328], "Tripura": ["Agartala", 23.8315, 91.2868], "Uttar Pradesh": ["Lucknow", 26.8467, 80.9462], "Uttarakhand": ["Dehradun", 30.3165, 78.0322], "West Bengal": ["Kolkata", 22.5726, 88.3639]
    };
    var popular = [["Bengaluru", 12.9716, 77.5946], ["New Delhi", 28.6139, 77.2090], ["Mumbai", 19.0760, 72.8777], ["Chennai", 13.0827, 80.2707], ["Kolkata", 22.5726, 88.3639], ["Hyderabad", 17.3850, 78.4867], ["Pune", 18.5204, 73.8567], ["Ahmedabad", 23.0225, 72.5714], ["Jaipur", 26.9124, 75.7873], ["Kochi", 9.9312, 76.2673], ["Guwahati", 26.1445, 91.7362], ["Srinagar", 34.0837, 74.7973]];
    var conditions = {0: "Clear sky", 1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast", 45: "Fog", 48: "Rime fog", 51: "Light drizzle", 53: "Drizzle", 55: "Heavy drizzle", 56: "Light freezing drizzle", 57: "Heavy freezing drizzle", 61: "Light rain", 63: "Rain", 65: "Heavy rain", 66: "Light freezing rain", 67: "Heavy freezing rain", 71: "Light snow", 73: "Snow", 75: "Heavy snow", 77: "Snow grains", 80: "Light rain showers", 81: "Rain showers", 82: "Heavy rain showers", 85: "Light snow showers", 86: "Heavy snow showers", 95: "Thunderstorm", 96: "Thunderstorm with hail", 99: "Heavy thunderstorm with hail"};
    var weatherColors = {clear: "#f6c445", cloudy: "#94a3b8", fog: "#cbd5e1", rain: "#3b82f6", snow: "#8b5cf6", storm: "#e4475b", unknown: "#dce6ec"};
    var number = function (value, digits) { return Number(value).toFixed(digits); };

    function weatherCategory(code) {
      code = Number(code);
      if (code === 0 || code === 1) { return "clear"; }
      if (code === 2 || code === 3) { return "cloudy"; }
      if (code === 45 || code === 48) { return "fog"; }
      if ((code >= 51 && code <= 67) || (code >= 80 && code <= 82)) { return "rain"; }
      if ((code >= 71 && code <= 77) || (code >= 85 && code <= 86)) { return "snow"; }
      if (code >= 95 && code <= 99) { return "storm"; }
      return "unknown";
    }

    function fetchJson(url) {
      return fetch(url, {headers: {Accept: "application/json"}}).then(function (response) {
        if (!response.ok) { throw new Error("HTTP " + response.status); }
        return response.json();
      });
    }

    function mercator(latitude, longitude) {
      var x = longitude * 20037508.34 / 180;
      var y = Math.log(Math.tan((90 + latitude) * Math.PI / 360)) / (Math.PI / 180);
      return [x, y * 20037508.34 / 180];
    }

    function projectionFor(features) {
      var points = [];
      features.forEach(function (feature) {
        feature.geometry.rings.forEach(function (ring) {
          ring.forEach(function (point) { points.push(point); });
        });
      });
      var xs = points.map(function (point) { return point[0]; });
      var ys = points.map(function (point) { return point[1]; });
      var minX = Math.min.apply(null, xs), maxX = Math.max.apply(null, xs);
      var minY = Math.min.apply(null, ys), maxY = Math.max.apply(null, ys);
      var pad = 34;
      var scale = Math.min((width - pad * 2) / Math.max(maxX - minX, 1), (height - pad * 2) / Math.max(maxY - minY, 1));
      var offsetX = (width - (maxX - minX) * scale) / 2;
      var offsetY = (height - (maxY - minY) * scale) / 2;
      return {
        point: function (point) { return [offsetX + (point[0] - minX) * scale, height - (offsetY + (point[1] - minY) * scale)]; },
        coordinate: function (event) {
          var rect = map.getBoundingClientRect();
          var svgX = (event.clientX - rect.left) * width / rect.width;
          var svgY = (event.clientY - rect.top) * height / rect.height;
          var mapX = (svgX - offsetX) / scale + minX;
          var mapY = ((height - svgY) - offsetY) / scale + minY;
          var longitude = mapX / 20037508.34 * 180;
          var latitude = 180 / Math.PI * (2 * Math.atan(Math.exp(mapY / 20037508.34 * Math.PI)) - Math.PI / 2);
          return [latitude, longitude];
        }
      };
    }

    function createBoundary(feature, projection, cssClass, key, label, activate) {
      var path = document.createElementNS(svgNS, "path");
      var commands = [];
      feature.geometry.rings.forEach(function (ring) {
        ring.forEach(function (point, index) {
          var projected = projection.point(point);
          commands.push((index ? "L" : "M") + projected[0].toFixed(1) + " " + projected[1].toFixed(1));
        });
        commands.push("Z");
      });
      path.setAttribute("d", commands.join(" "));
      path.setAttribute("fill-rule", "evenodd");
      path.setAttribute("class", "state-shape " + cssClass);
      path.setAttribute("tabindex", "0");
      path.setAttribute("role", "button");
      path.setAttribute("aria-label", label);
      var title = document.createElementNS(svgNS, "title");
      title.textContent = label;
      path.appendChild(title);
      path.addEventListener("click", function (event) { activate(event, path); });
      path.addEventListener("keydown", function (event) {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          activate(null, path);
        }
      });
      boundaryPaths[key] = path;
      map.appendChild(path);
      return path;
    }

    function selectPath(path) {
      if (selectedPath) { selectedPath.classList.remove("is-selected"); }
      selectedPath = path;
      selectedPath.classList.add("is-selected");
    }

    function loadBoundaryWeather(entries, levelLabel, generation) {
      if (!entries.length) {
        byId("map-weather-status").textContent = "Conditions unavailable";
        return;
      }
      byId("map-weather-status").textContent = "Loading " + entries.length + " live conditions...";
      var latitudes = entries.map(function (entry) { return entry.place[1]; }).join(",");
      var longitudes = entries.map(function (entry) { return entry.place[2]; }).join(",");
      var url = "https://api.open-meteo.com/v1/forecast?latitude=" + encodeURIComponent(latitudes) + "&longitude=" + encodeURIComponent(longitudes) + "&current=temperature_2m,weather_code&timezone=Asia%2FKolkata";
      fetchJson(url).then(function (data) {
        if (generation !== renderGeneration) { return; }
        var locations = Array.isArray(data) ? data : [data];
        entries.forEach(function (entry, index) {
          var current = locations[index] && locations[index].current;
          if (!current || !entry.path.isConnected) { return; }
          var condition = conditions[current.weather_code] || "Weather code " + current.weather_code;
          var temperature = number(current.temperature_2m, 1);
          var category = weatherCategory(current.weather_code);
          entry.path.style.setProperty("--state-weather-color", weatherColors[category]);
          entry.path.setAttribute("data-weather", category);
          entry.path.setAttribute("aria-label", entry.name + ": " + condition + ", " + temperature + " degrees Celsius. " + entry.action);
          entry.path.querySelector("title").textContent = entry.name + " - " + condition + ", " + temperature + " °C";
        });
        byId("map-weather-status").textContent = "Live at " + levelLabel + " representative points";
      }).catch(function () {
        if (generation !== renderGeneration) { return; }
        byId("map-weather-status").textContent = "Live colors unavailable";
      });
    }

    function openDrawer() { apex.theme.openRegion("weather-drawer"); }

    function loadWeather(place, region) {
      byId("drawer-location").textContent = place[0];
      byId("drawer-region").textContent = (region ? region + " | " : "") + number(place[1], 4) + ", " + number(place[2], 4);
      byId("weather-live").textContent = "LOADING REST API";
      byId("weather-live").classList.remove("is-live");
      byId("weather-error").hidden = true;
      byId("weather-days").innerHTML = "";
      openDrawer();
      var url = "https://api.open-meteo.com/v1/forecast?latitude=" + encodeURIComponent(place[1]) + "&longitude=" + encodeURIComponent(place[2]) + "&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,wind_direction_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,wind_speed_10m_max,sunrise,sunset&timezone=Asia%2FKolkata";
      fetchJson(url).then(function (data) {
        byId("weather-condition").textContent = conditions[data.current.weather_code] || "Weather code " + data.current.weather_code;
        byId("weather-updated").textContent = "Observed " + data.current.time.replace("T", " ") + " IST";
        byId("weather-temperature").innerHTML = number(data.current.temperature_2m, 1) + " &deg;C";
        byId("weather-feels").innerHTML = number(data.current.apparent_temperature, 1) + " &deg;C";
        byId("weather-humidity").textContent = number(data.current.relative_humidity_2m, 0) + "%";
        byId("weather-wind").textContent = number(data.current.wind_speed_10m, 1) + " km/h | " + number(data.current.wind_direction_10m, 0) + " deg";
        data.daily.time.forEach(function (day, index) {
          var card = document.createElement("article");
          var label = new Intl.DateTimeFormat("en-IN", {weekday: "short", day: "2-digit", month: "short", timeZone: "Asia/Kolkata"}).format(new Date(day + "T12:00:00+05:30"));
          card.className = "forecast-day";
          card.innerHTML = "<h4>" + label + "</h4><p><strong>" + (conditions[data.daily.weather_code[index]] || "Forecast") + "</strong></p><p>" + number(data.daily.temperature_2m_max[index], 1) + " / " + number(data.daily.temperature_2m_min[index], 1) + " &deg;C</p><p>Rain " + number(data.daily.precipitation_probability_max[index], 0) + "% | Wind " + number(data.daily.wind_speed_10m_max[index], 1) + " km/h</p><p>Sunrise " + data.daily.sunrise[index].slice(11) + " | Sunset " + data.daily.sunset[index].slice(11) + "</p>";
          byId("weather-days").appendChild(card);
        });
        byId("weather-source").textContent = "Source: Open-Meteo | Forecast timezone Asia/Kolkata";
        byId("weather-live").textContent = "LIVE REST API";
        byId("weather-live").classList.add("is-live");
      }).catch(function (error) {
        byId("weather-live").textContent = "API UNAVAILABLE";
        byId("weather-error").hidden = false;
        byId("weather-error").textContent = "Weather service unavailable: " + error.message;
      });
    }

    function setLoading(message, visible) {
      byId("map-loading").textContent = message;
      byId("map-loading").hidden = !visible;
    }

    function renderPopularCities(projection) {
      var list = byId("city-list");
      list.innerHTML = "";
      byId("side-panel-title").textContent = "Popular cities";
      byId("side-panel-help").textContent = "Or search for any location in India.";
      popular.forEach(function (city) {
        var projected = projection.point(mercator(city[1], city[2]));
        var dot = document.createElementNS(svgNS, "circle");
        dot.setAttribute("cx", projected[0]); dot.setAttribute("cy", projected[1]); dot.setAttribute("r", "5");
        dot.setAttribute("class", "city-dot"); dot.setAttribute("tabindex", "0"); dot.setAttribute("role", "button"); dot.setAttribute("aria-label", city[0] + " forecast");
        var title = document.createElementNS(svgNS, "title"); title.textContent = city[0]; dot.appendChild(title);
        var choose = function () { loadWeather(city, "City"); };
        dot.addEventListener("click", choose);
        dot.addEventListener("keydown", function (event) { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); choose(); } });
        map.appendChild(dot);
        var button = document.createElement("button");
        button.type = "button"; button.className = "city-chip"; button.textContent = city[0]; button.addEventListener("click", choose); list.appendChild(button);
      });
    }

    function renderIndia(payload) {
      var generation = ++renderGeneration;
      statePayload = payload;
      selectedPath = null;
      boundaryPaths = {};
      map.replaceChildren();
      byId("district-back").hidden = true;
      byId("map-level-title").textContent = "India";
      byId("map-caption").textContent = "Live colors: Open-Meteo at each state or UT representative location";
      map.setAttribute("aria-label", "Political map of India color-coded by current weather. Activate a state to open its district map.");
      var projection = projectionFor(payload.features);
      var weatherEntries = [];
      payload.features.forEach(function (feature) {
        var name = feature.attributes.name;
        var path = createBoundary(feature, projection, "state-level-shape", name, name + " district weather map", function () { openState(name); });
        if (statePlaces[name]) { weatherEntries.push({name: name, place: statePlaces[name], path: path, action: "Open district map"}); }
      });
      renderPopularCities(projection);
      setLoading("", false);
      loadBoundaryWeather(weatherEntries, "state and UT", generation);
    }

    function districtPlace(feature) {
      var point = feature.attributes.weather_point;
      return [feature.attributes.name, point[0], point[1]];
    }

    function renderDistrictList(features, stateName) {
      var list = byId("city-list");
      list.innerHTML = "";
      byId("side-panel-title").textContent = "Districts";
      byId("side-panel-help").textContent = features.length + " districts in " + stateName + ". Select one for its forecast.";
      features.slice().sort(function (a, b) { return a.attributes.name.localeCompare(b.attributes.name); }).forEach(function (feature) {
        var key = String(feature.attributes.lgd_districtcode);
        var button = document.createElement("button");
        button.type = "button"; button.className = "city-chip district-chip"; button.textContent = feature.attributes.name;
        button.addEventListener("click", function () {
          var path = boundaryPaths[key];
          if (path) { selectPath(path); }
          loadWeather(districtPlace(feature), stateName + " district representative point");
        });
        list.appendChild(button);
      });
    }

    function renderState(stateName, payload) {
      var features = payload.features.filter(function (feature) { return feature.attributes.state === stateName; });
      if (!features.length) { throw new Error("No district boundaries found for " + stateName); }
      var generation = ++renderGeneration;
      selectedPath = null;
      boundaryPaths = {};
      map.replaceChildren();
      byId("district-back").hidden = false;
      byId("map-level-title").textContent = stateName + " · " + features.length + " districts";
      byId("map-caption").textContent = "Live colors: Open-Meteo at each district representative point";
      map.setAttribute("aria-label", "Political district map of " + stateName + " color-coded by current weather.");
      var projection = projectionFor(features);
      var weatherEntries = [];
      features.forEach(function (feature) {
        var name = feature.attributes.name;
        var key = String(feature.attributes.lgd_districtcode);
        var place = districtPlace(feature);
        var path = createBoundary(feature, projection, "district-shape", key, name + " district forecast; weather loading", function (event, selected) {
          selectPath(selected);
          if (event) {
            var coordinate = projection.coordinate(event);
            loadWeather([name, coordinate[0], coordinate[1]], "Selected point in " + name + " district, " + stateName);
          } else {
            loadWeather(place, stateName + " district representative point");
          }
        });
        weatherEntries.push({name: name, place: place, path: path, action: "Open district forecast"});
      });
      renderDistrictList(features, stateName);
      setLoading("", false);
      loadBoundaryWeather(weatherEntries, "district", generation);
    }

    function openState(stateName) {
      setLoading("Loading " + stateName + " districts...", true);
      byId("district-back").hidden = false;
      if (!districtPayloadPromise) { districtPayloadPromise = fetchJson(districtAsset); }
      districtPayloadPromise.then(function (payload) { renderState(stateName, payload); }).catch(function (error) {
        setLoading("District map unavailable: " + error.message, true);
      });
    }

    function searchCity() {
      var query = byId("city-search").value.trim();
      if (query.length < 2) { return; }
      var results = byId("search-results");
      results.hidden = false; results.textContent = "Searching...";
      fetchJson("https://geocoding-api.open-meteo.com/v1/search?name=" + encodeURIComponent(query) + "&count=8&language=en&format=json&countryCode=IN").then(function (data) {
        results.innerHTML = "";
        (data.results || []).forEach(function (item) {
          var button = document.createElement("button");
          button.type = "button"; button.className = "search-result"; button.textContent = item.name + (item.admin1 ? ", " + item.admin1 : "");
          button.addEventListener("click", function () { results.hidden = true; loadWeather([item.name, item.latitude, item.longitude], item.admin1 || item.country); });
          results.appendChild(button);
        });
        if (!results.children.length) { results.textContent = "No Indian city found."; }
      }).catch(function (error) { results.textContent = "City search unavailable: " + error.message; });
    }

    byId("district-back").addEventListener("click", function () { if (statePayload) { renderIndia(statePayload); } });
    byId("city-search-button").addEventListener("click", searchCity);
    byId("city-search").addEventListener("keydown", function (event) { if (event.key === "Enter") { event.preventDefault(); searchCity(); } });
    document.addEventListener("keydown", function (event) { if (event.key === "Escape") { byId("search-results").hidden = true; } });
    fetchJson(stateAsset).then(renderIndia).catch(function (error) { setLoading("Political map unavailable: " + error.message, true); });
  }

  global.SASDistrictWeatherMap = {init: init};
})(window);
