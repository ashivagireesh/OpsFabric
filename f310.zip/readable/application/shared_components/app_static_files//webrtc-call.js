(function (global) {
  "use strict";

  function init() {
    var bootstrap = document.getElementById("webrtc-bootstrap");
    if (!bootstrap || bootstrap.dataset.initialized === "true") { return; }
    bootstrap.dataset.initialized = "true";

    var peerSelect = document.getElementById("P40_PEER");
    var callButton = document.getElementById("CALL_USER");
    var acceptButton = document.getElementById("ACCEPT_CALL");
    var declineButton = document.getElementById("DECLINE_CALL");
    var muteButton = document.getElementById("TOGGLE_MUTE");
    var cameraButton = document.getElementById("TOGGLE_CAMERA");
    var hangupButton = document.getElementById("HANG_UP");
    var auditModeSelect = document.getElementById("P40_AUDIT_MODE");
    var localVideo = document.getElementById("webrtc-local-video");
    var remoteVideo = document.getElementById("webrtc-remote-video");
    var statusBadge = document.getElementById("webrtc-status");
    var statusText = document.getElementById("webrtc-status-text");
    var mediaHelp = document.getElementById("webrtc-media-help");
    var mediaHelpText = document.getElementById("webrtc-media-help-text");
    var mediaRetryButton = document.getElementById("webrtc-media-retry");
    var appRefreshButton = document.getElementById("webrtc-app-refresh");
    var managePermissionButton = document.getElementById("webrtc-manage-permissions");
    var microphonePermissionButton = document.getElementById("webrtc-request-microphone");
    var cameraPermissionButton = document.getElementById("webrtc-request-camera");
    var permissionManagerMessage = document.getElementById("webrtc-permission-message");
    var peerLabel = document.getElementById("webrtc-peer-label");
    var incomingPanel = document.getElementById("webrtc-incoming");
    var incomingText = document.getElementById("webrtc-incoming-text");
    var ownIdentity = document.getElementById("webrtc-own-identity");
    var emptyRemote = document.getElementById("webrtc-remote-empty");
    var emptyLocal = document.getElementById("webrtc-local-empty");
    var authRequired = document.getElementById("webrtc-auth-required");
    var loginLink = document.getElementById("webrtc-login-link");
    var demoHelper = document.getElementById("webrtc-demo-helper");
    var demoPeerLink = document.getElementById("webrtc-demo-peer-link");
    var demoPeerLabel = document.getElementById("webrtc-demo-peer-label");
    var pushButton = document.getElementById("ENABLE_PUSH_ALERTS");
    var pushStatus = document.getElementById("webrtc-push-status");
    var pushSlot = document.getElementById("webrtc-push-button-slot");
    var pushProfileVersion = "20260722.2";

    var directLoopbackApex = ["127.0.0.1", "localhost"].indexOf(window.location.hostname) >= 0 && window.location.port === "8183";
    var signalUrl = directLoopbackApex
      ? bootstrap.dataset.signalUrl
      : (window.location.protocol === "https:" ? "wss://" : "ws://") + window.location.host + "/webrtc/ws";
    var loginUrl = directLoopbackApex ? bootstrap.dataset.loginUrl : window.location.origin + "/sas-portal";
    var demoMakerUrl = directLoopbackApex ? bootstrap.dataset.demoMakerUrl : window.location.origin + "/sas-portal/launch/officer";
    var demoCheckerUrl = directLoopbackApex ? bootstrap.dataset.demoCheckerUrl : window.location.origin + "/sas-portal/launch/checker";

    var socket = null;
    var reconnectTimer = null;
    var pingTimer = null;
    var localStream = null;
    var localMediaPromise = null;
    var peerConnection = null;
    var pendingCandidates = [];
    var iceServers = [];
    var ownUserId = "";
    var ownRoleCode = "";
    var presenceUsers = [];
    var knownUsers = [];
    var currentCall = null;
    var intentionalClose = false;
    var ticketRefreshInFlight = false;
    var reconnectAttempts = 0;
    var ringContext = null;
    var ringTimer = null;
    var ringActive = false;
    var ringNodes = [];
    var wakeLock = null;
    var originalTitle = document.title;
    var unansweredTimer = null;
    var incomingAvatar = null;
    var incomingMeta = null;

    try {
      knownUsers = JSON.parse(global.localStorage.getItem("sas-webrtc-known-users") || "[]");
      if (!Array.isArray(knownUsers)) { knownUsers = []; }
    } catch (ignore) { knownUsers = []; }

    function rememberUsers(users) {
      var byUser = {};
      knownUsers.concat(users || []).forEach(function (user) {
        if (user && user.user_id) { byUser[user.user_id] = user; }
      });
      knownUsers = Object.keys(byUser).map(function (key) { return byUser[key]; });
      try { global.localStorage.setItem("sas-webrtc-known-users", JSON.stringify(knownUsers)); } catch (ignore) {}
    }

    function setPushButtonLabel(label) {
      if (!pushButton) { return; }
      var labelNode = pushButton.querySelector(".t-Button-label");
      if (labelNode) { labelNode.textContent = label; } else { pushButton.textContent = label; }
    }

    function encodeApplicationServerKey(key) {
      if (!key) { return ""; }
      var bytes = new Uint8Array(key);
      var binary = "";
      bytes.forEach(function (value) { binary += String.fromCharCode(value); });
      return global.btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
    }

    async function browserPushKeyMatches() {
      if (!navigator.serviceWorker || !global.apex.pwa.publicKey) { return true; }
      var registration = await navigator.serviceWorker.ready;
      var subscription = await registration.pushManager.getSubscription();
      if (!subscription) { return false; }
      return encodeApplicationServerKey(subscription.options.applicationServerKey) === global.apex.pwa.publicKey;
    }

    async function refreshPushState() {
      if (!pushButton || !pushStatus) { return; }
      if (!global.apex || !global.apex.pwa || !global.apex.pwa.hasPushSubscription) {
        pushButton.hidden = true;
        pushStatus.textContent = "Push notifications are not supported by this browser.";
        return;
      }
      try {
        var subscribed = await global.apex.pwa.hasPushSubscription();
        var keyMatches = !subscribed || await browserPushKeyMatches();
        var profileMatches = false;
        try { profileMatches = global.localStorage.getItem("sas-webrtc-push-profile") === pushProfileVersion; } catch (ignore) {}
        var current = subscribed && keyMatches && profileMatches;
        pushButton.dataset.subscribed = current ? "true" : (subscribed ? "stale" : "false");
        pushButton.disabled = false;
        setPushButtonLabel(current ? "Disable Call Alerts" : (subscribed ? "Repair Call Alerts" : "Enable Call Alerts"));
        pushStatus.textContent = current
          ? "Enabled on this device. Closed-app calls will use a system notification."
          : (subscribed
            ? "The PWA notification configuration changed. Repair alerts once on this device."
            : "Enable alerts so calls can notify this device when the PWA is closed.");
      } catch (error) {
        pushButton.disabled = false;
        pushStatus.textContent = "Call alerts are unavailable: " + (error.message || "subscription check failed");
      }
    }

    async function togglePushAlerts(event) {
      event.preventDefault();
      pushButton.disabled = true;
      pushStatus.textContent = "Updating call alerts...";
      try {
        if (pushButton.dataset.subscribed === "true") {
          await global.apex.pwa.unsubscribePushNotifications();
          try { global.localStorage.removeItem("sas-webrtc-push-profile"); } catch (ignore) {}
        } else if (pushButton.dataset.subscribed === "stale") {
          await global.apex.pwa.unsubscribePushNotifications();
          await global.apex.pwa.subscribePushNotifications();
          try { global.localStorage.setItem("sas-webrtc-push-profile", pushProfileVersion); } catch (ignore) {}
        } else {
          await global.apex.pwa.subscribePushNotifications();
          try { global.localStorage.setItem("sas-webrtc-push-profile", pushProfileVersion); } catch (ignore) {}
        }
        await refreshPushState();
      } catch (error) {
        pushButton.disabled = false;
        pushStatus.textContent = "Permission was not enabled. Install the PWA and allow notifications in phone settings.";
      }
    }

    function preparePushControls() {
      if (!pushButton || !pushSlot) { return; }
      pushSlot.appendChild(pushButton);
      pushButton.disabled = true;
      pushButton.addEventListener("click", togglePushAlerts);
      refreshPushState();
    }
    function setControlPresentation(button, label, iconClass, off) {
      if (!button) { return; }
      var icon = button.querySelector(".t-Icon");
      if (!icon) {
        icon = document.createElement("span");
        icon.className = "t-Icon";
        icon.setAttribute("aria-hidden", "true");
        button.replaceChildren(icon);
      }
      icon.className = "t-Icon " + iconClass;
      button.setAttribute("aria-label", label);
      button.title = label;
      button.classList.toggle("is-off", Boolean(off));
      var item = button.closest(".webrtc-control-item");
      var labelNode = item && item.querySelector(".webrtc-control-label");
      if (labelNode) { labelNode.textContent = label; }
    }
    function moveFieldToSlot(item, slotId) {
      var slot = document.getElementById(slotId);
      if (!item || !slot) { return; }
      var container = item.closest(".t-Form-fieldContainer") || item.parentElement;
      slot.appendChild(container);
    }
    function mobileControl(button, label, iconClass, tone) {
      if (!button) { return; }
      var host = document.getElementById("webrtc-control-actions");
      var item = document.createElement("div");
      item.className = "webrtc-control-item webrtc-control-item--" + tone;
      var labelNode = document.createElement("span");
      labelNode.className = "webrtc-control-label"; labelNode.textContent = label;
      button.classList.add("webrtc-control-circle");
      item.appendChild(button); item.appendChild(labelNode); host.appendChild(item);
      setControlPresentation(button, label, iconClass, false);
    }
    function prepareMobileControls() {
      moveFieldToSlot(peerSelect, "webrtc-participant-slot");
      moveFieldToSlot(auditModeSelect, "webrtc-mode-slot");
      moveFieldToSlot(document.getElementById("P40_AUDIT_LANGUAGE"), "webrtc-language-slot");
      moveFieldToSlot(document.getElementById("P40_AVATAR_VOICE"), "webrtc-voice-slot");
      mobileControl(callButton, "Call", "fa fa-phone", "call");
      mobileControl(muteButton, "Mute", "fa fa-microphone", "mute");
      mobileControl(cameraButton, "Camera Off", "fa fa-video-camera", "camera");
      mobileControl(hangupButton, "Hang Up", "fa fa-phone-slash", "hangup");
    }
    function prepareExpandableVideoWidgets() {
      var expandedCard = null;
      function restore(card) {
        if (!card) { return; }
        card.classList.remove("is-expanded");
        var button = card.querySelector(".webrtc-video-expand");
        if (button) {
          var videoLabel = button.dataset.videoLabel || "video";
          button.setAttribute("aria-expanded", "false");
          button.setAttribute("aria-label", "Expand " + videoLabel);
          button.title = "Expand " + videoLabel;
          button.innerHTML = '<span class="fa fa-expand" aria-hidden="true"></span>';
        }
        if (expandedCard === card) { expandedCard = null; }
        document.body.classList.toggle("webrtc-has-expanded-video", Boolean(expandedCard));
      }
      [
        {video:remoteVideo, label:"Remote video"},
        {video:localVideo, label:"My video"}
      ].forEach(function (definition) {
        var card = definition.video && definition.video.closest(".webrtc-video-card");
        if (!card || card.querySelector(".webrtc-video-expand")) { return; }
        var button = document.createElement("button");
        button.type = "button";
        button.className = "webrtc-video-expand";
        button.dataset.videoLabel = definition.label;
        button.setAttribute("aria-expanded", "false");
        button.setAttribute("aria-label", "Expand " + definition.label);
        button.title = "Expand " + definition.label;
        button.innerHTML = '<span class="fa fa-expand" aria-hidden="true"></span>';
        button.addEventListener("click", function () {
          if (card.classList.contains("is-expanded")) {
            restore(card);
            return;
          }
          restore(expandedCard);
          expandedCard = card;
          card.classList.add("is-expanded");
          document.body.classList.add("webrtc-has-expanded-video");
          button.setAttribute("aria-expanded", "true");
          button.setAttribute("aria-label", "Restore " + definition.label);
          button.title = "Restore " + definition.label;
          button.innerHTML = '<span class="fa fa-compress" aria-hidden="true"></span>';
        });
        card.appendChild(button);
      });
      document.addEventListener("keydown", function (event) {
        if (event.key === "Escape" && expandedCard) { restore(expandedCard); }
      });
    }

    function videoAuditSelected() {
      return Boolean(auditModeSelect && auditModeSelect.value === "VIDEO");
    }

    function updateAuditModePresentation() {
      var shell = bootstrap.closest(".webrtc-shell");
      var avatarOnly = !videoAuditSelected();
      if (shell) { shell.classList.toggle("is-avatar-only", avatarOnly); }
      if (!localStream) {
        var localMessage = emptyLocal && emptyLocal.querySelector("p");
        if (localMessage) {
          localMessage.textContent = avatarOnly
            ? "Avatar audit selected. Camera remains off."
            : "Your Support Call evidence preview appears when calling.";
        }
      }
      setControlPresentation(
        cameraButton,
        avatarOnly ? "Video Disabled" : "Camera Off",
        "fa fa-video-camera",
        avatarOnly
      );
      setButtonState();
    }

    function callerInitials(name) {
      var parts = String(name || "Caller").trim().split(/\s+/).filter(Boolean);
      return parts.slice(0, 2).map(function (part) { return part.charAt(0).toUpperCase(); }).join("") || "C";
    }

    function prepareIncomingDialog() {
      incomingPanel.setAttribute("role", "alertdialog");
      incomingPanel.setAttribute("aria-modal", "true");
      incomingPanel.setAttribute("aria-labelledby", "webrtc-incoming-text");
      incomingPanel.classList.add("webrtc-incoming--phone");
      incomingAvatar = document.createElement("div");
      incomingAvatar.className = "webrtc-caller-avatar";
      incomingAvatar.setAttribute("aria-hidden", "true");
      incomingAvatar.textContent = "C";
      incomingPanel.insertBefore(incomingAvatar, incomingPanel.firstChild);
      var heading = incomingPanel.querySelector("strong");
      heading.className = "webrtc-incoming-kicker";
      heading.textContent = "Incoming audit call";
      incomingText.className = "webrtc-incoming-name";
      incomingMeta = document.createElement("div");
      incomingMeta.className = "webrtc-incoming-meta";
      incomingText.insertAdjacentElement("afterend", incomingMeta);
      var actions = document.createElement("div");
      actions.className = "webrtc-incoming-actions";
      actions.appendChild(declineButton);
      actions.appendChild(acceptButton);
      incomingPanel.appendChild(actions);
      var style = document.createElement("style");
      style.textContent = ".webrtc-incoming--phone:not([hidden]){position:fixed;z-index:10000;inset:0;display:flex;flex-direction:column;align-items:center;min-height:100vh;min-height:100dvh;padding:max(3rem,env(safe-area-inset-top)) 1.5rem max(2.25rem,env(safe-area-inset-bottom));border:0;border-radius:0;background:radial-gradient(circle at 50% 28%,#315879 0,#18364f 33%,#0a1c2d 72%,#06121e 100%);color:#fff;text-align:center;box-shadow:none}.webrtc-incoming-kicker{order:0;margin:0 0 2.6rem;color:#d5e6f4!important;font-size:.9rem!important;font-weight:700!important;letter-spacing:.13em;text-transform:uppercase}.webrtc-caller-avatar{order:1;position:relative;display:grid;place-items:center;width:clamp(7.5rem,28vw,10rem);height:clamp(7.5rem,28vw,10rem);margin-bottom:2rem;border:3px solid rgba(255,255,255,.72);border-radius:50%;background:linear-gradient(145deg,#6ca4ce,#244d70);box-shadow:0 18px 54px rgba(0,0,0,.35);color:#fff;font-size:clamp(2.6rem,9vw,4rem);font-weight:800}.webrtc-caller-avatar:before,.webrtc-caller-avatar:after{content:'';position:absolute;inset:-12px;border:2px solid rgba(113,194,255,.5);border-radius:50%;animation:webrtcCallerWave 1.8s ease-out infinite}.webrtc-caller-avatar:after{animation-delay:.7s}.webrtc-incoming-name{order:2;display:block!important;margin:0!important;color:#fff;font-size:clamp(1.7rem,6vw,2.5rem);font-weight:800;line-height:1.15}.webrtc-incoming-meta{order:3;margin-top:.75rem;color:#bcd1e1;font-size:1rem}.webrtc-incoming-actions{order:4;display:flex;justify-content:center;align-items:flex-start;gap:clamp(2.6rem,16vw,7rem);width:100%;margin-top:auto;padding-top:3rem}.webrtc-incoming-actions .t-Button{display:inline-flex!important;flex-direction:column;align-items:center;justify-content:center;width:5.6rem;height:5.6rem;min-width:5.6rem;padding:0;border:0!important;border-radius:50%!important;box-shadow:0 12px 28px rgba(0,0,0,.32);font-size:0!important}.webrtc-incoming-actions .t-Button .t-Icon{margin:0!important;font-size:2rem!important}.webrtc-incoming-actions .t-Button:after{position:absolute;top:calc(100% + .75rem);left:50%;transform:translateX(-50%);color:#fff;font-size:.9rem;font-weight:700;white-space:nowrap}.webrtc-incoming-actions #DECLINE_CALL{position:relative;background:#e13d48!important}.webrtc-incoming-actions #DECLINE_CALL:after{content:'Decline'}.webrtc-incoming-actions #ACCEPT_CALL{position:relative;background:#24a35a!important}.webrtc-incoming-actions #ACCEPT_CALL:after{content:'Accept'}.webrtc-incoming-actions .t-Button:focus{outline:4px solid rgba(255,255,255,.75);outline-offset:5px}@keyframes webrtcCallerWave{0%{opacity:.8;transform:scale(.94)}100%{opacity:0;transform:scale(1.28)}}@media(min-width:700px){.webrtc-incoming--phone:not([hidden]){left:50%;top:50%;right:auto;bottom:auto;width:min(31rem,92vw);height:min(44rem,90vh);min-height:0;transform:translate(-50%,-50%);padding:3rem 2rem;border-radius:30px;box-shadow:0 30px 100px rgba(0,0,0,.5)}.webrtc-incoming--phone:not([hidden]):before{content:'';position:fixed;z-index:-1;inset:-100vh -100vw;background:rgba(2,12,21,.68);backdrop-filter:blur(5px)}}";
      document.head.appendChild(style);
    }

    function audioContext() {
      if (!ringContext) {
        var AudioContext = global.AudioContext || global.webkitAudioContext;
        if (AudioContext) { ringContext = new AudioContext(); }
      }
      return ringContext;
    }

    function unlockRingAudio() {
      var context = audioContext();
      if (context && context.state === "suspended") {
        context.resume().catch(function () {});
      }
    }

    function ringPulse() {
      if (!ringActive) { return; }
      var context = audioContext();
      if (!context || context.state !== "running") { return; }
      [0, 0.95].forEach(function (offset) {
        [440, 480].forEach(function (frequency) {
          var oscillator = context.createOscillator();
          var gain = context.createGain();
          oscillator.type = "sine";
          oscillator.frequency.setValueAtTime(frequency, context.currentTime + offset);
          gain.gain.setValueAtTime(0.0001, context.currentTime + offset);
          gain.gain.exponentialRampToValueAtTime(0.07, context.currentTime + offset + 0.06);
          gain.gain.setValueAtTime(0.07, context.currentTime + offset + 0.55);
          gain.gain.exponentialRampToValueAtTime(0.0001, context.currentTime + offset + 0.72);
          oscillator.connect(gain);
          gain.connect(context.destination);
          ringNodes.push(oscillator);
          oscillator.onended = function () {
            ringNodes = ringNodes.filter(function (node) { return node !== oscillator; });
          };
          oscillator.start(context.currentTime + offset);
          oscillator.stop(context.currentTime + offset + 0.74);
        });
      });
    }

    function startIncomingRing(callerName) {
      stopIncomingRing();
      ringActive = true;
      document.title = "Incoming call - " + callerName;
      unlockRingAudio();
      ringPulse();
      ringTimer = global.setInterval(ringPulse, 3200);
      if (navigator.vibrate) { navigator.vibrate([450, 250, 450, 1800]); }
    }

    function stopIncomingRing() {
      ringActive = false;
      global.clearInterval(ringTimer);
      ringTimer = null;
      ringNodes.forEach(function (oscillator) {
        try { oscillator.onended = null; oscillator.stop(); } catch (ignore) {}
      });
      ringNodes = [];
      document.title = originalTitle;
      if (navigator.vibrate) { navigator.vibrate(0); }
    }

    async function requestWakeLock() {
      if (!navigator.wakeLock || document.visibilityState !== "visible" || wakeLock) { return; }
      try {
        wakeLock = await navigator.wakeLock.request("screen");
        wakeLock.addEventListener("release", function () { wakeLock = null; }, {once: true});
      } catch (ignore) {}
    }

    function dispatchCallState(connected) {
      document.dispatchEvent(new CustomEvent("sas:call-state", {detail: {
        connected: Boolean(connected),
        callId: currentCall ? currentCall.callId : "",
        peer: currentCall ? currentCall.peer : "",
        caller: currentCall ? currentCall.caller : false
      }}));
    }

    global.SASWebRTCCall.sendAudit = function (payload) {
      if (!currentCall || !currentCall.callId) { return false; }
      payload.call_id = currentCall.callId;
      return send(payload);
    };
    global.SASWebRTCCall.getContext = function () {
      return currentCall ? {
        callId: currentCall.callId,
        peer: currentCall.peer,
        caller: currentCall.caller,
        connected: Boolean(currentCall.accepted || (peerConnection && peerConnection.connectionState === "connected"))
      } : null;
    };
    global.SASWebRTCCall.getAudioStream = function () {
      if (!localStream) { return null; }
      var audioTracks = localStream.getAudioTracks();
      return audioTracks.length ? new MediaStream(audioTracks) : null;
    };
    global.SASWebRTCCall.getMediaStream = function () {
      return localStream && localStream.active ? localStream : null;
    };
    global.SASWebRTCCall.getRemoteMediaStream = function () {
      var stream = remoteVideo.srcObject;
      return stream && stream.active ? stream : null;
    };

    function setStatus(label, detail, state) {
      statusBadge.textContent = label;
      statusBadge.className = "webrtc-status webrtc-status--" + state;
      statusText.textContent = detail;
    }

    function mediaErrorDetail(error) {
      var name = String(error && error.name || "");
      if (!global.isSecureContext) {
        return "Microphone access requires a trusted HTTPS connection. Install and trust the SAS local certificate, then reopen the app.";
      }
      if (name === "PermissionTimeoutError") {
        return error.message || "The phone did not answer the permission request. Open Manage Permissions and test the device.";
      }
      if (name === "NotAllowedError" || name === "SecurityError") {
        return videoAuditSelected()
          ? "Camera or microphone access is blocked on this phone. Allow both permissions for this website/PWA, then retry."
          : "Microphone access is blocked on this phone. Allow Microphone for this website/PWA, then select Enable Microphone & Retry.";
      }
      if (name === "NotFoundError" || name === "DevicesNotFoundError") {
        return "No available microphone was found on this device.";
      }
      if (name === "NotReadableError" || name === "TrackStartError") {
        return "The microphone is being used by another app. Close the other call or recording app, then retry.";
      }
      return "The phone could not start call audio. Check microphone permission and retry.";
    }

    function hideMediaHelp() {
      if (mediaHelp) { mediaHelp.hidden = true; }
    }

    function showMediaHelp(error, retryAction) {
      var detail = mediaErrorDetail(error);
      var needsVideo = videoAuditSelected();
      setStatus(needsVideo ? "CAMERA BLOCKED" : "MICROPHONE BLOCKED", detail, "danger");
      if (!mediaHelp) { return; }
      mediaHelp.hidden = false;
      var heading = mediaHelp.querySelector("strong");
      if (heading) { heading.textContent = needsVideo ? "Camera and microphone permission required" : "Microphone permission is required"; }
      mediaHelpText.textContent = detail;
      mediaRetryButton.onclick = async function () {
        mediaRetryButton.disabled = true;
        mediaRetryButton.innerHTML = '<span class="fa fa-spinner fa-spin" aria-hidden="true"></span> Requesting access';
        try {
          if (retryAction) {
            await retryAction();
          } else {
            await ensureLocalMedia();
            stopLocalMedia();
            setStatus("MICROPHONE READY", "Permission is enabled. Ask the auditor to call again.", "ready");
          }
          hideMediaHelp();
        } catch (retryError) {
          showMediaHelp(retryError, retryAction);
        } finally {
          mediaRetryButton.disabled = false;
          mediaRetryButton.innerHTML = '<span class="fa fa-microphone" aria-hidden="true"></span> Enable Microphone & Retry';
        }
      };
    }

    async function refreshInstalledApp() {
      appRefreshButton.disabled = true;
      appRefreshButton.textContent = "Updating…";
      try {
        if (navigator.serviceWorker) {
          var registrations = await navigator.serviceWorker.getRegistrations();
          await Promise.all(registrations.map(function (registration) { return registration.update(); }));
        }
      } catch (ignore) {}
      global.location.reload();
    }

    function setPermissionIndicator(kind, state, text) {
      var node = document.getElementById("webrtc-" + kind + "-permission");
      if (!node) { return; }
      node.className = "webrtc-permission-state is-" + state;
      node.textContent = text || state;
    }

    async function browserPermissionState(kind) {
      if (!global.isSecureContext) { return "insecure"; }
      if (!navigator.permissions || !navigator.permissions.query) { return "unknown"; }
      try {
        var result = await navigator.permissions.query({name: kind});
        return result.state || "unknown";
      } catch (ignore) {
        return "unknown";
      }
    }

    async function refreshPermissionManager() {
      var secureState = global.isSecureContext ? "granted" : "insecure";
      setPermissionIndicator("secure", secureState, global.isSecureContext ? "Trusted HTTPS" : "Certificate not trusted");
      var states = await Promise.all([
        browserPermissionState("microphone"),
        browserPermissionState("camera")
      ]);
      setPermissionIndicator(
        "microphone",
        states[0],
        states[0] === "granted" ? "Allowed" : states[0] === "denied" ? "Blocked" : "Tap to test"
      );
      setPermissionIndicator(
        "camera",
        states[1],
        states[1] === "granted" ? "Allowed" : states[1] === "denied" ? "Blocked" : "Tap to test"
      );
      var busy = Boolean(currentCall);
      if (microphonePermissionButton) { microphonePermissionButton.disabled = busy; }
      if (cameraPermissionButton) { cameraPermissionButton.disabled = busy; }
      if (permissionManagerMessage) {
        permissionManagerMessage.textContent = busy
          ? "End the active call before testing or changing device permissions."
          : "Permission prompts appear only after you select a test button.";
      }
    }

    async function requestDevicePermission(kind, button) {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setPermissionIndicator(kind, "denied", "Unavailable");
        permissionManagerMessage.textContent = "A trusted HTTPS connection is required for device permissions.";
        return;
      }
      button.disabled = true;
      var original = button.innerHTML;
      button.innerHTML = '<span class="fa fa-spinner fa-spin" aria-hidden="true"></span> Testing';
      setPermissionIndicator(kind, "prompt", "Requesting…");
      try {
        var stream = await timedMediaRequest({
          audio: kind === "microphone" ? {echoCancellation:true, noiseSuppression:true} : false,
          video: kind === "camera" ? {facingMode:"user", width:{ideal:640}, height:{ideal:480}} : false
        }, 15000, "The phone did not answer the " + kind + " permission request.");
        stream.getTracks().forEach(function (track) { track.stop(); });
        setPermissionIndicator(kind, "granted", "Allowed");
        permissionManagerMessage.textContent = (kind === "microphone" ? "Microphone" : "Camera")
          + " access is working on this device.";
        if (kind === "microphone") { hideMediaHelp(); }
      } catch (error) {
        setPermissionIndicator(kind, "denied", "Blocked");
        permissionManagerMessage.textContent = mediaErrorDetail(error);
      } finally {
        button.disabled = Boolean(currentCall);
        button.innerHTML = original;
      }
    }

    function openPermissionManager() {
      refreshPermissionManager();
      if (global.apex && global.apex.theme) {
        global.apex.theme.openRegion("webrtc-permission-drawer");
      }
    }

    function setButtonState() {
      var connected = socket && socket.readyState === WebSocket.OPEN && ownUserId;
      var selectable = peerSelect && peerSelect.value && peerSelect.value !== ownUserId;
      callButton.disabled = !connected || !selectable || Boolean(currentCall);
      peerSelect.disabled = !connected || Boolean(currentCall);
      if (auditModeSelect) {
        auditModeSelect.disabled = Boolean(currentCall) || ownRoleCode.indexOf("CHECKER") >= 0;
      }
      hangupButton.disabled = !currentCall;
      muteButton.disabled = !localStream;
      cameraButton.disabled = !localStream || localStream.getVideoTracks().length === 0;
    }

    function showIncoming(show) {
      if (!show) { stopIncomingRing(); }
      incomingPanel.hidden = !show;
      acceptButton.classList.toggle("is-hidden", !show);
      declineButton.classList.toggle("is-hidden", !show);
      if (show) {
        global.setTimeout(function () { acceptButton.focus(); }, 50);
      }
    }

    function send(payload) {
      if (!socket || socket.readyState !== WebSocket.OPEN) {
        setStatus("OFFLINE", "Signaling is not connected.", "danger");
        return false;
      }
      socket.send(JSON.stringify(payload));
      return true;
    }

    function timedMediaRequest(constraints, timeoutMs, timeoutMessage) {
      return new Promise(function (resolve, reject) {
        var finished = false;
        var timer = global.setTimeout(function () {
          if (finished) { return; }
          finished = true;
          var error = new Error(timeoutMessage);
          error.name = "PermissionTimeoutError";
          reject(error);
        }, timeoutMs);
        navigator.mediaDevices.getUserMedia(constraints).then(function (stream) {
          if (finished) {
            stream.getTracks().forEach(function (track) { track.stop(); });
            return;
          }
          finished = true;
          global.clearTimeout(timer);
          resolve(stream);
        }).catch(function (error) {
          if (finished) { return; }
          finished = true;
          global.clearTimeout(timer);
          reject(error);
        });
      });
    }

    function renderPresence() {
      var selected = peerSelect.value;
      peerSelect.innerHTML = "";
      var placeholder = document.createElement("option");
      placeholder.value = "";
      placeholder.textContent = "-- Select a call participant --";
      peerSelect.appendChild(placeholder);
      rememberUsers(presenceUsers);
      var liveIds = {};
      presenceUsers.forEach(function (user) { liveIds[user.user_id] = true; });
      var candidates = {};
      knownUsers.concat(presenceUsers).forEach(function (user) {
        if (user && user.user_id && user.user_id !== ownUserId) { candidates[user.user_id] = user; }
      });
      Object.keys(candidates).sort(function (left, right) {
        if (Boolean(liveIds[left]) !== Boolean(liveIds[right])) { return liveIds[left] ? -1 : 1; }
        return String(candidates[left].display_name || left).localeCompare(String(candidates[right].display_name || right));
      }).forEach(function (userId) {
        var user = candidates[userId];
        var option = document.createElement("option");
        option.value = user.user_id;
        option.textContent = (user.display_name || "User " + user.user_id) + " · " + (user.role_code || "SAS") + " (" + user.user_id + ")" + (liveIds[user.user_id] ? " · Online" : " · Offline alert");
        peerSelect.appendChild(option);
      });
      if ([].some.call(peerSelect.options, function (option) { return option.value === selected; })) {
        peerSelect.value = selected;
      }
      var onlineCount = Math.max(0, presenceUsers.length - (ownUserId ? 1 : 0));
      document.getElementById("webrtc-online-count").textContent = String(onlineCount);
      if (ownUserId && !currentCall && onlineCount === 0) {
        var makerSignedIn = ownUserId === "112769";
        var peerUrl = makerSignedIn ? demoCheckerUrl : demoMakerUrl;
        if (peerUrl) {
          demoPeerLink.href = peerUrl;
          demoPeerLabel.textContent = makerSignedIn ? "Open Checker test user" : "Open Maker test user";
          demoHelper.hidden = false;
        }
        if (peerSelect.options.length > 1) {
          setStatus("READY", "Select an offline participant to send a call alert.", "ready");
        } else {
          setStatus("WAITING", "No participant is available yet. Open the other test user once to add it to this device.", "warning");
        }
      } else {
        demoHelper.hidden = true;
        if (ownUserId && !currentCall) {
          setStatus("READY", "Select a participant to start a call.", "ready");
        }
      }
      setButtonState();
    }

    async function ensureLocalMedia() {
      if (localStream) { return localStream; }
      if (localMediaPromise) { return localMediaPromise; }
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("Camera and microphone require HTTPS or localhost in a supported browser.");
      }
      localMediaPromise = (async function () {
        var useVideo = videoAuditSelected();
        setStatus(
          "MEDIA",
          useVideo ? "Starting camera and microphone…" : "Starting microphone access…",
          "ready"
        );
        localStream = await timedMediaRequest(
          {
            audio:{echoCancellation:true, noiseSuppression:true},
            video:useVideo ? {width:{ideal:1280}, height:{ideal:720}, facingMode:"user"} : false
          },
          15000,
          useVideo
            ? "The phone did not answer the camera and microphone permission request. Use Manage Permissions and retry."
            : "The phone did not respond to the microphone permission request. Use Manage Permissions and retry."
        );
        hideMediaHelp();
        var hasVideo = localStream.getVideoTracks().length > 0;
        if (useVideo && !hasVideo) {
          localStream.getTracks().forEach(function (track) { track.stop(); });
          localStream = null;
          var cameraError = new Error("Support Call evidence requires camera permission. Open Manage Permissions and enable the camera.");
          cameraError.name = "NotAllowedError";
          throw cameraError;
        }
        localVideo.srcObject = localStream;
        emptyLocal.hidden = hasVideo;
        if (hasVideo) { await localVideo.play().catch(function () {}); }
        setPermissionIndicator("microphone", "granted", "Allowed");
        if (hasVideo) { setPermissionIndicator("camera", "granted", "Allowed"); }
        setControlPresentation(muteButton, "Mute", "fa fa-microphone", false);
        setControlPresentation(
          cameraButton,
          hasVideo ? "Camera Off" : "Video Disabled",
          "fa fa-video-camera",
          !hasVideo
        );
        setButtonState();
        return localStream;
      }());
      try {
        return await localMediaPromise;
      } finally {
        localMediaPromise = null;
      }
    }

    async function createPeerConnection() {
      if (peerConnection) { return peerConnection; }
      peerConnection = new RTCPeerConnection({iceServers: iceServers});
      (localStream ? localStream.getTracks() : []).forEach(function (track) {
        peerConnection.addTrack(track, localStream);
      });
      peerConnection.onicecandidate = function (event) {
        if (currentCall) {
          send({type: "ice_candidate", call_id: currentCall.callId, candidate: event.candidate ? event.candidate.toJSON() : null});
        }
      };
      peerConnection.ontrack = function (event) {
        remoteVideo.srcObject = event.streams[0];
        var hasRemoteVideo = event.streams[0].getVideoTracks().length > 0;
        emptyRemote.hidden = hasRemoteVideo;
        remoteVideo.hidden = !hasRemoteVideo;
        remoteVideo.play().catch(function () {});
      };
      peerConnection.onconnectionstatechange = function () {
        if (!peerConnection) { return; }
        var state = peerConnection.connectionState;
        if (state === "connected") {
          setStatus("CONNECTED", "Encrypted peer media is active.", "success");
          dispatchCallState(true);
        } else if (state === "connecting") {
          setStatus("CONNECTING", "Negotiating the media path...", "warning");
        } else if (state === "failed") {
          setStatus("FAILED", "The media path failed. End the call and try again.", "danger");
        } else if (state === "disconnected") {
          setStatus("INTERRUPTED", "The peer connection was interrupted.", "warning");
        }
      };
      return peerConnection;
    }

    async function addPendingCandidates() {
      if (!peerConnection || !peerConnection.remoteDescription) { return; }
      while (pendingCandidates.length) {
        var candidate = pendingCandidates.shift();
        if (candidate) { await peerConnection.addIceCandidate(candidate); }
      }
    }

    function stopLocalMedia() {
      if (localStream) {
        localStream.getTracks().forEach(function (track) { track.stop(); });
      }
      localStream = null;
      localMediaPromise = null;
      localVideo.srcObject = null;
      emptyLocal.hidden = false;
      setControlPresentation(muteButton, "Mute", "fa fa-microphone", false);
      updateAuditModePresentation();
    }

    function resetCall(options) {
      options = options || {};
      stopIncomingRing();
      global.clearTimeout(unansweredTimer);
      unansweredTimer = null;
      if (peerConnection) {
        peerConnection.onicecandidate = null;
        peerConnection.ontrack = null;
        peerConnection.onconnectionstatechange = null;
        peerConnection.close();
      }
      peerConnection = null;
      pendingCandidates = [];
      remoteVideo.srcObject = null;
      emptyRemote.hidden = false;
      if (options.stopMedia !== false) { stopLocalMedia(); }
      currentCall = null;
      peerLabel.textContent = "Waiting for a call";
      showIncoming(false);
      setButtonState();
      dispatchCallState(false);
    }

    async function startCall() {
      var peer = peerSelect.value;
      if (!peer) { return; }
      try {
        await ensureLocalMedia();
        currentCall = {callId: "", peer: peer, caller: true};
        peerLabel.textContent = "Calling " + peer;
        setStatus("CALLING", "Waiting for the participant to answer...", "warning");
        setButtonState();
        send({
          type: "invite",
          to: peer,
          audit_mode: ownRoleCode.indexOf("CHECKER") >= 0 || videoAuditSelected() ? "VIDEO" : "AVATAR_ONLY"
        });
      } catch (error) {
        resetCall();
        showMediaHelp(error, async function () {
          await ensureLocalMedia();
          await startCall();
        });
      }
    }

    async function acceptCall() {
      if (!currentCall || currentCall.caller) { return; }
      stopIncomingRing();
      showIncoming(false);
      try {
        await ensureLocalMedia();
        setStatus("ACCEPTING", "Preparing the secure media connection...", "warning");
        send({type: "accept", call_id: currentCall.callId});
      } catch (error) {
        send({type: "decline", call_id: currentCall.callId});
        resetCall();
        showMediaHelp(error, null);
      }
    }

    function declineCall() {
      if (!currentCall) { return; }
      send({type: "decline", call_id: currentCall.callId});
      resetCall();
      setStatus("DECLINED", "The incoming call was declined.", "ready");
    }

    function hangUp() {
      if (!currentCall) { return; }
      send({type: "hangup", call_id: currentCall.callId});
      resetCall();
      setStatus("ENDED", "Call ended.", "ready");
    }

    function toggleTrack(kind) {
      if (!localStream || !currentCall) { return; }
      var tracks = kind === "audio" ? localStream.getAudioTracks() : localStream.getVideoTracks();
      tracks.forEach(function (track) { track.enabled = !track.enabled; });
      var audioEnabled = localStream.getAudioTracks().some(function (track) { return track.enabled; });
      var videoEnabled = localStream.getVideoTracks().some(function (track) { return track.enabled; });
      setControlPresentation(muteButton, audioEnabled ? "Mute" : "Unmute", audioEnabled ? "fa fa-microphone" : "fa fa-microphone-slash", !audioEnabled);
      setControlPresentation(cameraButton, videoEnabled ? "Camera Off" : "Camera On", "fa fa-video-camera", !videoEnabled);
      send({type: "media_state", call_id: currentCall.callId, audio_enabled: audioEnabled, video_enabled: videoEnabled});
    }

    async function handleMessage(message) {
      if (String(message.type || "").indexOf("audit_") === 0) {
        document.dispatchEvent(new CustomEvent("sas:audit-message", {detail: message}));
      } else if (message.type === "welcome") {
        ownUserId = message.user_id;
        ownRoleCode = String(message.role_code || "").toUpperCase();
        if (auditModeSelect && ownRoleCode.indexOf("CHECKER") >= 0) {
          auditModeSelect.value = "VIDEO";
          updateAuditModePresentation();
        }
        reconnectAttempts = 0;
        iceServers = message.ice_servers || [];
        ownIdentity.textContent = message.display_name + " · " + message.role_code + " (" + message.user_id + ")";
        setStatus("READY", "Select a participant to start a call.", "ready");
        send({type: "availability", foreground: document.visibilityState === "visible"});
        renderPresence();
        requestWakeLock();
      } else if (message.type === "presence") {
        presenceUsers = message.users || [];
        renderPresence();
      } else if (message.type === "call_created") {
        if (!currentCall) { currentCall = {caller: true}; }
        currentCall.callId = message.call_id;
        currentCall.peer = message.peer;
        currentCall.caller = true;
        global.clearTimeout(unansweredTimer);
        unansweredTimer = global.setTimeout(function () {
          if (!currentCall || !currentCall.caller || currentCall.callId !== message.call_id) { return; }
          send({type: "hangup", call_id: currentCall.callId});
          resetCall();
          setStatus("NO ANSWER", "The participant did not answer. Try again when their calling page is open.", "warning");
        }, 45000);
        setButtonState();
      } else if (message.type === "call_notification_sent") {
        setStatus("NOTIFIED", "The participant was notified. Waiting for an answer...", "warning");
      } else if (message.type === "incoming_call") {
        if (currentCall) { return; }
        if (auditModeSelect) {
          auditModeSelect.value = message.audit_mode === "VIDEO" ? "VIDEO" : "AVATAR_ONLY";
          updateAuditModePresentation();
        }
        var incomingHeading = incomingPanel.querySelector(".webrtc-incoming-kicker");
        if (incomingHeading) {
          incomingHeading.textContent = message.audit_mode === "VIDEO"
            ? "Incoming support call"
            : "Incoming avatar audit";
        }
        currentCall = {callId: message.call_id, peer: message.from, caller: false};
        peerLabel.textContent = message.display_name + " · " + message.role_code;
        incomingAvatar.textContent = callerInitials(message.display_name || message.from);
        incomingText.textContent = message.display_name || message.from;
        incomingMeta.textContent = message.role_code + " \u00b7 " + message.from + " \u00b7 "
          + (message.audit_mode === "VIDEO" ? "Support call" : "Avatar audit");
        showIncoming(true);
        setStatus("INCOMING", "Accept or decline the call.", "warning");
        startIncomingRing(message.display_name || message.from);
        setButtonState();
      } else if (message.type === "accepted") {
        if (!currentCall || currentCall.callId !== message.call_id) { return; }
        stopIncomingRing();
        showIncoming(false);
        global.clearTimeout(unansweredTimer);
        unansweredTimer = null;
        currentCall.accepted = true;
        peerLabel.textContent = "In call with " + currentCall.peer;
        dispatchCallState(true);
        if (currentCall.caller) {
          var connection = await createPeerConnection();
          var offer = await connection.createOffer();
          await connection.setLocalDescription(offer);
          send({type: "offer", call_id: currentCall.callId, description: connection.localDescription.toJSON()});
        }
        setStatus("CONNECTING", "Negotiating the media path...", "warning");
      } else if (message.type === "offer") {
        if (!currentCall || currentCall.callId !== message.call_id) { return; }
        var answeringConnection = await createPeerConnection();
        await answeringConnection.setRemoteDescription(message.description);
        await addPendingCandidates();
        var answer = await answeringConnection.createAnswer();
        await answeringConnection.setLocalDescription(answer);
        send({type: "answer", call_id: currentCall.callId, description: answeringConnection.localDescription.toJSON()});
      } else if (message.type === "answer") {
        if (!peerConnection || !currentCall || currentCall.callId !== message.call_id) { return; }
        await peerConnection.setRemoteDescription(message.description);
        await addPendingCandidates();
      } else if (message.type === "ice_candidate") {
        if (!currentCall || currentCall.callId !== message.call_id || !message.candidate) { return; }
        if (peerConnection && peerConnection.remoteDescription) {
          await peerConnection.addIceCandidate(message.candidate);
        } else {
          pendingCandidates.push(message.candidate);
        }
      } else if (message.type === "media_state") {
        var states = [];
        if (!message.audio_enabled) { states.push("peer muted"); }
        if (!message.video_enabled) { states.push("peer camera off"); }
        document.getElementById("webrtc-peer-media-state").textContent = states.join(" · ");
      } else if (message.type === "declined") {
        resetCall();
        setStatus("DECLINED", "The participant declined the call.", "ready");
      } else if (message.type === "ended" || message.type === "peer_disconnected") {
        resetCall();
        setStatus("ENDED", message.type === "peer_disconnected" ? "The participant disconnected." : "Call ended.", "ready");
      } else if (message.type === "session_replaced") {
        intentionalClose = true;
        resetCall();
        setStatus("REPLACED", message.message, "danger");
      } else if (message.type === "error") {
        if (["PEER_OFFLINE", "PEER_BUSY", "CALL_CREATE_FAILED", "CALL_IN_PROGRESS"].indexOf(message.code) >= 0) {
          resetCall();
        }
        setStatus("ERROR", message.message, "danger");
      }
    }

    function scheduleReconnect(delay) {
      if (intentionalClose) { return; }
      clearTimeout(reconnectTimer);
      reconnectTimer = global.setTimeout(refreshTicketAndReconnect, delay);
    }

    function refreshTicketAndReconnect() {
      if (intentionalClose || ticketRefreshInFlight || (socket && (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING))) { return; }
      if (document.visibilityState === "hidden") {
        setStatus("PAUSED", "Return to this page to reconnect for incoming calls.", "warning");
        return;
      }
      if (!global.apex || !global.apex.server || !global.apex.server.process) {
        setStatus("OFFLINE", "Signaling disconnected. Refresh this page to reconnect.", "danger");
        return;
      }
      ticketRefreshInFlight = true;
      setStatus("RECONNECTING", "Restoring the secure mobile connection...", "warning");
      global.apex.server.process("REFRESH_WEBRTC_TICKET", {}, {dataType: "json"})
        .done(function (result) {
          ticketRefreshInFlight = false;
          if (!result || !result.ticket) {
            setStatus("SIGN-IN REQUIRED", "Your calling session expired. Sign in again.", "danger");
            return;
          }
          bootstrap.dataset.ticket = result.ticket;
          connect();
        })
        .fail(function () {
          ticketRefreshInFlight = false;
          reconnectAttempts += 1;
          var retryDelay = Math.min(30000, 1000 * Math.pow(2, Math.min(reconnectAttempts, 5)));
          setStatus("OFFLINE", "Connection lost. Retrying when this page is active...", "danger");
          scheduleReconnect(retryDelay);
        });
    }

    function connect() {
      clearTimeout(reconnectTimer);
      intentionalClose = false;
      setStatus("CONNECTING", "Connecting to the authenticated signaling service...", "warning");
      socket = new WebSocket(signalUrl);
      socket.addEventListener("open", function () {
        send({type: "authenticate", ticket: bootstrap.dataset.ticket});
        clearInterval(pingTimer);
        pingTimer = setInterval(function () { send({type: "ping"}); }, 25000);
      });
      socket.addEventListener("message", function (event) {
        try {
          Promise.resolve(handleMessage(JSON.parse(event.data))).catch(function (error) {
            setStatus("CALL ERROR", error.message, "danger");
          });
        } catch (error) {
          setStatus("SIGNAL ERROR", "Invalid signaling response.", "danger");
        }
      });
      socket.addEventListener("close", function (event) {
        clearInterval(pingTimer);
        socket = null;
        ownUserId = "";
        ownRoleCode = "";
        presenceUsers = [];
        renderPresence();
        resetCall();
        if (!intentionalClose) {
          reconnectAttempts += 1;
          setStatus("RECONNECTING", "Mobile connection interrupted. Reconnecting securely...", "warning");
          scheduleReconnect(Math.min(5000, reconnectAttempts * 750));
        }
      });
      socket.addEventListener("error", function () {
        setStatus("OFFLINE", "The signaling service is unavailable.", "danger");
      });
    }

    peerSelect.addEventListener("change", setButtonState);
    if (auditModeSelect) { auditModeSelect.addEventListener("change", updateAuditModePresentation); }
    if (appRefreshButton) { appRefreshButton.addEventListener("click", refreshInstalledApp); }
    if (managePermissionButton) { managePermissionButton.addEventListener("click", openPermissionManager); }
    if (microphonePermissionButton) {
      microphonePermissionButton.addEventListener("click", function () {
        requestDevicePermission("microphone", microphonePermissionButton);
      });
    }
    if (cameraPermissionButton) {
      cameraPermissionButton.addEventListener("click", function () {
        requestDevicePermission("camera", cameraPermissionButton);
      });
    }
    callButton.addEventListener("click", startCall);
    acceptButton.addEventListener("click", acceptCall);
    declineButton.addEventListener("click", declineCall);
    muteButton.addEventListener("click", function () { toggleTrack("audio"); });
    cameraButton.addEventListener("click", function () { toggleTrack("video"); });
    hangupButton.addEventListener("click", hangUp);
    document.addEventListener("pointerdown", unlockRingAudio, {passive: true});
    document.addEventListener("visibilitychange", function () {
      if (socket && socket.readyState === WebSocket.OPEN) {
        send({type: "availability", foreground: document.visibilityState === "visible"});
      }
      if (document.visibilityState === "visible") {
        unlockRingAudio();
        requestWakeLock();
        if (!socket || socket.readyState === WebSocket.CLOSED) { scheduleReconnect(100); }
      }
    });
    global.addEventListener("online", function () { scheduleReconnect(100); });
    window.addEventListener("beforeunload", function () {
      intentionalClose = true;
      if (socket) { socket.close(); }
      stopLocalMedia();
    });

    prepareMobileControls();
    prepareExpandableVideoWidgets();
    updateAuditModePresentation();
    prepareIncomingDialog();
    preparePushControls();
    showIncoming(false);
    setButtonState();
    if (!bootstrap.dataset.ticket) {
      authRequired.hidden = false;
      if (loginUrl) { loginLink.href = loginUrl; }
      ownIdentity.textContent = "SAS identity not established";
      setStatus("SIGN-IN REQUIRED", "Open the SAS sign-in page, choose Maker or Checker, then return here.", "warning");
      return;
    }
    connect();
  }

  global.SASWebRTCCall = {
    init: init,
    sendAudit: function () { return false; },
    getContext: function () { return null; },
    getAudioStream: function () { return null; },
    getMediaStream: function () { return null; },
    getRemoteMediaStream: function () { return null; }
  };
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init, {once: true});
  } else {
    init();
  }
})(window);
