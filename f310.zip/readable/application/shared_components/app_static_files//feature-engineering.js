(function (apex, document, window) {
  "use strict";

  var studio = {
    entity: "AGENT",
    data: null,
    selectedField: null,
    previewProfile: {},
    previewEntityKey: "",
    previewUpdatedOn: "",
    collapsedPaths: {},
    collapsedJsonCodePaths: {},
    functionDraft: null,
    versionTab: "config",
    nextRunDate: null,
    nextRunIntervalMinutes: 5,
    nextRunTimer: null,
    functionConfigOpen: false,
    functionConfigTab: "parameters"
  };
  var panelIds = {
    profile: ["fe_profile_studio_region"],
    data: ["fe_agent_profiles_region", "fe_customer_profiles_region"],
    bre: ["fe_bre_bridge_region"],
    versions: ["fe_version_subtabs_region", "fe_profile_versions_region",
      "fe_profile_rebuilds_region"]
  };
  var jsonOutputCatalog = {
    UNIQUE_STATS: ["count", "sum", "avg", "min", "max", "var", "std", "last"],
    UNIQUE_METRIC: ["count", "sum", "avg", "min", "max", "var", "std", "last"],
    UNIQUE_METRICS: ["count", "sum", "avg", "min", "max", "var", "std", "last"],
    HOURLY_TRANSACTIONS: [
      "sourceField", "sourceTimezone", "reportingTimezone", "window",
      "totalTransactions", "activeHoursOfDay", "hours"
    ],
    PEAK_HOURS: [
      "sourceField", "sourceTimezone", "reportingTimezone", "window",
      "totalTransactions", "peakHours"
    ],
    CONTINUOUS_ABSENT_DAYS: [
      "sourceField", "sourceTimezone", "reportingTimezone", "window",
      "evaluatedThroughDate", "minimumDailyTransactions",
      "includeWeeklyOffDays", "weeklyOffDays", "firstObservedDate",
      "lastActiveDate", "absenceStartedDate", "currentAbsentDays",
      "maximumAbsentDays", "expectedWorkingDays", "activeWorkingDays",
      "status"
    ],
    UNIQUE_VELOCITY: [
      "window_min", "count", "sum", "avg", "per_min", "start_time", "end_time"
    ],
    UNIQUE_ROLLING: [
      "window_min", "count", "sum", "avg", "per_min", "start_time", "end_time"
    ],
    UNIQUE_WINDOW: [
      "window_min", "count", "sum", "avg", "per_min", "start_time", "end_time"
    ],
    ROLLING_UPDATE: [
      "window_min", "count", "sum", "avg", "per_min", "start_time", "end_time"
    ],
    GEO_VARIANCE: ["variance_km2", "mean_distance_km", "centroid"],
    UNIQUE_GEO: ["variance_km2", "mean_distance_km", "centroid"],
    GEO_ANOMALY: [
      "previous", "current", "distanceKm", "thresholdKm", "isAnomaly"
    ],
    ANOMALY_DETECTION: [
      "count", "sum", "avg", "stddev", "z_score", "abs_z_score",
      "is_outlier", "severity", "flag"
    ],
    ANAMOLY_DETECTION: [
      "count", "sum", "avg", "stddev", "z_score", "abs_z_score",
      "is_outlier", "severity", "flag"
    ],
    ANOMALY_GROUP_AGGREGATE: [
      "count", "sum", "avg", "stddev", "z_score", "abs_z_score",
      "is_outlier", "severity", "flag"
    ],
    ANAMOLY_GROUP_AGGREGATE: [
      "count", "sum", "avg", "stddev", "z_score", "abs_z_score",
      "is_outlier", "severity", "flag"
    ]
  };

  function byId(id) {
    return document.getElementById(id);
  }

  function text(id, value) {
    var node = byId(id);
    if (node) {
      node.textContent = value === null || value === undefined ? "" : String(value);
    }
  }

  function value(id, newValue) {
    var node = byId(id);
    if (!node) {
      return "";
    }
    if (arguments.length > 1) {
      node.value = newValue === null || newValue === undefined ? "" : String(newValue);
    }
    return node.value;
  }

  function checked(id, newValue) {
    var node = byId(id);
    if (!node) {
      return false;
    }
    if (arguments.length > 1) {
      node.checked = newValue === true || newValue === "Y";
    }
    return node.checked;
  }

  function titleFromJsonKey(key) {
    return String(key || "")
      .replace(/_/g, " ")
      .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
      .replace(/\b\w/g, function (letter) { return letter.toUpperCase(); });
  }

  function profileValueAtPath(path) {
    return String(path || "").split(".").filter(Boolean).reduce(
      function (current, key) {
        return current && typeof current === "object" ?
          current[key] : undefined;
      },
      studio.previewProfile || {}
    );
  }

  function objectKeysFromJsonValue(jsonValue) {
    var keys = [];
    if (Array.isArray(jsonValue)) {
      jsonValue.forEach(function (item) {
        if (item && typeof item === "object" && !Array.isArray(item)) {
          Object.keys(item).forEach(function (key) {
            if (!keys.includes(key)) {
              keys.push(key);
            }
          });
        }
      });
    } else if (jsonValue && typeof jsonValue === "object") {
      keys = Object.keys(jsonValue);
    }
    return keys;
  }

  function jsonOutputDefinition() {
    var selected = selectedFunction();
    var args = studio.functionConfigOpen && studio.functionDraft ?
      studio.functionDraft : parseFunctionArgs();
    var code = selected && selected.code || "";
    var fields = (jsonOutputCatalog[code] || []).slice();
    var mode = "OBJECT_FIELDS";
    var modeResolved = fields.length > 0;
    if (code === "UNIQUE_GROUP_AGGREGATE") {
      fields = (args.metrics || []).filter(function (metric) {
        return metric.enabled !== false && metric.outputName;
      }).map(function (metric) {
        return metric.outputName;
      });
      if (String(args.outputShape || "ARRAY").toUpperCase() === "ARRAY") {
        fields.unshift(args.groupOutputName || "groupKey");
        mode = "ARRAY_ITEM_FIELDS";
      } else {
        mode = "KEYED_OBJECT_VALUE_FIELDS";
      }
      modeResolved = true;
    } else if (code === "DIRECT_VALUE" &&
               String(args.valueType || "").toUpperCase() === "JSON") {
      try {
        var directJson = JSON.parse(String(args.directValue || ""));
        fields = objectKeysFromJsonValue(directJson);
        mode = Array.isArray(directJson) ?
          "ARRAY_ITEM_FIELDS" : "OBJECT_FIELDS";
        modeResolved = true;
      } catch (ignore) {
        fields = [];
      }
    }
    if (!fields.length && Array.isArray(args.availableOutputFields)) {
      fields = args.availableOutputFields.slice();
      mode = args.outputFieldSelectionMode || mode;
      modeResolved = Boolean(args.outputFieldSelectionMode);
    }
    if (!fields.length) {
      var sampleValue = profileValueAtPath(value("fe-json-path"));
      fields = objectKeysFromJsonValue(sampleValue);
      if (Array.isArray(sampleValue)) {
        mode = "ARRAY_ITEM_FIELDS";
      }
      modeResolved = fields.length > 0;
    }
    fields = fields.filter(function (field, index) {
      return field && fields.indexOf(field) === index;
    });
    return {
      fields: fields,
      mode: modeResolved ? mode : (args.outputFieldSelectionMode || mode)
    };
  }

  function updateJsonOutputCount() {
    var inputs = document.querySelectorAll("[data-json-output-field]");
    var selectedCount = Array.prototype.filter.call(inputs, function (input) {
      return input.checked;
    }).length;
    text("fe-json-output-count",
      selectedCount + " of " + inputs.length + " selected");
  }

  function syncJsonOutputSelection() {
    if (value("fe-output-type").toUpperCase() !== "JSON") {
      return;
    }
    var args = studio.functionConfigOpen && studio.functionDraft ?
      studio.functionDraft : parseFunctionArgs();
    var definition = jsonOutputDefinition();
    var inputs = document.querySelectorAll("[data-json-output-field]");
    if (!inputs.length) {
      return;
    }
    args.availableOutputFields = definition.fields;
    args.selectedOutputFields = Array.prototype.filter.call(
      inputs, function (input) { return input.checked; }
    ).map(function (input) {
      return input.getAttribute("data-json-output-field");
    });
    args.outputFieldSelectionMode = definition.mode;
    if (studio.functionConfigOpen) {
      studio.functionDraft = args;
    } else {
      value("fe-function-args", JSON.stringify(args, null, 2));
    }
    updateJsonOutputCount();
  }

  function renderJsonOutputFields() {
    var panel = byId("fe-json-output-fields");
    var list = byId("fe-json-output-list");
    if (!panel || !list) {
      return;
    }
    var isJson = value("fe-output-type").toUpperCase() === "JSON";
    panel.hidden = !isJson;
    if (!isJson) {
      list.replaceChildren();
      return;
    }
    var args = studio.functionConfigOpen && studio.functionDraft ?
      studio.functionDraft : parseFunctionArgs();
    var definition = jsonOutputDefinition();
    var selectedFields = Array.isArray(args.selectedOutputFields) ?
      args.selectedOutputFields.slice() : definition.fields.slice();
    if (Array.isArray(args.availableOutputFields)) {
      definition.fields.forEach(function (field) {
        if (!args.availableOutputFields.includes(field) &&
            !selectedFields.includes(field)) {
          selectedFields.push(field);
        }
      });
    }
    list.replaceChildren();
    definition.fields.forEach(function (field) {
      var label = document.createElement("label");
      var input = document.createElement("input");
      input.type = "checkbox";
      input.checked = selectedFields.includes(field);
      input.setAttribute("data-json-output-field", field);
      var copy = document.createElement("span");
      var name = document.createElement("strong");
      name.textContent = titleFromJsonKey(field);
      var key = document.createElement("small");
      key.textContent = field;
      copy.append(name, key);
      label.append(input, copy);
      list.appendChild(label);
    });
    if (!definition.fields.length) {
      var empty = document.createElement("div");
      empty.className = "fe-json-output-empty";
      empty.textContent =
        "This function returns dynamic JSON keys. Run the field once, then edit it to select keys from the generated JSON.";
      list.appendChild(empty);
      byId("fe-json-output-help").hidden = true;
    } else {
      byId("fe-json-output-help").hidden = false;
    }
    updateJsonOutputCount();
  }

  function setAllJsonOutputFields(selected) {
    document.querySelectorAll("[data-json-output-field]").forEach(
      function (input) { input.checked = selected; }
    );
    syncJsonOutputSelection();
  }

  function showFunctionConfigTab(tabName, focusTab) {
    var isJsonFunction = value("fe-output-type").toUpperCase() === "JSON";
    var selectedTab = tabName === "json-output" && isJsonFunction ?
      "json-output" : "parameters";
    studio.functionConfigTab = selectedTab;
    var parametersPanel = byId("fe-function-parameters-panel");
    var jsonPanel = byId("fe-function-json-panel");
    var jsonTab = byId("fe-json-output-tab");
    if (parametersPanel) {
      parametersPanel.hidden = selectedTab !== "parameters";
    }
    if (jsonPanel) {
      jsonPanel.hidden = selectedTab !== "json-output";
    }
    if (jsonTab) {
      jsonTab.hidden = !isJsonFunction;
    }
    document.querySelectorAll("[data-fe-function-tab]").forEach(
      function (button) {
        var active = button.getAttribute("data-fe-function-tab") === selectedTab;
        button.classList.toggle("is-active", active);
        button.setAttribute("aria-selected", active ? "true" : "false");
        button.setAttribute("tabindex", active ? "0" : "-1");
        if (active && focusTab) {
          button.focus();
        }
      }
    );
    if (selectedTab === "json-output") {
      renderJsonOutputFields();
    }
  }

  function formatNumber(number) {
    return new Intl.NumberFormat("en-IN", { maximumFractionDigits: 1 })
      .format(Number(number || 0));
  }

  function errorMessage(request, fallback) {
    var message = request && request.responseJSON &&
      (request.responseJSON.error || request.responseJSON.message);
    if (!message && request && request.responseText) {
      var plain = request.responseText
        .replace(/<script[\s\S]*?<\/script>/gi, " ")
        .replace(/<style[\s\S]*?<\/style>/gi, " ")
        .replace(/<[^>]+>/g, " ")
        .replace(/&quot;/g, "\"")
        .replace(/&amp;/g, "&")
        .replace(/\s+/g, " ")
        .trim();
      var governed = plain.match(/ORA-20\d{3}:\s*([^]*?)(?:ORA-\d{5}:|$)/);
      message = governed ? governed[1].trim() : plain.slice(0, 700);
    }
    return message || fallback;
  }

  function notify(message, kind) {
    apex.message.clearErrors();
    if (kind === "success") {
      apex.message.showPageSuccess(message);
      return;
    }
    apex.message.showErrors([{
      type: "error",
      location: ["page"],
      message: message,
      unsafe: false
    }]);
  }

  function setBusy(isBusy) {
    document.body.classList.toggle("fe-is-busy", isBusy);
    var grid = document.querySelector(".fe-studio-grid");
    if (grid) {
      grid.setAttribute("aria-busy", isBusy ? "true" : "false");
    }
  }

  function showTab(tabName, focusTab) {
    var selected = panelIds[tabName] ? tabName : "profile";
    Object.keys(panelIds).forEach(function (name) {
      panelIds[name].forEach(function (id) {
        var panel = byId(id);
        if (panel) {
          panel.hidden = name !== selected;
        }
      });
    });
    document.querySelectorAll(".fe-tab[data-fe-tab]").forEach(function (button) {
      var active = button.getAttribute("data-fe-tab") === selected;
      button.classList.toggle("is-active", active);
      button.setAttribute("aria-selected", active ? "true" : "false");
      button.setAttribute("tabindex", active ? "0" : "-1");
      if (active && focusTab) {
        button.focus();
      }
    });
    try {
      window.sessionStorage.setItem("sbos-fe-active-tab", selected);
    } catch (ignore) {
      // Storage is a convenience only.
    }
    if (selected === "versions") {
      showVersionTab(studio.versionTab, false);
    }
  }

  function showVersionTab(tabName, focusTab) {
    var selected = tabName === "rebuilds" ? "rebuilds" : "config";
    studio.versionTab = selected;
    var versions = byId("fe_profile_versions_region");
    var rebuilds = byId("fe_profile_rebuilds_region");
    if (versions) {
      versions.hidden = selected !== "config";
    }
    if (rebuilds) {
      rebuilds.hidden = selected !== "rebuilds";
    }
    document.querySelectorAll(".fe-version-tab[data-fe-version-tab]")
      .forEach(function (button) {
        var active = button.getAttribute("data-fe-version-tab") === selected;
        button.classList.toggle("is-active", active);
        button.setAttribute("aria-selected", active ? "true" : "false");
        button.setAttribute("tabindex", active ? "0" : "-1");
        if (active && focusTab) {
          button.focus();
        }
      });
    text("fe-version-view-title",
      selected === "config" ? "Configuration version history" : "Selective rebuild operations");
    text("fe-version-view-help",
      selected === "config" ?
        "Activate or pause the current version, and remove only unreferenced history." :
        "Monitor compact rebuild progress and remove completed job history.");
  }

  function replaceOptions(select, rows, label, key, emptyLabel) {
    if (!select) {
      return;
    }
    select.replaceChildren();
    if (emptyLabel) {
      var empty = document.createElement("option");
      empty.value = "";
      empty.textContent = emptyLabel;
      select.appendChild(empty);
    }
    rows.forEach(function (row) {
      var option = document.createElement("option");
      option.value = String(row[key] || "");
      option.textContent = String(row[label] || row[key] || "");
      select.appendChild(option);
    });
  }

  function statusClass(status) {
    var normalized = String(status || "").toUpperCase();
    if (["ACTIVE", "COMPLETED", "SUCCEEDED", "VALIDATED"].includes(normalized)) {
      return "fe-native-badge--success";
    }
    if (["FAILED", "ERROR", "CANCELLED"].includes(normalized)) {
      return "fe-native-badge--danger";
    }
    if (["QUEUED", "RUNNING", "DISPATCHED"].includes(normalized)) {
      return "fe-native-badge--info";
    }
    return "fe-native-badge--warning";
  }

  function renderValidation(validation) {
    var node = byId("fe-validation-state");
    if (!node) {
      return;
    }
    node.replaceChildren();
    var icon = document.createElement("span");
    icon.className = validation && validation.valid ?
      "fa fa-check-circle" : "fa fa-exclamation-triangle";
    icon.setAttribute("aria-hidden", "true");
    node.appendChild(icon);
    node.appendChild(document.createTextNode(
      validation && validation.message ? validation.message : "Configuration requires validation"
    ));
    node.classList.toggle("is-valid", Boolean(validation && validation.valid));
    node.classList.toggle("is-invalid", !validation || !validation.valid);
  }

  function renderNextRun() {
    var chip = byId("fe-next-run");
    if (!chip) {
      return;
    }
    var state = studio.data && studio.data.config &&
      String(studio.data.config.schedulerState || "").toUpperCase();
    chip.classList.toggle("is-running", state === "RUNNING");
    chip.classList.toggle("is-unavailable", !studio.nextRunDate);
    if (state === "RUNNING") {
      chip.innerHTML = '<span class="fa fa-refresh fa-spin" aria-hidden="true"></span>Running now';
      return;
    }
    if (!studio.nextRunDate || Number.isNaN(studio.nextRunDate.getTime())) {
      chip.innerHTML = '<span class="fa fa-clock-o" aria-hidden="true"></span>Not scheduled';
      chip.title = "Oracle Scheduler has no next run";
      return;
    }
    while (studio.nextRunDate.getTime() <= Date.now()) {
      studio.nextRunDate = new Date(
        studio.nextRunDate.getTime() + studio.nextRunIntervalMinutes * 60000
      );
    }
    var timeText = new Intl.DateTimeFormat("en-IN", {
      timeZone: "Asia/Kolkata",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: true
    }).format(studio.nextRunDate);
    var fullText = new Intl.DateTimeFormat("en-IN", {
      timeZone: "Asia/Kolkata",
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: true
    }).format(studio.nextRunDate);
    chip.innerHTML = '<span class="fa fa-clock-o" aria-hidden="true"></span>Next ' +
      timeText;
    chip.title = "Oracle Scheduler next run: " + fullText + " IST";
  }

  function configureNextRun(config) {
    studio.nextRunDate = config && config.nextRunIso ?
      new Date(config.nextRunIso) : null;
    studio.nextRunIntervalMinutes = Number(
      config && config.schedulerIntervalMinutes || config && config.scheduleMinutes || 5
    );
    if (!Number.isFinite(studio.nextRunIntervalMinutes) ||
        studio.nextRunIntervalMinutes < 1) {
      studio.nextRunIntervalMinutes = 5;
    }
    renderNextRun();
    if (!studio.nextRunTimer) {
      studio.nextRunTimer = window.setInterval(renderNextRun, 1000);
    }
  }

  function renderSetup() {
    var config = studio.data.config;
    value("fe-entity-key", config.entityKeyColumn);
    value("fe-dedupe-key", config.dedupeKeyColumn);
    value("fe-source-table", config.sourceTable);
    value("fe-processing-mode", "Incremental Micro-batch");
    value("fe-workers", config.parallelWorkers);
    value("fe-buckets", config.bucketCount);
    value("fe-schedule", config.scheduleMinutes);
    value("fe-watermark", config.watermarkColumn);
    checked("fe-target-daily", config.dailyEnabled);
    checked("fe-target-monthly", config.monthlyEnabled);
    checked("fe-target-360", config.profile360Enabled);
    text("fe-version-chip", "Version " + formatNumber(config.version));
    text("fe-active-chip", config.status || "DRAFT");
    text("fe-worker-chip", config.parallelWorkers + " workers");
    text("fe-schedule-chip", "Every " + config.scheduleMinutes + " min");
    configureNextRun(config);
    text("fe-impact-daily", config.entityType + " Daily");
    text("fe-impact-monthly", config.entityType + " Monthly");
    text("fe-impact-360", config.entityType + " 360");
    text("fe-impact-buckets", config.bucketCount);
    document.querySelectorAll("[data-fe-entity]").forEach(function (button) {
      button.classList.toggle("is-active",
        button.getAttribute("data-fe-entity") === studio.entity);
    });
    var rebuild = studio.data.recentRebuilds && studio.data.recentRebuilds[0];
    var historicalStatus = String(config.historicalStatus || "NOT_REQUESTED");
    var currentRebuild = rebuild && Number(rebuild.jobId) ===
      Number(config.rebuildJobId) ? rebuild : null;
    text("fe-rebuild-status", currentRebuild ?
      historicalStatus + (currentRebuild.totalEntities !== null ?
        " · " + formatNumber(currentRebuild.completedEntities) + "/" +
        formatNumber(currentRebuild.totalEntities) : "") :
      historicalStatus.replace(/_/g, " "));
    renderValidation(studio.data.validation);
  }

  function targetBadge(field, key, label) {
    var span = document.createElement("span");
    span.className = "fe-target-dot" + (field[key] === "Y" ? " is-on" : "");
    span.textContent = label;
    return span;
  }

  function fieldSearchMatch(field, term) {
    return !term || [
      field.jsonPath, field.metricCode, field.functionCode, field.name
    ].join(" ").toLowerCase().includes(term);
  }

  function fieldTree(fields) {
    var root = { path: "", children: {}, fields: [] };
    fields.forEach(function (field) {
      var parts = String(field.jsonPath || "").split(".");
      var node = root;
      parts.slice(0, -1).forEach(function (part) {
        var childPath = node.path ? node.path + "." + part : part;
        if (!node.children[part]) {
          node.children[part] = {
            name: part,
            path: childPath,
            children: {},
            fields: [],
            sequence: Number(field.displaySequence || 999999)
          };
        }
        node.children[part].sequence = Math.min(
          node.children[part].sequence,
          Number(field.displaySequence || 999999)
        );
        node = node.children[part];
      });
      node.fields.push(field);
    });
    return root;
  }

  function fieldRow(field, depth) {
    var row = document.createElement("tr");
    row.className = "fe-field-leaf";
    row.setAttribute("data-field-id", field.id);
    if (studio.selectedField && Number(studio.selectedField.id) === Number(field.id)) {
      row.classList.add("is-selected");
    }

    var pathCell = document.createElement("td");
    var path = document.createElement("button");
    path.type = "button";
    path.className = "fe-path-button";
    path.setAttribute("data-fe-action", "select-profile-field");
    path.setAttribute("data-field-id", field.id);
    path.style.setProperty("--fe-depth", depth);
    var icon = document.createElement("span");
    icon.className = "fa fa-file-code-o";
    icon.setAttribute("aria-hidden", "true");
    var copy = document.createElement("span");
    var strong = document.createElement("strong");
    strong.textContent = String(field.jsonPath || "").split(".").pop();
    var small = document.createElement("small");
    small.textContent = field.name || field.metricCode;
    copy.append(strong, small);
    path.append(icon, copy);
    pathCell.appendChild(path);

    var typeCell = document.createElement("td");
    typeCell.textContent = field.outputDataType;
    var functionCell = document.createElement("td");
    var functionBadge = document.createElement("span");
    functionBadge.className = "fe-function-badge";
    functionBadge.textContent = field.functionCode;
    var functionDefinition = (studio.data.functions || []).find(function (item) {
      return item.code === field.functionCode;
    });
    if (functionDefinition && functionDefinition.frameworkV2 === "Y") {
      functionBadge.classList.add("is-v2");
      functionBadge.title = "FRAMEWORK V2 · " +
        (field.accuracyMode || functionDefinition.accuracyMode || "EXACT");
    }
    functionCell.appendChild(functionBadge);
    var targetsCell = document.createElement("td");
    targetsCell.className = "fe-field-targets";
    targetsCell.append(
      targetBadge(field, "dailyEnabled", "D"),
      targetBadge(field, "monthlyEnabled", "M"),
      targetBadge(field, "profile360Enabled", "360")
    );
    var enabledCell = document.createElement("td");
    var enabled = document.createElement("span");
    enabled.className = "fe-native-badge " +
      (field.enabled === "Y" ? "fe-native-badge--success" : "fe-native-badge--neutral");
    enabled.textContent = field.enabled === "Y" ? "Enabled" : "Disabled";
    enabledCell.appendChild(enabled);
    var actionCell = document.createElement("td");
    var edit = document.createElement("button");
    edit.type = "button";
    edit.className = "fe-icon-button";
    edit.title = "Edit " + field.jsonPath;
    edit.setAttribute("aria-label", edit.title);
    edit.setAttribute("data-fe-action", "select-profile-field");
    edit.setAttribute("data-field-id", field.id);
    var editIcon = document.createElement("span");
    editIcon.className = "fa fa-pencil";
    editIcon.setAttribute("aria-hidden", "true");
    edit.appendChild(editIcon);
    actionCell.appendChild(edit);
    row.append(pathCell, typeCell, functionCell, targetsCell, enabledCell, actionCell);
    return row;
  }

  function countNodeFields(node) {
    return node.fields.length + Object.keys(node.children).reduce(function (total, key) {
      return total + countNodeFields(node.children[key]);
    }, 0);
  }

  function setFieldPathExpansion(expanded) {
    var tree = fieldTree((studio.data && studio.data.fields) || []);
    studio.collapsedPaths = {};

    function visit(node) {
      Object.keys(node.children).forEach(function (key) {
        var child = node.children[key];
        if (!expanded) {
          studio.collapsedPaths[child.path] = true;
        }
        visit(child);
      });
    }

    visit(tree);
    renderFields();
  }

  function renderFieldBranch(body, node, depth) {
    Object.keys(node.children)
      .map(function (key) { return node.children[key]; })
      .sort(function (a, b) {
        return a.sequence - b.sequence || a.name.localeCompare(b.name);
      })
      .forEach(function (child) {
        var collapsed = Boolean(studio.collapsedPaths[child.path]);
        var childCount = countNodeFields(child);
        var row = document.createElement("tr");
        row.className = "fe-field-parent";
        row.setAttribute("data-path", child.path);
        var pathCell = document.createElement("td");
        var toggle = document.createElement("button");
        toggle.type = "button";
        toggle.className = "fe-path-button fe-path-button--parent";
        toggle.style.setProperty("--fe-depth", depth);
        toggle.setAttribute("data-fe-action", "toggle-path");
        toggle.setAttribute("data-path", child.path);
        toggle.setAttribute("aria-expanded", collapsed ? "false" : "true");
        var chevron = document.createElement("span");
        chevron.className = collapsed ? "fa fa-angle-right" : "fa fa-angle-down";
        chevron.setAttribute("aria-hidden", "true");
        var folder = document.createElement("span");
        folder.className = collapsed ? "fa fa-folder-o" : "fa fa-folder-open-o";
        folder.setAttribute("aria-hidden", "true");
        var title = document.createElement("span");
        var strong = document.createElement("strong");
        strong.textContent = child.name;
        var small = document.createElement("small");
        small.textContent = child.path;
        title.append(strong, small);
        toggle.append(chevron, folder, title);
        pathCell.appendChild(toggle);
        var typeCell = document.createElement("td");
        typeCell.innerText = "OBJECT";
        var countCell = document.createElement("td");
        countCell.textContent = childCount + " configured fields";
        var targetsCell = document.createElement("td");
        var stateCell = document.createElement("td");
        var objectBadge = document.createElement("span");
        objectBadge.className = "fe-native-badge fe-native-badge--info";
        objectBadge.textContent = collapsed ? "Collapsed" : "Expanded";
        stateCell.appendChild(objectBadge);
        row.append(pathCell, typeCell, countCell, targetsCell, stateCell,
          document.createElement("td"));
        body.appendChild(row);
        if (!collapsed) {
          renderFieldBranch(body, child, depth + 1);
        }
      });
    node.fields
      .sort(function (a, b) {
        return Number(a.displaySequence || 0) - Number(b.displaySequence || 0);
      })
      .forEach(function (field) {
        body.appendChild(fieldRow(field, depth));
      });
  }

  function renderFields() {
    var body = byId("fe-field-rows");
    if (!body) {
      return;
    }
    body.replaceChildren();
    var term = String(value("fe-field-search") || "").trim().toLowerCase();
    var fields = (studio.data.fields || []).filter(function (field) {
      return fieldSearchMatch(field, term);
    });
    renderFieldBranch(body, fieldTree(fields), 0);
    text("fe-field-count", fields.length + " fields");
  }

  function renderFunctionAndMetaOptions() {
    var functions = studio.data.functions || [];
    replaceOptions(byId("fe-function"), functions, "name", "code");
    replaceOptions(byId("fe-source-field"), studio.data.metaFields || [],
      "name", "column", "Maintained state / derived");
    var seen = {};
    var metrics = [];
    (studio.data.fields || []).forEach(function (field) {
      if (!seen[field.metricCode]) {
        seen[field.metricCode] = true;
        metrics.push({ code: field.metricCode, name: field.metricCode.replace(/_/g, " ") });
      }
    });
    [
      {
        code: "HOURLY_TRANSACTION_COUNT",
        name: "Hourly transaction count"
      },
      {
        code: "PEAK_HOURS",
        name: "Peak hours"
      },
      {
        code: "CONTINUOUS_ABSENT_DAYS",
        name: "Continuous absent days"
      }
    ].forEach(function (metric) {
      if (!seen[metric.code]) {
        seen[metric.code] = true;
        metrics.push(metric);
      }
    });
    replaceOptions(byId("fe-metric-code"), metrics, "name", "code");
  }

  function jsonCodeToken(parent, className, tokenText) {
    var token = document.createElement("span");
    token.className = className;
    token.textContent = tokenText;
    parent.appendChild(token);
  }

  function jsonCodePrimitive(parent, primitiveValue) {
    if (primitiveValue === null) {
      jsonCodeToken(parent, "fe-json-token--null", "null");
    } else if (typeof primitiveValue === "string") {
      jsonCodeToken(parent, "fe-json-token--string", JSON.stringify(primitiveValue));
    } else if (typeof primitiveValue === "boolean") {
      jsonCodeToken(parent, "fe-json-token--boolean", String(primitiveValue));
    } else {
      jsonCodeToken(parent, "fe-json-token--number", String(primitiveValue));
    }
  }

  function jsonCodeKey(parent, key) {
    if (key === null || key === undefined) {
      return;
    }
    jsonCodeToken(parent, "fe-json-token--key", JSON.stringify(String(key)));
    jsonCodeToken(parent, "fe-json-token--punctuation", ": ");
  }

  function jsonCodeBranch(parent, key, branchValue, path, depth, isLast) {
    var complex = branchValue !== null && typeof branchValue === "object";
    if (!complex) {
      var leafLine = document.createElement("div");
      leafLine.className = "fe-json-code-line fe-json-code-leaf";
      leafLine.style.setProperty("--fe-json-code-depth", depth);
      leafLine.setAttribute("role", "treeitem");
      leafLine.setAttribute("data-json-code-path", path);
      jsonCodeKey(leafLine, key);
      jsonCodePrimitive(leafLine, branchValue);
      if (!isLast) {
        jsonCodeToken(leafLine, "fe-json-token--punctuation", ",");
      }
      parent.appendChild(leafLine);
      return;
    }

    var isArray = Array.isArray(branchValue);
    var keys = Object.keys(branchValue);
    var openCharacter = isArray ? "[" : "{";
    var closeCharacter = isArray ? "]" : "}";
    var details = document.createElement("details");
    details.className = "fe-json-code-node";
    details.style.setProperty("--fe-json-code-depth", depth);
    details.open = !studio.collapsedJsonCodePaths[path];
    details.setAttribute("data-json-code-path", path);

    var summary = document.createElement("summary");
    summary.className = "fe-json-code-line";
    summary.setAttribute("role", "treeitem");
    summary.setAttribute("aria-label",
      (key === null ? "JSON root" : String(key)) + ", " +
      keys.length + (isArray ? " items" : " fields"));
    jsonCodeKey(summary, key);
    jsonCodeToken(summary, "fe-json-token--punctuation", openCharacter);
    var compact = document.createElement("span");
    compact.className = "fe-json-code-compact";
    compact.textContent = " … " + closeCharacter + (isLast ? "" : ",");
    summary.appendChild(compact);
    var count = document.createElement("span");
    count.className = "fe-json-code-count";
    count.textContent = keys.length + (isArray ? " items" : " fields");
    summary.appendChild(count);

    var children = document.createElement("div");
    children.className = "fe-json-code-children";
    keys.forEach(function (childKey, index) {
      jsonCodeBranch(
        children,
        isArray ? null : childKey,
        branchValue[childKey],
        path + (isArray ? "[" + childKey + "]" : "." + childKey),
        depth + 1,
        index === keys.length - 1
      );
    });
    var closingLine = document.createElement("div");
    closingLine.className = "fe-json-code-line fe-json-code-closing";
    closingLine.style.setProperty("--fe-json-code-depth", depth);
    jsonCodeToken(
      closingLine,
      "fe-json-token--punctuation",
      closeCharacter + (isLast ? "" : ",")
    );
    children.appendChild(closingLine);
    details.append(summary, children);
    details.addEventListener("toggle", function () {
      studio.collapsedJsonCodePaths[path] = !details.open;
    });
    parent.appendChild(details);
  }

  function syntaxHighlightedJson(container, profile) {
    if (!container) {
      return;
    }
    container.replaceChildren();
    jsonCodeBranch(container, null, profile || {}, "$", 0, true);
  }

  function jsonValueLabel(valueToLabel) {
    if (valueToLabel === null) {
      return "null";
    }
    if (Array.isArray(valueToLabel)) {
      return "[" + valueToLabel.length + " items]";
    }
    if (typeof valueToLabel === "object") {
      return "{" + Object.keys(valueToLabel).length + " fields}";
    }
    if (typeof valueToLabel === "string") {
      return "\"" + valueToLabel + "\"";
    }
    return String(valueToLabel);
  }

  function jsonTreeBranch(parent, key, branchValue, path, depth, searchTerm) {
    var searchable = (path + " " + jsonValueLabel(branchValue)).toLowerCase();
    if (searchTerm &&
        searchable.indexOf(searchTerm) < 0 &&
        JSON.stringify(branchValue).toLowerCase().indexOf(searchTerm) < 0) {
      return;
    }
    var complex = branchValue !== null && typeof branchValue === "object";
    if (!complex) {
      var leaf = document.createElement("div");
      leaf.className = "fe-json-tree-leaf";
      leaf.style.setProperty("--fe-json-depth", depth);
      leaf.setAttribute("role", "treeitem");
      leaf.setAttribute("data-json-path", path);
      var leafKey = document.createElement("span");
      leafKey.className = "fe-json-tree-key";
      leafKey.textContent = key;
      var leafValue = document.createElement("span");
      leafValue.className = "fe-json-tree-value fe-json-tree-value--" +
        (branchValue === null ? "null" : typeof branchValue);
      leafValue.textContent = jsonValueLabel(branchValue);
      leaf.append(leafKey, leafValue);
      parent.appendChild(leaf);
      return;
    }

    var details = document.createElement("details");
    details.className = "fe-json-tree-node";
    details.style.setProperty("--fe-json-depth", depth);
    details.open = Boolean(searchTerm) || depth < 2;
    details.setAttribute("data-json-path", path);
    var summary = document.createElement("summary");
    summary.setAttribute("role", "treeitem");
    var nodeKey = document.createElement("span");
    nodeKey.className = "fe-json-tree-key";
    nodeKey.textContent = key;
    var count = document.createElement("span");
    count.className = "fe-json-tree-count";
    count.textContent = jsonValueLabel(branchValue);
    summary.append(nodeKey, count);
    var children = document.createElement("div");
    children.className = "fe-json-tree-children";
    Object.keys(branchValue).forEach(function (childKey) {
      jsonTreeBranch(
        children,
        childKey,
        branchValue[childKey],
        path ? path + "." + childKey : childKey,
        depth + 1,
        searchTerm
      );
    });
    details.append(summary, children);
    parent.appendChild(details);
  }

  function renderJsonTree() {
    var tree = byId("fe-json-tree");
    if (!tree) {
      return;
    }
    tree.replaceChildren();
    var term = String(value("fe-json-tree-search") || "").trim().toLowerCase();
    var profile = studio.previewProfile || {};
    Object.keys(profile).forEach(function (key) {
      jsonTreeBranch(tree, key, profile[key], key, 0, term);
    });
    if (!tree.childNodes.length) {
      var empty = document.createElement("p");
      empty.className = "fe-json-tree-empty";
      empty.textContent = term ? "No JSON path matches this search." : "No profile JSON loaded.";
      tree.appendChild(empty);
    }
  }

  function profileByteLength(profile) {
    var source = JSON.stringify(profile || {});
    if (window.TextEncoder) {
      return new window.TextEncoder().encode(source).length;
    }
    return source.length;
  }

  function renderJsonPreview() {
    syntaxHighlightedJson(byId("fe-json-code"), studio.previewProfile);
    text("fe-preview-status", studio.previewEntityKey || "Sample");
    text("fe-drawer-entity", studio.previewEntityKey ?
      studio.entity + " · " + studio.previewEntityKey : "Select an entity");
    text("fe-drawer-entity-type", studio.entity);
    text("fe-drawer-bytes",
      new Intl.NumberFormat("en-IN").format(profileByteLength(studio.previewProfile)) +
      " bytes");
    renderJsonTree();
  }

  function openJsonDrawer() {
    renderJsonPreview();
    apex.theme.openRegion("fe-profile-json-drawer");
  }

  function loadProfileJson(openDrawer) {
    var entityKey = String(value("fe-preview-entity-key") || "").trim();
    if (!entityKey) {
      notify("Enter an " + (studio.entity === "AGENT" ? "Agent ID." : "Customer ID."),
        "error");
      byId("fe-preview-entity-key").focus();
      return;
    }
    setBusy(true);
    apex.server.process("FE_PROFILE_JSON", {
      x01: studio.entity,
      x02: entityKey
    }, { dataType: "json" })
      .done(function (data) {
        studio.previewProfile = data.profile || {};
        studio.previewEntityKey = String(data.entityKey || entityKey);
        studio.previewUpdatedOn = data.updatedOn || "";
        value("fe-preview-entity-key", studio.previewEntityKey);
        renderJsonPreview();
        if (openDrawer) {
          openJsonDrawer();
        }
      })
      .fail(function (request) {
        notify(errorMessage(request, "The materialized profile could not be loaded."), "error");
      })
      .always(function () {
        setBusy(false);
      });
  }

  function renderSample() {
    studio.previewProfile = studio.data.sampleProfile || {};
    studio.previewEntityKey = String(studio.data.sampleEntityKey || "");
    studio.previewUpdatedOn = "";
    value("fe-preview-entity-key", studio.previewEntityKey);
    text("fe-preview-key-label", studio.entity === "AGENT" ? "Agent ID" : "Customer ID");
    var keyInput = byId("fe-preview-entity-key");
    if (keyInput) {
      keyInput.placeholder = studio.entity === "AGENT" ?
        "Enter Agent ID" : "Enter Customer ID";
    }
    renderJsonPreview();
  }

  function selectedFunction() {
    return (studio.data && studio.data.functions || []).find(function (item) {
      return item.code === value("fe-function");
    }) || null;
  }

  function parseFunctionArgs() {
    try {
      return JSON.parse(value("fe-function-args") || "{}");
    } catch (ignore) {
      return {};
    }
  }

  function directFieldOutputType(sourceField) {
    var metadata = (studio.data && studio.data.metaFields || []).find(
      function (field) {
        return field.column === sourceField;
      }
    );
    var dataType = String(metadata && metadata.dataType || "VARCHAR2").toUpperCase();
    if (dataType === "NUMBER") {
      return "NUMBER";
    }
    if (["DATE", "TIMESTAMP"].includes(dataType)) {
      return "TIMESTAMP";
    }
    return "VARCHAR2";
  }

  function renderDirectValueControls() {
    var selected = selectedFunction();
    var directMode = Boolean(selected && selected.code === "DIRECT_VALUE");
    var sourceControl = byId("fe-source-field-control");
    var directControl = byId("fe-direct-value-control");
    var filterControls = byId("fe-filter-controls");
    var windowControl = byId("fe-window-control");
    if (sourceControl) {
      sourceControl.hidden = directMode;
    }
    if (directControl) {
      directControl.hidden = !directMode;
    }
    if (filterControls) {
      filterControls.hidden = directMode;
    }
    if (windowControl) {
      windowControl.hidden = directMode;
    }
    if (!directMode) {
      return;
    }
    var args = parseFunctionArgs();
    var directType = String(args.valueType || "TEXT").toUpperCase();
    var directInput = byId("fe-direct-value-input");
    var directInputControl = byId("fe-direct-value-input-control");
    var directFieldControl = byId("fe-direct-value-field-control");
    var directField = byId("fe-direct-value-field");
    var fieldMode = directType === "FIELD";
    value("fe-direct-value-type", directType);
    if (directInputControl) {
      directInputControl.hidden = fieldMode || directType === "NULL";
    }
    if (directFieldControl) {
      directFieldControl.hidden = !fieldMode;
    }
    if (fieldMode && directField) {
      sourceFieldOptions(
        directField,
        args.sourceField || value("fe-source-field") || "",
        ""
      );
    }
    var configuredValue = args.directValue === undefined ||
      args.directValue === null ? "" : String(args.directValue);
    if (directInput && directInput.value !== configuredValue) {
      directInput.value = configuredValue;
    }
    if (directInput) {
      directInput.disabled = directType === "NULL" || fieldMode;
      directInput.placeholder = {
        TEXT: "ACTIVE",
        NUMBER: "100",
        BOOLEAN: "true",
        JSON: "{\"tier\":\"GOLD\"}",
        NULL: "No value required"
      }[directType] || "Enter value";
    }
  }

  function syncDirectValueControls() {
    var selected = selectedFunction();
    if (!selected || selected.code !== "DIRECT_VALUE") {
      return;
    }
    var args = parseFunctionArgs();
    var directType = String(value("fe-direct-value-type") || "TEXT").toUpperCase();
    args.valueType = directType;
    args.sourceField = directType === "FIELD" ?
      value("fe-direct-value-field") : "";
    args.directValue = ["FIELD", "NULL"].includes(directType) ? "" :
      value("fe-direct-value-input");
    value("fe-function-args", JSON.stringify(args, null, 2));
    value("fe-source-field", args.sourceField);
    value("fe-filter-code", "NONE");
    value("fe-filter-value", "");
    value("fe-window", "LIFETIME");
    value("fe-update-strategy", "REPLACE_VALUE");
    value("fe-output-type", directType === "FIELD" ?
      directFieldOutputType(args.sourceField) :
      (directType === "TEXT" ? "VARCHAR2" :
        (directType === "NUMBER" ? "NUMBER" : "JSON")));
    renderDirectValueControls();
    renderParameterSummary();
    updateFormulaPreview();
    renderJsonOutputFields();
  }

  function cloneJson(valueToClone) {
    return JSON.parse(JSON.stringify(valueToClone || {}));
  }

  function renderParameterSummary() {
    var selected = selectedFunction();
    var args = parseFunctionArgs();
    var summary = "No additional parameters";
    if (selected && selected.code === "DIRECT_VALUE") {
      var directType = String(args.valueType || "TEXT").toUpperCase();
      var directValue = directType === "FIELD" ?
        String(args.sourceField || "") :
        (directType === "NULL" ? "null" :
          String(args.directValue === undefined ? "" : args.directValue));
      summary = directType.replace("_", " ").toLowerCase() + " · " +
        (directValue || "enter value");
    } else if (selected && selected.parameterSchema &&
        selected.parameterSchema.editor === "GROUP_AGGREGATE") {
      summary = String(args.groupField || "Select group field") + " · " +
        String((args.metrics || []).length) + " metrics · " +
        String(args.outputShape || "ARRAY").replace("_", " ").toLowerCase();
    } else if (selected && selected.parameterSchema &&
               governedParameterFields(selected.parameterSchema).length) {
      summary = String(governedParameterFields(
        selected.parameterSchema
      ).length) +
        " governed parameters";
    }
    text("fe-parameter-summary", summary);
  }

  function sourceFieldOptions(select, selectedValue, dataType) {
    if (!select) {
      return;
    }
    select.replaceChildren();
    var empty = document.createElement("option");
    empty.value = "";
    empty.textContent = "-- Select field --";
    select.appendChild(empty);
    (studio.data && studio.data.metaFields || []).forEach(function (field) {
      if (dataType && String(field.dataType).toUpperCase() !==
          String(dataType).toUpperCase()) {
        return;
      }
      var option = document.createElement("option");
      option.value = field.column;
      option.textContent = field.name + " · " + field.column;
      option.selected = field.column === selectedValue;
      select.appendChild(option);
    });
    if (selectedValue && !Array.prototype.some.call(select.options, function (option) {
      return option.value === selectedValue;
    })) {
      var fallback = document.createElement("option");
      fallback.value = selectedValue;
      fallback.textContent = selectedValue;
      fallback.selected = true;
      select.appendChild(fallback);
    }
  }

  function appendSelectOptions(select, options, selectedValue) {
    options.forEach(function (optionValue) {
      var option = document.createElement("option");
      if (typeof optionValue === "object") {
        option.value = optionValue.value;
        option.textContent = optionValue.label;
      } else {
        option.value = optionValue;
        option.textContent = String(optionValue).replace(/_/g, " ")
          .toLowerCase().replace(/\b\w/g, function (letter) {
            return letter.toUpperCase();
          });
      }
      option.selected = String(option.value) === String(selectedValue || "");
      select.appendChild(option);
    });
  }

  function visibleFunctionField(field) {
    var selected = selectedFunction();
    var functions = field.visibleForFunctions || [];
    return !functions.length || functions.includes(selected && selected.code);
  }

  function governedParameterFields(schema) {
    var fields = (schema.fields || []).filter(visibleFunctionField);
    if (schema.dedupeAware) {
      fields = fields.concat([
        {
          name: "dedupeKey", label: "Dedupe key", type: "sourceField",
          required: true, section: "DEDUPE",
          help: "Stable transaction key used to ignore repeated input."
        },
        {
          name: "onDuplicate", label: "On duplicate", type: "select",
          required: true, section: "DEDUPE",
          options: [
            { value: "IGNORE", label: "Ignore duplicate" },
            { value: "REPLACE", label: "Replace prior value" },
            { value: "ERROR", label: "Reject batch" }
          ]
        },
        {
          name: "normalize", label: "Key normalization", type: "select",
          required: true, section: "DEDUPE",
          options: [
            { value: "UPPER_TRIM", label: "Uppercase and trim" },
            { value: "TRIM", label: "Trim only" },
            { value: "NONE", label: "No normalization" }
          ]
        },
        {
          name: "invalidKey", label: "Invalid key", type: "select",
          required: true, section: "DEDUPE",
          options: [
            { value: "SKIP", label: "Skip row" },
            { value: "ERROR", label: "Reject batch" }
          ]
        }
      ]);
    }
    return fields;
  }

  function parameterSections(schema, fields) {
    var sections = (schema.sections || []).slice();
    if (schema.dedupeAware) {
      sections.push({
        code: "DEDUPE",
        title: "Dedupe Policy",
        help: "FRAMEWORK V2 row gate applied before state is changed."
      });
    }
    var known = {};
    sections.forEach(function (section) {
      known[section.code || "GENERAL"] = true;
    });
    fields.forEach(function (field) {
      var code = field.section || "GENERAL";
      if (!known[code]) {
        sections.push({
          code: code,
          title: code === "GENERAL" ? "Parameters" :
            String(code).replace(/_/g, " ").toLowerCase()
              .replace(/\b\w/g, function (letter) { return letter.toUpperCase(); }),
          help: ""
        });
        known[code] = true;
      }
    });
    return sections;
  }

  function profilePathOptions(select, selectedValue) {
    if (!select) {
      return;
    }
    select.replaceChildren();
    var empty = document.createElement("option");
    empty.value = "";
    empty.textContent = "-- Select configured profile field --";
    select.appendChild(empty);
    ((studio.data && studio.data.fields) || []).forEach(function (field) {
      var option = document.createElement("option");
      option.value = field.jsonPath || field.path || "";
      option.textContent = (field.fieldName || field.name || option.value) +
        " · " + option.value;
      option.selected = option.value === selectedValue;
      if (option.value) {
        select.appendChild(option);
      }
    });
    if (selectedValue && !Array.prototype.some.call(
      select.options,
      function (option) { return option.value === selectedValue; }
    )) {
      var fallback = document.createElement("option");
      fallback.value = selectedValue;
      fallback.textContent = selectedValue + " · configured path";
      fallback.selected = true;
      select.appendChild(fallback);
    }
  }

  function parameterIsVisible(field) {
    if (Array.isArray(field.visibleForFunctions) &&
        !field.visibleForFunctions.includes(
          String((selectedFunction() || {}).code || "").toUpperCase()
        )) {
      return false;
    }
    if (field.hiddenWhen) {
      var hiddenActual = studio.functionDraft[field.hiddenWhen.field];
      var hiddenValues = field.hiddenWhen.values || [field.hiddenWhen.equals];
      if (hiddenValues.map(String).includes(String(hiddenActual))) {
        return false;
      }
    }
    if (!field.visibleWhen) {
      return true;
    }
    var actual = studio.functionDraft[field.visibleWhen.field];
    return String(actual) === String(field.visibleWhen.equals);
  }

  function createParameterControl(field) {
    var draftValue = studio.functionDraft[field.name];
    var control;
    if (field.type === "sourceField" || field.type === "sourceFieldList") {
      control = document.createElement("select");
      if (field.type === "sourceFieldList") {
        control.multiple = true;
        control.size = Math.min(6, Math.max(3, Number(field.maxItems || 4)));
      }
      sourceFieldOptions(control, field.type === "sourceField" ?
        (draftValue || "") : "", field.dataType || "");
      if (field.type === "sourceFieldList") {
        var selectedValues = Array.isArray(draftValue) ? draftValue : [];
        Array.prototype.forEach.call(control.options, function (option) {
          option.selected = selectedValues.includes(option.value);
        });
      }
    } else if (field.type === "profilePath") {
      control = document.createElement("select");
      profilePathOptions(control, draftValue || "");
    } else if (field.type === "boolean") {
      control = document.createElement("input");
      control.type = "checkbox";
      control.checked = Boolean(draftValue);
    } else if (field.type === "select") {
      control = document.createElement("select");
      appendSelectOptions(control, field.options || [], draftValue);
    } else {
      control = document.createElement("input");
      control.type = field.type === "number" ? "number" : "text";
      control.value = draftValue === undefined || draftValue === null ?
        "" : (Array.isArray(draftValue) ? draftValue.join(",") : draftValue);
      if (field.min !== undefined) {
        control.min = field.min;
      }
      if (field.max !== undefined) {
        control.max = field.max;
      }
      if (field.step !== undefined) {
        control.step = field.step;
      }
      if (field.placeholder) {
        control.placeholder = field.placeholder;
      }
    }
    control.setAttribute("data-parameter-name", field.name);
    control.setAttribute("data-parameter-type", field.type || "text");
    return control;
  }

  function groupMetricTemplate(index) {
    return {
      outputName: "metric_" + (index + 1),
      displayName: "Metric " + (index + 1),
      sourceMode: "FIELD",
      sourceField: "AMOUNT",
      constantValue: "",
      constantNumber: null,
      aggregation: "SUM",
      filterCode: "NONE",
      filterValue: "",
      nullHandling: "IGNORE",
      accuracy: "EXACT",
      enabled: true
    };
  }

  function renderGroupMetricRows() {
    var body = byId("fe-group-metric-rows");
    if (!body || !studio.functionDraft) {
      return;
    }
    body.replaceChildren();
    var aggregations = (selectedFunction().parameterSchema.aggregations || []);
    (studio.functionDraft.metrics || []).forEach(function (metric, index) {
      var row = document.createElement("tr");
      row.setAttribute("data-metric-index", index);

      var orderCell = document.createElement("td");
      orderCell.className = "fe-group-metric-order";
      orderCell.textContent = String(index + 1);

      var nameCell = document.createElement("td");
      var nameInput = document.createElement("input");
      nameInput.type = "text";
      nameInput.value = metric.outputName || "";
      nameInput.placeholder = "totalAmount";
      nameInput.setAttribute("data-metric-field", "outputName");
      nameInput.setAttribute("aria-label", "Metric output name");
      nameCell.appendChild(nameInput);

      var modeCell = document.createElement("td");
      var modeSelect = document.createElement("select");
      modeSelect.setAttribute("data-metric-field", "sourceMode");
      appendSelectOptions(modeSelect, [
        { value: "FIELD", label: "Source field" },
        { value: "CONSTANT", label: "Constant" }
      ], metric.sourceMode || "FIELD");
      modeCell.appendChild(modeSelect);

      var sourceCell = document.createElement("td");
      if ((metric.sourceMode || "FIELD") === "CONSTANT") {
        var constantInput = document.createElement("input");
        constantInput.type = "text";
        constantInput.value = metric.constantValue === undefined ?
          "" : metric.constantValue;
        constantInput.placeholder = "Constant value";
        constantInput.setAttribute("data-metric-field", "constantValue");
        constantInput.setAttribute("aria-label", "Constant metric value");
        sourceCell.appendChild(constantInput);
      } else {
        var sourceSelect = document.createElement("select");
        sourceSelect.setAttribute("data-metric-field", "sourceField");
        sourceFieldOptions(sourceSelect, metric.sourceField || "", "");
        sourceCell.appendChild(sourceSelect);
      }

      var aggregateCell = document.createElement("td");
      var aggregateSelect = document.createElement("select");
      aggregateSelect.setAttribute("data-metric-field", "aggregation");
      appendSelectOptions(aggregateSelect, aggregations, metric.aggregation || "COUNT");
      aggregateCell.appendChild(aggregateSelect);

      var filterCell = document.createElement("td");
      var filterWrap = document.createElement("div");
      filterWrap.className = "fe-group-filter";
      var filterSelect = document.createElement("select");
      filterSelect.setAttribute("data-metric-field", "filterCode");
      appendSelectOptions(filterSelect, [
        { value: "NONE", label: "No filter" },
        { value: "IS_FINANCIAL", label: "Is Financial" },
        { value: "IS_SUCCESS", label: "Is Success" },
        { value: "IS_ONUS", label: "Is On-us" },
        { value: "IS_ORIGINAL", label: "Is Original" },
        { value: "TRANSACTION_TYPE", label: "Transaction Type" },
        { value: "SERVICE_FAMILY", label: "Service Family" },
        { value: "SERVICE_NAME", label: "Service Name" },
        { value: "RESPONSE_CODE", label: "Response Code" }
      ], metric.filterCode || "NONE");
      var filterInput = document.createElement("input");
      filterInput.type = "text";
      filterInput.value = metric.filterValue || "";
      filterInput.placeholder = "Value";
      filterInput.disabled = (metric.filterCode || "NONE") === "NONE";
      filterInput.setAttribute("data-metric-field", "filterValue");
      filterWrap.append(filterSelect, filterInput);
      filterCell.appendChild(filterWrap);

      var nullCell = document.createElement("td");
      var nullSelect = document.createElement("select");
      nullSelect.setAttribute("data-metric-field", "nullHandling");
      appendSelectOptions(nullSelect, ["IGNORE", "ZERO", "PRESERVE", "REJECT"],
        metric.nullHandling || "IGNORE");
      nullCell.appendChild(nullSelect);

      var accuracyCell = document.createElement("td");
      var accuracySelect = document.createElement("select");
      accuracySelect.setAttribute("data-metric-field", "accuracy");
      appendSelectOptions(accuracySelect, ["EXACT", "BOUNDED", "APPROXIMATE"],
        metric.accuracy || "EXACT");
      accuracyCell.appendChild(accuracySelect);

      var actionCell = document.createElement("td");
      var deleteButton = document.createElement("button");
      deleteButton.type = "button";
      deleteButton.className = "fe-icon-button fe-icon-button--danger";
      deleteButton.setAttribute("data-fe-action", "delete-group-metric");
      deleteButton.setAttribute("data-metric-index", index);
      deleteButton.setAttribute("aria-label", "Delete metric " + (index + 1));
      var deleteIcon = document.createElement("span");
      deleteIcon.className = "fa fa-trash";
      deleteIcon.setAttribute("aria-hidden", "true");
      deleteButton.appendChild(deleteIcon);
      actionCell.appendChild(deleteButton);

      row.append(orderCell, nameCell, modeCell, sourceCell, aggregateCell,
        filterCell, nullCell, accuracyCell, actionCell);
      body.appendChild(row);
    });

    if (!body.childNodes.length) {
      var emptyRow = document.createElement("tr");
      var emptyCell = document.createElement("td");
      emptyCell.colSpan = 9;
      emptyCell.className = "fe-group-metric-empty";
      emptyCell.textContent = "No metrics configured. Select Add Metric.";
      emptyRow.appendChild(emptyCell);
      body.appendChild(emptyRow);
    }
    renderGroupOutputPreview();
  }

  function renderGroupOutputPreview() {
    var output = byId("fe-group-output-preview");
    if (!output || !studio.functionDraft) {
      return;
    }
    var metrics = {};
    (studio.functionDraft.metrics || []).forEach(function (metric) {
      if (metric.enabled !== false) {
        metrics[metric.outputName || "metric"] =
          metric.aggregation === "DISTINCT" ? [] :
            metric.aggregation === "VALUE_COUNTS" ? {} : 0;
      }
    });
    var example = Object.assign({}, metrics);
    example[studio.functionDraft.groupOutputName || "groupKey"] = "EXAMPLE";
    output.textContent = JSON.stringify(
      studio.functionDraft.outputShape === "KEYED_OBJECT" ?
        { EXAMPLE: metrics } : [example],
      null, 2
    );
  }

  function renderDynamicParameterFields(schema) {
    var container = byId("fe-dynamic-parameter-fields");
    if (!container) {
      return;
    }
    container.replaceChildren();
    var fields = governedParameterFields(schema);
    parameterSections(schema, fields).forEach(function (section) {
      var sectionFields = fields.filter(function (field) {
        return (field.section || "GENERAL") === (section.code || "GENERAL") &&
          parameterIsVisible(field);
      });
      if (!sectionFields.length) {
        return;
      }
      var card = document.createElement("section");
      card.className = "fe-parameter-section";
      var header = document.createElement("header");
      var heading = document.createElement("h4");
      heading.textContent = section.title || "Parameters";
      header.appendChild(heading);
      if (section.help) {
        var sectionHelp = document.createElement("p");
        sectionHelp.textContent = section.help;
        header.appendChild(sectionHelp);
      }
      var grid = document.createElement("div");
      grid.className = "fe-parameter-section-grid";
      sectionFields.forEach(function (field) {
        var label = document.createElement("label");
        label.className = "fe-control fe-parameter-control fe-parameter-control--" +
          String(field.type || "text").toLowerCase();
        var caption = document.createElement("span");
        caption.textContent = field.label + (field.required ? " *" : "");
        label.append(caption, createParameterControl(field));
        if (field.help) {
          var help = document.createElement("small");
          help.textContent = field.help;
          label.appendChild(help);
        }
        grid.appendChild(label);
      });
      card.append(header, grid);
      container.appendChild(card);
    });
    if (!fields.length) {
      var empty = document.createElement("div");
      empty.className = "fe-parameter-empty";
      empty.innerHTML = "<span class='fa fa-check-circle' aria-hidden='true'></span>" +
        "<div><strong>No additional parameters</strong>" +
        "<p>This function uses the selected source, filter and window settings.</p></div>";
      container.appendChild(empty);
    }
  }

  function prepareFunctionDraft(useDefaults) {
    var selected = selectedFunction();
    var schema = selected && selected.parameterSchema || {
      editor: "STANDARD", defaults: {}, fields: []
    };
    var args = useDefaults ? {} : parseFunctionArgs();
    studio.functionDraft = Object.assign({}, cloneJson(schema.defaults || {}), args);
    if (schema.dedupeAware) {
      studio.functionDraft.dedupeKey =
        studio.functionDraft.dedupeKey || "TRANSACTION_ID";
      studio.functionDraft.onDuplicate =
        studio.functionDraft.onDuplicate || "IGNORE";
      studio.functionDraft.normalize =
        studio.functionDraft.normalize || "UPPER_TRIM";
      studio.functionDraft.invalidKey =
        studio.functionDraft.invalidKey || "SKIP";
    }
    if (schema.editor === "GROUP_AGGREGATE") {
      studio.functionDraft.metrics = cloneJson(
        args.metrics || (schema.defaults || {}).metrics || []
      );
    }
    return schema;
  }

  function openFunctionConfiguration(useDefaults) {
    var selected = selectedFunction();
    if (!selected) {
      notify("Select a function before configuring its parameters.", "error");
      return;
    }
    studio.functionConfigOpen = true;
    var schema = prepareFunctionDraft(Boolean(useDefaults));
    text("fe-function-drawer-title", selected.name + " Configuration");
    text("fe-function-drawer-help",
      selected.helpText || "Configure governed function parameters.");
    text("fe-function-drawer-state", selected.frameworkV2 === "Y" ?
      "FRAMEWORK V2" : "CORE");
    var groupEditor = byId("fe-group-editor");
    var standardEditor = byId("fe-standard-parameter-editor");
    var isGroup = schema.editor === "GROUP_AGGREGATE";
    groupEditor.hidden = !isGroup;
    standardEditor.hidden = isGroup;
    if (isGroup) {
      sourceFieldOptions(byId("fe-group-field"),
        studio.functionDraft.groupField || "SERVICE_NAME", "");
      value("fe-group-output-name",
        studio.functionDraft.groupOutputName || "groupKey");
      value("fe-group-output-shape",
        studio.functionDraft.outputShape || "ARRAY");
      value("fe-group-event-time",
        studio.functionDraft.eventTimeField || "TRANSACTION_DATE_TIME");
      checked("fe-group-include-null",
        Boolean(studio.functionDraft.includeNullKey));
      renderGroupMetricRows();
    } else {
      renderDynamicParameterFields(schema);
    }
    renderJsonOutputFields();
    showFunctionConfigTab("parameters", false);
    apex.theme.openRegion("fe-function-config-drawer");
  }

  function validateFunctionDraft() {
    var selected = selectedFunction();
    var schema = selected && selected.parameterSchema || {};
    if (selected && selected.code === "DIRECT_VALUE") {
      var directType = String(studio.functionDraft.valueType || "TEXT").toUpperCase();
      var directValue = String(studio.functionDraft.directValue === undefined ?
        "" : studio.functionDraft.directValue).trim();
      if (!["FIELD", "TEXT", "NUMBER", "BOOLEAN", "JSON", "NULL"]
        .includes(directType)) {
        return "Select a supported direct value type.";
      }
      if (directType === "FIELD" && !studio.functionDraft.sourceField) {
        return "Select the field used as the direct value.";
      }
      if (!["FIELD", "NULL"].includes(directType) && !directValue) {
        return "Enter the direct value.";
      }
      if (directType === "NUMBER" && !Number.isFinite(Number(directValue))) {
        return "Enter a valid numeric direct value.";
      }
      if (directType === "BOOLEAN" &&
          !["TRUE", "FALSE", "YES", "NO", "Y", "N", "1", "0"]
            .includes(directValue.toUpperCase())) {
        return "Boolean direct value must be True or False.";
      }
      if (directType === "JSON") {
        try {
          JSON.parse(directValue);
        } catch (ignore) {
          return "Enter a valid JSON direct value.";
        }
      }
    }
    if (schema.editor !== "GROUP_AGGREGATE") {
      var fields = governedParameterFields(schema).filter(function (field) {
        return parameterIsVisible(field);
      });
      var missing = fields.find(function (field) {
        return field.required && (
          studio.functionDraft[field.name] === "" ||
          studio.functionDraft[field.name] === null ||
          studio.functionDraft[field.name] === undefined ||
          (Array.isArray(studio.functionDraft[field.name]) &&
           !studio.functionDraft[field.name].length)
        );
      });
      if (missing) {
        return missing.label + " is required.";
      }
      var invalidNumber = fields.find(function (field) {
        var configured = studio.functionDraft[field.name];
        return field.type === "number" && configured !== "" &&
          configured !== null && configured !== undefined && (
            !Number.isFinite(Number(configured)) ||
            (field.min !== undefined && Number(configured) < Number(field.min)) ||
            (field.max !== undefined && Number(configured) > Number(field.max))
          );
      });
      if (invalidNumber) {
        return invalidNumber.label + " is outside the supported range.";
      }
      var invalidDuration = fields.find(function (field) {
        var configured = String(studio.functionDraft[field.name] || "").trim();
        if (!configured ||
            !["duration", "durationList"].includes(field.type)) {
          return false;
        }
        var values = field.type === "durationList" ?
          configured.split(",") : [configured];
        return values.some(function (entry) {
          return !/^\d+(?:\.\d+)?(?:s|m|h|d|w)$/i.test(entry.trim());
        });
      });
      if (invalidDuration) {
        return invalidDuration.label +
          " must use values such as 5m, 2h, 7d or 1w.";
      }
      if (studio.functionDraft.veryHighZThreshold !== undefined &&
          Number(studio.functionDraft.veryHighZThreshold) <
          Number(studio.functionDraft.zThreshold || 0)) {
        return "Very-high threshold must be greater than or equal to the high threshold.";
      }
      if (studio.functionDraft.lowThreshold !== undefined &&
          Number(studio.functionDraft.highThreshold) <
          Number(studio.functionDraft.lowThreshold)) {
        return "High threshold must be greater than or equal to the low threshold.";
      }
      return "";
    }
    if (!studio.functionDraft.groupField) {
      return "Select the field used to group transactions.";
    }
    if (!/^[A-Za-z][A-Za-z0-9_]{0,99}$/.test(
      studio.functionDraft.groupOutputName || ""
    )) {
      return "Group output name must be a valid JSON property name.";
    }
    if (!(studio.functionDraft.metrics || []).length) {
      return "Add at least one output metric.";
    }
    var seen = {};
    var numericAggregations = [
      "SUM", "AVG", "MEAN", "MIN", "MAX", "STDDEV", "VARIANCE"
    ];
    for (var index = 0; index < studio.functionDraft.metrics.length; index += 1) {
      var metric = studio.functionDraft.metrics[index];
      if (!/^[A-Za-z][A-Za-z0-9_]{0,99}$/.test(metric.outputName || "")) {
        return "Metric " + (index + 1) + " needs a valid output name.";
      }
      if (seen[metric.outputName]) {
        return "Metric output names must be unique.";
      }
      seen[metric.outputName] = true;
      if (metric.sourceMode === "FIELD" && !metric.sourceField &&
          metric.aggregation !== "ROW_COUNT") {
        return "Select a source field for " + metric.outputName + ".";
      }
      if (metric.filterCode !== "NONE" && !String(metric.filterValue || "").trim()) {
        return "Enter a filter value for " + metric.outputName + ".";
      }
      if (metric.sourceMode === "FIELD" &&
          numericAggregations.includes(metric.aggregation)) {
        var meta = (studio.data.metaFields || []).find(function (candidate) {
          return candidate.column === metric.sourceField;
        });
        if (meta && String(meta.dataType).toUpperCase() !== "NUMBER") {
          return metric.outputName + " requires a numeric source field for " +
            metric.aggregation + ".";
        }
      }
      if (metric.sourceMode === "CONSTANT" &&
          numericAggregations.includes(metric.aggregation) &&
          (!String(metric.constantValue === undefined ?
            "" : metric.constantValue).trim() ||
           !Number.isFinite(Number(metric.constantValue)))) {
        return metric.outputName + " requires a numeric constant for " +
          metric.aggregation + ".";
      }
    }
    return "";
  }

  function applyFunctionConfiguration(saveAfterApply) {
    var selected = selectedFunction();
    var schema = selected.parameterSchema || {};
    if (schema.editor === "GROUP_AGGREGATE") {
      studio.functionDraft.groupField = value("fe-group-field");
      studio.functionDraft.groupOutputName =
        value("fe-group-output-name").trim();
      studio.functionDraft.outputShape = value("fe-group-output-shape");
      studio.functionDraft.eventTimeField = value("fe-group-event-time");
      studio.functionDraft.includeNullKey = checked("fe-group-include-null");
      studio.functionDraft.dedupeKey = "TRANSACTION_ID";
      studio.functionDraft.metrics.forEach(function (metric) {
        if (metric.sourceMode === "CONSTANT") {
          var rawConstant = String(metric.constantValue === undefined ?
            "" : metric.constantValue).trim();
          var numericValue = Number(rawConstant);
          metric.constantNumber = rawConstant && Number.isFinite(numericValue) ?
            numericValue : null;
        } else {
          metric.constantNumber = null;
        }
      });
    }
    var validationError = validateFunctionDraft();
    if (validationError) {
      notify(validationError, "error");
      return;
    }
    if (selected.code === "DIRECT_VALUE") {
      var directType = String(studio.functionDraft.valueType || "TEXT").toUpperCase();
      var directSource = directType === "FIELD" ?
        String(studio.functionDraft.sourceField || "") : "";
      value("fe-source-field", directSource);
      value("fe-filter-code", "NONE");
      value("fe-filter-value", "");
      value("fe-window", "LIFETIME");
      value("fe-update-strategy", "REPLACE_VALUE");
      value("fe-output-type", directType === "FIELD" ?
        directFieldOutputType(directSource) :
        (directType === "TEXT" ? "VARCHAR2" :
          (directType === "NUMBER" ? "NUMBER" : "JSON")));
    }
    governedParameterFields(schema).forEach(function (field) {
      if (!field.bindTo) {
        return;
      }
      var configured = studio.functionDraft[field.name];
      if (field.bindTo === "sourceField" && configured) {
        value("fe-source-field", configured);
      } else if (field.bindTo === "filterCode" && configured) {
        value("fe-filter-code", configured);
      } else if (field.bindTo === "filterValue") {
        value("fe-filter-value", configured);
      }
    });
    value("fe-function-args", JSON.stringify(studio.functionDraft, null, 2));
    if (schema.editor === "GROUP_AGGREGATE") {
      value("fe-source-field", studio.functionDraft.groupField);
      value("fe-output-type", "JSON");
    }
    renderParameterSummary();
    updateFormulaPreview();
    renderJsonOutputFields();
    studio.functionConfigOpen = false;
    apex.theme.closeRegion("fe-function-config-drawer");
    if (saveAfterApply) {
      window.setTimeout(saveField, 0);
    } else {
      notify("Function configuration applied. Save the profile field to persist it.",
        "success");
    }
    return true;
  }

  function clearField() {
    studio.selectedField = null;
    value("fe-field-id", "");
    value("fe-json-path", "");
    value("fe-field-code", "");
    value("fe-field-name", "");
    value("fe-filter-code", "NONE");
    value("fe-filter-value", "");
    value("fe-window", "LIFETIME");
    value("fe-output-type", "NUMBER");
    value("fe-null-handling", "ZERO");
    value("fe-update-strategy", "MERGE_TOUCHED_ENTITY");
    value("fe-accuracy-mode", "EXACT");
    value("fe-state-retention", "");
    value("fe-function-args", "{}");
    checked("fe-field-daily", true);
    checked("fe-field-monthly", true);
    checked("fe-field-360", true);
    checked("fe-field-enabled", true);
    text("fe-selected-badge", "New field");
    var deleteButton = document.querySelector("[data-fe-action='delete-profile-field']");
    if (deleteButton) {
      deleteButton.disabled = true;
    }
    updateFormulaPreview();
    renderFunctionInsight();
    renderParameterSummary();
    renderJsonOutputFields();
    renderFields();
  }

  function selectField(fieldId) {
    var field = (studio.data.fields || []).find(function (candidate) {
      return Number(candidate.id) === Number(fieldId);
    });
    if (!field) {
      return;
    }
    studio.selectedField = field;
    try {
      window.localStorage.setItem(
        "sbos-fe-selected-field-" + studio.entity, String(field.id)
      );
      window.localStorage.setItem("sbos-fe-selected-entity", studio.entity);
    } catch (ignore) {
      // Storage is a convenience only.
    }
    value("fe-field-id", field.id);
    value("fe-json-path", field.jsonPath);
    value("fe-field-code", field.code);
    value("fe-field-name", field.name);
    value("fe-metric-code", field.metricCode);
    value("fe-function", field.functionCode);
    value("fe-source-field", field.sourceField || "");
    value("fe-filter-code", field.filterCode || "NONE");
    value("fe-filter-value", field.filterValue || "");
    value("fe-window", field.windowCode);
    value("fe-output-type", field.outputDataType);
    value("fe-null-handling", field.nullHandling);
    value("fe-update-strategy", field.updateStrategy);
    value("fe-accuracy-mode", field.accuracyMode || "EXACT");
    value("fe-state-retention", field.stateRetentionDays || "");
    value("fe-function-args", JSON.stringify(field.functionArgs || {}, null, 2));
    checked("fe-field-daily", field.dailyEnabled);
    checked("fe-field-monthly", field.monthlyEnabled);
    checked("fe-field-360", field.profile360Enabled);
    checked("fe-field-enabled", field.enabled);
    value("fe-formula-preview", field.expressionPreview || "");
    text("fe-selected-badge", field.code);
    var deleteButton = document.querySelector("[data-fe-action='delete-profile-field']");
    if (deleteButton) {
      deleteButton.disabled = false;
    }
    renderFunctionInsight();
    renderParameterSummary();
    renderJsonOutputFields();
    renderFields();
  }

  function renderFunctionInsight() {
    var panel = byId("fe-function-insight");
    renderDirectValueControls();
    if (!panel) {
      return;
    }
    var selected = (studio.data && studio.data.functions || []).find(function (item) {
      return item.code === value("fe-function");
    });
    if (!selected) {
      panel.innerHTML = "<div><span class='fa fa-bolt' aria-hidden='true'></span>" +
        "<strong>Select a function</strong></div>" +
        "<p>Its incremental state, accuracy and parameters will appear here.</p>";
      return;
    }
    var v2 = selected.frameworkV2 === "Y" ? "FRAMEWORK V2" : "CORE";
    panel.replaceChildren();
    var heading = document.createElement("div");
    var icon = document.createElement("span");
    icon.className = "fa fa-bolt";
    icon.setAttribute("aria-hidden", "true");
    var title = document.createElement("strong");
    title.textContent = selected.name;
    var engine = document.createElement("span");
    engine.className = "fe-native-badge " +
      (selected.frameworkV2 === "Y" ?
        "fe-native-badge--info" : "fe-native-badge--neutral");
    engine.textContent = v2;
    heading.append(icon, title, engine);
    var help = document.createElement("p");
    help.textContent = selected.helpText || "Incremental profile function.";
    var meta = document.createElement("small");
    meta.textContent = [
      "State: " + (selected.strategy || "STATEFUL"),
      "Cost: " + (selected.stateCost || "LOW"),
      "Default accuracy: " + (selected.accuracyMode || "EXACT")
    ].join(" · ");
    panel.append(heading, help, meta);
    if (!studio.selectedField) {
      value("fe-accuracy-mode", selected.accuracyMode || "EXACT");
      if (selected.parameterSchema &&
          Object.keys(selected.parameterSchema).length &&
          value("fe-function-args") === "{}") {
        value("fe-function-args", JSON.stringify(
          selected.parameterSchema.defaults || {}, null, 2
        ));
      }
    }
    renderParameterSummary();
  }

  function updateFormulaPreview() {
    var selected = (studio.data && studio.data.functions || []).find(function (item) {
      return item.code === value("fe-function");
    });
    if (!selected) {
      value("fe-formula-preview", "");
      return;
    }
    if (selected.code === "UNIQUE_GROUP_AGGREGATE") {
      var groupArgs = parseFunctionArgs();
      value("fe-formula-preview",
        "UNIQUE_GROUP_AGGREGATE(" +
        String(groupArgs.groupField || value("fe-source-field") || "GROUP_FIELD") +
        ", " + String((groupArgs.metrics || []).length) + " metrics, " +
        String(groupArgs.outputShape || "ARRAY") + ")");
      renderFunctionInsight();
      return;
    }
    if (selected.code === "DIRECT_VALUE") {
      var directArgs = parseFunctionArgs();
      var directType = String(directArgs.valueType || "TEXT").toUpperCase();
      var directValue = directType === "FIELD" ?
        String(directArgs.sourceField || "SELECT_FIELD") :
        (directType === "NULL" ? "null" :
          String(directArgs.directValue === undefined ? "" : directArgs.directValue));
      value("fe-formula-preview",
        "DIRECT_VALUE(" + directType + ", " + directValue + ")");
      renderFunctionInsight();
      return;
    }
    var metric = value("fe-metric-code") || "METRIC";
    var source = value("fe-source-field") || metric;
    var days = {
      LAST_7_DAYS: "7",
      LAST_30_DAYS: "30",
      LAST_90_DAYS: "90"
    }[value("fe-window")] || "ACTIVE_DAYS";
    var formula = String(selected.template || "")
      .replace(/\{source\}/g, source)
      .replace(/\{numerator\}/g, metric)
      .replace(/\{denominator\}/g, "TRANSACTION_COUNT")
      .replace(/\{count\}/g, metric)
      .replace(/\{days\}/g, days);
    value("fe-formula-preview", formula);
    renderFunctionInsight();
  }

  function loadProfileStudio(entity, preserveSelection) {
    studio.entity = entity === "CUSTOMER" ? "CUSTOMER" : "AGENT";
    setBusy(true);
    apex.server.process("FE_PROFILE_STUDIO", { x01: studio.entity }, { dataType: "json" })
      .done(function (data) {
        studio.data = data;
        renderSetup();
        renderFunctionAndMetaOptions();
        renderSample();
        var selectedId = preserveSelection && studio.selectedField ?
          studio.selectedField.id : null;
        if (!selectedId) {
          try {
            selectedId = window.localStorage.getItem(
              "sbos-fe-selected-field-" + studio.entity
            );
          } catch (ignore) {
            selectedId = null;
          }
        }
        var selectedExists = (studio.data.fields || []).some(function (field) {
          return Number(field.id) === Number(selectedId);
        });
        if (selectedExists) {
          selectField(selectedId);
        } else if ((studio.data.fields || []).length) {
          selectField(studio.data.fields[0].id);
        } else {
          clearField();
        }
      })
      .fail(function (request) {
        notify(errorMessage(request, "Profile Studio configuration could not be loaded."), "error");
      })
      .always(function () {
        setBusy(false);
      });
  }

  function setupPayload() {
    return {
      configId: studio.data.config.id,
      entityType: studio.entity,
      parallelWorkers: Number(value("fe-workers")),
      bucketCount: Number(value("fe-buckets")),
      scheduleMinutes: Number(value("fe-schedule")),
      watermarkColumn: value("fe-watermark"),
      dailyEnabled: checked("fe-target-daily") ? "Y" : "N",
      monthlyEnabled: checked("fe-target-monthly") ? "Y" : "N",
      profile360Enabled: checked("fe-target-360") ? "Y" : "N"
    };
  }

  function saveSetup() {
    setBusy(true);
    apex.server.process("FE_PROFILE_SAVE_SETUP",
      { x01: JSON.stringify(setupPayload()) }, { dataType: "json" })
      .done(function (data) {
        notify(data.message, "success");
        loadProfileStudio(studio.entity, true);
      })
      .fail(function (request) {
        notify(errorMessage(request, "Profile setup could not be saved."), "error");
      })
      .always(function () {
        setBusy(false);
      });
  }

  function validateLocalField() {
    var path = value("fe-json-path").trim();
    var code = value("fe-field-code").trim().toUpperCase();
    if (!/^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z][A-Za-z0-9_]*)*$/.test(path)) {
      return "Enter a valid dotted JSON path, for example metrics.totalTransactions.";
    }
    if (!/^[A-Z][A-Z0-9_]{2,99}$/.test(code)) {
      return "Field code must use uppercase letters, numbers and underscores.";
    }
    if (!value("fe-metric-code") || !value("fe-function")) {
      return "Choose a governed metric and function.";
    }
    try {
      var functionArgs = JSON.parse(value("fe-function-args") || "{}");
      if (value("fe-output-type").toUpperCase() === "JSON" &&
          Array.isArray(functionArgs.availableOutputFields) &&
          functionArgs.availableOutputFields.length &&
          (!Array.isArray(functionArgs.selectedOutputFields) ||
           !functionArgs.selectedOutputFields.length)) {
        return "Select at least one JSON output field.";
      }
    } catch (ignore) {
      return "Function Parameters must contain valid JSON.";
    }
    studio.functionDraft = parseFunctionArgs();
    return validateFunctionDraft();
  }

  function fieldPayload() {
    syncJsonOutputSelection();
    var path = value("fe-json-path").trim();
    var dot = path.lastIndexOf(".");
    return {
      configId: studio.data.config.id,
      fieldId: Number(value("fe-field-id")) || null,
      parentPath: dot > 0 ? path.slice(0, dot) : null,
      jsonPath: path,
      fieldCode: value("fe-field-code").trim().toUpperCase(),
      fieldName: value("fe-field-name").trim(),
      metricCode: value("fe-metric-code"),
      functionCode: value("fe-function"),
      sourceField: value("fe-source-field") || null,
      filterCode: value("fe-filter-code"),
      filterValue: value("fe-filter-value").trim() || null,
      windowCode: value("fe-window"),
      outputDataType: value("fe-output-type"),
      nullHandling: value("fe-null-handling"),
      updateStrategy: value("fe-update-strategy"),
      accuracyMode: value("fe-accuracy-mode"),
      stateRetentionDays: Number(value("fe-state-retention")) || null,
      functionArgs: JSON.parse(value("fe-function-args") || "{}"),
      dailyEnabled: checked("fe-field-daily") ? "Y" : "N",
      monthlyEnabled: checked("fe-field-monthly") ? "Y" : "N",
      profile360Enabled: checked("fe-field-360") ? "Y" : "N",
      enabled: checked("fe-field-enabled") ? "Y" : "N",
      displaySequence: studio.selectedField ?
        studio.selectedField.displaySequence : (studio.data.fields.length + 1) * 10
    };
  }

  function saveField() {
    var localError = validateLocalField();
    if (localError) {
      notify(localError, "error");
      return;
    }
    setBusy(true);
    apex.server.process("FE_PROFILE_SAVE_FIELD",
      { x01: JSON.stringify(fieldPayload()) }, { dataType: "json" })
      .done(function (data) {
        notify(data.message, "success");
        studio.selectedField = { id: data.fieldId };
        loadProfileStudio(studio.entity, true);
      })
      .fail(function (request) {
        notify(errorMessage(request, "Profile field could not be saved."), "error");
      })
      .always(function () {
        setBusy(false);
      });
  }

  function deleteField() {
    if (!studio.selectedField) {
      return;
    }
    apex.message.confirm("Delete " + studio.selectedField.jsonPath +
      " from this draft configuration?", function (confirmed) {
      if (!confirmed) {
        return;
      }
      apex.server.process("FE_PROFILE_DELETE_FIELD",
        { x01: studio.selectedField.id }, { dataType: "json" })
        .done(function (data) {
          notify(data.message, "success");
          studio.selectedField = null;
          loadProfileStudio(studio.entity, false);
        })
        .fail(function (request) {
          notify(errorMessage(request, "Profile field could not be deleted."), "error");
        });
    });
  }

  function validateProfile(showSuccess) {
    apex.server.process("FE_PROFILE_VALIDATE",
      { x01: studio.data.config.id }, { dataType: "json" })
      .done(function (data) {
        studio.data.validation = data;
        renderValidation(data);
        if (data.valid && showSuccess) {
          notify(data.message, "success");
        } else if (!data.valid) {
          notify((data.errors || []).join(" "), "error");
        }
      })
      .fail(function (request) {
        notify(errorMessage(request, "Profile validation could not be completed."), "error");
      });
  }

  function activateProfile() {
    if (!studio.data.validation || !studio.data.validation.valid) {
      validateProfile(true);
      return;
    }
    var dialog = byId("fe-activation-dialog");
    var forward = dialog &&
      dialog.querySelector('input[name="fe-activation-mode"][value="FORWARD_ONLY"]');
    if (!dialog || !forward) {
      notify("Activation dialog is unavailable. Refresh the page and try again.", "error");
      return;
    }
    forward.checked = true;
    value("fe-activation-date", "");
    value("fe-activation-reason",
      "Profile configuration updated from Profile & Decision Studio");
    updateActivationDialog();
    dialog.hidden = false;
    document.body.classList.add("fe-dialog-open");
    window.setTimeout(function () {
      forward.focus();
    }, 0);
  }

  function activationMode() {
    var selected = document.querySelector(
      '#fe-activation-dialog input[name="fe-activation-mode"]:checked'
    );
    return selected ? selected.value : "FORWARD_ONLY";
  }

  function updateActivationDialog() {
    var mode = activationMode();
    var dateWrap = byId("fe-activation-date-wrap");
    if (dateWrap) {
      dateWrap.hidden = mode !== "FROM_DATE";
    }
    document.querySelectorAll(".fe-activation-option").forEach(function (option) {
      var radio = option.querySelector('input[name="fe-activation-mode"]');
      option.classList.toggle("is-selected", Boolean(radio && radio.checked));
    });
    if (mode === "FROM_DATE") {
      text("fe-activation-summary-title", "Bounded historical rebuild");
      text("fe-activation-summary-text",
        "A parallel background job will apply this version from the selected date.");
    } else if (mode === "FULL_HISTORY") {
      text("fe-activation-summary-title", "Complete historical rebuild");
      text("fe-activation-summary-text",
        "Every historical entity will be recomputed. This can be expensive at scale.");
    } else {
      text("fe-activation-summary-title", "No historical scan");
      text("fe-activation-summary-text",
        "Existing profiles remain unchanged until a future transaction touches that entity.");
    }
  }

  function closeActivationDialog() {
    var dialog = byId("fe-activation-dialog");
    if (dialog) {
      dialog.hidden = true;
    }
    document.body.classList.remove("fe-dialog-open");
  }

  function submitActivation() {
    var mode = activationMode();
    var fromDate = value("fe-activation-date");
    var reason = String(value("fe-activation-reason") || "").trim();
    if (mode === "FROM_DATE" && !fromDate) {
      notify("Select the historical start date before activation.", "error");
      byId("fe-activation-date").focus();
      return;
    }
    if (!reason) {
      notify("Enter an activation reason.", "error");
      byId("fe-activation-reason").focus();
      return;
    }
    if (mode === "FULL_HISTORY") {
      apex.message.confirm(
        "Apply this version to complete history? This explicitly queues a full parallel rebuild.",
        function (confirmed) {
          if (confirmed) {
            executeActivation(mode, fromDate, reason);
          }
        }
      );
      return;
    }
    executeActivation(mode, fromDate, reason);
  }

  function executeActivation(mode, fromDate, reason) {
    closeActivationDialog();
    setBusy(true);
    apex.server.process("FE_PROFILE_ACTIVATE", {
      x01: studio.data.config.id,
      x02: reason,
      x03: mode,
      x04: fromDate || ""
    }, { dataType: "json" })
      .done(function (data) {
        notify(data.message, "success");
        loadProfileStudio(studio.entity, false);
        try {
          apex.region("fe_profile_versions_region").refresh();
          apex.region("fe_profile_rebuilds_region").refresh();
        } catch (ignore) {
          // Lazy regions may not yet be initialized.
        }
      })
      .fail(function (request) {
        notify(errorMessage(request, "Profile configuration could not be activated."), "error");
      })
      .always(function () {
        setBusy(false);
      });
  }

  function refreshRegions() {
    ["fe_agent_profiles_region", "fe_customer_profiles_region",
      "fe_profile_versions_region", "fe_profile_rebuilds_region"].forEach(function (id) {
      try {
        apex.region(id).refresh();
      } catch (ignore) {
        // Hidden/lazy native reports are safe to skip.
      }
    });
    loadProfileStudio(studio.entity, true);
  }

  function deleteProfileVersion(button) {
    var configId = Number(button.getAttribute("data-profile-config-id"));
    var versionNo = Number(button.getAttribute("data-version-no"));
    var entityType = String(button.getAttribute("data-entity-type") || "Profile");
    if (!configId || !versionNo) {
      notify("The selected profile version is invalid.", "error");
      return;
    }
    apex.message.confirm(
      "Delete " + entityType + " profile configuration version " + versionNo +
        "? This permanently removes its saved definition and compiled execution plan.",
      function (confirmed) {
        if (!confirmed) {
          return;
        }
        setBusy(true);
        button.disabled = true;
        apex.server.process("FE_PROFILE_DELETE_VERSION", {
          x01: configId,
          x02: versionNo
        }, { dataType: "json" })
          .done(function (data) {
            notify(data.message || "Profile configuration version deleted.", "success");
            try {
              apex.region("fe_profile_versions_region").refresh();
            } catch (ignore) {
              // The lazy report may not yet be initialized.
            }
          })
          .fail(function (request) {
            notify(errorMessage(request,
              "The profile configuration version could not be deleted."), "error");
            button.disabled = false;
          })
          .always(function () {
            setBusy(false);
          });
      }
    );
  }

  function deleteRebuildJob(button) {
    var rebuildJobId = Number(button.getAttribute("data-rebuild-job-id"));
    if (!rebuildJobId) {
      notify("The selected rebuild job is invalid.", "error");
      return;
    }
    apex.message.confirm(
      "Delete rebuild job " + rebuildJobId +
        "? Its bucket-level execution history will also be permanently removed.",
      function (confirmed) {
        if (!confirmed) {
          return;
        }
        setBusy(true);
        button.disabled = true;
        apex.server.process("FE_PROFILE_DELETE_REBUILD", {
          x01: rebuildJobId
        }, { dataType: "json" })
          .done(function (data) {
            notify(data.message || "Rebuild job deleted.", "success");
            try {
              apex.region("fe_profile_rebuilds_region").refresh();
            } catch (ignore) {
              // The lazy report may not yet be initialized.
            }
          })
          .fail(function (request) {
            notify(errorMessage(request,
              "The rebuild job could not be deleted."), "error");
            button.disabled = false;
          })
          .always(function () {
            setBusy(false);
          });
      }
    );
  }

  function setProfileVersionState(button, active) {
    var configId = Number(button.getAttribute("data-profile-config-id"));
    var versionNo = Number(button.getAttribute("data-version-no"));
    var verb = active ? "Activate" : "Deactivate";
    if (!configId || !versionNo) {
      notify("The selected profile version is invalid.", "error");
      return;
    }
    apex.message.confirm(
      verb + " profile processing for current version " + versionNo + "?",
      function (confirmed) {
        if (!confirmed) {
          return;
        }
        setBusy(true);
        button.disabled = true;
        apex.server.process("FE_PROFILE_SET_STATE", {
          x01: configId,
          x02: versionNo,
          x03: active ? "Y" : "N"
        }, { dataType: "json" })
          .done(function (data) {
            notify(data.message, "success");
            try {
              apex.region("fe_profile_versions_region").refresh();
            } catch (ignore) {
              // The lazy report may not yet be initialized.
            }
            loadProfileStudio(studio.entity, true);
          })
          .fail(function (request) {
            notify(errorMessage(request,
              "The profile processing state could not be changed."), "error");
            button.disabled = false;
          })
          .always(function () {
            setBusy(false);
          });
      }
    );
  }

  function refreshVersionView() {
    var regionId = studio.versionTab === "rebuilds" ?
      "fe_profile_rebuilds_region" : "fe_profile_versions_region";
    try {
      apex.region(regionId).refresh();
    } catch (ignore) {
      notify("The selected version view could not be refreshed.", "error");
    }
  }

  function runNow(button) {
    setBusy(true);
    button.disabled = true;
    apex.server.process("FE_RUN_NOW", {}, { dataType: "json" })
      .done(function (data) {
        notify(data.message || "Incremental micro-job submitted.", "success");
        window.setTimeout(refreshRegions, 1600);
      })
      .fail(function (request) {
        notify(errorMessage(request, "The incremental micro-job could not be submitted."), "error");
      })
      .always(function () {
        setBusy(false);
        button.disabled = false;
      });
  }

  function openSecurePage(processName, button) {
    button.disabled = true;
    apex.server.process(processName, {}, { dataType: "json" })
      .done(function (data) {
        if (data && data.url) {
          apex.navigation.redirect(data.url);
        } else {
          notify("A secure page link could not be generated.", "error");
        }
      })
      .fail(function (request) {
        notify(errorMessage(request, "The requested page could not be opened."), "error");
      })
      .always(function () {
        button.disabled = false;
      });
  }

  function setJsonTreeExpansion(expanded) {
    document.querySelectorAll("#fe-json-tree details").forEach(function (details) {
      details.open = expanded;
    });
    setJsonCodeExpansion(expanded);
  }

  function setJsonCodeExpansion(expanded) {
    document.querySelectorAll("#fe-json-code details").forEach(function (details) {
      var path = details.getAttribute("data-json-code-path");
      details.open = expanded;
      if (path) {
        studio.collapsedJsonCodePaths[path] = !expanded;
      }
    });
  }

  function copyProfileJson() {
    var source = JSON.stringify(studio.previewProfile || {}, null, 2);
    function copied() {
      notify("Beautified profile JSON copied to the clipboard.", "success");
    }
    if (window.navigator.clipboard && window.isSecureContext) {
      window.navigator.clipboard.writeText(source).then(copied, function () {
        notify("Clipboard access was denied by the browser.", "error");
      });
      return;
    }
    var textarea = document.createElement("textarea");
    textarea.value = source;
    textarea.setAttribute("readonly", "readonly");
    textarea.className = "u-vh";
    document.body.appendChild(textarea);
    textarea.select();
    try {
      document.execCommand("copy");
      copied();
    } catch (ignore) {
      notify("Clipboard access was denied by the browser.", "error");
    }
    textarea.remove();
  }


  function handleClick(event) {
    var tab = event.target.closest(".fe-tab[data-fe-tab]");
    var versionTab = event.target.closest(".fe-version-tab[data-fe-version-tab]");
    var functionTab = event.target.closest("[data-fe-function-tab]");
    var actionNode = event.target.closest("[data-fe-action]");
    var entity = event.target.closest("[data-fe-entity]");
    var step = event.target.closest("[data-fe-step]");
    if (tab) {
      showTab(tab.getAttribute("data-fe-tab"), false);
      return;
    }
    if (versionTab) {
      showVersionTab(versionTab.getAttribute("data-fe-version-tab"), false);
      return;
    }
    if (functionTab) {
      showFunctionConfigTab(
        functionTab.getAttribute("data-fe-function-tab"), false
      );
      return;
    }
    if (entity) {
      loadProfileStudio(entity.getAttribute("data-fe-entity"), false);
      return;
    }
    if (step) {
      value("fe-workers", Math.max(1, Math.min(64,
        Number(value("fe-workers") || 1) + Number(step.getAttribute("data-fe-step")))));
      return;
    }
    if (!actionNode) {
      return;
    }
    var action = actionNode.getAttribute("data-fe-action");
    if (action === "select-profile-field") {
      selectField(actionNode.getAttribute("data-field-id"));
    } else if (action === "toggle-path") {
      var path = actionNode.getAttribute("data-path");
      studio.collapsedPaths[path] = !studio.collapsedPaths[path];
      renderFields();
    } else if (action === "expand-field-paths") {
      setFieldPathExpansion(true);
    } else if (action === "collapse-field-paths") {
      setFieldPathExpansion(false);
    } else if (action === "add-profile-field") {
      clearField();
      byId("fe-json-path").focus();
    } else if (action === "add-object") {
      clearField();
      value("fe-json-path", "metrics.");
      byId("fe-json-path").focus();
    } else if (action === "configure-function") {
      openFunctionConfiguration(false);
    } else if (action === "select-all-json-output-fields") {
      setAllJsonOutputFields(true);
    } else if (action === "clear-all-json-output-fields") {
      setAllJsonOutputFields(false);
    } else if (action === "add-group-metric") {
      studio.functionDraft.metrics = studio.functionDraft.metrics || [];
      studio.functionDraft.metrics.push(
        groupMetricTemplate(studio.functionDraft.metrics.length)
      );
      renderGroupMetricRows();
    } else if (action === "delete-group-metric") {
      studio.functionDraft.metrics.splice(
        Number(actionNode.getAttribute("data-metric-index")), 1
      );
      renderGroupMetricRows();
    } else if (action === "reset-function-config") {
      openFunctionConfiguration(true);
    } else if (action === "cancel-function-config") {
      studio.functionConfigOpen = false;
      apex.theme.closeRegion("fe-function-config-drawer");
    } else if (action === "apply-function-config") {
      applyFunctionConfiguration(false);
    } else if (action === "apply-save-function-config") {
      applyFunctionConfiguration(true);
    } else if (action === "save-profile-setup") {
      saveSetup();
    } else if (action === "save-profile-field") {
      saveField();
    } else if (action === "delete-profile-field") {
      deleteField();
    } else if (action === "delete-profile-version") {
      deleteProfileVersion(actionNode);
    } else if (action === "delete-rebuild-job") {
      deleteRebuildJob(actionNode);
    } else if (action === "activate-profile-version") {
      setProfileVersionState(actionNode, true);
    } else if (action === "deactivate-profile-version") {
      setProfileVersionState(actionNode, false);
    } else if (action === "refresh-version-view") {
      refreshVersionView();
    } else if (action === "validate-field") {
      var localError = validateLocalField();
      notify(localError || "Field mapping is locally valid and ready to save.",
        localError ? "error" : "success");
    } else if (action === "test-profile") {
      validateProfile(true);
    } else if (action === "activate-profile") {
      activateProfile();
    } else if (action === "cancel-activation") {
      closeActivationDialog();
    } else if (action === "confirm-activation") {
      submitActivation();
    } else if (action === "load-profile-json") {
      loadProfileJson(false);
    } else if (action === "open-json-drawer") {
      openJsonDrawer();
    } else if (action === "expand-json-tree") {
      setJsonTreeExpansion(true);
    } else if (action === "collapse-json-tree") {
      setJsonTreeExpansion(false);
    } else if (action === "expand-json-code") {
      setJsonCodeExpansion(true);
    } else if (action === "collapse-json-code") {
      setJsonCodeExpansion(false);
    } else if (action === "copy-profile-json") {
      copyProfileJson();
    } else if (action === "format-json") {
      openJsonDrawer();
    } else if (action === "run-now") {
      runNow(actionNode);
    } else if (action === "open-bre") {
      openSecurePage("FE_BRE_URL", actionNode);
    }
  }

  function handleChange(event) {
    if (event.target &&
        event.target.matches("[data-json-output-field]")) {
      syncJsonOutputSelection();
      return;
    }
    if (event.target &&
        event.target.matches('input[name="fe-activation-mode"]')) {
      updateActivationDialog();
      return;
    }
    var metricControl = event.target.closest("[data-metric-field]");
    var parameterControl = event.target.closest("[data-parameter-name]");
    if (metricControl && studio.functionDraft) {
      var row = metricControl.closest("[data-metric-index]");
      var index = Number(row && row.getAttribute("data-metric-index"));
      var fieldName = metricControl.getAttribute("data-metric-field");
      var metric = (studio.functionDraft.metrics || [])[index];
      if (!metric) {
        return;
      }
      metric[fieldName] = metricControl.type === "checkbox" ?
        metricControl.checked : metricControl.value;
      if (fieldName === "constantValue") {
        var numeric = Number(metricControl.value);
        metric.constantNumber = metricControl.value !== "" &&
          Number.isFinite(numeric) ? numeric : null;
      }
      if (fieldName === "sourceMode" || fieldName === "filterCode") {
        renderGroupMetricRows();
      } else {
        renderGroupOutputPreview();
      }
      return;
    }
    if (parameterControl && studio.functionDraft) {
      var parameterName = parameterControl.getAttribute("data-parameter-name");
      var parameterType = parameterControl.getAttribute("data-parameter-type");
      if (parameterType === "sourceFieldList") {
        studio.functionDraft[parameterName] = Array.prototype.map.call(
          parameterControl.selectedOptions,
          function (option) { return option.value; }
        ).filter(Boolean);
      } else {
        studio.functionDraft[parameterName] =
          parameterControl.type === "checkbox" ?
            parameterControl.checked :
            (parameterControl.type === "number" &&
             parameterControl.value !== "" ?
              Number(parameterControl.value) : parameterControl.value);
      }
      var selected = selectedFunction();
      var schema = selected && selected.parameterSchema || {};
      if (governedParameterFields(schema).some(function (field) {
        return (field.visibleWhen &&
          field.visibleWhen.field === parameterName) ||
          (field.hiddenWhen &&
           field.hiddenWhen.field === parameterName);
      })) {
        renderDynamicParameterFields(schema);
      }
      return;
    }
    if (event.target && event.target.id === "fe-group-field" &&
        studio.functionDraft) {
      studio.functionDraft.groupField = event.target.value;
    } else if (event.target && event.target.id === "fe-group-output-name" &&
               studio.functionDraft) {
      studio.functionDraft.groupOutputName = event.target.value;
      renderGroupOutputPreview();
    } else if (event.target && event.target.id === "fe-group-output-shape" &&
               studio.functionDraft) {
      studio.functionDraft.outputShape = event.target.value;
      renderGroupOutputPreview();
    } else if (event.target && event.target.id === "fe-group-include-null" &&
               studio.functionDraft) {
      studio.functionDraft.includeNullKey = event.target.checked;
    }
  }

  function handleKeydown(event) {
    if (event.key === "Escape" && byId("fe-activation-dialog") &&
        !byId("fe-activation-dialog").hidden) {
      event.preventDefault();
      closeActivationDialog();
      return;
    }
    if (event.target && event.target.id === "fe-preview-entity-key" &&
        event.key === "Enter") {
      event.preventDefault();
      loadProfileJson(false);
      return;
    }
    var currentVersionTab = event.target.closest(
      ".fe-version-tab[data-fe-version-tab]"
    );
    if (currentVersionTab &&
        ["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) {
      var versionTabs = Array.prototype.slice.call(
        document.querySelectorAll(".fe-version-tab[data-fe-version-tab]")
      );
      var versionIndex = versionTabs.indexOf(currentVersionTab);
      if (event.key === "Home") {
        versionIndex = 0;
      } else if (event.key === "End") {
        versionIndex = versionTabs.length - 1;
      } else if (event.key === "ArrowLeft") {
        versionIndex = (versionIndex - 1 + versionTabs.length) % versionTabs.length;
      } else {
        versionIndex = (versionIndex + 1) % versionTabs.length;
      }
      event.preventDefault();
      showVersionTab(
        versionTabs[versionIndex].getAttribute("data-fe-version-tab"), true
      );
      return;
    }
    var current = event.target.closest(".fe-tab[data-fe-tab]");
    if (!current || !["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) {
      return;
    }
    var tabs = Array.prototype.slice.call(document.querySelectorAll(".fe-tab[data-fe-tab]"));
    var index = tabs.indexOf(current);
    if (event.key === "Home") {
      index = 0;
    } else if (event.key === "End") {
      index = tabs.length - 1;
    } else if (event.key === "ArrowLeft") {
      index = (index - 1 + tabs.length) % tabs.length;
    } else {
      index = (index + 1) % tabs.length;
    }
    event.preventDefault();
    showTab(tabs[index].getAttribute("data-fe-tab"), true);
  }


  apex.jQuery(function () {
    var page50 = byId("fe_header_region");
    document.addEventListener("click", handleClick);
    document.addEventListener("keydown", handleKeydown);
    document.addEventListener("change", handleChange);
    if (page50) {
      var initial = "profile";
      var initialEntity = "AGENT";
      try {
        initial = window.sessionStorage.getItem("sbos-fe-active-tab") || "profile";
        initialEntity = window.localStorage.getItem(
          "sbos-fe-selected-entity"
        ) || "AGENT";
      } catch (ignore) {
        // Storage is a convenience only.
      }
      studio.versionTab = "config";
      showTab(initial, false);
      byId("fe-field-search").addEventListener("input", function () {
        if (String(value("fe-field-search") || "").trim()) {
          studio.collapsedPaths = {};
        }
        renderFields();
      });
      byId("fe-json-tree-search").addEventListener("input", renderJsonTree);
      ["fe-function", "fe-metric-code", "fe-source-field", "fe-window",
        "fe-accuracy-mode", "fe-output-type"]
        .forEach(function (id) {
          byId(id).addEventListener("change", updateFormulaPreview);
        });
      byId("fe-output-type").addEventListener(
        "change", renderJsonOutputFields
      );
      byId("fe-function").addEventListener("change", function () {
        var selected = selectedFunction();
        var defaults = selected && selected.parameterSchema &&
          selected.parameterSchema.defaults || {};
        var governedMetric = {
          HOURLY_TRANSACTIONS: "HOURLY_TRANSACTION_COUNT",
          PEAK_HOURS: "PEAK_HOURS",
          CONTINUOUS_ABSENT_DAYS: "CONTINUOUS_ABSENT_DAYS"
        }[selected && selected.code];
        value("fe-function-args", JSON.stringify(defaults, null, 2));
        value("fe-output-type", selected && selected.outputDataType || "NUMBER");
        if (governedMetric) {
          value("fe-metric-code", governedMetric);
          value("fe-update-strategy", "REPLACE_VALUE");
        }
        if (selected && selected.code === "DIRECT_VALUE") {
          value("fe-source-field", "");
          value("fe-filter-code", "NONE");
          value("fe-filter-value", "");
          value("fe-window", "LIFETIME");
          value("fe-update-strategy", "REPLACE_VALUE");
        }
        renderParameterSummary();
        updateFormulaPreview();
        renderJsonOutputFields();
      });
      byId("fe-direct-value-type").addEventListener(
        "change", syncDirectValueControls
      );
      byId("fe-direct-value-input").addEventListener(
        "input", syncDirectValueControls
      );
      byId("fe-direct-value-field").addEventListener(
        "change", syncDirectValueControls
      );
      byId("fe-function-args").addEventListener(
        "change", renderJsonOutputFields
      );
      loadProfileStudio(initialEntity, false);
    }
  });
})(window.apex, document, window);
