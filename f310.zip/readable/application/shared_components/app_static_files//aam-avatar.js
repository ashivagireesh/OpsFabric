(function (global, document, apex) {
  "use strict";

  var state = {
    auditId: "", role: "", questions: [], index: 0, current: null,
    score: 0, criticalFail: false, connected: false, transcript: [],
    audio: null, recorder: null, responseSent: false, language: "en", voice: "female",
    introductionActive: false, pendingQuestion: null,
    initializationAudioContext: null, initializationRingTimer: null,
    auditSyncTimer: null, introductionTimer: null, starting: false, autoStartAttempts: 0,
    autoListenTimer: null, questionSpeechTimer: null, voiceAttempts: 0,
    mediaWaitAttempts: 0, evidenceRequired: false, evidenceConsent: false,
    consentResolved: false, recordingStartedAt: 0, evidenceStream: null,
    answers: {}, evidencePreviews: {}, reviewing: false, reportBlob: null, reportFile: null,
    auditorName: "", auditorStno: "", agentName: "", agentStno: "", startedAt: "",
    auditMode: "AVATAR_ONLY", evidenceCaptureQuestionId: "", evidenceCaptureTimer: null,
    evidenceCaptureAttempts: 0, pendingSupportAdvance: "", receivedEvidence: {},
    supportRetakePending: "", supportRetakeQuestionId: ""
  };

  var LANGUAGE_TAGS = {en:"en-IN", hi:"hi-IN", kn:"kn-IN", ta:"ta-IN", te:"te-IN"};
  var SYSTEM_TEXT = {
    en:{welcome:"Welcome. I will guide you through this agent quality audit.", complete:"The audit is complete. Your final score is {score} percent."},
    hi:{welcome:"स्वागत है। यह सहायक आपको एजेंट गुणवत्ता ऑडिट में मार्गदर्शन करेगा।", complete:"ऑडिट पूरा हो गया है। आपका अंतिम स्कोर {score} प्रतिशत है।"},
    kn:{welcome:"ಸ್ವಾಗತ. ಈ ಸಹಾಯಕವು ಏಜೆಂಟ್ ಗುಣಮಟ್ಟದ ಆಡಿಟ್‌ನಲ್ಲಿ ನಿಮಗೆ ಮಾರ್ಗದರ್ಶನ ನೀಡುತ್ತದೆ.", complete:"ಆಡಿಟ್ ಪೂರ್ಣಗೊಂಡಿದೆ. ನಿಮ್ಮ ಅಂತಿಮ ಅಂಕ {score} ಶೇಕಡಾ."},
    ta:{welcome:"வரவேற்கிறோம். இந்த உதவியாளர் முகவர் தரத் தணிக்கையில் உங்களுக்கு வழிகாட்டுவார்.", complete:"தணிக்கை முடிந்தது. உங்கள் இறுதி மதிப்பெண் {score} சதவீதம்."},
    te:{welcome:"స్వాగతం. ఈ సహాయకుడు ఏజెంట్ నాణ్యత ఆడిట్‌లో మీకు మార్గనిర్దేశం చేస్తారు.", complete:"ఆడిట్ పూర్తయింది. మీ తుది స్కోరు {score} శాతం."}
  };
  var OPTION_LABELS = {
    hi:{Yes:"हाँ", No:"नहीं", "Not Applicable":"लागू नहीं"},
    kn:{Yes:"ಹೌದು", No:"ಇಲ್ಲ", "Not Applicable":"ಅನ್ವಯಿಸುವುದಿಲ್ಲ"},
    ta:{Yes:"ஆம்", No:"இல்லை", "Not Applicable":"பொருந்தாது"},
    te:{Yes:"అవును", No:"కాదు", "Not Applicable":"వర్తించదు"}
  };
  var REPORT_LABELS = {
    hi:{
      auditTitle:"एजेंट ऑडिट रिपोर्ट", supportTitle:"सहायता कॉल रिपोर्ट",
      question:"नियंत्रण / प्रश्न", response:"उत्तर", notAnswered:"उत्तर नहीं दिया"
    },
    kn:{
      auditTitle:"ಏಜೆಂಟ್ ಆಡಿಟ್ ವರದಿ", supportTitle:"ಸಹಾಯ ಕರೆ ವರದಿ",
      question:"ನಿಯಂತ್ರಣ / ಪ್ರಶ್ನೆ", response:"ಉತ್ತರ", notAnswered:"ಉತ್ತರಿಸಲಾಗಿಲ್ಲ"
    },
    ta:{
      auditTitle:"முகவர் தணிக்கை அறிக்கை", supportTitle:"ஆதரவு அழைப்பு அறிக்கை",
      question:"கட்டுப்பாடு / கேள்வி", response:"பதில்", notAnswered:"பதிலளிக்கப்படவில்லை"
    },
    te:{
      auditTitle:"ఏజెంట్ ఆడిట్ నివేదిక", supportTitle:"సహాయ కాల్ నివేదిక",
      question:"నియంత్రణ / ప్రశ్న", response:"సమాధానం", notAnswered:"సమాధానం ఇవ్వలేదు"
    }
  };

  function byId(id) { return document.getElementById(id); }
  function callApi() { return global.SASWebRTCCall || {}; }
  function setText(id, value) { var node = byId(id); if (node) { node.textContent = value; } }
  function selectedValue(id, fallback) {
    try { return apex.item(id).getValue() || fallback; } catch (ignore) { return fallback; }
  }
  function isVideoMode() { return state.auditMode === "VIDEO"; }
  function systemText(key, score) {
    var messages = SYSTEM_TEXT[state.language] || SYSTEM_TEXT.en;
    return messages[key].replace("{score}", String(score == null ? "" : score));
  }
  function localizedOption(value) {
    var labels = OPTION_LABELS[state.language] || {};
    return labels[value] || value;
  }
  function reportText(report, key, fallback) {
    var labels = REPORT_LABELS[report.language] || {};
    return labels[key] || fallback;
  }
  function localizedReportAnswer(report, value) {
    var answer = String(value || reportText(report, "notAnswered", "Not answered"));
    var labels = OPTION_LABELS[report.language] || {};
    return labels[answer] || (
      answer === "Not answered" ? reportText(report, "notAnswered", answer) : answer
    );
  }
  function decodeMetadataText(value) {
    return String(value || "").replace(/\\([0-9a-fA-F]{4})/g, function (match, hex) {
      return String.fromCharCode(parseInt(hex, 16));
    });
  }
  function showPanel(show) {
    var panel = byId("aam-audit-panel");
    panel.hidden = !show;
    var shell = panel.closest(".webrtc-shell");
    var media = shell && shell.querySelector(".webrtc-media-grid");
    var videoMode = state.auditMode === "VIDEO";
    panel.classList.toggle("aam-panel--video", show && videoMode);
    if (shell) { shell.classList.toggle("is-video-audit", show && videoMode); }
    if (media) { media.style.display = show && !videoMode ? "none" : ""; }
    var badge = panel.querySelector(".aam-badge");
    var title = byId("aam-title");
    if (badge) { badge.textContent = videoMode ? "SUPPORT CALL" : "AI AVATAR"; }
    if (title) { title.textContent = videoMode ? "Agent Support Call" : "AIRA Agent Audit"; }
  }
  function setAvatarMode(mode) {
    var stage = byId("aam-avatar-stage");
    stage.classList.remove("is-speaking", "is-listening", "is-thinking");
    if (mode) { stage.classList.add("is-" + mode); }
    setText("aam-avatar-state", mode === "speaking" ? "Speaking" : mode === "listening" ? "Listening" : mode === "thinking" ? "Evaluating" : "Ready");
  }
  function setStatus(text, tone) {
    var node = byId("aam-audit-status");
    node.textContent = text;
    node.className = "aam-status aam-status--" + (tone || "ready");
  }
  function ajax(processName, payload) {
    return new Promise(function (resolve, reject) {
      apex.server.process(processName, payload || {}, {
        dataType: "json",
        success: resolve,
        error: function (request, status, error) {
          reject(new Error((request.responseJSON && request.responseJSON.error) || error || status || "APEX request failed"));
        }
      });
    });
  }
  function logEntry(actor, text, tone) {
    state.transcript.push({actor:actor, text:text, tone:tone || ""});
    var row = document.createElement("div");
    row.className = "aam-transcript-row " + (tone ? "aam-transcript-row--" + tone : "");
    var who = document.createElement("strong"); who.textContent = actor;
    var body = document.createElement("span"); body.textContent = text;
    row.appendChild(who); row.appendChild(body);
    byId("aam-transcript").appendChild(row);
    row.scrollIntoView({block:"nearest"});
  }
  function updateProgress() {
    var count = state.questions.length || Number(byId("aam-audit-panel").dataset.questionCount || 0);
    var current = Math.min(state.index + (state.current ? 1 : 0), count);
    setText("aam-progress-text", current + " of " + count);
    byId("aam-progress-fill").style.width = (count ? Math.round(100 * current / count) : 0) + "%";
    setText("aam-live-score", Math.round(state.score) + "%");
  }
  function stopSpeech() {
    if (state.audio) {
      state.audio.pause();
      state.audio.removeAttribute("src");
      state.audio = null;
    }
    if (global.speechSynthesis) { global.speechSynthesis.cancel(); }
  }
  function findLocalLanguageVoice() {
    if (!global.speechSynthesis) { return null; }
    var language = (LANGUAGE_TAGS[state.language] || LANGUAGE_TAGS.en).slice(0,2).toLowerCase();
    var matches = global.speechSynthesis.getVoices().filter(function (voice) {
      return voice.lang && voice.lang.toLowerCase().slice(0,2) === language && voice.localService === true;
    });
    if (!matches.length) { return null; }
    var preference = state.voice === "male" ? /male|rishi|ravi|valluvar/i : /female|lekha|veena|vani|sangeetha/i;
    return matches.find(function (voice) { return preference.test(voice.name); }) || matches[0];
  }
  function browserSpeak(text, preferredVoice, onComplete) {
    if (!global.speechSynthesis || !text) { return false; }
    global.speechSynthesis.cancel();
    var utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = LANGUAGE_TAGS[state.language] || LANGUAGE_TAGS.en;
    utterance.rate = state.voice === "slow_female" ? 0.82 : 0.94;
    utterance.pitch = state.voice === "male" ? 0.92 : 1.0;
    var matchingVoice = preferredVoice || findLocalLanguageVoice();
    if (matchingVoice) { utterance.voice = matchingVoice; }
    utterance.onstart = function () { setAvatarMode("speaking"); };
    utterance.onend = function () { setAvatarMode(""); if (onComplete) { onComplete(); } };
    utterance.onerror = function () { setAvatarMode(""); if (onComplete) { onComplete(); } };
    global.speechSynthesis.speak(utterance);
    return true;
  }
  function speak(text, audioBase64, onComplete) {
    stopSpeech();
    if (!text) { if (onComplete) { onComplete(); } return; }
    // A locally installed OS voice is usually more natural than eSpeak and
    // remains fully offline.  Server audio is retained as the deterministic
    // fallback when that language is not installed on the device.
    var localVoice = findLocalLanguageVoice();
    if (localVoice && browserSpeak(text, localVoice, onComplete)) { return; }
    if (!audioBase64) {
      if (!browserSpeak(text, null, onComplete) && onComplete) { onComplete(); }
      return;
    }
    var audio = new Audio("data:audio/mpeg;base64," + audioBase64);
    state.audio = audio;
    audio.onplay = function () { setAvatarMode("speaking"); };
    audio.onended = function () {
      if (state.audio === audio) { state.audio = null; }
      setAvatarMode(""); if (onComplete) { onComplete(); }
    };
    audio.onerror = function () {
      if (state.audio === audio) { state.audio = null; }
      if (!browserSpeak(text, null, onComplete) && onComplete) { onComplete(); }
    };
    audio.play().catch(function () {
      if (state.audio === audio) { state.audio = null; }
      if (!browserSpeak(text, null, onComplete) && onComplete) { onComplete(); }
    });
  }
  function stopInitializationRing() {
    if (state.initializationRingTimer) { global.clearInterval(state.initializationRingTimer); }
    state.initializationRingTimer = null;
    if (state.initializationAudioContext) {
      state.initializationAudioContext.close().catch(function () {});
      state.initializationAudioContext = null;
    }
  }
  function stopAuditSync() {
    if (state.auditSyncTimer) { global.clearInterval(state.auditSyncTimer); }
    state.auditSyncTimer = null;
  }
  function stopAutoListening() {
    if (state.autoListenTimer) { global.clearTimeout(state.autoListenTimer); }
    if (state.questionSpeechTimer) { global.clearTimeout(state.questionSpeechTimer); }
    state.autoListenTimer = null;
    state.questionSpeechTimer = null;
  }
  function requestAuditSync() {
    if (!state.connected || state.auditId) { stopAuditSync(); return; }
    var context = callApi().getContext && callApi().getContext();
    if (!context || !context.connected || context.caller) { stopAuditSync(); return; }
    callApi().sendAudit({type:"audit_sync"});
  }
  function startAuditSync() {
    stopAuditSync();
    requestAuditSync();
    state.auditSyncTimer = global.setInterval(requestAuditSync, 2000);
  }
  function startInitializationRing() {
    stopInitializationRing();
    var AudioContext = global.AudioContext || global.webkitAudioContext;
    if (!AudioContext) { return; }
    try {
      var context = new AudioContext();
      state.initializationAudioContext = context;
      function chime() {
        if (state.initializationAudioContext !== context) { return; }
        [0, 0.17].forEach(function (delay, index) {
          var oscillator = context.createOscillator();
          var gain = context.createGain();
          var start = context.currentTime + delay;
          oscillator.frequency.value = index ? 820 : 620;
          oscillator.type = "sine";
          gain.gain.setValueAtTime(0.0001, start);
          gain.gain.exponentialRampToValueAtTime(0.055, start + 0.025);
          gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.15);
          oscillator.connect(gain); gain.connect(context.destination);
          oscillator.start(start); oscillator.stop(start + 0.16);
        });
      }
      context.resume().then(chime).catch(function () {});
      state.initializationRingTimer = global.setInterval(chime, 1050);
    } catch (ignore) {}
  }
  function playRingtone(audioBase64, onComplete) {
    stopSpeech();
    if (!audioBase64) { onComplete(); return; }
    var completed = false;
    var finish = function () {
      if (completed) { return; }
      completed = true;
      if (state.audio === audio) { state.audio = null; }
      onComplete();
    };
    var audio = new Audio("data:audio/mpeg;base64," + audioBase64);
    state.audio = audio;
    audio.onplay = function () { setAvatarMode("thinking"); };
    audio.onended = finish;
    audio.onerror = finish;
    audio.play().catch(finish);
  }
  function presentAgentQuestion(question) {
    renderQuestion(question, false);
    logEntry("AIRA", question.text);
  }
  function playAuditIntroduction(welcomeText, ringtoneBase64, welcomeAudioBase64) {
    state.introductionActive = true;
    var completed = false;
    var finish = function () {
      if (completed) { return; }
      completed = true;
      if (state.introductionTimer) { global.clearTimeout(state.introductionTimer); }
      state.introductionTimer = null;
      state.introductionActive = false;
      if (state.pendingQuestion && state.consentResolved) {
        var pending = state.pendingQuestion;
        state.pendingQuestion = null;
        presentAgentQuestion(pending);
      }
    };
    // Browser audio callbacks are not guaranteed when autoplay is blocked or
    // an OS speech voice hangs. Never let audio prevent the questionnaire UI.
    state.introductionTimer = global.setTimeout(finish, 5000);
    playRingtone(ringtoneBase64, function () {
      speak(welcomeText, welcomeAudioBase64, function () {
        finish();
      });
    });
  }

  function acknowledgeAudit(messageType, message) {
    return callApi().sendAudit({
      type:"audit_received", audit_id:String(message.audit_id),
      message_type:messageType,
      question_id:message.question ? String(message.question.questionId || "") : ""
    });
  }
  function questionPayload(question) {
    return {
      questionId: String(question.questionId), sequence: question.sequence,
      category: question.category, text: question.text,
      responseType: question.responseType, options: question.options || [],
      critical: Boolean(question.critical), evidenceMode: question.evidenceMode || "NONE",
      language: state.language, voice: state.voice
    };
  }
  function clearResponses() { byId("aam-response-controls").replaceChildren(); }
  function answerButton(label, question, value) {
    var button = document.createElement("button");
    button.type = "button";
    button.className = "aam-answer";
    button.textContent = label;
    button.addEventListener("click", function () { submitAgentAnswer(question, value == null ? label : value, ""); });
    return button;
  }
  function renderEvidenceConsent() {
    stopAutoListening();
    clearResponses();
    setText("aam-category", "Recording consent");
    setText("aam-question", "Only questionnaire steps marked for evidence will capture media: agent voice, agent photo, location photo, or location video. Evidence remains on-premises for 30 days.");
    var host = byId("aam-response-controls");
    var notice = document.createElement("div");
    notice.className = "aam-evidence-consent";
    notice.innerHTML = isVideoMode()
      ? '<strong><span class="fa fa-circle" aria-hidden="true"></span> Support evidence consent</strong><span>The Checker may send a short image, audio clip, or video clip from the Checker device only when the configured support step requires it. You can review every item before closing.</span>'
      : '<strong><span class="fa fa-circle" aria-hidden="true"></span> Questionnaire-controlled capture</strong><span>Each evidence step names exactly what will be captured. Location camera access starts only after you select its capture button.</span>';
    var allow = document.createElement("button");
    allow.type = "button"; allow.className = "aam-answer aam-answer--consent";
    allow.textContent = "Allow once for this audit";
    allow.addEventListener("click", function () { resolveEvidenceConsent(true); });
    var decline = document.createElement("button");
    decline.type = "button"; decline.className = "aam-answer";
    decline.textContent = "Continue without stored evidence";
    decline.addEventListener("click", function () { resolveEvidenceConsent(false); });
    host.appendChild(notice); host.appendChild(allow); host.appendChild(decline);
    byId("aam-voice-answer").hidden = true;
    setAvatarMode("thinking"); setStatus("Your recording choice is required once", "active");
  }
  function resolveEvidenceConsent(consented) {
    if (state.consentResolved) { return; }
    state.consentResolved = true;
    state.evidenceConsent = Boolean(consented);
    callApi().sendAudit({type:"audit_evidence_consent", audit_id:state.auditId, consented:state.evidenceConsent});
    logEntry("AIRA", state.evidenceConsent ? (isVideoMode() ? "Checker-provided support evidence allowed for this call." : "Questionnaire-controlled evidence capture allowed for this audit.") : "Stored evidence declined; answer buttons remain available.", "system");
    setStatus(state.evidenceConsent ? "Recording consent granted" : "Continuing without stored evidence", state.evidenceConsent ? "active" : "ready");
    if (state.pendingQuestion && !state.introductionActive) {
      var pending = state.pendingQuestion;
      state.pendingQuestion = null;
      presentAgentQuestion(pending);
    }
  }
  function stopEvidenceStream() {
    if (state.evidenceStream) {
      state.evidenceStream.getTracks().forEach(function (track) { track.stop(); });
      state.evidenceStream = null;
    }
  }
  function imageFromVideo(video) {
    if (!video || !video.videoWidth || !video.videoHeight) {
      return Promise.reject(new Error("Camera preview is not ready."));
    }
    var width = Math.min(480, video.videoWidth);
    var height = Math.max(1, Math.round(video.videoHeight * width / video.videoWidth));
    var canvas = document.createElement("canvas");
    canvas.width = width; canvas.height = height;
    var context = canvas.getContext("2d", {alpha:false});
    if (!context) { return Promise.reject(new Error("Photo capture is unavailable.")); }
    context.drawImage(video, 0, 0, width, height);
    return new Promise(function (resolve, reject) {
      canvas.toBlob(function (blob) {
        if (!blob) { reject(new Error("Photo capture failed.")); return; }
        blobToBase64(blob).then(function (encoded) {
          resolve({base64:encoded, mimeType:"image/jpeg"});
        }).catch(reject);
      }, "image/jpeg", 0.62);
    });
  }
  function sendEvidenceCapture(question, encoded, mimeType, durationMs, previewBase64) {
    setAvatarMode("thinking");
    setStatus("Securing the required questionnaire evidence…", "active");
    if (!callApi().sendAudit({
      type:"audit_evidence_capture", audit_id:state.auditId,
      question_id:String(question.questionId),
      evidence_mode:question.evidenceMode,
      media_base64:encoded, mime_type:mimeType, duration_ms:durationMs,
      preview_base64:previewBase64 || ""
    })) {
      throw new Error("The secure call is not connected.");
    }
  }
  function clearVideoEvidenceTimer() {
    if (state.evidenceCaptureTimer) { global.clearTimeout(state.evidenceCaptureTimer); }
    state.evidenceCaptureTimer = null;
  }
  function videoEvidenceMime(candidates) {
    if (!global.MediaRecorder || !MediaRecorder.isTypeSupported) { return ""; }
    for (var index = 0; index < candidates.length; index += 1) {
      if (MediaRecorder.isTypeSupported(candidates[index])) { return candidates[index]; }
    }
    return "";
  }
  function scheduleVideoEvidenceRetry(question) {
    clearVideoEvidenceTimer();
    if (!state.current || String(state.current.questionId) !== String(question.questionId)) { return; }
    state.evidenceCaptureAttempts += 1;
    if (state.evidenceCaptureAttempts > 10) {
      state.evidenceCaptureQuestionId = "";
      setStatus("Live Checker media was not ready for evidence capture", "error");
      return;
    }
    state.evidenceCaptureTimer = global.setTimeout(function () {
      state.evidenceCaptureTimer = null;
      captureVideoAuditEvidence(question);
    }, 650);
  }
  function reviewCheckerSupportCapture(question, capture) {
    clearResponses();
    var panel = document.createElement("div");
    panel.className = "aam-capture-review";
    var title = document.createElement("strong");
    title.textContent = "Review Checker " + capture.kind + " before sending";
    var media;
    if (capture.kind === "video") {
      media = document.createElement("video");
      media.controls = true; media.playsInline = true;
      if (capture.posterSrc) { media.poster = capture.posterSrc; }
    } else if (capture.kind === "audio") {
      media = document.createElement("audio");
      media.controls = true;
    } else {
      media = document.createElement("img");
      media.alt = "Checker support evidence preview";
    }
    media.src = capture.src;
    panel.appendChild(title);
    panel.appendChild(media);
    var actions = evidenceReviewActions(question, function () {
      state.evidencePreviews[String(question.questionId)] = {
        kind:capture.kind,
        src:capture.src,
        poster:capture.posterSrc || "",
        mode:question.evidenceMode,
        stored:false
      };
      actions.replaceChildren();
      var sending = document.createElement("span");
      sending.className = "aam-capture-sent";
      sending.innerHTML = '<span class="fa fa-lock" aria-hidden="true"></span> Sending securely for Maker review…';
      actions.appendChild(sending);
      try {
        sendEvidenceCapture(
          question, capture.base64, capture.mimeType,
          capture.durationMs || 0, capture.posterBase64 || ""
        );
      } catch (error) {
        state.evidenceCaptureQuestionId = "";
        setStatus(error.message || "Support evidence could not be sent", "error");
      }
    }, null, function () {
      state.evidenceCaptureQuestionId = "";
      delete state.evidencePreviews[String(question.questionId)];
      clearResponses();
      var waiting = document.createElement("div");
      waiting.className = "aam-waiting";
      waiting.textContent = "Preparing a new Checker capture…";
      byId("aam-response-controls").appendChild(waiting);
      global.setTimeout(function () { captureVideoAuditEvidence(question); }, 0);
    });
    panel.appendChild(actions);
    byId("aam-response-controls").appendChild(panel);
    setAvatarMode("thinking");
    setStatus("Review the Checker capture · use it or retake", "active");
  }
  function recordCheckerSupportEvidence(question, stream) {
    var audioOnly = question.evidenceMode === "AGENT_AUDIO";
    var sourceTracks = audioOnly ? stream.getAudioTracks() : stream.getTracks();
    if (!sourceTracks.length || (!audioOnly && !stream.getVideoTracks().length)) {
      scheduleVideoEvidenceRetry(question);
      return;
    }
    var mimeType = audioOnly
      ? videoEvidenceMime(["audio/webm;codecs=opus", "audio/webm", "audio/ogg"])
      : videoEvidenceMime(["video/webm;codecs=vp8,opus", "video/webm", "video/mp4"]);
    if (!mimeType) {
      state.evidenceCaptureQuestionId = "";
      setStatus("This Checker browser cannot record the configured evidence", "error");
      return;
    }
    var evidenceStream = new MediaStream(sourceTracks);
    var chunks = [];
    var recorder;
    try {
      recorder = new MediaRecorder(
        evidenceStream,
        audioOnly ? {mimeType:mimeType, audioBitsPerSecond:32000}
          : {mimeType:mimeType, videoBitsPerSecond:140000, audioBitsPerSecond:24000}
      );
    } catch (error) {
      state.evidenceCaptureQuestionId = "";
      setStatus("Checker-side evidence recording could not start", "error");
      return;
    }
    var startedAt = Date.now();
    recorder.ondataavailable = function (event) {
      if (event.data && event.data.size) { chunks.push(event.data); }
    };
    recorder.onerror = function () {
      state.evidenceCaptureQuestionId = "";
      setStatus("Checker-side evidence recording failed", "error");
    };
    recorder.onstop = function () {
      var blob = new Blob(chunks, {type:recorder.mimeType || mimeType});
      var durationMs = Math.max(500, Math.min(Date.now() - startedAt, 10000));
      if (!blob.size || blob.size > 250000) {
        state.evidenceCaptureQuestionId = "";
        setStatus("Checker-side evidence was too large; capture skipped", "error");
        return;
      }
      var posterPromise = audioOnly
        ? Promise.resolve(null)
        : imageFromVideo(byId("webrtc-local-video")).catch(function () { return null; });
      Promise.all([blobToBase64(blob), posterPromise]).then(function (values) {
        var encoded = values[0];
        var poster = values[1];
        reviewCheckerSupportCapture(question, {
          kind:audioOnly ? "audio" : "video",
          src:"data:" + blob.type + ";base64," + encoded,
          base64:encoded,
          mimeType:blob.type,
          durationMs:durationMs,
          posterBase64:poster ? poster.base64 : "",
          posterSrc:poster ? "data:" + poster.mimeType + ";base64," + poster.base64 : ""
        });
      }).catch(function () {
        state.evidenceCaptureQuestionId = "";
        setStatus("Checker-side evidence could not be prepared", "error");
      });
    };
    setStatus(
      audioOnly
        ? "Recording Checker audio for Maker review"
        : "Recording Checker video for Maker review",
      "active"
    );
    recorder.start(250);
    global.setTimeout(function () {
      if (recorder.state !== "inactive") { recorder.stop(); }
    }, audioOnly ? 3000 : 4000);
  }
  function captureVideoAuditEvidence(question) {
    if (
      !isVideoMode() || state.role !== "AUDITOR" || !state.evidenceConsent
      || !question || (question.evidenceMode || "NONE") === "NONE"
      || state.evidencePreviews[String(question.questionId)]
    ) { return; }
    if (
      state.evidenceCaptureQuestionId
      && state.evidenceCaptureQuestionId !== String(question.questionId)
    ) { return; }
    state.evidenceCaptureQuestionId = String(question.questionId);
    var stream = callApi().getMediaStream && callApi().getMediaStream();
    if (!stream) {
      scheduleVideoEvidenceRetry(question);
      return;
    }
    state.evidenceCaptureAttempts = 0;
    if (question.evidenceMode === "AGENT_PHOTO" || question.evidenceMode === "LOCATION_PHOTO") {
      imageFromVideo(byId("webrtc-local-video")).then(function (photo) {
        reviewCheckerSupportCapture(question, {
          kind:"image",
          src:"data:" + photo.mimeType + ";base64," + photo.base64,
          base64:photo.base64,
          mimeType:photo.mimeType,
          durationMs:0,
          posterBase64:"",
          posterSrc:""
        });
      }).catch(function () {
        state.evidenceCaptureQuestionId = "";
        scheduleVideoEvidenceRetry(question);
      });
      return;
    }
    recordCheckerSupportEvidence(question, stream);
  }
  function evidenceReviewActions(question, useCapture, releaseCapture, retakeCapture) {
    var actions = document.createElement("div"); actions.className = "aam-capture-review-actions";
    var use = document.createElement("button"); use.type = "button"; use.className = "aam-answer aam-answer--consent";
    use.textContent = "Use this capture";
    use.addEventListener("click", function () { use.disabled = true; useCapture(); });
    var retake = document.createElement("button"); retake.type = "button"; retake.className = "aam-answer";
    retake.textContent = "Retake";
    retake.addEventListener("click", function () {
      if (releaseCapture) { releaseCapture(); }
      if (retakeCapture) { retakeCapture(); }
      else { clearResponses(); renderCaptureResponses(question); }
      setStatus("Previous capture discarded · capture again", "active");
    });
    actions.appendChild(use); actions.appendChild(retake);
    return actions;
  }
  function reviewImageCapture(question, photo) {
    clearResponses();
    var panel = document.createElement("div"); panel.className = "aam-capture-review";
    var title = document.createElement("strong"); title.textContent = "Review captured image";
    var image = document.createElement("img"); image.alt = "Captured audit evidence preview";
    image.src = "data:" + photo.mimeType + ";base64," + photo.base64;
    panel.appendChild(title); panel.appendChild(image);
    panel.appendChild(evidenceReviewActions(question, function () {
      state.evidencePreviews[String(question.questionId)] = {
        kind:"image", src:"data:" + photo.mimeType + ";base64," + photo.base64
      };
      sendEvidenceCapture(question, photo.base64, photo.mimeType, 0, "");
    }));
    byId("aam-response-controls").appendChild(panel);
    setAvatarMode("thinking"); setStatus("Review the image · use it or retake", "active");
  }
  function reviewVideoCapture(question, blob, durationMs, poster) {
    clearResponses();
    var panel = document.createElement("div"); panel.className = "aam-capture-review";
    var title = document.createElement("strong"); title.textContent = "Review captured location video";
    var video = document.createElement("video"); video.controls = true; video.playsInline = true;
    var videoUrl = URL.createObjectURL(blob); video.src = videoUrl;
    panel.appendChild(title); panel.appendChild(video);
    panel.appendChild(evidenceReviewActions(question, function () {
      blobToBase64(blob).then(function (encoded) {
        state.evidencePreviews[String(question.questionId)] = {
          kind:"video", src:"data:" + blob.type + ";base64," + encoded,
          poster:poster ? "data:" + poster.mimeType + ";base64," + poster.base64 : ""
        };
        URL.revokeObjectURL(videoUrl);
        sendEvidenceCapture(question, encoded, blob.type, durationMs, poster ? poster.base64 : "");
      }).catch(function () { setStatus("Location video could not be prepared.", "error"); });
    }, function () { URL.revokeObjectURL(videoUrl); }));
    byId("aam-response-controls").appendChild(panel);
    setAvatarMode("thinking"); setStatus("Review the video · use it or retake", "active");
  }
  function recordLocationVideo(question, video, button) {
    var stream = state.evidenceStream;
    if (!stream || !global.MediaRecorder) {
      setStatus("Location video recording is unavailable.", "error");
      return;
    }
    var mimeType = "";
    if (MediaRecorder.isTypeSupported("video/webm;codecs=vp8")) { mimeType = "video/webm;codecs=vp8"; }
    else if (MediaRecorder.isTypeSupported("video/webm")) { mimeType = "video/webm"; }
    else if (MediaRecorder.isTypeSupported("video/mp4")) { mimeType = "video/mp4"; }
    if (!mimeType) { setStatus("This browser cannot record location video.", "error"); return; }
    var chunks = [];
    var recorder;
    try {
      recorder = new MediaRecorder(stream, {mimeType:mimeType, videoBitsPerSecond:140000});
    } catch (error) {
      setStatus("Location video recording could not start.", "error");
      return;
    }
    var startedAt = Date.now();
    button.disabled = true;
    button.innerHTML = '<span class="fa fa-circle" aria-hidden="true"></span> Recording location · slowly pan';
    recorder.ondataavailable = function (event) { if (event.data && event.data.size) { chunks.push(event.data); } };
    recorder.onerror = function () {
      stopEvidenceStream(); button.disabled = false; button.textContent = "Retry Location Video";
      setStatus("Location video capture failed. Please retry.", "error");
    };
    recorder.onstop = function () {
      var blob = new Blob(chunks, {type:recorder.mimeType || mimeType});
      var durationMs = Math.max(500, Math.min(Date.now() - startedAt, 10000));
      var posterPromise = imageFromVideo(video).catch(function () { return null; });
      stopEvidenceStream();
      if (!blob.size || blob.size > 250000) {
        button.disabled = false; button.textContent = "Retry Location Video";
        setStatus("Location video was too large. Please retry and pan slowly.", "error");
        return;
      }
      posterPromise.then(function (poster) {
        reviewVideoCapture(question, blob, durationMs, poster);
      });
    };
    setAvatarMode("listening"); setStatus("Recording the work location for 4 seconds…", "active");
    recorder.start(250);
    global.setTimeout(function () { if (recorder.state !== "inactive") { recorder.stop(); } }, 4000);
  }
  function openEvidenceCamera(question, button) {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setStatus("A camera is not available in this browser.", "error");
      return;
    }
    var agentPhoto = question.evidenceMode === "AGENT_PHOTO";
    var cameraLabel = agentPhoto ? "agent camera" : "location camera";
    button.disabled = true;
    button.innerHTML = '<span class="fa fa-spinner fa-spin" aria-hidden="true"></span> Opening ' + cameraLabel;
    stopEvidenceStream();
    navigator.mediaDevices.getUserMedia({
      audio:false,
      video:{facingMode:{ideal:agentPhoto ? "user" : "environment"}, width:{ideal:640, max:960}, height:{ideal:480, max:720}}
    }).then(function (stream) {
      state.evidenceStream = stream;
      var host = byId("aam-response-controls");
      var video = document.createElement("video");
      video.className = "aam-evidence-preview";
      video.autoplay = true; video.muted = true; video.playsInline = true;
      video.srcObject = stream;
      host.insertBefore(video, button);
      video.play().catch(function () {});
      button.disabled = false;
      if (question.evidenceMode === "LOCATION_VIDEO") {
        button.textContent = "Record 4-second Location Video";
        button.onclick = function () { recordLocationVideo(question, video, button); };
      } else {
        button.textContent = agentPhoto ? "Capture Agent Photo" : "Capture Location Photo";
        button.onclick = function () {
          button.disabled = true;
          imageFromVideo(video).then(function (photo) {
            stopEvidenceStream();
            reviewImageCapture(question, photo);
          }).catch(function (error) {
            button.disabled = false; setStatus(error.message, "error");
          });
        };
      }
      setStatus(
        agentPhoto
          ? "Front camera preview is visible · frame the agent clearly"
          : "Rear camera preview is visible · frame the work location",
        "active"
      );
    }).catch(function () {
      button.disabled = false;
      button.textContent = agentPhoto ? "Retry Agent Camera" : "Retry Location Camera";
      setStatus(
        agentPhoto
          ? "Could not open the front camera. Allow camera access and retry."
          : "Could not open the rear camera. Allow camera access and retry.",
        "error"
      );
    });
  }
  function renderCaptureResponses(question) {
    var host = byId("aam-response-controls");
    var guide = document.createElement("div");
    guide.className = "aam-capture-guide";
    var labels = {
      AGENT_PHOTO:"Required: clear agent photo",
      LOCATION_PHOTO:"Required: work-location photo",
      LOCATION_VIDEO:"Required: short work-location video"
    };
    guide.innerHTML = '<strong>' + labels[question.evidenceMode] + '</strong><span>Nothing is captured until you select the button below.</span>';
    host.appendChild(guide);
    var capture = document.createElement("button");
    capture.type = "button"; capture.className = "aam-answer aam-answer--consent";
    capture.disabled = !state.evidenceConsent;
    capture.textContent = question.evidenceMode === "AGENT_PHOTO" ? "Open Front Camera" : "Open Rear Camera";
    capture.addEventListener("click", function () { openEvidenceCamera(question, capture); }, {once:true});
    var unable = answerButton("Unable to capture", question, "Unable");
    unable.addEventListener("click", stopEvidenceStream);
    host.appendChild(capture); host.appendChild(unable);
    var voice = byId("aam-voice-answer");
    voice.hidden = true;
    setAvatarMode("listening");
  }
  function renderAgentResponses(question) {
    clearResponses();
    var host = byId("aam-response-controls");
    var evidenceMode = question.evidenceMode || "NONE";
    if (
      isVideoMode()
      && evidenceMode !== "NONE"
      && state.evidenceConsent
      && state.receivedEvidence[String(question.questionId)] !== true
    ) {
      var evidenceWait = document.createElement("div");
      evidenceWait.className = "aam-waiting";
      evidenceWait.textContent = "Waiting for the Checker to capture, review, and send this evidence…";
      host.appendChild(evidenceWait);
      byId("aam-voice-answer").hidden = true;
      setAvatarMode("thinking");
      setStatus("Waiting for Checker evidence", "active");
      return;
    }
    if (!isVideoMode() && (evidenceMode === "AGENT_PHOTO" || evidenceMode === "LOCATION_PHOTO" || evidenceMode === "LOCATION_VIDEO")) {
      renderCaptureResponses(question);
      return;
    }
    if (question.responseType === "TEXT") {
      var textarea = document.createElement("textarea");
      textarea.className = "aam-answer-text";
      textarea.maxLength = 1000;
      textarea.placeholder = "Enter your answer";
      var submit = document.createElement("button");
      submit.type = "button";
      submit.className = "aam-answer";
      submit.textContent = "Submit answer";
      submit.addEventListener("click", function () {
        if (textarea.value.trim()) { submitAgentAnswer(question, textarea.value.trim(), ""); }
      });
      host.appendChild(textarea); host.appendChild(submit);
    } else {
      (question.options || []).forEach(function (option) { host.appendChild(answerButton(localizedOption(option), question, option)); });
    }
    var voice = byId("aam-voice-answer");
    voice.hidden = isVideoMode() || !(global.MediaRecorder && callApi().getAudioStream && callApi().getAudioStream());
    voice.disabled = false;
    voice.innerHTML = state.evidenceConsent && evidenceMode === "AGENT_AUDIO"
      ? '<span class="fa fa-circle" aria-hidden="true"></span> Record required agent voice'
      : '<span class="fa fa-microphone" aria-hidden="true"></span> Answer by voice (not stored)';
    setAvatarMode("listening");
  }
  function sendVoiceStatus(stage, detail) {
    if (!state.auditId || state.role !== "AGENT") { return; }
    callApi().sendAudit({
      type:"audit_voice_status", audit_id:state.auditId,
      stage:stage, detail:String(detail || "").slice(0,160)
    });
  }
  function scheduleAutomaticListening(question, delay) {
    stopAutoListening();
    if (!global.MediaRecorder) {
      sendVoiceStatus("unavailable", "MediaRecorder is not supported");
      setStatus("Automatic voice is unavailable in this browser · select an answer", "error");
      return;
    }
    if (!callApi().getAudioStream || !callApi().getAudioStream()) {
      state.mediaWaitAttempts += 1;
      if (state.mediaWaitAttempts <= 12) {
        setStatus("Preparing microphone for automatic voice answer…", "active");
        sendVoiceStatus("preparing", "Waiting for call microphone");
        state.autoListenTimer = global.setTimeout(function () {
          state.autoListenTimer = null;
          scheduleAutomaticListening(question, 0);
        }, 750);
      } else {
        sendVoiceStatus("unavailable", "Call microphone is not available");
        setStatus("Microphone is unavailable · select an answer", "error");
      }
      return;
    }
    state.mediaWaitAttempts = 0;
    sendVoiceStatus("armed", "Automatic listening is ready");
    state.autoListenTimer = global.setTimeout(function () {
      state.autoListenTimer = null;
      if (state.role === "AGENT" && state.current === question && !state.responseSent) {
        recognizeAnswer(true);
      }
    }, delay == null ? 450 : delay);
  }
  function speakQuestionThenListen(question) {
    stopAutoListening();
    state.questionSpeechTimer = global.setTimeout(function () {
      state.questionSpeechTimer = null;
      if (state.role === "AGENT" && state.current === question && !state.responseSent) {
        stopSpeech();
        if (!isVideoMode() && ((question.evidenceMode || "NONE") === "AGENT_AUDIO" || (question.evidenceMode || "NONE") === "NONE")) {
          scheduleAutomaticListening(question, 250);
        }
      }
    }, 15000);
    speak(question.text, question.audioBase64 || "", function () {
      if (state.questionSpeechTimer) { global.clearTimeout(state.questionSpeechTimer); }
      state.questionSpeechTimer = null;
      if (isVideoMode()) {
        setStatus("Enter the response while the Checker monitors live progress", "active");
      } else if ((question.evidenceMode || "NONE") === "AGENT_AUDIO" || (question.evidenceMode || "NONE") === "NONE") {
        scheduleAutomaticListening(question);
      } else {
        setStatus(state.evidenceConsent ? "Use the required capture action below" : "Evidence consent was not granted", state.evidenceConsent ? "active" : "error");
      }
    });
  }
  function renderQuestion(question, waiting) {
    state.current = question;
    state.responseSent = false;
    setText("aam-category", question.category + (question.critical ? " · Critical control" : ""));
    setText("aam-question", question.text);
    updateProgress();
    if (waiting) {
      clearResponses();
      var wait = document.createElement("div"); wait.className = "aam-waiting";
      wait.textContent = isVideoMode()
        ? "Waiting for Maker data entry · live audio/video remains visible"
        : "Waiting for the agent response…";
      byId("aam-response-controls").appendChild(wait);
      setAvatarMode("speaking");
      setStatus("Audit in progress", "active");
    } else {
      state.voiceAttempts = 0;
      state.mediaWaitAttempts = 0;
      renderAgentResponses(question);
      setStatus(question.evidenceMode && question.evidenceMode !== "NONE" ? "Required evidence step · listen to the question" : "Listen to the question", "active");
      speakQuestionThenListen(question);
    }
  }
  function askCurrent() {
    if (state.index >= state.questions.length) {
      if (isVideoMode()) { requestMakerSupportClose(); }
      else { requestParticipantReview(); }
      return;
    }
    var question = state.questions[state.index];
    clearVideoEvidenceTimer();
    state.evidenceCaptureQuestionId = "";
    state.evidenceCaptureAttempts = 0;
    renderQuestion(question, true);
    logEntry("AIRA", question.text);
    callApi().sendAudit({type:"audit_question", audit_id:state.auditId, question:questionPayload(question)});
    if (isVideoMode()) {
      setStatus("Maker is updating support status · prepare the required Checker evidence", "active");
      captureVideoAuditEvidence(question);
    } else {
      setStatus("Question delivered to the Maker · voice plays on receiver only", "active");
    }
  }
  async function startAudit() {
    state.auditMode = selectedValue("P40_AUDIT_MODE", "AVATAR_ONLY") === "VIDEO"
      ? "VIDEO" : "AVATAR_ONLY";
    var context = callApi().getContext && callApi().getContext();
    if (!context || !context.connected || !context.caller) {
      setStatus("The outgoing audit call must be connected before initialization.", "error");
      showPanel(true);
      return;
    }
    if (state.starting || state.auditId) { return; }
    state.starting = true;
    try {
      showPanel(true); setAvatarMode("thinking"); setStatus(isVideoMode() ? "Initializing support call…" : "Initializing audit…", "active");
      startInitializationRing();
      state.language = selectedValue("P40_AUDIT_LANGUAGE", "en");
      state.voice = selectedValue("P40_AVATAR_VOICE", "female");
      var result = await ajax("START_AAM_AUDIT", {
        x01:context.peer, x02:context.callId, x03:state.language, x04:state.auditMode
      });
      state.auditId = String(result.auditId);
      state.autoStartAttempts = 0;
      state.role = "AUDITOR";
      state.auditorName = result.auditorName || "Auditor";
      state.auditorStno = result.auditorStno || "";
      state.agentStno = result.agentStno || context.peer || "";
      var peerSelect = byId("P40_PEER");
      state.agentName = peerSelect && peerSelect.selectedOptions && peerSelect.selectedOptions.length
        ? peerSelect.selectedOptions[0].textContent.trim() : state.agentStno;
      state.startedAt = new Date().toISOString();
      state.questions = (result.questions || []).map(function (question) {
        question.category = decodeMetadataText(question.category);
        question.text = decodeMetadataText(question.text);
        return question;
      });
      state.index = 0; state.score = 0; state.criticalFail = false;
      state.answers = {}; state.evidencePreviews = {}; state.receivedEvidence = {}; state.reviewing = false; state.reportBlob = null; state.reportFile = null;
      state.supportRetakePending = ""; state.supportRetakeQuestionId = "";
      state.transcript = []; byId("aam-transcript").replaceChildren();
      byId("aam-audit-panel").dataset.questionCount = String(state.questions.length);
      setText("aam-audit-id", (isVideoMode() ? "Support #" : "Audit #") + state.auditId);
      callApi().sendAudit({
        type:"audit_start", audit_id:state.auditId, title:result.title,
        question_count:state.questions.length, language:state.language,
        voice:state.voice, audit_mode:state.auditMode,
        welcome:isVideoMode()
          ? "Support call connected. The Maker will update status while the Checker sends supporting evidence."
          : systemText("welcome"),
        auditor_name:state.auditorName, auditor_stno:state.auditorStno,
        agent_name:state.agentName, agent_stno:state.agentStno
      });
      logEntry("AIRA", (isVideoMode() ? "Secure support call" : "Secure agent audit") + " started with " + state.questions.length + " steps.", "system");
      askCurrent();
    } catch (error) {
      setAvatarMode(""); setStatus(error.message, "error");
      state.starting = false;
      state.autoStartAttempts += 1;
      var retryContext = callApi().getContext && callApi().getContext();
      if (state.autoStartAttempts < 3 && retryContext && retryContext.connected && retryContext.caller) {
        setStatus("Audit initialization is retrying automatically…", "active");
        global.setTimeout(startAudit, 1200 * state.autoStartAttempts);
      }
    } finally {
      stopInitializationRing();
    }
  }
  function submitAgentAnswer(question, value, note) {
    if (state.role !== "AGENT" || state.responseSent) { return; }
    state.responseSent = true;
    stopAutoListening();
    stopSpeech();
    if (state.recorder && state.recorder.state !== "inactive") { state.recorder.stop(); }
    state.answers[String(question.questionId)] = {value:value, note:note || "", finding:false};
    callApi().sendAudit({type:"audit_answer", audit_id:state.auditId, question_id:String(question.questionId), value:value, note:note || ""});
    logEntry("You", value, "answer");
    clearResponses();
    var wait = document.createElement("div"); wait.className = "aam-waiting"; wait.textContent = "Answer sent securely. Waiting for the next question…";
    byId("aam-response-controls").appendChild(wait);
    setAvatarMode("thinking"); setStatus("Answer submitted", "ready");
  }
  function advanceSupportAfterEvidence(questionId) {
    if (
      !state.pendingSupportAdvance
      || String(state.pendingSupportAdvance) !== String(questionId)
    ) { return; }
    state.pendingSupportAdvance = "";
    state.current = null;
    state.index += 1;
    updateProgress();
    global.setTimeout(askCurrent, 650);
  }
  async function receiveAnswer(message) {
    if (state.role !== "AUDITOR" || String(message.audit_id) !== state.auditId || (!state.current && !state.reviewing)) { return; }
    setAvatarMode("thinking");
    logEntry("Agent", message.value, "answer");
    try {
      var result = await ajax("SAVE_AAM_RESPONSE", {
        x01:state.auditId, x02:String(message.question_id), x03:message.value, x04:message.note || ""
      });
      state.score = Number(result.runningScore || 0);
      state.criticalFail = state.criticalFail || result.criticalFail === true;
      state.answers[String(message.question_id)] = {
        value:message.value, note:message.note || "", finding:result.finding === true
      };
      callApi().sendAudit({
        type:"audit_progress", audit_id:state.auditId, score:state.score,
        critical_fail:state.criticalFail, completed:state.reviewing ? state.questions.length : state.index + 1,
        total:state.questions.length
      });
      logEntry("AIRA", result.finding ? "Response recorded · finding raised" : "Response recorded · control passed", result.finding ? "finding" : "pass");
      var answeredQuestion = state.current;
      var preview = answeredQuestion
        ? state.evidencePreviews[String(answeredQuestion.questionId)]
        : null;
      var waitForSupportEvidence = Boolean(
        isVideoMode()
        && state.evidenceConsent
        && answeredQuestion
        && (answeredQuestion.evidenceMode || "NONE") !== "NONE"
        && (!preview || preview.stored !== true)
      );
      if (waitForSupportEvidence) {
        state.pendingSupportAdvance = String(answeredQuestion.questionId);
        setStatus("Maker status saved · send the reviewed Checker evidence to continue", "active");
        return;
      }
      state.current = null;
      if (state.reviewing) {
        updateProgress();
        callApi().sendAudit({type:"audit_review_start", audit_id:state.auditId, question_count:state.questions.length});
        setText("aam-category", "Participant final review");
        setText("aam-question", "The audited participant is reviewing responses and may retake evidence before final submission.");
        clearResponses();
        var reviewWait = document.createElement("div"); reviewWait.className = "aam-waiting";
        reviewWait.textContent = "Waiting for the participant to submit the reviewed audit…";
        byId("aam-response-controls").appendChild(reviewWait);
        setStatus("Participant review in progress", "active");
      } else {
        state.index += 1; updateProgress();
        global.setTimeout(askCurrent, 650);
      }
    } catch (error) {
      setStatus(error.message, "error"); setAvatarMode("");
    }
  }
  function reviewEditor(question, answer) {
    var input;
    var options = question.options || [];
    if (options.length) {
      input = document.createElement("select");
      options.forEach(function (option) {
        var item = document.createElement("option");
        item.value = option; item.textContent = localizedOption(option);
        if (String(answer.value) === String(option)) { item.selected = true; }
        input.appendChild(item);
      });
    } else {
      input = document.createElement("input");
      input.type = "text"; input.maxLength = 1000; input.value = answer.value || "";
    }
    input.className = "aam-review-input";
    input.dataset.questionId = String(question.questionId);
    input.dataset.originalValue = answer.value || "";
    return input;
  }
  function retakeEvidenceQuestion(question) {
    state.current = question; state.responseSent = false;
    setText("aam-category", question.category + " · Retake");
    setText("aam-question", question.text);
    renderAgentResponses(question);
    setStatus("Retake the evidence on this device", "active");
    speakQuestionThenListen(question);
  }
  function finalReviewEvidencePreview(question) {
    var preview = state.evidencePreviews[String(question.questionId)];
    if (!preview || !preview.src) { return null; }
    var media;
    if (preview.kind === "video") {
      media = document.createElement("video");
      media.controls = true; media.playsInline = true;
      if (preview.poster) { media.poster = preview.poster; }
    } else if (preview.kind === "audio") {
      media = document.createElement("audio");
      media.controls = true;
    } else {
      media = document.createElement("img");
      media.alt = "Captured audit evidence";
    }
    media.className = "aam-review-media";
    media.src = preview.src;
    return media;
  }
  function renderFinalReview() {
    if (state.role !== "AGENT") { return; }
    state.reviewing = true; state.current = null;
    state.index = state.questions.length;
    clearResponses(); updateProgress(); setAvatarMode("thinking");
    setText("aam-category", "Final review before submission");
    setText("aam-question", "Review every response. Edit an answer or request an evidence retake before submitting the audit.");
    var host = byId("aam-response-controls");
    var list = document.createElement("div"); list.className = "aam-review-list";
    state.questions.forEach(function (question, position) {
      var answer = state.answers[String(question.questionId)] || {value:"Not answered", note:""};
      var row = document.createElement("div"); row.className = "aam-review-row";
      var heading = document.createElement("div"); heading.className = "aam-review-question";
      heading.innerHTML = "<strong>" + (position + 1) + ". " + question.category + "</strong><span></span>";
      heading.querySelector("span").textContent = question.text;
      row.appendChild(heading);
      if ((question.evidenceMode || "NONE") !== "NONE") {
        var evidence = document.createElement("div"); evidence.className = "aam-review-evidence";
        var preview = finalReviewEvidencePreview(question);
        if (preview) { evidence.appendChild(preview); }
        var evidenceDetails = document.createElement("div"); evidenceDetails.className = "aam-review-evidence-details";
        var evidenceText = document.createElement("span");
        evidenceText.textContent = answer.value + (answer.note ? " · " + answer.note : "");
        var retake = document.createElement("button"); retake.type = "button"; retake.className = "aam-review-retake";
        retake.textContent = "Retake";
        retake.addEventListener("click", function () { retakeEvidenceQuestion(question); });
        evidenceDetails.appendChild(evidenceText); evidenceDetails.appendChild(retake);
        evidence.appendChild(evidenceDetails); row.appendChild(evidence);
      } else {
        row.appendChild(reviewEditor(question, answer));
      }
      list.appendChild(row);
    });
    var actions = document.createElement("div"); actions.className = "aam-review-actions";
    var submit = document.createElement("button");
    submit.type = "button"; submit.className = "aam-answer aam-answer--consent";
    submit.innerHTML = '<span class="fa fa-check" aria-hidden="true"></span> Submit Final Audit';
    submit.addEventListener("click", function () { finalizeReviewedAudit(submit); });
    actions.appendChild(submit); host.appendChild(list); host.appendChild(actions);
    appendStoredEvidenceGallery(host, state.auditId, "Captured Evidence Review");
    setStatus("Final review required", "active");
  }
  async function finalizeReviewedAudit(button) {
    if (button.disabled) { return; }
    button.disabled = true;
    button.innerHTML = '<span class="fa fa-spinner fa-spin" aria-hidden="true"></span> Sending reviewed answers';
    try {
      var inputs = Array.prototype.slice.call(byId("aam-response-controls").querySelectorAll(".aam-review-input"));
      var changes = [];
      for (var index = 0; index < inputs.length; index += 1) {
        var input = inputs[index];
        if (input.value.trim() && input.value !== input.dataset.originalValue) {
          changes.push({question_id:input.dataset.questionId, value:input.value.trim()});
          state.answers[input.dataset.questionId] = {
            value:input.value.trim(), note:"Edited by participant during final review", finding:false
          };
        }
      }
      if (!callApi().sendAudit({type:"audit_review_submit", audit_id:state.auditId, answers:changes})) {
        throw new Error("The secure audit connection is unavailable.");
      }
      clearResponses();
      var wait = document.createElement("div"); wait.className = "aam-waiting";
      wait.textContent = "Reviewed answers submitted. Waiting for the auditor to finalize the report…";
      byId("aam-response-controls").appendChild(wait);
      setStatus("Review submitted", "active");
    } catch (error) {
      button.disabled = false; button.textContent = "Submit Final Audit";
      setStatus(error.message, "error");
    }
  }
  function appendReadOnlyAuditRows(host, allowSupportRetake) {
    var list = document.createElement("div");
    list.className = "aam-review-list";
    state.questions.forEach(function (question, position) {
      var answer = state.answers[String(question.questionId)] || {value:"Not answered", note:""};
      var row = document.createElement("div");
      row.className = "aam-review-row";
      var heading = document.createElement("div");
      heading.className = "aam-review-question";
      heading.innerHTML = "<strong>" + (position + 1) + ". " + question.category + "</strong><span></span>";
      heading.querySelector("span").textContent = question.text;
      var result = document.createElement("div");
      result.className = "aam-review-evidence-details";
      var answerText = document.createElement("strong");
      answerText.textContent = answer.value || "Not answered";
      result.appendChild(answerText);
      if ((question.evidenceMode || "NONE") !== "NONE") {
        var evidence = document.createElement("span");
        evidence.textContent = state.evidencePreviews[String(question.questionId)]
          ? "Checker-side evidence captured"
          : "No stored evidence";
        result.appendChild(evidence);
        if (allowSupportRetake && state.evidencePreviews[String(question.questionId)]) {
          var retake = document.createElement("button");
          retake.type = "button";
          retake.className = "aam-review-retake";
          retake.disabled = Boolean(state.supportRetakePending);
          retake.innerHTML = '<span class="fa fa-refresh" aria-hidden="true"></span> Request Retake';
          retake.addEventListener("click", function () {
            if (state.supportRetakePending) { return; }
            state.supportRetakePending = String(question.questionId);
            retake.disabled = true;
            retake.innerHTML = '<span class="fa fa-spinner fa-spin" aria-hidden="true"></span> Retake requested';
            if (!callApi().sendAudit({
              type:"audit_retake_request",
              audit_id:state.auditId,
              question_id:String(question.questionId),
              evidence_mode:question.evidenceMode
            })) {
              state.supportRetakePending = "";
              retake.disabled = false;
              retake.innerHTML = '<span class="fa fa-refresh" aria-hidden="true"></span> Request Retake';
              setStatus("The retake request could not be sent.", "error");
              return;
            }
            setText("aam-question", "Retake requested for " + question.category + ". Waiting for the Checker to send replacement evidence.");
            setStatus("Waiting for Checker retake", "active");
          });
          result.appendChild(retake);
        }
      }
      row.appendChild(heading);
      row.appendChild(result);
      list.appendChild(row);
    });
    host.appendChild(list);
  }
  function requestCheckerFinalConsent() {
    if (state.role !== "AUDITOR" || state.reviewing) { return; }
    state.reviewing = true;
    state.current = null;
    state.index = state.questions.length;
    clearVideoEvidenceTimer();
    updateProgress();
    clearResponses();
    setAvatarMode("thinking");
    setText("aam-category", "Checker final confirmation");
    setText("aam-question", "Review the completed Maker entries and captured evidence progress, then confirm the final audit output.");
    var host = byId("aam-response-controls");
    appendReadOnlyAuditRows(host);
    appendStoredEvidenceGallery(host, state.auditId, "Checker Evidence Review");
    var actions = document.createElement("div");
    actions.className = "aam-review-actions";
    var confirm = document.createElement("button");
    confirm.type = "button";
    confirm.className = "aam-answer aam-answer--consent";
    confirm.innerHTML = '<span class="fa fa-check-circle" aria-hidden="true"></span> Confirm &amp; Generate Final Output';
    confirm.addEventListener("click", async function () {
      if (confirm.disabled) { return; }
      confirm.disabled = true;
      confirm.innerHTML = '<span class="fa fa-spinner fa-spin" aria-hidden="true"></span> Finalizing audit';
      try {
        if (!callApi().sendAudit({
          type:"audit_final_consent", audit_id:state.auditId, confirmed:true
        })) {
          throw new Error("The secure audit connection is unavailable.");
        }
        await completeAudit();
      } catch (error) {
        confirm.disabled = false;
        confirm.innerHTML = '<span class="fa fa-check-circle" aria-hidden="true"></span> Confirm &amp; Generate Final Output';
        setStatus(error.message || "Final confirmation failed", "error");
      }
    });
    actions.appendChild(confirm);
    host.appendChild(actions);
    callApi().sendAudit({
      type:"audit_review_start", audit_id:state.auditId,
      question_count:state.questions.length, final_consent_required:true
    });
    setStatus("Checker final confirmation required", "active");
  }
  function renderCheckerConsentWaiting() {
    state.reviewing = true;
    state.current = null;
    state.index = state.questions.length;
    clearResponses();
    updateProgress();
    setAvatarMode("thinking");
    setText("aam-category", "Maker entries completed");
    setText("aam-question", "The Checker is reviewing progress and providing final confirmation. The final View and Share options will appear here when complete.");
    var wait = document.createElement("div");
    wait.className = "aam-waiting";
    wait.textContent = "Waiting for Checker final confirmation…";
    var host = byId("aam-response-controls");
    host.appendChild(wait);
    appendStoredEvidenceGallery(host, state.auditId, "Maker Evidence Review");
    setStatus("Awaiting Checker confirmation", "active");
  }
  function requestMakerSupportClose() {
    if (state.role !== "AUDITOR" || state.reviewing) { return; }
    state.reviewing = true;
    state.current = null;
    state.index = state.questions.length;
    clearVideoEvidenceTimer();
    updateProgress();
    clearResponses();
    setAvatarMode("thinking");
    setText("aam-category", "Maker review and closure");
    setText("aam-question", "The Maker is reviewing the support status and all Checker-provided image, audio, and video evidence before closing the support call.");
    var host = byId("aam-response-controls");
    var wait = document.createElement("div");
    wait.className = "aam-waiting";
    wait.textContent = "Waiting for the Maker to review and close this support call…";
    host.appendChild(wait);
    appendStoredEvidenceGallery(host, state.auditId, "Evidence Sent by Checker");
    callApi().sendAudit({
      type:"audit_review_start",
      audit_id:state.auditId,
      question_count:state.questions.length,
      support_close_required:true
    });
    setStatus("Maker final review in progress", "active");
  }
  function renderMakerSupportClose(evidenceReady) {
    if (state.role !== "AGENT") { return; }
    state.reviewing = true;
    state.current = null;
    state.index = state.questions.length;
    clearResponses();
    updateProgress();
    setAvatarMode("thinking");
    setText("aam-category", "Review and close support call");
    setText("aam-question", "Review your status updates and the Checker evidence below. Close only after the support outcome is correct.");
    var host = byId("aam-response-controls");
    if (evidenceReady !== true) {
      var loading = document.createElement("div");
      loading.className = "aam-waiting";
      loading.innerHTML = '<span class="fa fa-spinner fa-spin" aria-hidden="true"></span> Loading image, audio, and video for Maker review…';
      host.appendChild(loading);
      loadAuditEvidence(state.auditId).then(function (items) {
        rememberAuditEvidence(items, state.auditId);
        renderMakerSupportClose(true);
      }).catch(function (error) {
        setStatus(error.message || "Evidence could not be loaded for review.", "error");
        renderMakerSupportClose(true);
      });
      return;
    }
    appendReadOnlyAuditRows(host, true);
    appendStoredEvidenceGallery(host, state.auditId, "Checker Image, Audio & Video");
    var actions = document.createElement("div");
    actions.className = "aam-review-actions";
    var close = document.createElement("button");
    close.type = "button";
    close.className = "aam-answer aam-answer--consent";
    close.innerHTML = '<span class="fa fa-check-circle" aria-hidden="true"></span> Review &amp; Close Support Call';
    close.addEventListener("click", function () {
      if (close.disabled) { return; }
      if (state.supportRetakePending) {
        setStatus("Wait for the requested evidence retake before closing.", "error");
        return;
      }
      close.disabled = true;
      close.innerHTML = '<span class="fa fa-spinner fa-spin" aria-hidden="true"></span> Closing support call';
      if (!callApi().sendAudit({
        type:"audit_review_submit",
        audit_id:state.auditId,
        answers:[],
        support_close:true
      })) {
        close.disabled = false;
        close.innerHTML = '<span class="fa fa-check-circle" aria-hidden="true"></span> Review &amp; Close Support Call';
        setStatus("The secure support connection is unavailable.", "error");
        return;
      }
      setText("aam-question", "Closure confirmed. Waiting for the support summary and View / Share options…");
      setStatus("Support closure submitted", "active");
    });
    actions.appendChild(close);
    host.appendChild(actions);
    setStatus("Maker closure required", "active");
  }
  function requestParticipantReview() {
    if (state.role !== "AUDITOR" || state.reviewing) { return; }
    state.reviewing = true; state.current = null; state.index = state.questions.length;
    updateProgress(); clearResponses(); setAvatarMode("thinking");
    setText("aam-category", "Participant final review");
    setText("aam-question", "The audited participant is reviewing responses and may retake evidence before final submission.");
    var wait = document.createElement("div"); wait.className = "aam-waiting";
    wait.textContent = "Waiting for the participant to submit the reviewed audit…";
    byId("aam-response-controls").appendChild(wait);
    callApi().sendAudit({type:"audit_review_start", audit_id:state.auditId, question_count:state.questions.length});
    setStatus("Participant review in progress", "active");
  }
  async function applyParticipantReview(message) {
    if (state.role !== "AUDITOR" || !state.reviewing) { return; }
    if (isVideoMode() && message.support_close !== true) {
      setStatus("Maker closure confirmation is required", "error");
      return;
    }
    setStatus("Saving participant review…", "active");
    try {
      var changes = message.answers || [];
      for (var index = 0; index < changes.length; index += 1) {
        var change = changes[index];
        var result = await ajax("SAVE_AAM_RESPONSE", {
          x01:state.auditId, x02:String(change.question_id), x03:change.value,
          x04:"Edited by participant during final review"
        });
        state.answers[String(change.question_id)] = {
          value:change.value, note:"Edited by participant during final review", finding:result.finding === true
        };
        state.score = Number(result.runningScore || state.score);
      }
      await completeAudit();
    } catch (error) {
      setStatus(error.message, "error");
    }
  }
  async function completeAudit() {
    try {
      var result = await ajax("COMPLETE_AAM_AUDIT", {x01:state.auditId});
      state.score = Number(result.score || 0); state.criticalFail = result.criticalFail === true;
      callApi().sendAudit({
        type:"audit_complete", audit_id:state.auditId, score:state.score,
        critical_fail:state.criticalFail, language:state.language, voice:state.voice,
        completion_text:isVideoMode()
          ? "The support call is closed. The final record is ready to view or share."
          : systemText("complete", state.score)
      });
      showSummary(state.score, state.criticalFail);
      logEntry(
        "AIRA",
        isVideoMode() ? "Support call reviewed and closed by the Maker." : "Audit completed with a score of " + state.score + "%.",
        "system"
      );
    } catch (error) {
      setStatus(error.message, "error"); setAvatarMode("");
      throw error;
    }
  }
  function reportLine(context, text, x, y, maxWidth, lineHeight, maxLines) {
    var words = String(text || "").split(/\s+/);
    var line = ""; var lines = [];
    words.forEach(function (word) {
      var trial = line ? line + " " + word : word;
      if (context.measureText(trial).width > maxWidth && line) {
        lines.push(line); line = word;
      } else { line = trial; }
    });
    if (line) { lines.push(line); }
    var limit = maxLines || 2;
    var truncated = lines.length > limit;
    lines = lines.slice(0, limit);
    if (truncated) {
      var last = lines.length - 1;
      while (context.measureText(lines[last] + "…").width > maxWidth && lines[last].length) {
        lines[last] = lines[last].slice(0, -1);
      }
      lines[last] += "…";
    }
    lines.forEach(function (value, index) { context.fillText(value, x, y + index * lineHeight); });
    return lines.length * lineHeight;
  }
  function jpegToSinglePagePdf(jpegBlob, width, height) {
    return jpegBlob.arrayBuffer().then(function (jpegBuffer) {
      var encoder = new TextEncoder();
      var chunks = []; var length = 0; var offsets = [0];
      function addBytes(bytes) { chunks.push(bytes); length += bytes.length; }
      function addText(text) { addBytes(encoder.encode(text)); }
      function object(number, body) {
        offsets[number] = length;
        addText(number + " 0 obj\n" + body + "\nendobj\n");
      }
      addText("%PDF-1.4\n");
      object(1, "<< /Type /Catalog /Pages 2 0 R >>");
      object(2, "<< /Type /Pages /Kids [3 0 R] /Count 1 >>");
      object(3, "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /XObject << /Im0 5 0 R >> >> /Contents 4 0 R >>");
      var drawing = "q\n595 0 0 842 0 0 cm\n/Im0 Do\nQ\n";
      object(4, "<< /Length " + encoder.encode(drawing).length + " >>\nstream\n" + drawing + "endstream");
      offsets[5] = length;
      addText("5 0 obj\n<< /Type /XObject /Subtype /Image /Width " + width + " /Height " + height +
        " /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length " + jpegBuffer.byteLength + " >>\nstream\n");
      addBytes(new Uint8Array(jpegBuffer));
      addText("\nendstream\nendobj\n");
      var xref = length;
      addText("xref\n0 6\n0000000000 65535 f \n");
      for (var number = 1; number <= 5; number += 1) {
        addText(String(offsets[number]).padStart(10, "0") + " 00000 n \n");
      }
      addText("trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n" + xref + "\n%%EOF");
      return new Blob(chunks, {type:"application/pdf"});
    });
  }
  function roundedRect(context, x, y, width, height, radius) {
    var r = Math.min(radius, width / 2, height / 2);
    context.beginPath();
    context.moveTo(x + r, y);
    context.arcTo(x + width, y, x + width, y + height, r);
    context.arcTo(x + width, y + height, x, y + height, r);
    context.arcTo(x, y + height, x, y, r);
    context.arcTo(x, y, x + width, y, r);
    context.closePath();
  }
  function drawImageCover(context, image, x, y, width, height) {
    var scale = Math.max(width / image.naturalWidth, height / image.naturalHeight);
    var sourceWidth = width / scale;
    var sourceHeight = height / scale;
    var sourceX = (image.naturalWidth - sourceWidth) / 2;
    var sourceY = (image.naturalHeight - sourceHeight) / 2;
    context.drawImage(image, sourceX, sourceY, sourceWidth, sourceHeight, x, y, width, height);
  }
  function evidenceKind(mimeType) {
    var value = String(mimeType || "").toLowerCase();
    if (value.indexOf("video/") === 0) { return "video"; }
    if (value.indexOf("audio/") === 0) { return "audio"; }
    return "image";
  }
  function normalizeEvidenceItem(item) {
    var mimeType = item.mimeType || "application/octet-stream";
    var base64 = String(item.base64 || "").replace(/\s/g, "");
    var previewBase64 = String(item.previewBase64 || "").replace(/\s/g, "");
    return {
      evidenceId:String(item.evidenceId || ""),
      questionId:String(item.questionId || ""),
      mode:item.evidenceMode || "EVIDENCE",
      kind:evidenceKind(mimeType),
      mimeType:mimeType,
      src:base64 ? "data:" + mimeType + ";base64," + base64 : "",
      poster:previewBase64
        ? "data:" + (item.previewMimeType || "image/jpeg") + ";base64," + previewBase64
        : "",
      durationMs:Number(item.durationMs || 0),
      capturedOn:item.capturedOn || ""
    };
  }
  function loadAuditEvidence(auditId) {
    return ajax("GET_AAM_REPORT_MEDIA", {x01:auditId || state.auditId}).then(function (result) {
      return (result.evidence || []).map(normalizeEvidenceItem).filter(function (item) {
        return Boolean(item.src);
      });
    });
  }
  function rememberAuditEvidence(items, auditId) {
    if (String(auditId || "") !== String(state.auditId || "")) { return; }
    items.forEach(function (item) {
      state.evidencePreviews[String(item.questionId)] = {
        kind:item.kind, src:item.src, poster:item.poster || "",
        mode:item.mode, evidenceId:item.evidenceId
      };
    });
  }
  function evidenceModeLabel(mode) {
    return {
      AGENT_AUDIO:"Agent audio",
      AGENT_PHOTO:"Agent image",
      LOCATION_PHOTO:"Location image",
      LOCATION_VIDEO:"Location video"
    }[mode] || "Audit evidence";
  }
  function evidenceMediaNode(item) {
    var media;
    if (item.kind === "video") {
      media = document.createElement("video");
      media.controls = true;
      media.playsInline = true;
      media.preload = "metadata";
      if (item.poster) { media.poster = item.poster; }
    } else if (item.kind === "audio") {
      media = document.createElement("audio");
      media.controls = true;
      media.preload = "metadata";
    } else {
      media = document.createElement("img");
      media.alt = evidenceModeLabel(item.mode) + " preview";
      media.loading = "lazy";
    }
    media.className = "aam-evidence-gallery-media";
    media.src = item.src;
    return media;
  }
  function renderEvidenceGalleryItems(host, items) {
    host.replaceChildren();
    if (!items.length) {
      var empty = document.createElement("div");
      empty.className = "aam-evidence-gallery-empty";
      empty.textContent = "No captured image, audio, or video evidence is available yet.";
      host.appendChild(empty);
      return;
    }
    items.forEach(function (item) {
      var card = document.createElement("article");
      card.className = "aam-evidence-gallery-card";
      var heading = document.createElement("div");
      heading.className = "aam-evidence-gallery-heading";
      var title = document.createElement("strong");
      title.textContent = evidenceModeLabel(item.mode);
      var meta = document.createElement("span");
      meta.textContent = item.capturedOn || (
        item.durationMs ? (Math.round(item.durationMs / 100) / 10) + " seconds" : "Captured"
      );
      heading.appendChild(title);
      heading.appendChild(meta);
      card.appendChild(heading);
      card.appendChild(evidenceMediaNode(item));
      host.appendChild(card);
    });
  }
  function localEvidenceItems() {
    return Object.keys(state.evidencePreviews || {}).map(function (questionId) {
      var preview = state.evidencePreviews[questionId] || {};
      var question = state.questions.find(function (item) {
        return String(item.questionId) === String(questionId);
      });
      if (!preview.src) { return null; }
      return {
        evidenceId:String(preview.evidenceId || ""),
        questionId:String(questionId),
        mode:preview.mode || (question && question.evidenceMode) || "EVIDENCE",
        kind:preview.kind || evidenceKind(String(preview.src).slice(5, 40)),
        src:preview.src,
        poster:preview.poster || "",
        durationMs:0,
        capturedOn:"Current audit"
      };
    }).filter(Boolean);
  }
  function appendStoredEvidenceGallery(host, auditId, titleText) {
    var section = document.createElement("section");
    section.className = "aam-evidence-gallery";
    var header = document.createElement("div");
    header.className = "aam-evidence-gallery-header";
    var title = document.createElement("strong");
    title.textContent = titleText || "Captured Evidence";
    var refresh = document.createElement("button");
    refresh.type = "button";
    refresh.className = "aam-evidence-refresh";
    refresh.innerHTML = '<span class="fa fa-refresh" aria-hidden="true"></span> Refresh';
    var body = document.createElement("div");
    body.className = "aam-evidence-gallery-grid";
    header.appendChild(title);
    header.appendChild(refresh);
    section.appendChild(header);
    section.appendChild(body);
    host.appendChild(section);
    var currentAudit = String(auditId || state.auditId);
    var local = currentAudit === String(state.auditId) ? localEvidenceItems() : [];
    if (local.length) { renderEvidenceGalleryItems(body, local); }
    else {
      body.innerHTML = '<div class="aam-evidence-gallery-loading"><span class="fa fa-spinner fa-spin" aria-hidden="true"></span> Loading protected evidence…</div>';
    }
    function reload() {
      refresh.disabled = true;
      loadAuditEvidence(currentAudit).then(function (items) {
        rememberAuditEvidence(items, currentAudit);
        renderEvidenceGalleryItems(body, items.length ? items : local);
      }).catch(function (error) {
        body.innerHTML = "";
        var failure = document.createElement("div");
        failure.className = "aam-evidence-gallery-empty";
        failure.textContent = error.message || "Evidence could not be loaded.";
        body.appendChild(failure);
      }).finally(function () {
        refresh.disabled = false;
      });
    }
    refresh.addEventListener("click", reload);
    reload();
    return section;
  }
  function appendInlineQuestionEvidence(questionId) {
    var host = byId("aam-response-controls");
    if (!host) { return; }
    var previous = host.querySelector(".aam-inline-question-evidence");
    if (previous) { previous.remove(); }
    var section = document.createElement("section");
    section.className = "aam-evidence-gallery aam-inline-question-evidence";
    var title = document.createElement("strong");
    title.textContent = "Checker evidence received · review here";
    var grid = document.createElement("div");
    grid.className = "aam-evidence-gallery-grid";
    grid.innerHTML = '<div class="aam-evidence-gallery-loading"><span class="fa fa-spinner fa-spin" aria-hidden="true"></span> Loading protected media…</div>';
    section.appendChild(title);
    section.appendChild(grid);
    host.appendChild(section);
    loadAuditEvidence(state.auditId).then(function (items) {
      var matching = items.filter(function (item) {
        return String(item.questionId) === String(questionId);
      });
      rememberAuditEvidence(items, state.auditId);
      renderEvidenceGalleryItems(grid, matching);
    }).catch(function (error) {
      grid.textContent = error.message || "Evidence preview could not be loaded.";
    });
  }
  function loadReportImages(auditId) {
    return loadAuditEvidence(auditId).then(function (evidence) {
      return Promise.all(evidence.map(function (item) {
        var imageSource = item.kind === "image" ? item.src : item.poster;
        if (!imageSource) { return Promise.resolve(null); }
        return new Promise(function (resolve) {
          var image = new Image();
          image.onload = function () {
            resolve({mode:item.mode, questionId:item.questionId, image:image});
          };
          image.onerror = function () { resolve(null); };
          image.src = imageSource;
        });
      })).then(function (items) { return items.filter(Boolean); });
    });
  }
  function buildAuditPdf(reportData) {
    var report = reportData || state;
    var supportReport = report.workflowType === "SUPPORT" || (!reportData && isVideoMode());
    return loadReportImages(report.auditId).then(function (reportImages) {
      var canvas = document.createElement("canvas");
      canvas.width = 1400; canvas.height = 1980;
      var context = canvas.getContext("2d", {alpha:false});
      var font = '"Noto Sans Kannada","Kannada Sangam MN","Noto Sans Devanagari","Kohinoor Devanagari","Noto Sans Tamil","Tamil Sangam MN","Noto Sans Telugu","Noto Sans","Arial Unicode MS",Arial,sans-serif';
      context.fillStyle = "#f4f7fb"; context.fillRect(0, 0, canvas.width, canvas.height);

      context.fillStyle = "#10243e"; context.fillRect(0, 0, canvas.width, 260);
      context.fillStyle = "#e4374f"; context.fillRect(0, 0, 18, 260);
      context.fillStyle = "#27b29a";
      context.beginPath(); context.arc(94, 82, 38, 0, Math.PI * 2); context.fill();
      context.fillStyle = "#ffffff"; context.font = "800 31px " + font; context.textAlign = "center";
      context.fillText("AA", 94, 93); context.textAlign = "left";
      context.font = "800 50px " + font;
      context.fillText(
        supportReport
          ? reportText(report, "supportTitle", "SUPPORT CALL REPORT")
          : reportText(report, "auditTitle", "AGENT AUDIT REPORT"),
        155, 88
      );
      context.fillStyle = "#a9bdd1"; context.font = "500 23px " + font;
      context.fillText((supportReport ? "Maker-reviewed support summary · Support #" : "Verified digital audit summary · Audit #") + report.auditId, 158, 130);
      context.fillStyle = "#ffffff"; context.font = "650 24px " + font;
      context.fillText((supportReport ? "Checker  " : "Auditor  ") + report.auditorName + (report.auditorStno ? "  ·  " + report.auditorStno : ""), 66, 198);
      context.fillText((supportReport ? "Maker  " : "Participant  ") + report.agentName + (report.agentStno ? "  ·  " + report.agentStno : ""), 66, 230);

      context.fillStyle = report.criticalFail ? "#e4374f" : "#27b29a";
      roundedRect(context, 1120, 48, 215, 160, 20); context.fill();
      context.fillStyle = "#ffffff"; context.textAlign = "center";
      context.font = "800 " + (supportReport ? "38px " : "66px ") + font;
      context.fillText(supportReport ? "CLOSED" : Math.round(report.score) + "%", 1228, 125);
      context.font = "750 19px " + font;
      context.fillText(supportReport ? "MAKER REVIEWED" : (report.criticalFail ? "ACTION REQUIRED" : "AUDIT COMPLETE"), 1228, 166);
      context.textAlign = "left";

      context.fillStyle = "#ffffff"; roundedRect(context, 54, 292, 1292, 112, 18); context.fill();
      context.fillStyle = "#6a7b8d"; context.font = "700 18px " + font;
      context.fillText("AUDIT DATE", 84, 330); context.fillText("LANGUAGE", 478, 330); context.fillText("EVIDENCE", 765, 330); context.fillText("RESULT", 1085, 330);
      context.fillStyle = "#172b4d"; context.font = "650 23px " + font;
      context.fillText(report.completedOn || new Date().toLocaleString(), 84, 371);
      context.fillText(String(report.language || "en").toUpperCase(), 478, 371);
      context.fillText(reportImages.length + " visual records", 765, 371);
      context.fillStyle = report.criticalFail ? "#b4233c" : "#08775c";
      context.fillText(supportReport ? "Closed" : (report.criticalFail ? "Critical review" : "Completed"), 1085, 371);

      context.fillStyle = "#172b4d"; context.font = "800 25px " + font;
      context.fillText("CAPTURED EVIDENCE", 58, 452);
      context.fillStyle = "#718096"; context.font = "500 18px " + font;
      context.fillText("Reviewed by the audited participant before final submission", 330, 452);
      var evidenceCards = [
        {mode:"AGENT_PHOTO", label:"Agent identity"},
        {mode:"LOCATION_PHOTO", label:"Work location"},
        {mode:"LOCATION_VIDEO", label:"Location video snapshot"}
      ];
      evidenceCards.forEach(function (card, index) {
        var x = 54 + index * 431;
        var found = reportImages.find(function (item) { return item.mode === card.mode; });
        context.fillStyle = "#ffffff"; roundedRect(context, x, 476, 404, 246, 18); context.fill();
        context.save();
        roundedRect(context, x + 10, 486, 384, 174, 13); context.clip();
        if (found) {
          drawImageCover(context, found.image, x + 10, 486, 384, 174);
        } else {
          context.fillStyle = "#e8eef5"; context.fillRect(x + 10, 486, 384, 174);
          context.fillStyle = "#91a2b5"; context.textAlign = "center"; context.font = "700 18px " + font;
          context.fillText(card.mode === "LOCATION_VIDEO" ? "No video snapshot available" : "No image available", x + 202, 578);
          context.textAlign = "left";
        }
        context.restore();
        context.fillStyle = "#172b4d"; context.font = "750 20px " + font; context.fillText(card.label, x + 18, 696);
        context.fillStyle = found ? "#08775c" : "#8b98a7"; context.textAlign = "right";
        context.fillText(found ? "VERIFIED" : "NOT AVAILABLE", x + 384, 696); context.textAlign = "left";
      });

      var tableTop = 766;
      context.fillStyle = "#10243e"; roundedRect(context, 54, tableTop, 1292, 54, 12); context.fill();
      context.fillStyle = "#ffffff"; context.font = "750 18px " + font;
      context.fillText("#", 76, tableTop + 35);
      context.fillText(reportText(report, "question", "CONTROL / QUESTION"), 137, tableTop + 35);
      context.textAlign = "right";
      context.fillText(reportText(report, "response", "RESPONSE"), 1317, tableTop + 35);
      context.textAlign = "left";
      var rowHeight = 88;
      report.questions.forEach(function (question, index) {
        var answer = report.answers[String(question.questionId)] || {value:"Not answered", note:""};
        var y = tableTop + 56 + index * rowHeight;
        context.fillStyle = index % 2 ? "#ffffff" : "#edf3f8"; context.fillRect(54, y, 1292, rowHeight - 2);
        context.fillStyle = "#738397"; context.font = "750 18px " + font;
        context.fillText(String(index + 1).padStart(2, "0"), 76, y + 34);
        context.fillStyle = "#172b4d"; context.font = "650 20px " + font;
        reportLine(context, question.text, 137, y + 30, 865, 25, 2);
        var answerText = localizedReportAnswer(report, answer.value);
        if ((question.evidenceMode || "NONE") !== "NONE" && answer.note) { answerText += " ✓"; }
        context.fillStyle = answer.finding ? "#b4233c" : "#08775c";
        context.font = "750 20px " + font; context.textAlign = "right";
        context.fillText(answerText, 1317, y + 43, 280);
        context.textAlign = "left";
      });

      context.fillStyle = "#10243e"; context.fillRect(0, 1904, 1400, 76);
      context.fillStyle = "#ffffff"; context.font = "600 18px " + font;
      context.fillText("SAS Agent Audit Management", 54, 1948);
      context.fillStyle = "#a9bdd1"; context.textAlign = "right";
      context.fillText("Generated on-premises · Evidence governed by configured retention policy", 1346, 1948);
      context.textAlign = "left";
      return new Promise(function (resolve, reject) {
        canvas.toBlob(function (jpeg) {
          if (!jpeg) { reject(new Error("PDF report could not be generated.")); return; }
          jpegToSinglePagePdf(jpeg, canvas.width, canvas.height).then(resolve).catch(reject);
        }, "image/jpeg", 0.92);
      });
    });
  }
  function downloadAuditPdf() {
    if (!state.reportBlob) { return; }
    var url = URL.createObjectURL(state.reportBlob);
    var link = document.createElement("a");
    link.href = url; link.download = (isVideoMode() ? "support-call-" : "agent-audit-") + state.auditId + ".pdf";
    document.body.appendChild(link); link.click(); link.remove();
    global.setTimeout(function () { URL.revokeObjectURL(url); }, 30000);
  }
  function viewReportFile(file) {
    if (!file) { return; }
    var url = URL.createObjectURL(file);
    global.open(url, "_blank", "noopener");
    global.setTimeout(function () { URL.revokeObjectURL(url); }, 300000);
  }
  async function shareAuditPdf(target) {
    if (!state.reportFile) { return; }
    var support = isVideoMode();
    var shareData = {
      title:(support ? "Support Call #" : "Agent Audit #") + state.auditId,
      text:support
        ? "Support call #" + state.auditId + " was reviewed and closed by the Maker."
        : "Agent audit #" + state.auditId + " completed with score " + Math.round(state.score) + "%.",
      files:[state.reportFile]
    };
    try {
      if (navigator.share && (!navigator.canShare || navigator.canShare({files:[state.reportFile]}))) {
        await navigator.share(shareData);
        return;
      }
    } catch (error) {
      if (error && error.name === "AbortError") { return; }
    }
    downloadAuditPdf();
    var message = encodeURIComponent(shareData.text + " The PDF has been downloaded; attach it to this message.");
    if (target === "whatsapp") {
      global.open("https://wa.me/?text=" + message, "_blank", "noopener");
    } else {
      global.location.href = "mailto:?subject=" + encodeURIComponent(shareData.title) + "&body=" + message;
    }
  }
  function downloadReportFile(file, auditId) {
    var url = URL.createObjectURL(file);
    var link = document.createElement("a");
    link.href = url; link.download = file.name || "agent-audit-" + auditId + ".pdf";
    document.body.appendChild(link); link.click(); link.remove();
    global.setTimeout(function () { URL.revokeObjectURL(url); }, 30000);
  }
  async function shareReportFile(file, report, target) {
    var support = report.workflowType === "SUPPORT";
    var shareData = {
      title:(support ? "Support Call #" : "Agent Audit #") + report.auditId,
      text:support
        ? "Support call #" + report.auditId + " was reviewed and closed by the Maker."
        : "Agent audit #" + report.auditId + " completed with score " + Math.round(report.score) + "%.",
      files:[file]
    };
    try {
      if (navigator.share && (!navigator.canShare || navigator.canShare({files:[file]}))) {
        await navigator.share(shareData); return;
      }
    } catch (error) {
      if (error && error.name === "AbortError") { return; }
    }
    downloadReportFile(file, report.auditId);
    var message = encodeURIComponent(shareData.text + " The PDF has been downloaded; attach it to this message.");
    if (target === "whatsapp") { global.open("https://wa.me/?text=" + message, "_blank", "noopener"); }
    else { global.location.href = "mailto:?subject=" + encodeURIComponent(shareData.title) + "&body=" + message; }
  }
  function historicalReportModel(result) {
    var answers = {};
    var questions = (result.questions || []).map(function (question) {
      question.category = decodeMetadataText(question.category);
      question.text = decodeMetadataText(question.text);
      answers[String(question.questionId)] = {
        value:question.answer || "Not answered",
        note:question.note || "",
        finding:question.finding === true
      };
      return question;
    });
    return {
      auditId:String(result.auditId), score:Number(result.score || 0),
      workflowType:result.workflowType || "AUDIT",
      criticalFail:result.criticalFail === true, language:result.language || "en",
      auditorName:result.auditorName || "Auditor", auditorStno:result.auditorStno || "",
      agentName:result.agentName || "Audited participant", agentStno:result.agentStno || "",
      completedOn:result.completedOn || "", questions:questions, answers:answers
    };
  }
  function historyActionButton(label, icon, handler) {
    var button = document.createElement("button");
    button.type = "button"; button.className = "aam-history-action";
    button.innerHTML = '<span class="fa ' + icon + '" aria-hidden="true"></span> ' + label;
    button.addEventListener("click", handler);
    return button;
  }
  function historyLanguageSelect(audit) {
    var select = document.createElement("select");
    select.className = "aam-history-language";
    select.setAttribute("aria-label", "PDF language");
    [
      ["en","English"], ["hi","हिन्दी"], ["kn","ಕನ್ನಡ"],
      ["ta","தமிழ்"], ["te","తెలుగు"]
    ].forEach(function (definition) {
      var option = document.createElement("option");
      option.value = definition[0];
      option.textContent = definition[1];
      select.appendChild(option);
    });
    select.value = audit.language || selectedValue("P40_AUDIT_LANGUAGE", "en");
    select.title = audit.language
      ? "Saved audit language"
      : "Choose a language for this older history record";
    return select;
  }
  function prepareHistoryReport(audit, actions, button) {
    button.disabled = true;
    button.innerHTML = '<span class="fa fa-spinner fa-spin" aria-hidden="true"></span> Preparing';
    var language = actions.querySelector(".aam-history-language");
    ajax("GET_AAM_REPORT_DATA", {
      x01:String(audit.auditId),
      x02:language ? language.value : (audit.language || "en")
    }).then(function (result) {
      var report = historicalReportModel(result);
      return buildAuditPdf(report).then(function (blob) {
        var file = new File([blob], (report.workflowType === "SUPPORT" ? "support-call-" : "agent-audit-") + report.auditId + ".pdf", {type:"application/pdf"});
        actions.replaceChildren(
          historyActionButton("View", "fa-eye", function () { viewReportFile(file); }),
          historyActionButton("Download", "fa-download", function () { downloadReportFile(file, report.auditId); }),
          historyActionButton("WhatsApp", "fa-whatsapp", function () { shareReportFile(file, report, "whatsapp"); }),
          historyActionButton("Share", "fa-share-alt", function () { shareReportFile(file, report, "mail"); })
        );
      });
    }).catch(function (error) {
      button.disabled = false; button.textContent = "Retry PDF & Share";
      setText("aam-history-message", error.message || "The audit report could not be prepared.");
    });
  }
  function deleteHistoryAudit(audit, button) {
    if (!global.confirm(
      "Delete audit #" + audit.auditId + " permanently?\n\n"
      + "The report, responses, photos, audio and video evidence will be removed for both participants."
    )) { return; }
    button.disabled = true;
    button.innerHTML = '<span class="fa fa-spinner fa-spin" aria-hidden="true"></span> Deleting';
    setText("aam-history-message", "");
    ajax("DELETE_AAM_AUDIT", {x01:String(audit.auditId)}).then(function () {
      setText("aam-history-message", "Audit #" + audit.auditId + " was deleted.");
      loadAuditHistory();
    }).catch(function (error) {
      button.disabled = false;
      button.innerHTML = '<span class="fa fa-trash-o" aria-hidden="true"></span> Delete';
      setText("aam-history-message", error.message || "The audit could not be deleted.");
    });
  }
  function renderAuditHistory(audits) {
    var host = byId("aam-history-list");
    host.replaceChildren();
    function createHistorySection(title, count, emptyText) {
      var section = document.createElement("section");
      section.className = "aam-history-section";
      var heading = document.createElement("div");
      heading.className = "aam-history-section-heading";
      var label = document.createElement("strong"); label.textContent = title;
      var badge = document.createElement("span"); badge.textContent = String(count);
      var list = document.createElement("div"); list.className = "aam-history-section-list";
      heading.appendChild(label); heading.appendChild(badge);
      if (!count) {
        var empty = document.createElement("div");
        empty.className = "aam-history-section-empty";
        empty.textContent = emptyText;
        list.appendChild(empty);
      }
      section.appendChild(heading); section.appendChild(list); host.appendChild(section);
      return list;
    }
    var supportCount = audits.filter(function (item) { return item.workflowType === "SUPPORT"; }).length;
    var supportHost = createHistorySection("Support Calls", supportCount, "No completed support calls.");
    var auditHost = createHistorySection("Audits", audits.length - supportCount, "No completed avatar audits.");
    audits.forEach(function (audit) {
      var card = document.createElement("article"); card.className = "aam-history-card";
      var support = audit.workflowType === "SUPPORT";
      var scoreTone = audit.criticalFail === true ? "is-critical" : "is-complete";
      var id = document.createElement("div"); id.className = "aam-history-id";
      var idLabel = document.createElement("span"); idLabel.textContent = support ? "Support" : "Audit";
      var idValue = document.createElement("strong"); idValue.textContent = "#" + audit.auditId;
      id.appendChild(idLabel); id.appendChild(idValue);
      var detail = document.createElement("div"); detail.className = "aam-history-detail";
      var party = document.createElement("strong");
      party.textContent = support
        ? (audit.role === "AUDITOR" ? "Maker " + audit.agentStno : "Checker " + audit.auditorStno)
        : (audit.role === "AUDITOR" ? "Participant " + audit.agentStno : "Auditor " + audit.auditorStno);
      var meta = document.createElement("span");
      meta.textContent = audit.completedOn + " · " + audit.evidenceCount + " evidence records";
      detail.appendChild(party); detail.appendChild(meta);
      var score = document.createElement("div"); score.className = "aam-history-score " + scoreTone;
      var scoreValue = document.createElement("strong"); scoreValue.textContent = support ? "Closed" : Math.round(Number(audit.score || 0)) + "%";
      var scoreLabel = document.createElement("span");
      scoreLabel.textContent = support ? "Maker reviewed" : (audit.criticalFail === true ? "Critical review" : audit.status);
      score.appendChild(scoreValue); score.appendChild(scoreLabel);
      card.appendChild(id); card.appendChild(detail); card.appendChild(score);
      var actions = document.createElement("div"); actions.className = "aam-history-actions";
      if (audit.status === "COMPLETED") {
        actions.appendChild(historyLanguageSelect(audit));
        var prepare = historyActionButton("PDF & Share", "fa-file-pdf-o", function () {
          prepareHistoryReport(audit, actions, prepare);
        });
        actions.appendChild(prepare);
        if (Number(audit.evidenceCount || 0) > 0) {
          var evidenceButton = historyActionButton("View Evidence", "fa-play-circle", function () {
            var visible = !evidenceHost.hidden;
            evidenceHost.hidden = visible;
            evidenceButton.innerHTML = visible
              ? '<span class="fa fa-play-circle" aria-hidden="true"></span> View Evidence'
              : '<span class="fa fa-times-circle" aria-hidden="true"></span> Hide Evidence';
            if (!visible && !evidenceHost.dataset.loaded) {
              evidenceHost.dataset.loaded = "Y";
              appendStoredEvidenceGallery(evidenceHost, String(audit.auditId), "Stored Image, Audio & Video");
            }
          });
          actions.appendChild(evidenceButton);
        }
      }
      if (audit.role === "AUDITOR") {
        var remove = historyActionButton("Delete", "fa-trash-o", function () {
          deleteHistoryAudit(audit, remove);
        });
        remove.classList.add("aam-history-action--delete");
        actions.appendChild(remove);
      }
      var evidenceHost = document.createElement("div");
      evidenceHost.className = "aam-history-evidence";
      evidenceHost.hidden = true;
      card.appendChild(actions);
      card.appendChild(evidenceHost);
      (support ? supportHost : auditHost).appendChild(card);
    });
  }
  function loadAuditHistory() {
    var host = byId("aam-history-list");
    host.innerHTML = '<div class="aam-history-loading"><span class="fa fa-spinner fa-spin" aria-hidden="true"></span> Loading audit history…</div>';
    setText("aam-history-message", "");
    ajax("GET_AAM_HISTORY").then(function (result) {
      renderAuditHistory(result.audits || []);
    }).catch(function (error) {
      host.replaceChildren(); setText("aam-history-message", error.message || "Audit history could not be loaded.");
    });
  }
  function showAuditHistory(show) {
    var shell = byId("aam-history-view").closest(".webrtc-shell");
    shell.classList.toggle("is-history", show);
    byId("aam-history-view").hidden = !show;
    byId("aam-tab-history").classList.toggle("is-active", show);
    byId("aam-tab-calling").classList.toggle("is-active", !show);
    byId("aam-tab-history").setAttribute("aria-selected", show ? "true" : "false");
    byId("aam-tab-calling").setAttribute("aria-selected", show ? "false" : "true");
    if (show) { loadAuditHistory(); }
  }
  function renderReportActions(host) {
    var actions = document.createElement("div"); actions.className = "aam-report-actions";
    var preparing = document.createElement("span"); preparing.className = "aam-report-preparing";
    preparing.innerHTML = '<span class="fa fa-spinner fa-spin" aria-hidden="true"></span> Preparing one-page PDF…';
    actions.appendChild(preparing); host.appendChild(actions);
    buildAuditPdf().then(function (blob) {
      state.reportBlob = blob;
      state.reportFile = new File([blob], (isVideoMode() ? "support-call-" : "agent-audit-") + state.auditId + ".pdf", {type:"application/pdf"});
      actions.replaceChildren();
      [
        ["View PDF", "fa-eye", function () { viewReportFile(state.reportFile); }],
        ["Download PDF", "fa-download", downloadAuditPdf],
        ["WhatsApp", "fa-whatsapp", function () { shareAuditPdf("whatsapp"); }],
        ["Mail / Share", "fa-share-alt", function () { shareAuditPdf("mail"); }]
      ].forEach(function (definition) {
        var button = document.createElement("button"); button.type = "button"; button.className = "aam-report-button";
        button.innerHTML = '<span class="fa ' + definition[1] + '" aria-hidden="true"></span> ' + definition[0];
        button.addEventListener("click", definition[2]); actions.appendChild(button);
      });
    }).catch(function (error) {
      preparing.textContent = error.message;
    });
  }
  function showSummary(score, critical) {
    state.score = Number(score || 0); state.criticalFail = Boolean(critical);
    state.index = state.questions.length || Number(byId("aam-audit-panel").dataset.questionCount || 0);
    state.current = null; clearResponses(); updateProgress(); setAvatarMode("");
    setText(
      "aam-category",
      isVideoMode() ? "Support call closed" : (critical ? "Critical finding identified" : "Audit completed")
    );
    setText(
      "aam-question",
      isVideoMode() ? "Maker review is complete. The support record and evidence are ready to View or Share." : "Final quality score: " + score + "%"
    );
    var summary = document.createElement("div");
    summary.className = "aam-summary " + (critical ? "aam-summary--critical" : "");
    summary.textContent = isVideoMode()
      ? "Support status, Maker updates, and Checker evidence saved successfully"
      : (critical ? "Supervisor review required · critical control failed" : "Responses saved successfully");
    var responseHost = byId("aam-response-controls");
    responseHost.appendChild(summary);
    appendStoredEvidenceGallery(responseHost, state.auditId, "Captured Image, Audio & Video");
    if ((state.role === "AUDITOR" || state.role === "AGENT") && state.questions.length) {
      renderReportActions(responseHost);
    }
    setStatus(
      isVideoMode() ? "Support call closed" : (critical ? "Completed with critical finding" : "Audit completed"),
      isVideoMode() ? "complete" : (critical ? "error" : "complete")
    );
  }
  async function cancelAudit() {
    if (!state.auditId || state.role !== "AUDITOR") { showPanel(false); return; }
    try {
      await ajax("CANCEL_AAM_AUDIT", {x01:state.auditId});
      callApi().sendAudit({type:"audit_cancel", audit_id:state.auditId, reason:"Audit cancelled by auditor"});
    } catch (ignore) {}
    resetAudit(); showPanel(false);
  }
  function resetAudit() {
    stopSpeech();
    stopInitializationRing();
    stopAuditSync();
    stopAutoListening();
    clearVideoEvidenceTimer();
    if (state.introductionTimer) { global.clearTimeout(state.introductionTimer); }
    state.introductionTimer=null;
    if (state.recorder && state.recorder.state !== "inactive") { state.recorder.stop(); }
    state.auditId=""; state.role=""; state.questions=[]; state.index=0; state.current=null; state.score=0; state.criticalFail=false;
    state.recorder=null; state.responseSent=false; state.introductionActive=false; state.pendingQuestion=null; state.starting=false; state.autoStartAttempts=0; state.voiceAttempts=0; state.mediaWaitAttempts=0;
    stopEvidenceStream();
    state.evidenceRequired=false; state.evidenceConsent=false; state.consentResolved=false; state.recordingStartedAt=0;
    state.answers={}; state.evidencePreviews={}; state.receivedEvidence={}; state.reviewing=false; state.reportBlob=null; state.reportFile=null;
    state.auditorName=""; state.auditorStno=""; state.agentName=""; state.agentStno=""; state.startedAt="";
    state.evidenceCaptureQuestionId=""; state.evidenceCaptureAttempts=0; state.pendingSupportAdvance="";
    state.supportRetakePending=""; state.supportRetakeQuestionId="";
    clearResponses(); setAvatarMode("");
  }
  function blobToBase64(blob) {
    return blob.arrayBuffer().then(function (buffer) {
      var bytes = new Uint8Array(buffer);
      var binary = "";
      for (var offset = 0; offset < bytes.length; offset += 8192) {
        binary += String.fromCharCode.apply(null, bytes.subarray(offset, offset + 8192));
      }
      return global.btoa(binary);
    });
  }
  function captureEvidencePhoto() {
    if (!state.evidenceConsent) { return Promise.resolve({base64:"", mimeType:"image/jpeg"}); }
    var video = byId("webrtc-local-video");
    if (!video || !video.videoWidth || !video.videoHeight) {
      return Promise.resolve({base64:"", mimeType:"image/jpeg"});
    }
    var width = Math.min(360, video.videoWidth);
    var height = Math.max(1, Math.round(video.videoHeight * width / video.videoWidth));
    var canvas = document.createElement("canvas");
    canvas.width = width; canvas.height = height;
    var context = canvas.getContext("2d", {alpha:false});
    if (!context) { return Promise.resolve({base64:"", mimeType:"image/jpeg"}); }
    context.drawImage(video, 0, 0, width, height);
    return new Promise(function (resolve) {
      canvas.toBlob(function (blob) {
        if (!blob) { resolve({base64:"", mimeType:"image/jpeg"}); return; }
        blobToBase64(blob).then(function (encoded) {
          resolve({base64:encoded, mimeType:"image/jpeg"});
        }).catch(function () { resolve({base64:"", mimeType:"image/jpeg"}); });
      }, "image/jpeg", 0.58);
    });
  }
  function recordingConfiguration() {
    var mediaStream = callApi().getAudioStream && callApi().getAudioStream();
    if (!mediaStream) { return null; }
    var mimeType = global.MediaRecorder.isTypeSupported("audio/webm;codecs=opus") ? "audio/webm;codecs=opus" : "audio/webm";
    var options = {audioBitsPerSecond:24000};
    options.mimeType = mimeType;
    return {stream:mediaStream, mimeType:mimeType, options:options, cleanup:function () {}};
  }
  function retryAutomaticVoice(message) {
    var voiceButton = byId("aam-voice-answer");
    if (state.voiceAttempts < 2 && state.current && !state.responseSent) {
      voiceButton.disabled = false;
      voiceButton.innerHTML = '<span class="fa fa-microphone" aria-hidden="true"></span> Listening again automatically';
      setAvatarMode("listening"); setStatus(message + " Please repeat your answer.", "active");
      sendVoiceStatus("retry", message);
      scheduleAutomaticListening(state.current, 900);
    } else {
      voiceButton.disabled = false;
      voiceButton.innerHTML = '<span class="fa fa-microphone" aria-hidden="true"></span> Retry voice answer';
      setAvatarMode(""); setStatus(message + " Select an answer or retry voice.", "error");
      sendVoiceStatus("unavailable", message);
    }
  }
  function sendVoiceRecording(question, blob, durationMs, voiceButton) {
    var auditId = state.auditId;
    var questionId = String(question.questionId);
    setAvatarMode("thinking"); setStatus("Recognizing your answer securely…", "active");
    sendVoiceStatus("processing", "Converting voice answer locally");
    voiceButton.innerHTML = '<span class="fa fa-spinner fa-spin" aria-hidden="true"></span> Recognizing';
    blobToBase64(blob).then(function (encoded) {
      if (state.evidenceConsent && (question.evidenceMode || "NONE") === "AGENT_AUDIO") {
        state.evidencePreviews[String(question.questionId)] = {
          kind:"audio", src:"data:" + (blob.type || "audio/webm") + ";base64," + encoded
        };
      }
      if (!callApi().sendAudit({
        type:"audit_voice_answer", audit_id:auditId,
        question_id:questionId, media_base64:encoded,
        mime_type:blob.type || "audio/webm",
        photo_base64:"",
        photo_mime_type:"image/jpeg",
        duration_ms:durationMs,
        evidence_consent:state.evidenceConsent && (question.evidenceMode || "NONE") === "AGENT_AUDIO",
        evidence_mode:question.evidenceMode || "NONE",
        response_type:question.responseType || "YES_NO",
        language:state.language,
        options:question.options || []
      })) { throw new Error("The secure call is not connected."); }
    }).catch(function (error) {
      voiceButton.disabled = false;
      voiceButton.innerHTML = '<span class="fa fa-microphone" aria-hidden="true"></span> Answer by voice';
      setAvatarMode(""); setStatus(error.message || "Voice answer could not be sent.", "error");
    });
  }
  function reviewAudioCapture(question, blob, durationMs, voiceButton) {
    clearResponses();
    var panel = document.createElement("div"); panel.className = "aam-capture-review";
    var title = document.createElement("strong"); title.textContent = "Review recorded agent voice";
    var audio = document.createElement("audio"); audio.controls = true;
    var audioUrl = URL.createObjectURL(blob); audio.src = audioUrl;
    panel.appendChild(title); panel.appendChild(audio);
    panel.appendChild(evidenceReviewActions(question, function () {
      URL.revokeObjectURL(audioUrl);
      sendVoiceRecording(question, blob, durationMs, voiceButton);
    }, function () {
      URL.revokeObjectURL(audioUrl);
      renderAgentResponses(question);
      scheduleAutomaticListening(question, 700);
    }));
    byId("aam-response-controls").appendChild(panel);
    voiceButton.hidden = true;
    setAvatarMode("thinking"); setStatus("Listen to the recording · use it or retake", "active");
  }
  function recognizeAnswer(automatic) {
    if (!global.MediaRecorder || !state.current || state.role !== "AGENT" || state.responseSent) { return; }
    stopAutoListening();
    var configuration = recordingConfiguration();
    if (!configuration || !configuration.stream) { setStatus("Microphone is not available. Select an answer below.", "error"); return; }
    var questionId = String(state.current.questionId);
    var mimeType = configuration.mimeType;
    var chunks = [];
    var voiceButton = byId("aam-voice-answer");
    try {
      state.voiceAttempts += 1;
      var recorder = new MediaRecorder(configuration.stream, configuration.options);
      state.recorder = recorder;
      state.recordingStartedAt = Date.now();
      recorder.ondataavailable = function (event) { if (event.data && event.data.size) { chunks.push(event.data); } };
      recorder.onerror = function () {
        configuration.cleanup();
        state.recorder = null; voiceButton.disabled = false;
        retryAutomaticVoice("Voice recording was not captured.");
      };
      recorder.onstop = function () {
        configuration.cleanup();
        state.recorder = null;
        if (state.responseSent || !state.current || String(state.current.questionId) !== questionId) { return; }
        var blob = new Blob(chunks, {type:recorder.mimeType || mimeType});
        var durationMs = Math.max(500, Math.min(Date.now() - state.recordingStartedAt, 10000));
        if (!blob.size || blob.size > 250000) {
          retryAutomaticVoice("The evidence recording was too large (" + blob.size + " bytes)."); return;
        }
        var question = state.current;
        if (state.evidenceConsent && (question.evidenceMode || "NONE") === "AGENT_AUDIO") {
          reviewAudioCapture(question, blob, durationMs, voiceButton);
        } else {
          sendVoiceRecording(question, blob, durationMs, voiceButton);
        }
      };
      voiceButton.disabled = true;
      var storesAgentAudio = state.evidenceConsent && (state.current.evidenceMode || "NONE") === "AGENT_AUDIO";
      voiceButton.innerHTML = storesAgentAudio ? '<span class="fa fa-circle" aria-hidden="true"></span> Recording required agent audio' : '<span class="fa fa-circle" aria-hidden="true"></span> Listening';
      setAvatarMode("listening"); setStatus(storesAgentAudio ? "Recording the required agent voice response · speak now…" : "Voice answer is on · speak now…", "active");
      sendVoiceStatus("listening", storesAgentAudio ? "Recording required agent audio" : "Speak now");
      recorder.start(250);
      global.setTimeout(function () { if (recorder.state !== "inactive") { recorder.stop(); } }, 3000);
    } catch (error) {
      configuration.cleanup();
      state.recorder = null; voiceButton.disabled = false;
      retryAutomaticVoice("Microphone recording is not supported.");
    }
  }
  function mapVoiceAnswer(transcript, question) {
    var spoken = String(transcript || "").trim();
    var normalized = spoken.toLowerCase().replace(/[^a-z0-9 ]/g, " ").replace(/\s+/g, " ").trim();
    var aliases = {one:"1", two:"2", three:"3", four:"4", five:"5", yes:"yes", yeah:"yes", yep:"yes", no:"no", nope:"no"};
    var words = normalized.split(" ");
    var options = (question.options || []).slice().sort(function (left, right) {
      return String(right).length - String(left).length;
    });
    var match = "";
    options.some(function (option) {
      var candidate = String(option);
      var key = candidate.toLowerCase().replace(/[^a-z0-9 ]/g, " ").replace(/\s+/g, " ").trim();
      if (normalized === key || (" " + normalized + " ").indexOf(" " + key + " ") >= 0 || words.some(function (word) { return aliases[word] === key; })) {
        match = candidate; return true;
      }
      return false;
    });
    return match || spoken;
  }
  function receiveAudit(message) {
    if (message.type === "audit_start") {
      showAuditHistory(false);
      acknowledgeAudit("audit_start", message);
      if (state.role === "AGENT" && state.auditId === String(message.audit_id)) { return; }
      resetAudit();
      state.auditMode=message.audit_mode === "VIDEO" ? "VIDEO" : "AVATAR_ONLY";
      try { apex.item("P40_AUDIT_MODE").setValue(state.auditMode); } catch (ignore) {}
      showPanel(true); state.auditId=String(message.audit_id); state.role="AGENT";
      state.language=message.language || "en"; state.voice=message.voice || "female";
      state.auditorName=message.auditor_name || "Auditor";
      state.auditorStno=message.auditor_stno || "";
      state.agentName=message.agent_name || "Audited participant";
      state.agentStno=message.agent_stno || "";
      state.evidenceRequired=message.evidence_required === true;
      byId("aam-audit-panel").dataset.questionCount=String(message.question_count || 0);
      setText("aam-audit-id", (isVideoMode() ? "Support #" : "Audit #")+state.auditId);
      setStatus(state.auditMode === "VIDEO" ? "Initializing secure support call…" : "Initializing secure avatar audit…", "active");
      logEntry("AIRA", isVideoMode() ? "Support call connected. Update each status while the Checker prepares supporting evidence." : systemText("welcome"), "system");
      if (state.evidenceRequired) { renderEvidenceConsent(); }
      else { state.consentResolved=true; }
      playAuditIntroduction(systemText("welcome"), message.ringtone_base64 || "", message.audio_base64 || "");
    } else if (message.type === "audit_waiting" && !state.auditId) {
      setStatus("Call connected - waiting for audit initialization…", "ready");
    } else if (message.type === "audit_queued" && state.role === "AUDITOR") {
      setStatus(message.message || "Agent reconnecting - audit state queued…", "active");
    } else if (message.type === "audit_agent_resumed" && state.role === "AUDITOR") {
      setStatus("Agent reconnected - questionnaire synchronized", "active");
    } else if (message.type === "audit_agent_ready" && state.role === "AUDITOR") {
      setStatus(message.message || "Agent questionnaire is ready", "active");
    } else if (message.type === "audit_voice_status" && state.role === "AUDITOR" && String(message.audit_id) === state.auditId) {
      var voiceLabels = {
        preparing:"Agent microphone is preparing…", armed:"Agent voice answer is ready",
        listening:"Agent is answering by voice…", processing:"Converting the agent voice response…",
        retry:"Agent is repeating the voice answer…", unavailable:"Agent voice unavailable · answer buttons remain available"
      };
      setStatus(voiceLabels[message.stage] || message.detail || "Agent voice status updated", message.stage === "unavailable" ? "error" : "active");
    } else if (message.type === "audit_evidence_consent" && state.role === "AUDITOR" && String(message.audit_id) === state.auditId) {
      state.evidenceConsent = message.consented === true;
      state.consentResolved = true;
      setStatus(message.consented ? "Maker allowed questionnaire-controlled evidence" : "Maker declined stored evidence", message.consented ? "active" : "error");
      logEntry("AIRA", message.consented ? "Agent granted evidence consent for this audit." : "Agent declined evidence storage; the audit can continue with manual answers.", "system");
      if (message.consented && isVideoMode() && state.current) {
        captureVideoAuditEvidence(state.current);
      }
    } else if (message.type === "audit_capture_status" && state.role === "AUDITOR" && String(message.audit_id) === state.auditId) {
      setStatus(message.message || "Required evidence captured", "active");
      logEntry(
        "AIRA",
        (message.evidence_mode || "Required") + (
          isVideoMode() ? " evidence sent from the Checker device for Maker review." : " evidence captured on the Maker device."
        ),
        "pass"
      );
    } else if (message.type === "audit_capture_status" && state.role === "AGENT" && String(message.audit_id) === state.auditId) {
      setStatus(message.message || "Checker evidence received", "active");
      state.receivedEvidence[String(message.question_id)] = true;
      if (
        state.reviewing
        && state.supportRetakePending
        && String(state.supportRetakePending) === String(message.question_id)
      ) {
        state.supportRetakePending = "";
        renderMakerSupportClose();
        setStatus("Replacement evidence received · review before closing", "active");
        return;
      }
      if (state.current && String(state.current.questionId) === String(message.question_id)) {
        renderAgentResponses(state.current);
      }
      appendInlineQuestionEvidence(message.question_id);
    } else if (message.type === "audit_question" && state.role === "AGENT" && String(message.audit_id) === state.auditId) {
      acknowledgeAudit("audit_question", message);
      if (state.current && !state.responseSent && String(state.current.questionId) === String(message.question.questionId)) { return; }
      state.language=message.language || state.language; state.voice=message.voice || state.voice;
      state.index = Math.max(0, Number(message.question.sequence || 1) - 1);
      message.question.audioBase64 = message.audio_base64 || "";
      var knownQuestion = state.questions.findIndex(function (question) {
        return String(question.questionId) === String(message.question.questionId);
      });
      if (knownQuestion >= 0) { state.questions[knownQuestion] = message.question; }
      else {
        state.questions.push(message.question);
        state.questions.sort(function (left, right) { return Number(left.sequence || 0) - Number(right.sequence || 0); });
      }
      if (state.introductionActive || !state.consentResolved) { state.pendingQuestion = message.question; }
      else { presentAgentQuestion(message.question); }
    } else if (message.type === "audit_review_start" && state.role === "AGENT" && String(message.audit_id) === state.auditId) {
      if (message.support_close_required === true || isVideoMode()) {
        renderMakerSupportClose();
      } else {
        renderFinalReview();
      }
    } else if (message.type === "audit_retake_request" && state.role === "AUDITOR" && String(message.audit_id) === state.auditId) {
      var retakeQuestion = state.questions.find(function (question) {
        return String(question.questionId) === String(message.question_id);
      });
      if (!retakeQuestion || (retakeQuestion.evidenceMode || "NONE") === "NONE") {
        setStatus("The requested evidence step was not found.", "error");
        return;
      }
      state.supportRetakeQuestionId = String(retakeQuestion.questionId);
      state.current = retakeQuestion;
      state.reviewing = true;
      state.evidenceCaptureQuestionId = "";
      state.evidenceCaptureAttempts = 0;
      delete state.evidencePreviews[state.supportRetakeQuestionId];
      clearResponses();
      setText("aam-category", retakeQuestion.category + " · Maker requested retake");
      setText("aam-question", retakeQuestion.text);
      var retakeWait = document.createElement("div");
      retakeWait.className = "aam-waiting";
      retakeWait.textContent = "Preparing replacement evidence on the Checker device…";
      byId("aam-response-controls").appendChild(retakeWait);
      setStatus("Maker requested an evidence retake", "active");
      captureVideoAuditEvidence(retakeQuestion);
    } else if (message.type === "audit_review_submit" && state.role === "AUDITOR" && String(message.audit_id) === state.auditId) {
      applyParticipantReview(message);
    } else if (message.type === "audit_final_consent" && state.role === "AGENT" && String(message.audit_id) === state.auditId) {
      setStatus("Checker confirmed the audit · preparing final output", "active");
      setText("aam-question", "Checker confirmation received. Generating final View and Share options…");
    } else if (message.type === "audit_answer") {
      receiveAnswer(message);
    } else if (message.type === "audit_evidence_result" && state.role === "AUDITOR" && String(message.audit_id) === state.auditId) {
      state.evidenceCaptureQuestionId = "";
      clearVideoEvidenceTimer();
      if (message.error) {
        delete state.evidencePreviews[String(message.question_id)];
        setStatus(message.error, "error");
        if (state.current && String(state.current.questionId) === String(message.question_id)) {
          clearResponses();
          var retryCapture = document.createElement("button");
          retryCapture.type = "button";
          retryCapture.className = "aam-answer aam-answer--consent";
          retryCapture.textContent = "Retake Checker Evidence";
          retryCapture.addEventListener("click", function () {
            retryCapture.disabled = true;
            captureVideoAuditEvidence(state.current);
          }, {once:true});
          byId("aam-response-controls").appendChild(retryCapture);
        }
      } else {
        var completedRetake = Boolean(
          state.supportRetakeQuestionId
          && String(state.supportRetakeQuestionId) === String(message.question_id)
        );
        var storedPreview = state.evidencePreviews[String(message.question_id)];
        if (storedPreview) {
          storedPreview.stored = true;
          storedPreview.evidenceId = String(message.evidence_id || "");
        }
        var sent = byId("aam-response-controls").querySelector(".aam-capture-sent");
        if (sent) {
          sent.innerHTML = '<span class="fa fa-check-circle" aria-hidden="true"></span> Sent securely · visible to Maker';
        }
        setStatus("Checker evidence sent securely for Maker review", "active");
        logEntry("AIRA", (message.evidence_mode || "Required") + " evidence stored from the Checker device.", "pass");
        if (completedRetake) {
          state.supportRetakeQuestionId = "";
          state.current = null;
          clearResponses();
          setText("aam-category", "Replacement evidence sent");
          setText("aam-question", "The replacement is with the Maker for review. Waiting for closure or another retake request.");
          var reviewWait = document.createElement("div");
          reviewWait.className = "aam-waiting";
          reviewWait.textContent = "Waiting for Maker review…";
          byId("aam-response-controls").appendChild(reviewWait);
          appendStoredEvidenceGallery(byId("aam-response-controls"), state.auditId, "Updated Evidence Sent by Checker");
        }
        advanceSupportAfterEvidence(message.question_id);
      }
    } else if (message.type === "audit_evidence_result" && state.role === "AGENT" && String(message.audit_id) === state.auditId && state.current && String(message.question_id) === String(state.current.questionId)) {
      if (message.error) {
        clearResponses(); renderCaptureResponses(state.current);
        setStatus(message.error, "error");
      } else {
        stopEvidenceStream();
        setStatus("Required evidence captured securely", "active");
        submitAgentAnswer(state.current, "Captured", "Questionnaire evidence #" + message.evidence_id + " · " + message.evidence_mode);
      }
    } else if (message.type === "audit_voice_result" && state.role === "AGENT" && String(message.audit_id) === state.auditId && state.current && String(message.question_id) === String(state.current.questionId)) {
      var voiceButton = byId("aam-voice-answer");
      voiceButton.disabled = false;
      voiceButton.innerHTML = '<span class="fa fa-microphone" aria-hidden="true"></span> Answer by voice';
      if (!message.transcript) {
        retryAutomaticVoice(message.error || "Voice answer was not recognized.");
      } else {
        var voiceValue = message.normalized_value || mapVoiceAnswer(message.transcript, state.current);
        setStatus('Recognized: "' + message.transcript + '"', "active");
        submitAgentAnswer(
          state.current,
          voiceValue,
          "Voice response: " + message.transcript + (message.evidence_id ? " · Evidence #" + message.evidence_id : "")
        );
      }
    } else if (message.type === "audit_progress" && state.role === "AGENT" && String(message.audit_id) === state.auditId) {
      state.score = Number(message.score || 0);
      state.criticalFail = state.criticalFail || Boolean(message.critical_fail);
      updateProgress();
      setStatus("Answer scored · live score " + Math.round(state.score) + "%", state.criticalFail ? "error" : "active");
    } else if (message.type === "audit_complete" && String(message.audit_id) === state.auditId) {
      showSummary(Number(message.score || 0), Boolean(message.critical_fail));
      speak(
        isVideoMode() ? "The support call is closed. The final record is ready to view or share." : systemText("complete", Number(message.score || 0)),
        message.audio_base64 || ""
      );
    } else if (message.type === "audit_cancel" && String(message.audit_id) === state.auditId) {
      setStatus("Audit cancelled", "error"); setText("aam-question", message.reason || "The audit was cancelled."); clearResponses(); setAvatarMode("");
    }
  }
  function updateCallState(detail) {
    state.connected = Boolean(detail && detail.connected);
    if (state.connected && !state.auditId) {
      setText("aam-category", "Call connected");
      setText(
        "aam-question",
        detail.caller
          ? "The call was accepted. AIRA is starting the audit automatically."
          : "The call was accepted. Waiting for AIRA to deliver the first question."
      );
      setStatus(detail.caller ? "Starting audit automatically…" : "Call connected", detail.caller ? "active" : "ready");
      if (detail.caller) { global.setTimeout(startAudit, 0); }
      else { startAuditSync(); }
    } else if (!state.connected && !state.auditId) {
      stopAuditSync();
      setText("aam-category", "Connect a call to begin");
      setText("aam-question", "AIRA will ask the configured quality questions in sequence.");
    }
    if (!state.connected && state.auditId) { resetAudit(); showPanel(false); }
  }
  function init() {
    if (!byId("aam-audit-panel") || byId("aam-audit-panel").dataset.initialized === "Y") { return; }
    byId("aam-audit-panel").dataset.initialized="Y";
    if (!byId("aam-evidence-styles")) {
      var evidenceStyles = document.createElement("style");
      evidenceStyles.id = "aam-evidence-styles";
      evidenceStyles.textContent = ".aam-evidence-consent,.aam-capture-guide{display:grid;width:100%;gap:.35rem;padding:.75rem;border:1px solid #f0b7bd;border-left:4px solid #c62842;border-radius:9px;background:#fff7f8;color:#4a2830;font-size:.76rem;line-height:1.4}.aam-evidence-consent strong,.aam-capture-guide strong{display:flex;align-items:center;gap:.4rem;color:#a51d34}.aam-evidence-consent .fa-circle{font-size:.58rem;color:#d3203f;animation:aam-recording-pulse 1.2s ease-in-out infinite}.aam-answer--consent{border-color:#08775c!important;background:#08775c!important;color:#fff!important}.aam-evidence-preview{display:block;width:100%;max-height:240px;object-fit:cover;border-radius:10px;background:#10283a;border:2px solid #08775c}@keyframes aam-recording-pulse{50%{opacity:.3;transform:scale(.72)}}";
      document.head.appendChild(evidenceStyles);
    }
    byId("aam-close").addEventListener("click", cancelAudit);
    byId("aam-repeat").addEventListener("click", function () {
      if (state.current && state.role === "AGENT") { speak(state.current.text, state.current.audioBase64 || ""); }
    });
    byId("aam-voice-answer").addEventListener("click", function () { recognizeAnswer(false); });
    byId("aam-tab-calling").addEventListener("click", function () { showAuditHistory(false); });
    byId("aam-tab-history").addEventListener("click", function () { showAuditHistory(true); });
    byId("aam-history-refresh").addEventListener("click", loadAuditHistory);
    document.addEventListener("sas:call-state", function (event) { updateCallState(event.detail); });
    document.addEventListener("sas:audit-message", function (event) { receiveAudit(event.detail); });
    updateCallState(callApi().getContext ? callApi().getContext() : null);
  }

  if (document.readyState === "loading") { document.addEventListener("DOMContentLoaded", init, {once:true}); } else { init(); }
}(window, document, window.apex));
