(function (window, document, apex) {
  "use strict";

  var ATTRIBUTES = [
    ["AMOUNT", "Amount"], ["CHANNEL_CODE", "Channel"],
    ["MERCHANT_CATEGORY", "Merchant Category"], ["COUNTRY_CODE", "Country"],
    ["IS_INTERNATIONAL_YN", "International Y/N"], ["DEVICE_TRUST_SCORE", "Device Trust Score"],
    ["CUSTOMER_AGE_DAYS", "Customer Age Days"], ["PRIOR_24H_COUNT", "Prior 24h Count"],
    ["TRANSACTION_STATUS", "Transaction Status"], ["TRANSACTION_HOUR", "Transaction Hour"]
  ];
  var NUMERIC = {AMOUNT:1, DEVICE_TRUST_SCORE:1, CUSTOMER_AGE_DAYS:1, PRIOR_24H_COUNT:1, TRANSACTION_HOUR:1};
  var NUMBER_OPERATORS = [["EQ","Equals"],["NE","Not equal"],["GT","Greater than"],["GTE","Greater than or equal"],["LT","Less than"],["LTE","Less than or equal"],["BETWEEN","Between"]];
  var TEXT_OPERATORS = [["EQ","Equals"],["NE","Not equal"],["IN","Is one of"],["NOT_IN","Is not one of"],["LIKE","Like"],["NOT_LIKE","Not like"]];
  var state;
  var root;
  var dragPath;

  function item(name) { return apex.item(name); }
  function clone(value) { return JSON.parse(JSON.stringify(value)); }
  function condition() {
    return {type:"condition", attribute:"AMOUNT", operator:"GT", value1:"", value2:null, enabled:true, negate:false};
  }
  function group(logic) {
    return {type:"group", logic:logic || "AND", name:"", enabled:true, negate:false, children:[condition()]};
  }
  function defaultState() { return {version:1, root:group("AND")}; }
  function safeJson(value, fallback) { try { return JSON.parse(value); } catch (ignore) { return fallback; } }
  function cleanState() {
    return JSON.parse(JSON.stringify(state, function (key, value) {
      return key === "_collapsed" ? undefined : value;
    }));
  }
  function getNode(path) {
    var node = state.root;
    for (var i = 0; i < path.length; i += 1) { node = node.children[path[i]]; }
    return node;
  }
  function getParent(path) { return path.length ? getNode(path.slice(0, -1)) : null; }
  function sameParent(a, b) {
    return JSON.stringify(a.slice(0, -1)) === JSON.stringify(b.slice(0, -1));
  }
  function el(tag, className, text) {
    var node = document.createElement(tag);
    if (className) { node.className = className; }
    if (text !== undefined) { node.textContent = text; }
    return node;
  }
  function button(label, className, handler, title) {
    var node = el("button", "bre-icon-button " + (className || ""), label);
    node.type = "button";
    node.title = title || label;
    node.setAttribute("aria-label", title || label);
    node.addEventListener("click", handler);
    return node;
  }
  function select(options, value, onChange, className) {
    var node = el("select", className || "bre-control");
    options.forEach(function (option) {
      var itemNode = el("option", "", option[1]);
      itemNode.value = option[0];
      itemNode.selected = option[0] === value;
      node.appendChild(itemNode);
    });
    node.addEventListener("change", function () { onChange(node.value); });
    return node;
  }
  function input(value, placeholder, onInput, className) {
    var node = el("input", className || "bre-control");
    node.type = "text";
    node.value = value == null ? "" : value;
    node.placeholder = placeholder || "Value";
    node.addEventListener("input", function () { onInput(node.value); sync(false); });
    return node;
  }
  function toggle(label, checked, onChange, className) {
    var wrapper = el("label", "bre-toggle " + (className || ""));
    var control = el("input");
    control.type = "checkbox";
    control.checked = !!checked;
    control.addEventListener("change", function () { onChange(control.checked); sync(false); });
    wrapper.appendChild(control);
    wrapper.appendChild(el("span", "bre-toggle-track"));
    if (label) { wrapper.appendChild(el("span", "bre-toggle-label", label)); }
    return wrapper;
  }
  function pathLabel(path) { return [1].concat(path.map(function (value) { return value + 1; })).join("."); }
  function groupTitle(node) {
    var text = node.logic === "AND" ? "ALL conditions must match" : "ANY condition can match";
    return node.negate ? "NOT (" + text + ")" : text;
  }
  function depthOf(path) { return path.filter(function (_, index) { return index >= 0; }).length + 1; }

  function move(path, delta) {
    var parent = getParent(path);
    var index = path[path.length - 1];
    var target = index + delta;
    if (!parent || target < 0 || target >= parent.children.length) { return; }
    var temp = parent.children[index];
    parent.children[index] = parent.children[target];
    parent.children[target] = temp;
    render();
  }
  function remove(path) {
    var parent = getParent(path);
    if (!parent) { return; }
    parent.children.splice(path[path.length - 1], 1);
    render();
  }
  function duplicate(path) {
    var parent = getParent(path);
    var index = path[path.length - 1];
    if (!parent) { return; }
    parent.children.splice(index + 1, 0, clone(parent.children[index]));
    render();
  }
  function appendCondition(path) { getNode(path).children.push(condition()); render(); }
  function appendGroup(path) {
    if (depthOf(path) >= 12) { showMessage("Maximum nesting depth is 12.", true); return; }
    getNode(path).children.push(group("OR"));
    render();
  }
  function handleDrop(targetPath) {
    if (!dragPath || !sameParent(dragPath, targetPath)) { return; }
    var parent = getParent(dragPath);
    var from = dragPath[dragPath.length - 1];
    var to = targetPath[targetPath.length - 1];
    var moved = parent.children.splice(from, 1)[0];
    parent.children.splice(to, 0, moved);
    dragPath = null;
    render();
  }

  function renderCondition(node, path) {
    var row = el("div", "bre-condition bre-node" + (node.enabled === false ? " is-disabled" : ""));
    row.draggable = true;
    row.addEventListener("dragstart", function () { dragPath = path.slice(); row.classList.add("is-dragging"); });
    row.addEventListener("dragend", function () { row.classList.remove("is-dragging"); dragPath = null; });
    row.addEventListener("dragover", function (event) { event.preventDefault(); });
    row.addEventListener("drop", function (event) { event.preventDefault(); handleDrop(path); });
    row.appendChild(el("span", "bre-path", pathLabel(path)));
    row.appendChild(el("span", "bre-drag", "⠿"));

    row.appendChild(select(ATTRIBUTES, node.attribute, function (value) {
      node.attribute = value;
      var allowed = NUMERIC[value] ? NUMBER_OPERATORS : TEXT_OPERATORS;
      if (!allowed.some(function (entry) { return entry[0] === node.operator; })) { node.operator = allowed[0][0]; }
      render();
    }, "bre-control bre-attribute"));
    var operators = NUMERIC[node.attribute] ? NUMBER_OPERATORS : TEXT_OPERATORS;
    row.appendChild(select(operators, node.operator, function (value) { node.operator = value; render(); }, "bre-control bre-operator"));
    row.appendChild(input(node.value1, node.operator === "IN" || node.operator === "NOT_IN" ? "Comma-separated values" : "Value", function (value) { node.value1 = value; }, "bre-control bre-value"));
    if (node.operator === "BETWEEN") {
      row.appendChild(el("span", "bre-and", "and"));
      row.appendChild(input(node.value2, "Value 2", function (value) { node.value2 = value; }, "bre-control bre-value bre-value-2"));
    }
    row.appendChild(toggle("NOT", node.negate, function (value) { node.negate = value; }, "bre-not-toggle"));
    row.appendChild(toggle("", node.enabled !== false, function (value) { node.enabled = value; render(); }));
    var actions = el("div", "bre-node-actions");
    actions.appendChild(button("↑", "", function () { move(path, -1); }, "Move up"));
    actions.appendChild(button("↓", "", function () { move(path, 1); }, "Move down"));
    actions.appendChild(button("⧉", "", function () { duplicate(path); }, "Duplicate"));
    actions.appendChild(button("×", "is-danger", function () { remove(path); }, "Delete"));
    row.appendChild(actions);
    return row;
  }

  function renderGroup(node, path, isRoot) {
    var card = el("section", "bre-group bre-node bre-group--" + node.logic.toLowerCase() + (node.enabled === false ? " is-disabled" : ""));
    if (!isRoot) {
      card.draggable = true;
      card.addEventListener("dragstart", function (event) { event.stopPropagation(); dragPath = path.slice(); card.classList.add("is-dragging"); });
      card.addEventListener("dragend", function () { card.classList.remove("is-dragging"); dragPath = null; });
      card.addEventListener("dragover", function (event) { event.preventDefault(); event.stopPropagation(); });
      card.addEventListener("drop", function (event) { event.preventDefault(); event.stopPropagation(); handleDrop(path); });
    }
    var header = el("header", "bre-group-header");
    header.appendChild(el("span", "bre-path bre-path--group", pathLabel(path)));
    header.appendChild(button(node._collapsed ? "›" : "⌄", "bre-collapse", function () { node._collapsed = !node._collapsed; render(); }, "Collapse group"));
    header.appendChild(el("strong", "bre-group-title", groupTitle(node)));
    header.appendChild(select([["AND","AND"],["OR","OR"]], node.logic, function (value) { node.logic = value; render(); }, "bre-logic bre-logic--" + node.logic.toLowerCase()));
    header.appendChild(toggle("NOT", node.negate, function (value) { node.negate = value; render(); }, "bre-not-toggle"));
    header.appendChild(toggle("", node.enabled !== false, function (value) { node.enabled = value; render(); }));
    var actions = el("div", "bre-group-actions");
    actions.appendChild(button("＋ Condition", "bre-add", function () { appendCondition(path); }, "Add condition"));
    actions.appendChild(button("＋ Group", "bre-add", function () { appendGroup(path); }, "Add nested group"));
    if (!isRoot) {
      actions.appendChild(button("⧉", "", function () { duplicate(path); }, "Duplicate group"));
      actions.appendChild(button("×", "is-danger", function () { remove(path); }, "Delete group"));
    }
    header.appendChild(actions);
    card.appendChild(header);
    if (!node._collapsed) {
      var body = el("div", "bre-group-body");
      node.children.forEach(function (child, index) {
        var childPath = path.concat(index);
        body.appendChild(child.type === "group" ? renderGroup(child, childPath, false) : renderCondition(child, childPath));
      });
      if (!node.children.length) {
        var empty = el("div", "bre-empty", "This group is empty. Add a condition or nested group.");
        empty.appendChild(button("＋ Condition", "bre-add", function () { appendCondition(path); }));
        empty.appendChild(button("＋ Group", "bre-add", function () { appendGroup(path); }));
        body.appendChild(empty);
      }
      card.appendChild(body);
    }
    return card;
  }

  function stats(node, result) {
    result.groups += 1;
    node.children.forEach(function (child) {
      if (child.type === "group") { stats(child, result); } else { result.conditions += 1; }
    });
  }
  function updateStats() {
    var result = {groups:0, conditions:0};
    stats(state.root, result);
    document.getElementById("breConditionCount").textContent = result.conditions + " conditions";
    document.getElementById("breGroupCount").textContent = result.groups + " groups";
  }
  function showMessage(message, error) {
    var node = document.getElementById("breValidation");
    node.textContent = message || "Rule tree is valid";
    node.className = "bre-validation " + (error ? "is-error" : "is-valid");
  }
  function validateGroup(node, depth, path, errors, counts) {
    counts.groups += 1;
    if (depth > 12) { errors.push(path + ": nesting exceeds 12 levels"); }
    if (node.logic !== "AND" && node.logic !== "OR") { errors.push(path + ": choose AND or OR"); }
    if (!Array.isArray(node.children) || !node.children.length) { errors.push(path + ": group cannot be empty"); return; }
    node.children.forEach(function (child, index) {
      var childPath = path + "." + (index + 1);
      if (child.type === "group") { validateGroup(child, depth + 1, childPath, errors, counts); return; }
      counts.conditions += 1;
      if (!child.attribute || !child.operator || !String(child.value1 || "").trim()) { errors.push(childPath + ": attribute, operator and Value 1 are required"); }
      if (NUMERIC[child.attribute] && !/^-?[0-9]+([.][0-9]+)?$/.test(String(child.value1 || "").trim())) { errors.push(childPath + ": Value 1 must be numeric"); }
      if (child.operator === "BETWEEN" && !/^-?[0-9]+([.][0-9]+)?$/.test(String(child.value2 || "").trim())) { errors.push(childPath + ": BETWEEN requires numeric Value 2"); }
    });
  }
  function validate() {
    var errors = [];
    var counts = {groups:0, conditions:0};
    validateGroup(state.root, 1, "1", errors, counts);
    if (counts.groups > 100) { errors.push("Maximum 100 groups per rule"); }
    if (counts.conditions > 500) { errors.push("Maximum 500 conditions per rule"); }
    showMessage(errors.length ? errors[0] : "Rule tree is valid · " + counts.conditions + " conditions / " + counts.groups + " groups", !!errors.length);
    return !errors.length;
  }
  function sync(runValidation) {
    item("P31_RULE_JSON").setValue(JSON.stringify(cleanState()));
    item("P31_RULE_CODE").setValue(document.getElementById("breRuleCode").value.trim().toUpperCase().replace(/[^A-Z0-9_]/g, "_"));
    item("P31_RULE_NAME").setValue(document.getElementById("breRuleName").value.trim());
    item("P31_RULE_DESCRIPTION").setValue(document.getElementById("breRuleDescription").value.trim());
    item("P31_RISK_POINTS").setValue(document.getElementById("breRiskPoints").value);
    item("P31_PRIORITY_NO").setValue(document.getElementById("brePriority").value);
    item("P31_TEST_TRANSACTION_ID").setValue(document.getElementById("breTestTransaction").value);
    return runValidation === false ? true : validate();
  }
  function renderTrace() {
    var host = document.getElementById("breTrace");
    var banner = document.getElementById("breTestResult");
    var trace = safeJson(item("P31_TEST_TRACE").getValue() || "[]", []);
    var matched = item("P31_TEST_MATCHED").getValue();
    host.replaceChildren();
    if (!matched) { banner.className = "bre-test-result is-empty"; banner.textContent = "Choose a transaction and run a test."; return; }
    banner.className = "bre-test-result " + (matched === "Y" ? "is-match" : "is-no-match");
    banner.textContent = matched === "Y" ? "✓ MATCHED · Risk +" + document.getElementById("breRiskPoints").value : "✕ NOT MATCHED";
    trace.forEach(function (entry) {
      var row = el("div", "bre-trace-row bre-trace-row--" + entry.nodeType);
      row.appendChild(el("span", "bre-trace-path", entry.path));
      row.appendChild(el("span", "bre-trace-label", entry.label));
      row.appendChild(el("strong", entry.result ? "is-true" : "is-false", entry.result ? "True" : "False"));
      host.appendChild(row);
    });
  }
  function render() {
    var canvas = document.getElementById("breTree");
    canvas.replaceChildren(renderGroup(state.root, [], true));
    updateStats();
    sync(false);
    validate();
  }
  function bindProperties() {
    [["breRuleCode","P31_RULE_CODE"],["breRuleName","P31_RULE_NAME"],["breRuleDescription","P31_RULE_DESCRIPTION"],["breRiskPoints","P31_RISK_POINTS"],["brePriority","P31_PRIORITY_NO"]].forEach(function (pair) {
      var control = document.getElementById(pair[0]);
      control.value = item(pair[1]).getValue() || control.value;
      control.addEventListener("input", function () { sync(false); });
    });
    var active = item("P31_ACTIVE_YN").getValue() !== "N";
    var activeControl = document.getElementById("breActive");
    activeControl.checked = active;
    activeControl.addEventListener("change", function () { item("P31_ACTIVE_YN").setValue(activeControl.checked ? "Y" : "N"); });
    var selector = document.getElementById("breRuleSelector");
    selector.value = item("P31_RULE_ID").getValue() || "";
    selector.addEventListener("change", function () {
      item("P31_RULE_ID").setValue(selector.value);
      apex.submit({request:"LOAD_RULE", showWait:true});
    });
  }
  function bindButtons() {
    function submit(request, active) {
      if (!sync(true)) { return; }
      if (active !== null) { item("P31_ACTIVE_YN").setValue(active ? "Y" : "N"); }
      apex.submit({request:request, showWait:true});
    }
    document.getElementById("BRE_SAVE_DRAFT").addEventListener("click", function (event) { event.preventDefault(); submit("SAVE_DRAFT", false); });
    document.getElementById("BRE_SAVE_ACTIVATE").addEventListener("click", function (event) { event.preventDefault(); submit("SAVE_ACTIVATE", true); });
    document.getElementById("breRunTest").addEventListener("click", function (event) { event.preventDefault(); submit("TEST_RULE", null); });
    document.querySelectorAll(".bre-tab").forEach(function (tab) {
      tab.addEventListener("click", function () {
        document.querySelectorAll(".bre-tab").forEach(function (other) { other.classList.remove("is-active"); });
        tab.classList.add("is-active");
        var history = document.getElementById("rule_version_ir");
        if (history) { history.style.display = tab.dataset.target === "history" ? "block" : "none"; }
        if (tab.dataset.target === "history" && history) {
          history.scrollIntoView({behavior:"smooth", block:"start"});
          try { apex.region("rule_version_ir").refresh(); } catch (ignore) {}
        }
        if (tab.dataset.target === "trace") { document.getElementById("breTracePanel").scrollIntoView({behavior:"smooth", block:"center"}); }
      });
    });
  }
  function init() {
    root = document.getElementById("breAdvancedBuilder");
    if (!root || root.dataset.initialized === "Y") { return; }
    root.dataset.initialized = "Y";
    state = safeJson(item("P31_RULE_JSON").getValue(), defaultState());
    if (!state || !state.root) { state = defaultState(); }
    bindProperties();
    bindButtons();
    render();
    renderTrace();
  }

  document.addEventListener("DOMContentLoaded", init);
  document.addEventListener("apexreadyend", init);
}(window, document, window.apex));
