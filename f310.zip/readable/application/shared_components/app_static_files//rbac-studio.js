(function ($) {
  "use strict";

  /*
   * Page assets can be evaluated again after an APEX partial-page lifecycle.
   * A second delegated handler queues a second drawer open; closing the first
   * then makes the drawer appear to open again. Keep one RBAC controller for
   * the whole browser page.
   */
  if (window.__SBOS_RBAC_STUDIO_INITIALIZED__) {
    return;
  }
  window.__SBOS_RBAC_STUDIO_INITIALIZED__ = true;

  var state = {
    tab: "overview",
    verticalId: null,
    search: "",
    offset: 0,
    limit: 100,
    treeNodes: {},
    selectedTreeNode: null,
    showInactive: false,
    overviewPane: "health",
    hierarchyPane: "levels",
    roleCataloguePane: "roles",
    selectedRoleGroupId: null,
    selectedAssignmentUserId: null,
    selectedAssignmentUserName: "",
    activeNativeTab: null,
    refreshNative: false,
    versionsPane: "versions",
    data: null,
    busy: false,
    editorOpen: false,
    editorClosing: false,
    suppressEditorOpenUntil: 0
  };
  var editorCloseTimer;
  var userLookupTimer;
  var assignmentDetailRefreshTimer;
  var nativeRegionIds = [
    "rbac_native_users",
    "rbac_native_assignment_users",
    "rbac_native_assignment_detail"
  ];
  var nativeRegionNodes = {};

  var tabTitles = {
    overview: ["Governance overview", "Current RBAC health and Agent Master delta flow."],
    hierarchy: ["Hierarchy", "Configure vertical levels and manage derived organization nodes."],
    roles: ["Roles & Permissions", "Organize reusable roles and govern live APEX resources."],
    assignments: ["Users & Access", "Assign reusable roles to users at an exact hierarchy scope."],
    userlevels: ["Users & Access", "Manage governance levels, identities and scoped access."],
    users: ["Users & Access", "Manage governance levels, identities and scoped access."],
    versions: ["Governance", "Validate, synchronize, version and audit governed RBAC changes."]
  };

  function esc(value) {
    return $("<div>").text(value === null || value === undefined ? "" : String(value)).html();
  }

  function attr(value) {
    return esc(value).replace(/"/g, "&quot;");
  }

  function n(value) {
    return Number(value || 0).toLocaleString();
  }

  function today() {
    return new Date().toISOString().slice(0, 10);
  }

  function badge(value, type) {
    var text = value || "-";
    var kind = type || (String(text).toUpperCase() === "ACTIVE" ||
      String(text).toUpperCase() === "COMPLETED" ||
      String(text).toUpperCase() === "Y" ? "success" : "muted");
    return '<span class="rbac-badge rbac-badge--' + kind + '">' + esc(text) + "</span>";
  }

  function icon(name) {
    return '<span class="fa fa-' + name + '" aria-hidden="true"></span>';
  }

  function toast(message, isError) {
    var $toast = $("#rbac-toast");
    $toast.text(message || (isError ? "The operation failed." : "Saved."))
      .toggleClass("is-error", !!isError)
      .addClass("is-visible");
    window.clearTimeout(toast.timer);
    toast.timer = window.setTimeout(function () {
      $toast.removeClass("is-visible is-error");
    }, 3500);
  }

  function errorMessage(xhr, fallback) {
    var result = fallback || "The operation could not be completed.";
    var responseText = xhr && xhr.responseText ? String(xhr.responseText) : "";
    var internalError = /APEX\.API\.RUNTIME_API_USAGE\.ERROR|PL\/SQL Call Stack|error_backtrace|incident are available via debug id/i;

    if (internalError.test(responseText)) {
      return "The account could not be provisioned. Contact the application administrator and provide the time of this attempt.";
    }

    try {
      var body = JSON.parse(responseText);
      result = body.message || body.error || result;
    } catch (ignore) {
      if (responseText) {
        /*
         * APEX can append its own error envelope after an on-demand process
         * response. Never surface that diagnostic payload or a PL/SQL stack in
         * the drawer. Preserve a short plain-text validation message only.
         */
        var firstLine = responseText
          .replace(/<[^>]+>/g, " ")
          .replace(/\s+/g, " ")
          .trim();
        if (firstLine &&
            firstLine.length <= 240 &&
            !/[{}\[\]"]/.test(firstLine) &&
            !/ORA-\d+|WWV_FLOW|APEX_\d+/i.test(firstLine)) {
          result = firstLine;
        }
      }
    }
    return result;
  }

  function setBusy(value) {
    state.busy = value;
    if (value) {
      $("#rbac-studio button:not(:disabled)")
        .attr("data-rbac-busy-disabled", "Y")
        .prop("disabled", true);
    } else {
      $("#rbac-studio button[data-rbac-busy-disabled='Y']")
        .removeAttr("data-rbac-busy-disabled")
        .prop("disabled", false);
    }
    $("#rbac-loading").toggle(value);
  }

  function process(name, payload) {
    payload = payload || {};
    return apex.server.process(name, payload, { dataType: "json" });
  }

  function entityDetail(entity, id) {
    return process("RBAC_ENTITY_DETAIL", {
      x01: entity,
      x02: Number(id)
    });
  }

  function setSelectedAssignmentUser(user) {
    state.selectedAssignmentUserId = Number(user.id);
    state.selectedAssignmentUserName =
      user.displayName || user.userName || ("User #" + user.id);
    apex.item("P60_SELECTED_RBAC_USER_ID")
      .setValue(state.selectedAssignmentUserId, null, true);
  }

  function selectedAssignmentHeaderHtml() {
    return '<div class="rbac-native-selected-identity"><span class="rbac-workflow-step">2</span>' +
      '<span class="rbac-ir-avatar">' + icon("key") +
      '</span><span><small>Manage assignments for</small><strong>' +
      esc(state.selectedAssignmentUserName || ("User #" +
        state.selectedAssignmentUserId)) +
      '</strong></span></div><button type="button" class="rbac-button rbac-button--primary" ' +
      'data-rbac-action="add-scope">' + icon("plus") +
      " Add Assignment</button>";
  }

  function updateSelectedAssignmentPanel() {
    var $panel = $(".rbac-native-detail-panel");
    $("#rbac-assignment-selected-head").html(
      selectedAssignmentHeaderHtml()
    );
    $panel.removeClass("is-awaiting-selection");
    $panel.find(".rbac-native-detail-empty").remove();
    var selectedSelector =
      "[data-rbac-action='native-select-assignment-user'][data-id='" +
      state.selectedAssignmentUserId + "']";
    $("#rbac_native_assignment_users .a-IRR-table tr")
      .removeClass("is-rbac-selected");
    $("#rbac_native_assignment_users")
      .find(selectedSelector).closest("tr").addClass("is-rbac-selected");
  }

  function selectNativeAssignmentUser(id, navigate, displayName) {
    setSelectedAssignmentUser({
      id: Number(id),
      displayName: displayName || ("User #" + id)
    });
    if (navigate) {
      state.tab = "assignments";
      state.search = "";
      state.offset = 0;
      state.refreshNative = "assignment-detail";
      load();
    } else {
      updateSelectedAssignmentPanel();
      refreshSelectedAssignments();
    }
  }

  function editNativeEntity(entity, id) {
    setBusy(true);
    entityDetail(entity, id).done(function (detail) {
      if (!detail || !detail.found) {
        toast("The selected record is no longer available.", true);
        state.refreshNative = state.tab === "users" ?
          "users" : "assignment-detail";
        syncNativeRegions();
        return;
      }
      openForm(entity, detail);
    }).fail(function (xhr) {
      toast(errorMessage(xhr, "The record could not be loaded."), true);
    }).always(function () {
      setBusy(false);
    });
  }

  function setEditorTitle(title) {
    var $drawer = $("#rbac-dialog");
    $drawer.attr("title", title);
    if ($drawer.hasClass("ui-dialog-content") &&
        typeof $drawer.dialog === "function") {
      $drawer.dialog("option", "title", title);
    }
    $("#rbac-dialog-title").text(title);
  }

  function fixDrawerFrame() {
    var $region = $("#rbac-dialog");
    var $dialog = $region.closest(".ui-dialog");

    if (!$region.length || !$dialog.length) {
      return;
    }

    /*
     * Universal Theme sizes the drawer content independently from its title
     * bar. Mark the generated frame so CSS can make the whole drawer one
     * viewport-height flex column: title, scrollable body, fixed actions.
     */
    $dialog.addClass("rbac-editor-drawer");
    $dialog.addClass("rbac-editor-open");
    $region.addClass("rbac-editor-region");
  }

  function beginEditorClose() {
    var element = document.getElementById("rbac-dialog");
    state.editorOpen = false;
    state.editorClosing = true;
    state.suppressEditorOpenUntil = Date.now() + 1000;
    if (element) {
      element.removeAttribute("data-rbac-open-requested");
      $(element).closest(".ui-dialog").removeClass("rbac-editor-open");
    }
    window.clearTimeout(editorCloseTimer);
    editorCloseTimer = window.setTimeout(function () {
      state.editorClosing = false;
    }, 250);
  }

  function openEditor() {
    var element = document.getElementById("rbac-dialog");

    /*
     * Inline drawers restore focus to their triggering control when they
     * close. On some APEX/Universal Theme builds that interaction can replay
     * the delegated edit click. Ignore every open request until the close
     * lifecycle and focus restoration have completely finished.
     */
    if (!element ||
        state.editorClosing ||
        state.editorOpen ||
        Date.now() < state.suppressEditorOpenUntil ||
        element.getAttribute("data-rbac-open-requested") === "Y") {
      return;
    }
    element.setAttribute("data-rbac-open-requested", "Y");
    state.editorOpen = true;
    if (element && element.tagName === "DIALOG" &&
        typeof element.showModal === "function") {
      element.showModal();
      return;
    }
    apex.theme.openRegion("rbac-dialog");
    fixDrawerFrame();
    window.requestAnimationFrame(fixDrawerFrame);
  }

  function closeEditor() {
    var element = document.getElementById("rbac-dialog");
    if (state.editorClosing) {
      return;
    }
    beginEditorClose();
    if (element && element.tagName === "DIALOG" &&
        typeof element.close === "function") {
      element.close();
      return;
    }
    apex.theme.closeRegion("rbac-dialog");
  }

  function load(showSpinner) {
    if (showSpinner !== false) {
      parkNativeRegions();
      $("#rbac-content").html('<div class="rbac-spinner">' +
        icon("spinner fa-spin") + " Loading governed access data…</div>");
    }
    setBusy(true);
    process("RBAC_STUDIO_DATA", {
      x01: state.tab,
      x02: state.verticalId || "",
      x03: state.search || "",
      x04: state.offset,
      x05: state.limit
    }).done(function (data) {
      state.data = data;
      state.verticalId = Number(data.selectedVerticalId || state.verticalId);
      if (!(data.roleGroups || []).some(function (group) {
        return Number(group.id) === Number(state.selectedRoleGroupId);
      })) {
        state.selectedRoleGroupId = data.roleGroups && data.roleGroups.length ?
          Number(data.roleGroups[0].id) : null;
      }
      if (["users", "assignments"].indexOf(state.tab) < 0 &&
          !(data.users || []).some(function (user) {
            return Number(user.id) === Number(state.selectedAssignmentUserId);
          })) {
        state.selectedAssignmentUserId = data.users && data.users.length ?
          Number(data.users[0].id) : null;
      }
      updateHeader();
      render();
    }).fail(function (xhr) {
      $("#rbac-content").html('<div class="rbac-empty">' + icon("warning") +
        "<strong>RBAC Studio could not be loaded.</strong><br>" +
        esc(errorMessage(xhr)) + "</div>");
    }).always(function () {
      setBusy(false);
    });
  }

  function updateHeader() {
    var d = state.data || {};
    $("#rbac-version-chip").html(icon("database") + "Version " + esc(d.currentVersion || 1));
    $("#rbac-active-chip").html(icon("check-circle") + (d.active ? "ACTIVE" : "DRAFT"));
  }

  function renderToolbar() {
    var d = state.data || {};
    var title = tabTitles[state.tab];
    var left = '<div><div class="rbac-region-title">' + esc(title[0]) +
      '</div><div class="rbac-region-subtitle">' + esc(title[1]) + "</div></div>";
    var actions = "";

    if (state.tab === "hierarchy") {
      actions += '<select id="rbac-vertical-select" class="rbac-select" aria-label="Vertical">' +
        d.verticals.map(function (v) {
          return '<option value="' + v.id + '"' +
            (Number(v.id) === Number(state.verticalId) ? " selected" : "") + ">" +
            esc(v.name) + "</option>";
        }).join("") + "</select>";
      actions += button("sitemap", "New Vertical", "add-vertical");
    } else if (state.tab === "roles") {
      if (state.roleCataloguePane === "resources") {
        actions += button("refresh", "Sync APEX Resources", "sync-apex-resources",
          "primary");
      } else {
        actions += searchBox("Search roles");
      }
    } else if (state.tab === "assignments") {
      actions = "";
    } else if (state.tab === "userlevels") {
      actions += button("plus", "New User Level", "add-user-level", "primary");
    } else if (state.tab === "users") {
      actions += button("user-plus", "New User", "add-user", "primary");
    } else if (state.tab === "versions") {
      actions += button("check-circle", "Validate", "validate");
      actions += button("refresh", "Run Delta Sync", "sync");
      actions += button("bolt", "Activate Version", "activate", "primary");
    } else {
      actions += button("refresh", "Run Delta Sync", "sync");
      actions += button("shield", "Validate", "validate", "primary");
    }
    return '<div class="rbac-toolbar"><div class="rbac-toolbar-group">' + left +
      '</div><div class="rbac-toolbar-group">' + actions + "</div></div>";
  }

  function searchBox(placeholder) {
    return '<div class="rbac-search-wrap">' + icon("search") +
      '<input id="rbac-search" class="rbac-input rbac-search" type="search" value="' +
      attr(state.search) + '" placeholder="' + attr(placeholder) + '"></div>';
  }

  function button(iconName, label, action, kind) {
    return '<button type="button" class="rbac-button' +
      (kind ? " rbac-button--" + kind : "") + '" data-rbac-action="' + action + '">' +
      icon(iconName) + esc(label) + "</button>";
  }

  function render() {
    if (!state.data) {
      return;
    }
    var views = {
      overview: overviewView,
      hierarchy: hierarchyView,
      roles: rolesView,
      assignments: assignmentsView,
      userlevels: userLevelsView,
      users: usersView,
      versions: versionsView
    };
    updatePrimaryTabs();
    parkNativeRegions();
    $("#rbac-content").html(renderToolbar() +
      '<div class="rbac-view">' + views[state.tab]() + pager() + "</div>");
    syncNativeRegions();
    if (state.tab === "hierarchy" && state.hierarchyPane === "nodes") {
      window.setTimeout(function () { loadHierarchyTree(null, ""); }, 0);
    }
  }

  function refreshNativeRegion(staticId) {
    var region;
    try {
      region = apex.region(staticId);
    } catch (ignore) {
      region = null;
    }
    if (region && typeof region.refresh === "function") {
      region.refresh();
    }
  }

  function refreshSelectedAssignments() {
    window.clearTimeout(assignmentDetailRefreshTimer);
    assignmentDetailRefreshTimer = window.setTimeout(function () {
      refreshNativeRegion("rbac_native_assignment_detail");
    }, 80);
  }

  function captureNativeRegions() {
    nativeRegionIds.forEach(function (staticId) {
      if (!nativeRegionNodes[staticId] ||
          !nativeRegionNodes[staticId].length) {
        var $region = $("#" + staticId);
        if ($region.length) {
          nativeRegionNodes[staticId] = $region;
        }
      }
    });
  }

  function parkNativeRegions() {
    captureNativeRegions();
    var $parking = $("#rbac-native-parking");
    if (!$parking.length) {
      return;
    }
    nativeRegionIds.forEach(function (staticId) {
      var $region = nativeRegionNodes[staticId];
      if ($region && $region.length) {
        $region.removeClass("is-visible").detach().appendTo($parking);
      }
    });
  }

  function mountNativeRegions(nativeTab) {
    var mounts = nativeTab === "users" ? {
      rbac_native_users: "#rbac-native-users-slot"
    } : (nativeTab === "assignments" ? {
      rbac_native_assignment_users: "#rbac-native-assignment-users-slot",
      rbac_native_assignment_detail: "#rbac-native-assignment-detail-slot"
    } : {});

    Object.keys(mounts).forEach(function (staticId) {
      var $region = nativeRegionNodes[staticId];
      var $slot = $(mounts[staticId]);
      if ($region && $region.length && $slot.length) {
        $region.detach().appendTo($slot).addClass("is-visible");
        if (staticId === "rbac_native_users") {
          $region.find(".a-IRR-search-field")
            .attr("placeholder", "Search users");
        } else if (staticId === "rbac_native_assignment_users") {
          $region.find(".a-IRR-search-field")
            .attr("placeholder", "Find a user");
        }
      }
    });
    if (nativeTab === "assignments" && state.selectedAssignmentUserId) {
      var selectedSelector =
        "[data-rbac-action='native-select-assignment-user'][data-id='" +
        state.selectedAssignmentUserId + "']";
      $("#rbac_native_assignment_users .a-IRR-table tr")
        .removeClass("is-rbac-selected");
      $("#rbac_native_assignment_users")
        .find(selectedSelector).closest("tr").addClass("is-rbac-selected");
    }
  }

  function syncNativeRegions() {
    var nativeTab = state.tab === "users" ? "users" :
      (state.tab === "assignments" ? "assignments" : null);
    mountNativeRegions(nativeTab);
    $("#rbac_studio_region")
      .toggleClass("rbac-native-users-active", nativeTab === "users")
      .toggleClass("rbac-native-assignments-active",
        nativeTab === "assignments");

    if (nativeTab && state.refreshNative) {
      if (state.refreshNative === "users") {
        refreshNativeRegion("rbac_native_users");
      } else if (state.refreshNative === "assignment-users") {
        refreshNativeRegion("rbac_native_assignment_users");
      } else if (state.refreshNative === "assignment-detail") {
        refreshNativeRegion("rbac_native_assignment_detail");
      } else if (state.refreshNative === "assignments") {
        refreshNativeRegion("rbac_native_assignment_users");
        refreshNativeRegion("rbac_native_assignment_detail");
      }
    }
    state.activeNativeTab = nativeTab;
    state.refreshNative = false;
  }

  function primaryGroup(tab) {
    if (tab === "roles") { return "roles"; }
    if (tab === "userlevels" || tab === "users" || tab === "assignments") {
      return "users";
    }
    if (tab === "versions") { return "governance"; }
    return tab;
  }

  function updatePrimaryTabs() {
    var group = primaryGroup(state.tab);
    $(".rbac-tab").each(function () {
      var active = this.dataset.rbacGroup === group;
      $(this).toggleClass("is-active", active)
        .attr("aria-selected", active ? "true" : "false");
    });
  }

  function sectionTabs(label, items, activeTab) {
    return '<div class="rbac-inner-tabs rbac-management-tabs" role="tablist" aria-label="' +
      attr(label) + '">' + items.map(function (item) {
        var active = item.tab === activeTab;
        return '<button type="button" class="rbac-inner-tab' +
          (active ? " is-active" : "") +
          '" data-rbac-action="section-tab" data-tab="' + attr(item.tab) +
          '" role="tab" aria-selected="' + active + '">' + icon(item.icon) +
          esc(item.label) + "</button>";
      }).join("") + "</div>";
  }

  function userManagementTabs() {
    return sectionTabs("Users and Access sections", [
      { tab: "userlevels", label: "User Level Master", icon: "sort-amount-asc" },
      { tab: "users", label: "User Master", icon: "users" },
      { tab: "assignments", label: "RBAC Assignments", icon: "key" }
    ], state.tab);
  }

  function pager() {
    var page = state.data.page || {};
    var total = Number(page.total || 0);
    if (["users", "assignments"].indexOf(state.tab) >= 0 ||
        total <= state.limit) {
      return "";
    }
    var from = Math.min(state.offset + 1, total);
    var to = Math.min(state.offset + state.limit, total);
    return '<div class="rbac-toolbar" style="margin-top:12px;border:1px solid var(--rbac-border);border-radius:8px">' +
      '<span class="rbac-region-subtitle">Showing ' + n(from) + "–" + n(to) +
      " of " + n(total) + "</span><div class=\"rbac-toolbar-group\">" +
      '<button type="button" class="rbac-button" data-rbac-action="page-prev"' +
      (state.offset === 0 ? " disabled" : "") + ">" + icon("chevron-left") +
      ' Previous</button><button type="button" class="rbac-button" data-rbac-action="page-next"' +
      (to >= total ? " disabled" : "") + ">Next " + icon("chevron-right") +
      "</button></div></div>";
  }

  function stat(label, value, iconName) {
    return '<div class="rbac-stat"><span class="rbac-stat-icon">' + icon(iconName) +
      '</span><span class="rbac-stat-label">' + esc(label) +
      '</span><strong class="rbac-stat-value">' + n(value) + "</strong></div>";
  }

  function region(title, subtitle, body, action) {
    return '<section class="rbac-region"><div class="rbac-region-head"><div>' +
      '<h2 class="rbac-region-title">' + esc(title) + '</h2><p class="rbac-region-subtitle">' +
      esc(subtitle || "") + "</p></div>" + (action || "") +
      '</div><div class="rbac-region-body">' + body + "</div></section>";
  }

  function overviewView() {
    var c = state.data.counts;
    var cards = '<div class="rbac-card-grid">' +
      stat("Agent Master Rows", c.agents, "users") +
      stat("Hierarchy Nodes", c.nodes, "sitemap") +
      stat("Active Roles", c.roles, "shield") +
      stat("Active Assignments", c.assignments, "key") + "</div>";
    var pipeline = connectedFlow([
      { icon: "exchange", title: "ETL Workflow", detail: "Curated source load" },
      { icon: "database", title: "SBOS_AGENT_MASTER",
        detail: n(c.agents) + " governed agents" },
      { icon: "refresh", title: "Hierarchy Delta Sync", detail: "Changed rows only" },
      { icon: "sitemap", title: "RBAC Scope Resolver",
        detail: n(c.nodes) + " searchable nodes" },
      { icon: "lock", title: "Secured Modules", detail: "Access, Profile and BRE" }
    ], "rbac-level-flow--overview");
    var verticals = compactTable(
      ["Vertical", "Source", "Levels", "Agents", "Version", "Status"],
      state.data.verticals.map(function (v) {
        return [esc(v.name), '<code>' + esc(v.sourceTable) + "</code>",
          n(v.levelCount), n(v.agentCount), "v" + esc(v.version), badge(v.status)];
      })
    );
    var paneTabs =
      '<div class="rbac-inner-tabs rbac-overview-tabs" role="tablist" aria-label="Overview sections">' +
      '<button type="button" class="rbac-inner-tab' +
      (state.overviewPane === "health" ? " is-active" : "") +
      '" data-rbac-action="overview-pane" data-pane="health" role="tab" aria-selected="' +
      (state.overviewPane === "health") + '">' + icon("heartbeat") +
      ' Operational Health</button>' +
      '<button type="button" class="rbac-inner-tab' +
      (state.overviewPane === "history" ? " is-active" : "") +
      '" data-rbac-action="overview-pane" data-pane="history" role="tab" aria-selected="' +
      (state.overviewPane === "history") + '">' + icon("history") +
      ' Sync History</button></div>';
    var healthPane = '<div class="rbac-section-stack">' +
      region("Operational snapshot",
        "Current governed entities and active access coverage.", cards) +
      region("Governed access pipeline",
        "RBAC consumes the ETL-managed Agent Master through a controlled delta path.",
        pipeline) +
      region("Vertical health",
        "Each vertical keeps an independent, metadata-driven level structure.",
        verticals) + "</div>";
    var historyPane = '<div class="rbac-section-stack">' +
      region("Synchronization history",
        "Daily and manual delta processing with queue and change counts.",
        runsTable()) + "</div>";
    return paneTabs + '<div class="rbac-overview-pane">' +
      (state.overviewPane === "history" ? historyPane : healthPane) + "</div>";
  }

  function connectedFlow(items, extraClass) {
    return '<div class="rbac-level-flow ' + (extraClass || "") + '">' +
      items.map(function (item, index) {
        var tag = item.action ? "button" : "div";
        var attributes = item.action ?
          ' type="button" data-rbac-action="' + attr(item.action) +
          '" data-id="' + attr(item.id) + '"' : "";
        return "<" + tag + ' class="rbac-level' +
          (item.action ? " rbac-level--action" : "") + '"' + attributes + ">" +
          '<span class="rbac-level-icon">' + icon(item.icon) + "</span>" +
          '<span class="rbac-level-copy"><strong>' + esc(item.title) +
          "</strong><small>" + esc(item.detail) + "</small></span></" + tag + ">" +
          (index < items.length - 1 ?
            '<span class="rbac-level-connector" aria-hidden="true">' +
            icon("chevron-right") + "</span>" : "");
      }).join("") + "</div>";
  }

  function hierarchyView() {
    var d = state.data;
    var vertical = d.verticals.filter(function (v) {
      return Number(v.id) === Number(state.verticalId);
    })[0] || {};
    var activeLevels = d.levels.filter(function (level) {
      return level.status !== "INACTIVE";
    });
    var flow = connectedFlow(activeLevels.map(function (l, index) {
      return {
        icon: l.agentLeaf === "Y" ? "user" :
          (index === 0 ? "building" : "sitemap"),
        title: l.name,
        detail: l.sourceCode +
          (l.identityScope === "PARENT" ? " · within parent" : "") +
          " · " + n(l.nodeCount) + " nodes",
        action: "edit-level",
        id: l.id
      };
    }), "rbac-level-flow--levels");
    var levels = compactTable(
      ["Position", "Level", "Agent Master Mapping", "Nodes", "Assignable", "Status", ""],
      d.levels.map(function (l) {
        var inactive = l.status === "INACTIVE";
        var activeIndex = activeLevels.findIndex(function (level) {
          return Number(level.id) === Number(l.id);
        });
        var previous = activeLevels[activeIndex - 1];
        var next = activeLevels[activeIndex + 1];
        var controls = '<div class="rbac-level-actions">';
        if (!inactive) {
          controls +=
            '<button type="button" class="rbac-link-button" data-rbac-action="move-level" data-id="' +
            l.id + '" data-position="' + activeIndex + '" title="Move level up"' +
            (!previous || l.agentLeaf === "Y" ? " disabled" : "") + ">" +
            icon("arrow-up") + '</button>' +
            '<button type="button" class="rbac-link-button" data-rbac-action="move-level" data-id="' +
            l.id + '" data-position="' + (activeIndex + 2) + '" title="Move level down"' +
            (!next || (next && next.agentLeaf === "Y") ? " disabled" : "") + ">" +
            icon("arrow-down") + '</button>';
        }
        controls +=
          '<button type="button" class="rbac-link-button" data-rbac-action="edit-level" data-id="' +
          l.id + '" title="' + (inactive ? "View inactive level" : "Edit level") + '">' +
          icon(inactive ? "eye" : "pencil") + (inactive ? " View" : " Edit") + "</button>";
        if (inactive) {
          controls +=
            '<button type="button" class="rbac-link-button rbac-link-button--restore" ' +
            'data-rbac-action="restore-level" data-id="' + l.id +
            '" title="Restore level">' + icon("refresh") + " Restore</button>";
        }
        controls += "</div>";
        return [inactive ? badge("Retired", "muted") : badge(activeIndex + 1, "blue"),
          "<strong>" + esc(l.name) + "</strong><br><small>" +
          esc(l.code) + "</small>", '<code>' + esc(l.sourceCode) + "</code> / <code>" +
          esc(l.sourceName) + "</code><br><small>" +
          (l.identityScope === "PARENT" ?
            icon("sitemap") + " Within Parent" : "Global identity") + "</small>",
          n(inactive ? l.totalNodeCount : l.nodeCount),
          badge(l.assignmentAllowed === "Y" ? "Yes" : "No", l.assignmentAllowed === "Y" ? "blue" : "muted"),
          badge(l.status), controls];
      })
    );
    var manager = '<div class="rbac-hierarchy-manager">' +
      '<aside class="rbac-tree-pane"><div class="rbac-tree-toolbar">' +
      '<div class="rbac-search-wrap">' + icon("search") +
      '<input id="rbac-tree-search" class="rbac-input rbac-search" type="search" ' +
      'placeholder="Find code or node name"></div>' +
      '<button type="button" class="rbac-button rbac-button--icon" data-rbac-action="tree-search" title="Search">' +
      icon("search") + '</button><button type="button" class="rbac-button rbac-button--icon" data-rbac-action="tree-reload" title="Reload">' +
      icon("refresh") + '</button><label class="rbac-tree-disabled-toggle">' +
      '<input id="rbac-tree-show-disabled" type="checkbox"' +
      (state.showInactive ? " checked" : "") + "> Show disabled</label></div>" +
      '<div class="rbac-tree" id="rbac-tree"><div class="rbac-spinner">' +
      icon("spinner fa-spin") + " Loading hierarchy…</div></div></aside>" +
      '<section class="rbac-node-detail" id="rbac-node-detail">' +
      '<div class="rbac-empty">' + icon("sitemap") +
      "Select a hierarchy node to manage it.</div></section></div>";
    var levelPanel = region("Level Manager",
      "Use the arrows to reorder levels. A valid change rebuilds the hierarchy from Agent Master.",
      flow + levels,
      '<div class="rbac-row-actions"><button type="button" class="rbac-button" data-rbac-action="edit-vertical" data-id="' +
      attr(vertical.id) + '">' + icon("pencil") +
      ' Edit Vertical</button><button type="button" class="rbac-button rbac-button--primary" data-rbac-action="add-level">' +
      icon("plus") + " Add Level</button></div>");
    var nodePanel = region("Hierarchy Manager",
      "Expand nodes on demand. Add children, rename, move, disable or restore the selected node.",
      manager,
      '<button type="button" class="rbac-button rbac-button--primary" data-rbac-action="add-root-node">' +
      icon("plus") + " Add Root Node</button>");
    var paneTabs = '<div class="rbac-inner-tabs" role="tablist" aria-label="Hierarchy configuration">' +
      '<button type="button" class="rbac-inner-tab' +
      (state.hierarchyPane === "levels" ? " is-active" : "") +
      '" data-rbac-action="hierarchy-pane" data-pane="levels" role="tab" aria-selected="' +
      (state.hierarchyPane === "levels" ? "true" : "false") + '">' +
      icon("list-ol") + ' Level Manager</button>' +
      '<button type="button" class="rbac-inner-tab' +
      (state.hierarchyPane === "nodes" ? " is-active" : "") +
      '" data-rbac-action="hierarchy-pane" data-pane="nodes" role="tab" aria-selected="' +
      (state.hierarchyPane === "nodes" ? "true" : "false") + '">' +
      icon("sitemap") + ' Hierarchy Manager</button></div>';
    return '<div class="rbac-notice"><strong>' + esc(vertical.name || "Vertical") +
      ":</strong> hierarchy codes and names come from <code>" + esc(vertical.sourceTable) +
      "</code>. Manual parent changes are protected from the next daily sync.</div>" +
      paneTabs + '<div class="rbac-inner-panel">' +
      (state.hierarchyPane === "levels" ? levelPanel : nodePanel) + "</div>";
  }

  function loadHierarchyTree(parentId, search, targetSelector) {
    var target = targetSelector || "#rbac-tree";
    if (!parentId) {
      state.treeNodes = {};
      state.selectedTreeNode = null;
      $("#rbac-node-detail").html('<div class="rbac-empty">' + icon("sitemap") +
        "Select a hierarchy node to manage it.</div>");
    }
    $(target).html('<div class="rbac-spinner">' + icon("spinner fa-spin") +
      " Loading hierarchy…</div>");
    process("RBAC_HIERARCHY_CHILDREN", {
      x01: state.verticalId,
      x02: parentId || "",
      x03: search || "",
      x04: 200,
      x05: state.showInactive ? "Y" : "N"
    }).done(function (data) {
      (data.nodes || []).forEach(function (node) {
        state.treeNodes[String(node.id)] = node;
      });
      $(target).html(treeNodesHtml(data.nodes || [], !!search));
    }).fail(function (xhr) {
      $(target).html('<div class="rbac-empty">' + icon("warning") +
        esc(errorMessage(xhr, "Hierarchy could not be loaded.")) + "</div>");
    });
  }

  function treeNodesHtml(nodes, searchMode) {
    if (!nodes.length) {
      return '<div class="rbac-empty">' + icon("inbox") +
        "No hierarchy nodes found.</div>";
    }
    return '<ul class="rbac-tree-list">' + nodes.map(function (node) {
      var expand = node.hasChildren ?
        '<button type="button" class="rbac-tree-expander" data-rbac-action="tree-toggle" data-id="' +
        node.id + '" aria-expanded="false">' + icon("chevron-right") + "</button>" :
        '<span class="rbac-tree-expander rbac-tree-expander--empty"></span>';
      return '<li class="rbac-tree-item' +
        (node.active === "Y" ? "" : " is-disabled") +
        '" data-tree-node-id="' + node.id + '">' +
        '<div class="rbac-tree-row">' + expand +
        '<button type="button" class="rbac-tree-node" data-rbac-action="tree-select" data-id="' +
        node.id + '"><span class="rbac-tree-node-icon">' +
        icon(node.agentLeaf === "Y" ? "user" : "folder-o") +
        '</span><span class="rbac-tree-node-text"><strong>' + esc(node.name) +
        '</strong><small>' + esc(node.levelName + " · " + node.code) +
        (searchMode && node.parentName ? " · Parent: " + esc(node.parentName) : "") +
        '</small></span>' +
        (node.active === "Y" ? "" :
          '<span class="rbac-badge rbac-badge--warning">Disabled</span>') +
        '<span class="rbac-badge rbac-badge--muted">' +
        n(node.childCount) + "</span></button></div>" +
        '<div class="rbac-tree-children" id="rbac-tree-children-' + node.id +
        '" hidden></div></li>';
    }).join("") + "</ul>";
  }

  function nextHierarchyLevel(node) {
    return (state.data.allLevels || []).filter(function (level) {
      return Number(level.verticalId) === Number(node.verticalId) &&
        Number(level.sequence) > Number(node.sequence);
    }).sort(function (a, b) {
      return Number(a.sequence) - Number(b.sequence);
    })[0] || null;
  }

  function firstHierarchyLevel() {
    return (state.data.allLevels || []).filter(function (level) {
      return Number(level.verticalId) === Number(state.verticalId);
    }).sort(function (a, b) {
      return Number(a.sequence) - Number(b.sequence);
    })[0] || null;
  }

  function renderNodeDetail(node) {
    state.selectedTreeNode = node;
    $(".rbac-tree-item").removeClass("is-selected");
    $('.rbac-tree-item[data-tree-node-id="' + node.id + '"]').addClass("is-selected");
    var next = nextHierarchyLevel(node);
    var sourceLabel = node.sourceManaged === "Y" ?
      (node.manualOverride === "Y" ? "Agent Master + override" : "Agent Master") :
      "Manual";
    var actions = '<div class="rbac-row-actions">' +
      (next && node.active === "Y" ?
        '<button type="button" class="rbac-button rbac-button--primary" data-rbac-action="add-child-node" data-id="' +
        node.id + '">' + icon("plus") + " Add " + esc(next.name) + "</button>" : "") +
      '<button type="button" class="rbac-button" data-rbac-action="edit-tree-node" data-id="' +
      node.id + '">' + icon("pencil") + " Rename / Move</button>" +
      '<button type="button" class="rbac-button' +
      (node.active === "Y" ? " rbac-button--danger" : " rbac-button--primary") +
      '" data-rbac-action="toggle-tree-node-status" data-id="' +
      node.id + '">' + icon(node.active === "Y" ? "ban" : "check") +
      (node.active === "Y" ? " Make Inactive" : " Restore") + "</button>" +
      (node.active === "N" ?
        '<button type="button" class="rbac-button rbac-button--danger" data-rbac-action="purge-tree-node" data-id="' +
        node.id + '">' + icon("trash") + " Permanent Delete</button>" : "") +
      "</div>";
    $("#rbac-node-detail").html(
      '<div class="rbac-node-detail-head"><div><span class="rbac-badge rbac-badge--blue">' +
      esc(node.levelName) + '</span><h3>' + esc(node.name) +
      '</h3><code>' + esc(node.code) + "</code></div>" + actions + "</div>" +
      '<dl class="rbac-detail-grid"><div><dt>Parent</dt><dd>' +
      esc(node.parentName || "Root") + '</dd></div><div><dt>Children</dt><dd>' +
      n(node.childCount) + '</dd></div><div><dt>Management</dt><dd>' +
      esc(sourceLabel) + '</dd></div><div><dt>Status</dt><dd>' +
      badge(node.active === "Y" ? "ACTIVE" : "INACTIVE",
        node.active === "Y" ? "success" : "warning") +
      "</dd></div></dl><div class=\"rbac-notice\">" +
      (node.sourceManaged === "Y" ?
        "A rename or move becomes a protected manual override and will not be replaced by daily synchronization." :
        "This manually governed node remains independent of Agent Master synchronization.") +
      "</div>"
    );
  }

  function setTreeNodeActive(node, active, closeOnSuccess) {
    var verb = active === "Y" ? "Restore " : "Make inactive: ";
    apex.message.confirm(
      verb + node.name + "?" +
        (active === "N" ?
          " This is a soft delete. The node is retained, can be restored, and is shown only when Show disabled is enabled. Active children must be disabled or moved first." :
          ""),
      function (confirmed) {
        if (!confirmed) { return; }
        var payload = {
          id: Number(node.id),
          rowVersion: Number(node.rowVersion),
          verticalId: Number(node.verticalId),
          levelId: Number(node.levelId),
          code: node.code,
          name: node.name,
          parentId: node.parentId ? Number(node.parentId) : null,
          active: active
        };
        setBusy(true);
        process("RBAC_SAVE", {
          x01: "NODE",
          x02: JSON.stringify(payload)
        }).done(function (data) {
          if (data.saved === false) {
            toast(data.message || "Hierarchy node status could not be changed.", true);
            return;
          }
          if (closeOnSuccess) {
            closeEditor();
          }
          toast(data.message ||
            (active === "Y" ? "Hierarchy node restored." :
              "Hierarchy node made inactive and retained for restoration."));
          load(false);
        }).fail(function (xhr) {
          toast(errorMessage(xhr, "Hierarchy node status could not be changed."), true);
        }).always(function () { setBusy(false); });
      }
    );
  }

  function purgeTreeNode(node, closeOnSuccess) {
    if (!node || !node.id) {
      toast("The hierarchy node is unavailable. Reload and try again.", true);
      return;
    }
    if (node.active !== "N") {
      toast("Make the hierarchy node inactive before permanently deleting it.", true);
      return;
    }
    apex.message.confirm(
      "Permanently delete " + node.name +
        " and all inactive descendants? This cannot be undone. The node will be removed from the hierarchy, and Agent Master synchronization will not recreate its source key.",
      function (confirmed) {
        if (!confirmed) { return; }
        setBusy(true);
        process("RBAC_SAVE", {
          x01: "NODE_PURGE",
          x02: JSON.stringify({
            id: Number(node.id),
            rowVersion: Number(node.rowVersion)
          })
        }).done(function (data) {
          if (data.saved === false) {
            toast(data.message || "The hierarchy node could not be permanently deleted.", true);
            return;
          }
          if (closeOnSuccess) {
            closeEditor();
          }
          state.selectedTreeNode = null;
          delete state.treeNodes[String(node.id)];
          toast(data.message || "Hierarchy node permanently deleted.");
          load(false);
        }).fail(function (xhr) {
          toast(errorMessage(xhr,
            "The hierarchy node could not be permanently deleted."), true);
        }).always(function () {
          setBusy(false);
        });
      }
    );
  }

  function rolesView() {
    var query = state.search.toUpperCase();
    var groups = state.data.roleGroups || [];
    var selectedGroup = find(groups, state.selectedRoleGroupId) ||
      groups[0] || {};
    var filteredRoles = state.data.roles.filter(function (role) {
      var inGroup = Number(role.groupId) === Number(selectedGroup.id);
      var matches = !query ||
        (role.code + " " + role.name + " " + (role.description || ""))
          .toUpperCase().indexOf(query) >= 0;
      return inGroup && matches;
    });
    var groupList = groups.map(function (group) {
      var selected = Number(group.id) === Number(selectedGroup.id);
      return '<div class="rbac-master-list-row' +
        (selected ? " is-selected" : "") + '">' +
        '<button type="button" class="rbac-master-list-select" ' +
        'data-rbac-action="select-role-group" data-id="' + attr(group.id) +
        '" aria-current="' + selected + '"><span><strong>' +
        esc(group.name) + '</strong><small>' + esc(group.code) +
        '</small></span><span class="rbac-master-list-meta">' +
        badge(group.status, group.status === "ACTIVE" ? "success" : "muted") +
        '<span class="rbac-count-pill">' + n(group.roleCount) +
        '</span></span></button><button type="button" class="rbac-icon-button" ' +
        'data-rbac-action="edit-role-group" data-id="' + attr(group.id) +
        '" title="Manage role group">' + icon("pencil") + "</button></div>";
    }).join("");
    var roleRows = filteredRoles.map(function (r) {
        var appResources = state.data.permissions.filter(function (p) {
          return p.metadataSource === "APEX" && allowed(p, r.id);
        }).length;
        return ["<strong>" + esc(r.name) + "</strong><br><small>" + esc(r.code) + "</small>",
          esc(r.description), n(appResources),
          n(String(r.allowedLevelIds || "").split(",").filter(Boolean).length),
          n(r.userCount), "v" + esc(r.version),
          badge(r.status), rowEdit("edit-role", r.id)];
      });
    var groupManager =
      '<div class="rbac-master-detail rbac-role-master-detail">' +
      '<aside class="rbac-master-list"><div class="rbac-master-list-head">' +
      '<span><strong>Role Groups</strong><small>Reusable operating clusters</small></span>' +
      '<button type="button" class="rbac-icon-button rbac-icon-button--primary" ' +
      'data-rbac-action="add-role-group" title="Create role group">' +
      icon("plus") + '</button></div><div class="rbac-master-list-body">' +
      (groupList || '<div class="rbac-empty">Create the first role group.</div>') +
      '</div></aside><section class="rbac-detail-panel">' +
      '<div class="rbac-detail-panel-head"><div><strong>' +
      esc(selectedGroup.name || "Select a role group") + '</strong><small>' +
      esc(selectedGroup.description || "Roles must belong to a managed group.") +
      '</small></div><div class="rbac-button-row">' +
      (selectedGroup.id ?
        '<button type="button" class="rbac-button" data-rbac-action="edit-role-group" data-id="' +
        attr(selectedGroup.id) + '">' + icon("pencil") + ' Manage Group</button>' +
        '<button type="button" class="rbac-button rbac-button--primary" data-rbac-action="add-role">' +
        icon("plus") + ' New Role</button>' : "") +
      '</div></div>' + compactTable(
        ["Role", "Description", "App Resources", "Levels",
          "Users", "Version", "Status", ""], roleRows
      ) + '</section></div>';
    var modules = {};
    state.data.permissions.filter(function (p) {
      return p.metadataSource === "APEX";
    }).forEach(function (p) {
      modules[p.module] = modules[p.module] || {
        NAVIGATION: 0, PAGE: 0, REGION: 0, BUTTON: 0, ITEM: 0
      };
      modules[p.module][p.resourceType] =
        (modules[p.module][p.resourceType] || 0) + 1;
    });
    var summary = compactTable(
      ["APEX Module", "Menu Entries", "Pages", "Sections", "Buttons", "Fields"],
      Object.keys(modules).map(function (key) {
        return [esc(prettyModule(key)), n(modules[key].NAVIGATION),
          n(modules[key].PAGE),
          n(modules[key].REGION), n(modules[key].BUTTON),
          n(modules[key].ITEM)];
      })
    );
    var roleCatalogueTabs =
      '<div class="rbac-inner-tabs rbac-catalogue-tabs" role="tablist" aria-label="Role catalogues">' +
      '<button type="button" class="rbac-inner-tab' +
      (state.roleCataloguePane === "roles" ? " is-active" : "") +
      '" data-rbac-action="role-catalogue-pane" data-pane="roles" role="tab" aria-selected="' +
      (state.roleCataloguePane === "roles") + '">' + icon("users") +
      ' Role catalogue <span class="rbac-count-pill">' +
      n(state.data.roles.length) + "</span></button>" +
      '<button type="button" class="rbac-inner-tab' +
      (state.roleCataloguePane === "resources" ? " is-active" : "") +
      '" data-rbac-action="role-catalogue-pane" data-pane="resources" role="tab" aria-selected="' +
      (state.roleCataloguePane === "resources") + '">' + icon("desktop") +
      ' APEX resource catalogue <span class="rbac-count-pill">' +
      n(state.data.permissions.filter(function (permission) {
        return permission.metadataSource === "APEX";
      }).length) + "</span></button></div>";
    var catalogue = state.roleCataloguePane === "resources" ?
      region("APEX resource catalogue",
        "Live navigation entries, pages, regions and controls discovered from application 310.", summary) :
      region("Role catalogue",
        "Select a persisted group on the left, then create and manage its roles on the right.",
        groupManager);
    return '<div class="rbac-management-pane">' + roleCatalogueTabs +
      '<div class="rbac-catalogue-pane">' + catalogue + "</div></div>";
  }

  function prettyModule(code) {
    return String(code || "").toLowerCase().split("_").map(function (part) {
      return part ? part.charAt(0).toUpperCase() + part.slice(1) : "";
    }).join(" ");
  }

  function assignmentsView() {
    var hasSelectedUser = !!state.selectedAssignmentUserId;
    var selectedUserHeader = hasSelectedUser ?
      selectedAssignmentHeaderHtml() :
      '<div class="rbac-native-selected-identity"><span class="rbac-workflow-step">2</span>' +
      '<span><small>Manage assignments</small><strong>Select a user first</strong>' +
      '<small>Choose View Access from the user list.</small></span></div>';
    var assignmentLayout =
      '<div class="rbac-native-assignment-layout">' +
      '<section class="rbac-native-master-panel">' +
      '<header class="rbac-native-panel-head"><div class="rbac-native-panel-title">' +
      '<span class="rbac-workflow-step">1</span>' +
      '<span class="rbac-native-panel-icon">' + icon("users") +
      '</span><span><strong>Users</strong>' +
      '<small>Find a user, then choose View Access</small></span></div></header>' +
      '<div id="rbac-native-assignment-users-slot" class="rbac-native-slot"></div>' +
      '</section><section class="rbac-native-detail-panel' +
      (hasSelectedUser ? "" : " is-awaiting-selection") + '">' +
      '<header class="rbac-native-panel-head rbac-native-detail-head" ' +
      'id="rbac-assignment-selected-head">' +
      selectedUserHeader + '</header>' +
      '<div id="rbac-native-assignment-detail-slot" class="rbac-native-slot"></div>' +
      (!hasSelectedUser ?
        '<div class="rbac-native-detail-empty">' + icon("key") +
        '<strong>No user selected</strong><span>Choose View Access from the user list.</span></div>' :
        "") + '</section></div>';
    return userManagementTabs() + '<div class="rbac-management-pane">' +
      region("Scoped role assignments",
        "Choose a user and manage reusable roles at an exact hierarchy scope.",
        assignmentLayout) + "</div>";
  }

  function userLevelsView() {
    var rows = state.data.userLevels.map(function (l) {
      return [esc(l.rank), "<strong>" + esc(l.name) + "</strong><br><small>" + esc(l.code) + "</small>",
        esc(l.description), flagList(l), n(l.userCount), badge(l.status), rowEdit("edit-user-level", l.id)];
    });
    return userManagementTabs() + '<div class="rbac-management-pane">' +
      region("User governance levels",
      "Level rank drives delegation; lower rank means broader administrative authority.",
      compactTable(["Rank", "Level", "Purpose", "Capabilities", "Users", "Status", ""], rows)) +
      "</div>";
  }

  function flagList(level) {
    var flags = [];
    if (level.manageLower === "Y") { flags.push("Manage lower"); }
    if (level.approveAssignment === "Y") { flags.push("Approve"); }
    if (level.createUser === "Y") { flags.push("Create user"); }
    if (level.makerChecker === "Y") { flags.push("Maker-checker"); }
    return flags.map(function (f) { return badge(f, "blue"); }).join(" ");
  }

  function usersView() {
    return userManagementTabs() + '<div class="rbac-management-pane">' +
      region("Application users",
      "Search, filter and manage enterprise identities and their scoped access.",
      '<div id="rbac-native-users-slot" class="rbac-native-slot rbac-native-users-slot"></div>') +
      "</div>";
  }

  function versionsView() {
    var panes = [
      { pane: "versions", label: "Versions", icon: "code-fork" },
      { pane: "runs", label: "Sync Runs", icon: "refresh" },
      { pane: "audit", label: "Audit Log", icon: "history" }
    ];
    var tabs =
      '<div class="rbac-inner-tabs rbac-management-tabs" role="tablist" aria-label="Version and synchronization sections">' +
      panes.map(function (item) {
        var active = state.versionsPane === item.pane;
        return '<button type="button" class="rbac-inner-tab' +
          (active ? " is-active" : "") +
          '" data-rbac-action="versions-pane" data-pane="' + item.pane +
          '" role="tab" aria-selected="' + active + '">' + icon(item.icon) +
          esc(item.label) + "</button>";
      }).join("") + "</div>";
    var pane;
    if (state.versionsPane === "runs") {
      pane = region("Synchronization runs",
        "Daily, manual and full hierarchy processing history.",
        runsTable());
    } else if (state.versionsPane === "audit") {
      pane = region("Audit log",
        "Immutable governed changes with actor and correlation identifier.",
        auditTable());
    } else {
      pane = region("Governed versions",
        "Activated versions are immutable and previous versions are retained.",
        versionsTable());
    }
    return tabs + '<div class="rbac-management-pane">' + pane + "</div>";
  }

  function versionsTable() {
    return compactTable(
      ["Vertical", "Version", "Status", "Reason", "Activated", "By", "Hash"],
      (state.data.versions || []).map(function (v) {
        return [esc(v.verticalName), "v" + esc(v.version),
          badge(v.status, v.status === "ACTIVE" ? "success" : "muted"),
          esc(v.reason || "-"), esc((v.activatedOn || v.createdOn || "").replace("T", " ")),
          esc(v.activatedBy || v.createdBy),
          "<code>" + esc((v.hash || "").slice(0, 12)) + "…</code>"];
      })
    );
  }

  function auditTable() {
    return compactTable(
      ["Event", "Entity", "ID", "Actor", "Timestamp", "Correlation"],
      (state.data.auditEvents || []).map(function (a) {
        return [badge(a.eventType, a.eventType === "ACTIVATE" ? "success" : "blue"),
          esc(a.entityType), esc(a.entityId || "-"), esc(a.actor),
          esc((a.eventOn || "").replace("T", " ")),
          "<code>" + esc((a.correlationId || "").slice(0, 12)) + "…</code>"];
      })
    );
  }

  function runsTable() {
    return compactTable(
      ["Run", "Trigger", "Started", "Queue", "Delta Agents", "Nodes Changed",
        "Time", "Status", ""],
      state.data.runs.map(function (r) {
        var actions =
          '<button type="button" class="rbac-link-button" data-rbac-action="view-run-log"' +
          ' data-id="' + attr(r.id) + '" title="View synchronization log">' +
          icon("file-text-o") + " Log</button>";
        if (r.deletable) {
          actions +=
            '<button type="button" class="rbac-link-button rbac-link-button--danger"' +
            ' data-rbac-action="delete-run" data-id="' + attr(r.id) +
            '" title="Delete this history row">' + icon("trash") + " Delete</button>";
        } else {
          actions +=
            '<span class="rbac-row-lock" title="Retained because ' +
            attr(n(r.nodeReferences)) + ' hierarchy nodes reference this run">' +
            icon("lock") + " Retained</span>";
        }
        return ["#" + esc(r.id), esc(r.triggerType), esc((r.startedOn || "").replace("T", " ")),
          n(r.queueRows), n(r.deltaAgents), n(r.nodesChanged),
          n(r.elapsedMs) + " ms",
          badge(r.status, r.status === "COMPLETED" ? "success" : "warning"),
          actions];
      })
    );
  }

  function openRunLog(run) {
    var errorBlock = run.error ?
      '<div class="rbac-run-error"><strong>' + icon("exclamation-triangle") +
      ' Error details</strong><pre>' + esc(run.error) + "</pre></div>" :
      '<div class="rbac-run-ok">' + icon("check-circle") +
      " No error was recorded for this run.</div>";
    var detail = [
      ["Run", "#" + run.id],
      ["Status", run.status || "-"],
      ["Trigger", run.triggerType || "-"],
      ["Requested By", run.requestedBy || "-"],
      ["Started", (run.startedOn || "-").replace("T", " ")],
      ["Completed", (run.completedOn || "-").replace("T", " ")],
      ["Elapsed", n(run.elapsedMs) + " ms"],
      ["Source Rows", n(run.sourceRows)],
      ["Queue Rows", n(run.queueRows)],
      ["Delta Agents", n(run.deltaAgents)],
      ["Nodes Changed", n(run.nodesChanged)],
      ["Assignments Changed", n(run.assignmentsChanged)],
      ["Users Affected", n(run.usersAffected)],
      ["Exceptions", n(run.exceptions)],
      ["Node References", n(run.nodeReferences)]
    ];
    setEditorTitle("Synchronization Log #" + run.id);
    $("#rbac-dialog-body").html(
      '<div class="rbac-run-log">' +
      detail.map(function (item) {
        return "<div><span>" + esc(item[0]) + "</span><strong>" +
          esc(item[1]) + "</strong></div>";
      }).join("") + "</div>" + errorBlock
    );
    $("#rbac-dialog-delete, #rbac-dialog-purge, #rbac-dialog-save, " +
      "#rbac-dialog-save-assign").prop("hidden", true);
    $("#rbac-dialog-cancel-foot").text("Close");
    openEditor();
  }

  function deleteRun(run) {
    if (!run.deletable) {
      toast("This run is retained because hierarchy nodes reference it.", true);
      return;
    }
    apex.message.confirm(
      "Delete synchronization history row #" + run.id +
      "? This removes the selected run log only.",
      function (confirmed) {
        if (!confirmed) { return; }
        setBusy(true);
        process("RBAC_SAVE", {
          x01: "SYNC_RUN_DELETE",
          x02: JSON.stringify({ id: Number(run.id) })
        }).done(function (data) {
          if (data.saved === false) {
            toast(data.message || "The synchronization run could not be deleted.", true);
            return;
          }
          toast("Synchronization run #" + run.id + " deleted.");
          load(false);
        }).fail(function (xhr) {
          toast(errorMessage(xhr, "The synchronization run could not be deleted."), true);
        }).always(function () {
          setBusy(false);
        });
      }
    );
  }

  function compactTable(headers, rows) {
    var head = headers.map(function (h) { return "<th>" + h + "</th>"; }).join("");
    if (!rows.length) {
      return '<div class="rbac-empty">' + icon("inbox") + "No records found.</div>";
    }
    var body = rows.map(function (row) {
      return "<tr>" + row.map(function (cell, index) {
        return '<td class="' + (index === row.length - 1 && headers[index] === "" ?
          "rbac-actions" : "") + '">' + (cell === null ? "-" : cell) + "</td>";
      }).join("") + "</tr>";
    }).join("");
    return '<div class="rbac-table-wrap"><table class="rbac-table"><thead><tr>' +
      head + "</tr></thead><tbody>" + body + "</tbody></table></div>";
  }

  function rowEdit(action, id) {
    return '<button type="button" class="rbac-link-button" data-rbac-action="' + action +
      '" data-id="' + id + '" title="Edit">' + icon("pencil") + " Edit</button>";
  }

  function allowed(permission, roleId) {
    return String(permission.allowedRoleIds || "").split(",").some(function (id) {
      return Number(id) === Number(roleId);
    });
  }

  function allowedLevel(role, levelId) {
    return String(role.allowedLevelIds || "").split(",").some(function (id) {
      return Number(id) === Number(levelId);
    });
  }

  function nodeOptions(selectedId, selectedName, blankLabel) {
    var items = (state.data.nodes || []).slice();
    Object.keys(state.treeNodes || {}).forEach(function (key) {
      var treeNode = state.treeNodes[key];
      if (!items.some(function (item) {
        return Number(item.id) === Number(treeNode.id);
      })) {
        items.push(treeNode);
      }
    });
    if (selectedId && !items.some(function (item) {
      return Number(item.id) === Number(selectedId);
    })) {
      items.unshift({ id: selectedId, name: selectedName || ("Node " + selectedId) });
    }
    return opts(items, "id", "name", blankLabel || "Search and select scope");
  }

  function openForm(type, record) {
    var config = formConfig(type, record || {});
    var inactiveLevel = config.entity === "LEVEL" && record &&
      record.status === "INACTIVE";
    var inactiveNode = config.entity === "NODE" && record &&
      record.id && record.active === "N";
    var existingNode = config.entity === "NODE" && record && record.id;
    var retireEligible = (config.entity === "LEVEL" && record && record.id &&
      record.agentLeaf !== "Y") || existingNode;
    var purgeEligible = (config.entity === "LEVEL" && record && record.id &&
      record.agentLeaf !== "Y") || inactiveNode;
    setEditorTitle(config.title);
    $("#rbac-dialog-body").html('<div id="rbac-form" data-entity="' + config.entity +
      '">' + config.html +
      '<div class="rbac-form-message" id="rbac-form-message" role="status" aria-live="polite"></div>' +
      "</div>");
    $("#rbac-f-verticalDisplay").prop("readonly", true);
    if (config.entity === "USER" && record && record.id) {
      $("#rbac-f-userName").prop("readonly", true);
    }
    if (config.entity === "ROLE_GROUP" && record && record.id) {
      $("#rbac-f-code").prop("readonly", true);
    }
    $("#rbac-dialog-delete")
      .prop("hidden", !retireEligible)
      .attr("data-mode", inactiveLevel || inactiveNode ? "restore" : "retire")
      .removeAttr("data-confirmed")
      .toggleClass("rbac-button--danger", !(inactiveLevel || inactiveNode))
      .toggleClass("rbac-button--primary", inactiveLevel || inactiveNode)
      .html(inactiveLevel || inactiveNode ?
        icon("refresh") + (inactiveNode ? " Restore Node" : " Restore Level") :
        icon("archive") + " Make Inactive");
    $("#rbac-dialog-purge")
      .prop("hidden", !purgeEligible)
      .removeAttr("data-confirmed")
      .html(icon("trash") + " Permanent Delete");
    $("#rbac-dialog-save")
      .prop("hidden", inactiveLevel || inactiveNode)
      .text(config.saveLabel || "Save");
    $("#rbac-dialog-save-assign")
      .prop("hidden",
        config.entity !== "USER" || inactiveLevel || inactiveNode)
      .html(icon("key") +
        (record && record.id ?
          " Save & Manage Access" : " Save & Assign Access"));
    if (inactiveLevel || inactiveNode) {
      $("#rbac-form").find("input:not([type='hidden']), select, textarea")
        .prop("disabled", true);
    }
    openEditor();
    if (config.entity === "SCOPE") {
      renderRoleAccessPreview($("#rbac-f-roleId").val());
      refreshNodePicker($("[data-rbac-node-picker]"), {
        keepSelection: true,
        query: "",
        open: false
      });
    }
    if (config.entity === "ROLE") {
      updateRoleExplorerCounts();
      updateRoleLevelCounts();
    }
    if (config.entity === "USER") {
      toggleUserCredentials();
      refreshNodePicker($("[data-rbac-node-picker]"), {
        keepSelection: true,
        query: "",
        open: false
      });
    }
  }

  function renderRoleAccessPreview(roleId) {
    var role = find(state.data.roles, roleId);
    var permissions = (state.data.permissions || []).filter(function (permission) {
      return allowed(permission, roleId);
    });
    var modules = {};
    permissions.filter(function (permission) {
      return permission.metadataSource === "APEX";
    }).forEach(function (permission) {
      modules[permission.module] = modules[permission.module] || {
        pages: {}, resources: 0
      };
      modules[permission.module].pages[permission.pageId] = true;
      modules[permission.module].resources += 1;
    });
    var moduleSummary = Object.keys(modules).map(function (moduleCode) {
      return '<span class="rbac-access-chip">' + icon("desktop") +
        esc(prettyModule(moduleCode)) + " · " +
        n(Object.keys(modules[moduleCode].pages).length) + " pages · " +
        n(modules[moduleCode].resources) + " resources</span>";
    }).join("");
    var appPermissionCount = permissions.filter(function (permission) {
      return permission.metadataSource === "APEX";
    }).length;
    var levelCount = String(role.allowedLevelIds || "")
      .split(",").filter(Boolean).length;
    $("#rbac-role-access-preview").html(
      role.id ?
        '<div class="rbac-access-preview-title"><strong>' + esc(role.name) +
        '</strong><span>' + n(appPermissionCount) +
        ' application resources</span></div><div class="rbac-access-chip-list">' +
        (moduleSummary || '<span class="rbac-access-chip">No application pages selected</span>') +
        '</div><div class="rbac-access-preview-foot">' +
        icon("sitemap") + " " + n(levelCount) +
        " allowed hierarchy levels. The selected node and descendant coverage limit this access.</div>" :
        '<span class="rbac-muted">Select a Role to preview its application and hierarchy access.</span>'
    );
  }

  function updateScopeRoleOptions() {
    var groupId = Number($("#rbac-f-groupId").val());
    var currentRoleId = Number($("#rbac-f-roleId").val());
    var roles = (state.data.roles || []).filter(function (role) {
      return Number(role.groupId) === groupId &&
        (role.status === "ACTIVE" || Number(role.id) === currentRoleId);
    });
    var html = '<option value="">Select role</option>' +
      roles.map(function (role) {
        return '<option value="' + attr(role.id) + '"' +
          (Number(role.id) === currentRoleId ? " selected" : "") + ">" +
          esc(role.name) + "</option>";
      }).join("");
    $("#rbac-f-roleId").html(html);
    if (!roles.some(function (role) {
      return Number(role.id) === currentRoleId;
    })) {
      $("#rbac-f-roleId").val("");
    }
    renderRoleAccessPreview($("#rbac-f-roleId").val());
  }

  function permissionIds(value) {
    return String(value || "").split(",").filter(Boolean).map(Number);
  }

  function setStoredRolePermissions(ids, checked) {
    ids.forEach(function (permissionId) {
      $("#rbac-role-permission-store input[value='" + permissionId + "']")
        .prop("checked", checked);
      $(".rbac-explorer-permission[data-permission-id='" + permissionId + "']")
        .prop("checked", checked);
    });
    updateRoleExplorerCounts();
  }

  function storedPermissionSelected(permissionId) {
    return $("#rbac-role-permission-store input[value='" + permissionId + "']")
      .prop("checked");
  }

  function permissionPreset(ids) {
    var permissions = (state.data.permissions || []).filter(function (permission) {
      return ids.indexOf(Number(permission.id)) >= 0;
    });
    var selected = permissions.filter(function (permission) {
      return storedPermissionSelected(Number(permission.id));
    });
    if (!selected.length) {
      return "NONE";
    }
    if (selected.length === permissions.length) {
      return "FULL";
    }
    var viewTypes = ["NAVIGATION", "PAGE", "REGION"];
    var selectedIds = selected.map(function (permission) {
      return Number(permission.id);
    });
    var viewIds = permissions.filter(function (permission) {
      return viewTypes.indexOf(permission.resourceType) >= 0;
    }).map(function (permission) {
      return Number(permission.id);
    });
    if (selectedIds.length === viewIds.length &&
        selectedIds.every(function (permissionId) {
          return viewIds.indexOf(permissionId) >= 0;
        })) {
      return "VIEW";
    }
    return "CUSTOM";
  }

  function applyPermissionPreset(ids, preset) {
    var permissions = (state.data.permissions || []).filter(function (permission) {
      return ids.indexOf(Number(permission.id)) >= 0;
    });
    if (preset === "CUSTOM") {
      return;
    }
    permissions.forEach(function (permission) {
      var checked = preset === "FULL" ||
        (preset === "VIEW" &&
          ["NAVIGATION", "PAGE", "REGION"].indexOf(permission.resourceType) >= 0);
      var permissionId = Number(permission.id);
      $("#rbac-role-permission-store input[value='" + permissionId + "']")
        .prop("checked", checked);
      $(".rbac-explorer-permission[data-permission-id='" + permissionId + "']")
        .prop("checked", checked);
    });
    updateRoleExplorerCounts();
  }

  function updateRoleExplorerCounts() {
    $("[data-permission-ids]").each(function () {
      var ids = permissionIds(this.dataset.permissionIds);
      var selected = ids.filter(function (permissionId) {
        return $("#rbac-role-permission-store input[value='" + permissionId + "']")
          .prop("checked");
      }).length;
      $(this).find(".rbac-explorer-count").text(selected + "/" + ids.length);
      $(this).find(".rbac-app-card-progress > span").css(
        "width", (ids.length ? Math.round(selected * 100 / ids.length) : 0) + "%"
      );
      $(this).toggleClass("is-complete", ids.length > 0 && selected === ids.length)
        .toggleClass("is-partial", selected > 0 && selected < ids.length);
    });
    var apexPermissionIds = (state.data.permissions || []).filter(function (permission) {
      return permission.metadataSource === "APEX";
    }).map(function (permission) {
      return Number(permission.id);
    });
    var selectedApex = apexPermissionIds.filter(function (permissionId) {
      return $("#rbac-role-permission-store input[value='" + permissionId + "']")
        .prop("checked");
    }).length;
    $(".rbac-role-tabs [data-pane='application'] .rbac-count-pill")
      .text(selectedApex + "/" + apexPermissionIds.length);
    $(".rbac-page-bulk-toggle").each(function () {
      var ids = permissionIds(this.dataset.permissionIds);
      var selected = ids.filter(function (permissionId) {
        return $("#rbac-role-permission-store input[value='" + permissionId + "']")
          .prop("checked");
      }).length;
      var allSelected = ids.length > 0 && selected === ids.length;
      var partiallySelected = selected > 0 && !allSelected;
      $(this)
        .toggleClass("is-selected", allSelected)
        .toggleClass("is-partial", partiallySelected)
        .attr("aria-pressed", allSelected ? "true" : "false")
        .attr("title", allSelected ?
          "Clear all page controls" : "Select all page controls")
        .html(
          icon(allSelected ? "check-circle" :
            (partiallySelected ? "adjust" : "square-o")) +
          '<span class="rbac-page-bulk-label">' +
          (allSelected ? "All selected" :
            (partiallySelected ? "Select remaining" : "Select all")) +
          "</span>"
        );
    });
    $(".rbac-access-preset").each(function () {
      var ids = permissionIds(this.dataset.permissionIds);
      $(this).val(permissionPreset(ids));
    });
    $(".rbac-application-summary").each(function () {
      var ids = permissionIds(this.dataset.permissionIds);
      var selected = ids.filter(storedPermissionSelected).length;
      $(this).find(".rbac-application-summary-count")
        .text(selected + " of " + ids.length + " resources granted");
      $(this).toggleClass("is-complete",
        ids.length > 0 && selected === ids.length);
    });
  }

  function showRoleModule(moduleCode) {
    $(".rbac-explorer-module").removeClass("is-active")
      .attr("aria-selected", "false");
    $(".rbac-explorer-module[data-module='" + moduleCode + "']")
      .addClass("is-active").attr("aria-selected", "true");
    $(".rbac-application-workspace").prop("hidden", true);
    $(".rbac-application-workspace[data-module='" + moduleCode + "']")
      .prop("hidden", false);
    $(".rbac-application-workspace[data-module='" + moduleCode +
      "'] .rbac-role-control-search").val("");
    $(".rbac-application-workspace[data-module='" + moduleCode +
      "'] .rbac-role-control-type").val("");
    filterRoleControls();
  }

  function toggleRolePageCard(moduleCode, pageId) {
    var $workspace = $(".rbac-application-workspace[data-module='" +
      moduleCode + "']");
    var $card = $workspace.find(".rbac-page-card[data-page-id='" +
      pageId + "']");
    var willOpen = !$card.hasClass("is-open");
    $workspace.find(".rbac-page-card").removeClass("is-open");
    $workspace.find(".rbac-page-card-body").prop("hidden", true);
    $workspace.find(".rbac-page-card-toggle")
      .attr("aria-expanded", "false");
    if (willOpen) {
      $card.addClass("is-open");
      $card.find(".rbac-page-card-body").prop("hidden", false);
      $card.find(".rbac-page-card-toggle")
        .attr("aria-expanded", "true");
    }
  }

  function filterRoleControls() {
    var $workspace = $(".rbac-application-workspace:not([hidden])");
    var query = ($workspace.find(".rbac-role-control-search").val() || "")
      .trim().toUpperCase();
    var type = $workspace.find(".rbac-role-control-type").val() || "";
    $(".rbac-application-workspace:not([hidden]) [data-resource-search]")
      .each(function () {
      var matchesQuery = !query ||
        String(this.dataset.resourceSearch || "").toUpperCase().indexOf(query) >= 0;
      var matchesType = !type || this.dataset.resourceType === type;
      $(this).prop("hidden", !matchesQuery || !matchesType);
    });
  }

  function showRoleVertical(verticalId) {
    $(".rbac-explorer-vertical").removeClass("is-active")
      .attr("aria-selected", "false");
    $(".rbac-explorer-vertical[data-vertical-id='" + verticalId + "']")
      .addClass("is-active").attr("aria-selected", "true");
    $(".rbac-level-scope-panel").prop("hidden", true);
    $(".rbac-level-scope-panel[data-vertical-id='" + verticalId + "']")
      .prop("hidden", false);
  }

  function updateRoleLevelCounts() {
    $(".rbac-explorer-vertical").each(function () {
      var verticalId = this.dataset.verticalId;
      var $levels = $(".rbac-level-scope-panel[data-vertical-id='" +
        verticalId + "'] input[name='levelIds']");
      var selected = $levels.filter(":checked").length;
      var total = $levels.length;
      $(this).find(".rbac-explorer-count")
        .text(selected + "/" + total);
      $(this).find(".rbac-scope-card-progress > span").css(
        "width", (total ? Math.round(selected * 100 / total) : 0) + "%"
      );
      $(this).toggleClass("is-complete", total > 0 && selected === total)
        .toggleClass("is-partial", selected > 0 && selected < total);
      var $panel = $(".rbac-level-scope-panel[data-vertical-id='" +
        verticalId + "']");
      $panel.find(".rbac-level-panel-count")
        .text(selected + " of " + total + " selected");
      $panel.find(".rbac-level-scope-summary-count")
        .text(selected + " of " + total + " assignment levels enabled");
      $panel.find(".rbac-level-scope-row").each(function () {
        $(this).toggleClass("is-selected",
          $(this).find("input[name='levelIds']").prop("checked"));
      });
    });
  }

  function input(name, label, value, type, wide, required, help, placeholder) {
    return '<div class="rbac-field' + (wide ? " rbac-field--wide" : "") +
      '"><label for="rbac-f-' + name + '">' + esc(label) + (required ? " *" : "") +
      '</label><input class="rbac-input" id="rbac-f-' + name + '" name="' + name +
      '" type="' + (type || "text") + '" value="' + attr(value || "") + '"' +
      (placeholder ? ' placeholder="' + attr(placeholder) + '"' : "") +
      (required ? " required" : "") + ">" +
      (help ? '<small class="rbac-field-help">' + esc(help) + "</small>" : "") +
      "</div>";
  }

  function passwordInput(name, label, required, help) {
    return '<div class="rbac-field"><label for="rbac-f-' + name + '">' +
      esc(label) + (required ? " *" : "") +
      '</label><input class="rbac-input" id="rbac-f-' + name +
      '" name="' + name + '" type="password" value="" autocomplete="new-password"' +
      ' minlength="12" data-required-for-apex="' + (required ? "Y" : "N") + '"' +
      (required ? " required" : "") + '><small class="rbac-field-help">' +
      esc(help) + "</small></div>";
  }

  function select(name, label, value, options, wide, required, help) {
    return '<div class="rbac-field' + (wide ? " rbac-field--wide" : "") +
      '"><label for="rbac-f-' + name + '">' + esc(label) + (required ? " *" : "") +
      '</label><select class="rbac-select" id="rbac-f-' + name + '" name="' + name + '"' +
      (required ? " required" : "") + ">" + options.map(function (o) {
        return '<option value="' + attr(o.value) + '"' +
          (String(o.value) === String(value === null || value === undefined ? "" : value) ?
            " selected" : "") + ">" + esc(o.label) + "</option>";
      }).join("") + "</select>" +
      (help ? '<small class="rbac-field-help">' + esc(help) + "</small>" : "") +
      "</div>";
  }

  function searchableNodePicker(config) {
    var inputId = "rbac-f-" + config.searchName;
    var valueId = "rbac-f-" + config.valueName;
    var listId = "rbac-f-" + config.prefix + "Results";
    return '<div class="rbac-field rbac-node-picker-field' +
      (config.wide ? " rbac-field--wide" : "") + '">' +
      '<label for="' + inputId + '">' + esc(config.label) +
      (config.required ? " *" : "") + '</label>' +
      '<div class="rbac-node-picker" data-rbac-node-picker ' +
      'data-vertical-selector="' + attr(config.verticalSelector) + '" ' +
      'data-required="' + (config.required ? "Y" : "N") + '">' +
      '<div class="rbac-node-picker-control">' +
      '<span class="fa fa-search rbac-node-picker-search-icon" aria-hidden="true"></span>' +
      '<input class="rbac-input rbac-node-picker-input" id="' + inputId +
      '" name="' + attr(config.searchName) + '" type="search" value="' +
      attr(config.displayValue || "") +
      '" placeholder="Search by location name or code" autocomplete="off"' +
      ' role="combobox" aria-autocomplete="list" aria-expanded="false"' +
      ' aria-controls="' + listId + '"' +
      (config.required ? ' aria-required="true"' : "") + '>' +
      '<button type="button" class="rbac-node-picker-toggle" ' +
      'aria-label="Show hierarchy locations" tabindex="-1">' +
      '<span class="fa fa-chevron-down" aria-hidden="true"></span></button>' +
      '</div>' +
      '<input type="hidden" id="' + valueId + '" name="' +
      attr(config.valueName) + '" value="' + attr(config.value || "") + '">' +
      '<div class="rbac-node-picker-results" id="' + listId +
      '" role="listbox" hidden>' +
      '<div class="rbac-node-picker-status">Loading locations…</div>' +
      '</div></div>' +
      (config.help ? '<small class="rbac-field-help">' +
        esc(config.help) + "</small>" : "") +
      "</div>";
  }

  function searchableUserPicker(config) {
    var inputId = "rbac-f-" + config.searchName;
    var valueId = "rbac-f-" + config.valueName;
    var listId = "rbac-f-" + config.prefix + "Results";
    return '<div class="rbac-field rbac-user-picker-field">' +
      '<label for="' + inputId + '">' + esc(config.label) + '</label>' +
      '<div class="rbac-node-picker rbac-user-picker" data-rbac-user-picker ' +
      'data-exclude-id="' + attr(config.excludeId || "") + '">' +
      '<div class="rbac-node-picker-control">' +
      '<span class="fa fa-search rbac-node-picker-search-icon" aria-hidden="true"></span>' +
      '<input class="rbac-input rbac-user-picker-input" id="' + inputId +
      '" name="' + attr(config.searchName) + '" type="search" value="' +
      attr(config.displayValue || "") +
      '" placeholder="Search manager name or user name" autocomplete="off"' +
      ' role="combobox" aria-autocomplete="list" aria-expanded="false"' +
      ' aria-controls="' + listId + '">' +
      '</div><input type="hidden" id="' + valueId + '" name="' +
      attr(config.valueName) + '" value="' + attr(config.value || "") + '">' +
      '<div class="rbac-node-picker-results rbac-user-picker-results" id="' +
      listId + '" role="listbox" hidden>' +
      '<div class="rbac-node-picker-status">Type at least 2 characters.</div>' +
      '</div></div><small class="rbac-field-help">' +
      esc(config.help || "") + "</small></div>";
  }

  function fixedAssignmentUser(userId, displayName) {
    return '<div class="rbac-field"><label>User *</label>' +
      '<div class="rbac-fixed-user">' + icon("user") + '<strong>' +
      esc(displayName || ("User #" + userId)) +
      '</strong></div><input type="hidden" id="rbac-f-userId" name="userId" value="' +
      attr(userId || "") + '" required></div>';
  }

  function check(name, label, checked) {
    return '<div class="rbac-field"><label>' + esc(label) +
      '</label><label class="rbac-switch"><input type="checkbox" name="' + name + '"' +
      (checked ? " checked" : "") + "> Enabled</label></div>";
  }

  function textarea(name, label, value) {
    return '<div class="rbac-field rbac-field--wide"><label for="rbac-f-' + name + '">' +
      esc(label) + '</label><textarea class="rbac-textarea" id="rbac-f-' + name +
      '" name="' + name + '">' + esc(value || "") + "</textarea></div>";
  }

  function opts(items, valueKey, labelKey, blank) {
    var result = blank ? [{ value: "", label: blank }] : [];
    return result.concat(items.map(function (item) {
      return { value: item[valueKey], label: item[labelKey] };
    }));
  }

  function formConfig(type, r) {
    var d = state.data;
    var statusOptions = [
      { value: "DRAFT", label: "Draft" },
      { value: "ACTIVE", label: "Active" },
      { value: "INACTIVE", label: "Inactive" }
    ];
    var yesNo = [{ value: "Y", label: "Yes" }, { value: "N", label: "No" }];
    var id = '<input type="hidden" name="id" value="' + attr(r.id || "") + '">' +
      '<input type="hidden" name="rowVersion" value="' + attr(r.rowVersion || "") + '">';

    if (type === "VERTICAL") {
      return {
        entity: type, title: (r.id ? "Edit" : "Create") + " Vertical",
        html: id + '<div class="rbac-notice">A vertical is metadata only. Add its ordered levels next, then validate before activation.</div>' +
          '<div class="rbac-form-grid">' +
          input("code", "Vertical Code", r.code, "text", false, true) +
          input("name", "Vertical Name", r.name, "text", false, true) +
          input("sourceOwner", "Source Owner", r.sourceOwner || "SAS", "text", false, true) +
          input("sourceTable", "Source Table", r.sourceTable || "SBOS_AGENT_MASTER", "text", false, true) +
          input("scheduleMinutes", "Schedule Minutes", r.scheduleMinutes || 1440, "number", false, true) +
          select("status", "Status", r.status || "DRAFT", statusOptions) + "</div>"
      };
    }

    if (type === "LEVEL") {
      var levelVertical = find(d.verticals, r.verticalId || state.verticalId);
      var editableLevels = d.levels.filter(function (level) {
        return level.status !== "INACTIVE";
      });
      var levelCount = editableLevels.length +
        (r.id || r.status === "INACTIVE" ? 0 : 1);
      var currentPosition = r.id ? editableLevels.findIndex(function (level) {
        return Number(level.id) === Number(r.id);
      }) + 1 : Math.max(1, levelCount - (editableLevels.some(function (level) {
        return level.agentLeaf === "Y";
      }) ? 1 : 0));
      if (r.status === "INACTIVE") {
        currentPosition = Math.max(1, Math.round(Number(r.sequence || 10) / 10));
        levelCount = Math.max(levelCount, currentPosition);
      }
      var positionOptions = [];
      for (var position = 1; position <= levelCount; position += 1) {
        positionOptions.push({
          value: position,
          label: position + " — " +
            (position === 1 ? "Top level" :
              (position === levelCount ? "Final level" : "Between levels"))
        });
      }
      var sourceColumnOptions = (d.sourceColumns || []).map(function (column) {
        return {
          value: column.name,
          label: column.name + " · " + column.dataType
        };
      });
      var levelStatusOptions = r.status === "INACTIVE" ?
        [{ value: "INACTIVE", label: "Inactive (soft deleted)" }] :
        [
          { value: "DRAFT", label: "Draft" },
          { value: "ACTIVE", label: "Active" }
        ];
      var identityScopeOptions = [
        {
          value: "GLOBAL",
          label: "Global — one node for each source code"
        },
        {
          value: "PARENT",
          label: "Within Parent — repeat a code under different parents"
        }
      ];
      return {
        entity: type, title: (r.id ? "Edit" : "Add") + " Hierarchy Level",
        html: id +
          '<input type="hidden" name="verticalId" value="' +
          attr(r.verticalId || state.verticalId) + '">' +
          '<div class="rbac-notice">Changing the position rebuilds parent relationships from Agent Master. Use Within Parent when the same source code legitimately appears below more than one parent.</div>' +
          '<div class="rbac-form-grid">' +
          input("verticalDisplay", "Vertical", levelVertical.name || "", "text") +
          select("position", "Position", currentPosition,
            positionOptions, false, true) +
          input("code", "Level Code", r.code, "text", false, true) +
          input("name", "Level Name", r.name, "text", false, true) +
          select("sourceCode", "Agent Master Code Column", r.sourceCode,
            sourceColumnOptions, false, true) +
          select("sourceName", "Agent Master Name Column", r.sourceName,
            sourceColumnOptions, false, true) +
          select("identityScope", "Node Identity Scope",
            r.identityScope || "GLOBAL", identityScopeOptions, false, true) +
          select("agentLeaf", "Agent Leaf", r.agentLeaf || "N", yesNo) +
          select("assignmentAllowed", "Assignment Allowed", r.assignmentAllowed || "Y", yesNo) +
          select("status", "Status", r.status || "DRAFT", levelStatusOptions) + "</div>"
      };
    }
    if (type === "ROLE_GROUP") {
      return {
        entity: type,
        title: (r.id ? "Manage" : "Create") + " Role Group",
        html: id + '<div class="rbac-notice">Role groups are persisted master data. Every role must belong to one group.</div>' +
          '<div class="rbac-form-grid">' +
          input("code", "Group Code", r.code, "text", false, true) +
          input("name", "Group Name", r.name, "text", false, true) +
          input("sequence", "Display Sequence", r.sequence || 100,
            "number", false, true) +
          select("status", "Status", r.status || "DRAFT", statusOptions) +
          textarea("description", "Description", r.description) +
          '</div>'
      };
    }
    if (type === "ROLE") {
      var availableGroups = (d.roleGroups || []).filter(function (group) {
        return group.status !== "INACTIVE" ||
          Number(group.id) === Number(r.groupId);
      });
      var selectedGroupId = r.groupId || state.selectedRoleGroupId;
      var apexPermissions = d.permissions.filter(function (p) {
        return p.metadataSource === "APEX";
      });
      var moduleCodes = [];
      apexPermissions.forEach(function (permission) {
        if (moduleCodes.indexOf(permission.module) < 0) {
          moduleCodes.push(permission.module);
        }
      });
      moduleCodes.sort(function (a, b) {
        return prettyModule(a).localeCompare(prettyModule(b));
      });
      var selectedApexCount = apexPermissions.filter(function (permission) {
        return r.id && allowed(permission, r.id);
      }).length;
      var permissionStore = d.permissions.map(function (permission) {
        return '<input type="checkbox" name="permissionIds" value="' +
          permission.id + '"' +
          (r.id && allowed(permission, r.id) ? " checked" : "") + ">";
      }).join("");
      var moduleIcons = {
        ACCESS_PORTAL: "shield",
        BUSINESS_RULE_ENGINE: "cogs",
        ETL_WORKBENCH: "database",
        PROFILE_DECISION_STUDIO: "id-card",
        RBAC_STUDIO: "lock",
        USER_MANAGEMENT: "users",
        WEATHER_FORECAST: "cloud",
        WEBRTC_CALLING: "video-camera"
      };
      var moduleNavigation = moduleCodes.map(function (moduleCode, moduleIndex) {
        var modulePermissions = apexPermissions.filter(function (permission) {
          return permission.module === moduleCode;
        });
        var moduleSelectedCount = modulePermissions.filter(function (permission) {
          return r.id && allowed(permission, r.id);
        }).length;
        var moduleComplete = modulePermissions.length > 0 &&
          moduleSelectedCount === modulePermissions.length;
        var modulePartial = moduleSelectedCount > 0 && !moduleComplete;
        var moduleProgress = modulePermissions.length ?
          Math.round(moduleSelectedCount * 100 / modulePermissions.length) : 0;
        return '<button type="button" class="rbac-explorer-nav-item rbac-explorer-module' +
          (moduleIndex === 0 ? " is-active" : "") +
          (moduleComplete ? " is-complete" : (modulePartial ? " is-partial" : "")) +
          ' rbac-app-card rbac-app-card--tone-' + (moduleIndex % 8) +
          '" data-rbac-action="role-module" data-module="' + attr(moduleCode) +
          '" data-permission-ids="' +
          attr(modulePermissions.map(function (permission) {
            return permission.id;
          }).join(",")) + '" aria-selected="' +
          (moduleIndex === 0 ? "true" : "false") + '">' +
          '<span class="rbac-app-card-row"><span class="rbac-app-card-icon">' +
          icon(moduleIcons[moduleCode] || "desktop") +
          '</span><span class="rbac-app-card-copy"><strong>' +
          esc(prettyModule(moduleCode)) +
          '</strong><small><span class="rbac-explorer-count">' +
          moduleSelectedCount + "/" + modulePermissions.length +
          '</span> resources selected</small></span>' +
          '<span class="rbac-app-card-chevron">' + icon("chevron-right") +
          '</span></span><span class="rbac-app-card-progress" aria-hidden="true">' +
          '<span style="width:' + moduleProgress + '%"></span></span></button>';
      }).join("");
      var actionColumns = ["ACCESS", "VIEW", "EDIT", "EXECUTE"];
      var typeLabels = {
        NAVIGATION: "Menu",
        PAGE: "Page",
        REGION: "Section",
        BUTTON: "Button",
        ITEM: "Field"
      };
      function permissionMatrixRow(permission) {
        return '<label class="rbac-permission-matrix-row" data-resource-type="' +
          attr(permission.resourceType) + '" data-resource-search="' +
          attr((permission.resourceName || "") + " " +
            permission.resourceType + " " + permission.action) + '">' +
          '<span class="rbac-permission-resource"><span class="rbac-resource-type rbac-resource-type--' +
          String(permission.resourceType || "").toLowerCase() + '">' +
          esc(typeLabels[permission.resourceType] || permission.resourceType) +
          "</span><span><strong>" +
          esc(permission.resourceName || permission.name) +
          "</strong><small>" + esc(permission.action) +
          "</small></span></span>" +
          actionColumns.map(function (actionCode) {
            return '<span class="rbac-permission-action">' +
              (permission.action === actionCode ?
                '<input type="checkbox" class="rbac-explorer-permission" aria-label="' +
                attr(actionCode + " " +
                  (permission.resourceName || permission.name)) +
                '" data-permission-id="' + permission.id + '"' +
                (r.id && allowed(permission, r.id) ? " checked" : "") + ">" :
                '<span aria-hidden="true">—</span>') +
              "</span>";
          }).join("") + "</label>";
      }
      function permissionMatrix(permissions) {
        return '<div class="rbac-permission-matrix">' +
          '<div class="rbac-permission-matrix-head"><span>Resource</span>' +
          actionColumns.map(function (actionCode) {
            return "<span>" + esc(actionCode.charAt(0) +
              actionCode.slice(1).toLowerCase()) + "</span>";
          }).join("") + "</div>" +
          permissions.map(permissionMatrixRow).join("") + "</div>";
      }
      var applicationWorkspaces = "";
      moduleCodes.forEach(function (moduleCode, moduleIndex) {
        var modulePermissions = apexPermissions.filter(function (permission) {
          return permission.module === moduleCode;
        });
        var modulePermissionIds = modulePermissions.map(function (permission) {
          return Number(permission.id);
        });
        var navigationPermissions = modulePermissions.filter(function (permission) {
          return permission.resourceType === "NAVIGATION";
        });
        var pageIds = [];
        modulePermissions.forEach(function (permission) {
          if (permission.resourceType !== "NAVIGATION" &&
              pageIds.indexOf(Number(permission.pageId)) < 0) {
            pageIds.push(Number(permission.pageId));
          }
        });
        pageIds.sort(function (a, b) { return a - b; });
        var pageCards = pageIds.map(function (pageId, pageIndex) {
          var pagePermissions = modulePermissions.filter(function (permission) {
            return Number(permission.pageId) === pageId &&
              permission.resourceType !== "NAVIGATION";
          });
          var pagePermissionIds = pagePermissions.map(function (permission) {
            return Number(permission.id);
          });
          var pageSelectedCount = pagePermissions.filter(function (permission) {
            return r.id && allowed(permission, r.id);
          }).length;
          var pageAllSelected = pagePermissionIds.length > 0 &&
            pageSelectedCount === pagePermissionIds.length;
          var pagePermission = pagePermissions.filter(function (permission) {
            return permission.resourceType === "PAGE";
          })[0] || {};
          var permissionGroups = [
            {
              title: "Page access",
              permissions: pagePermissions.filter(function (permission) {
                return permission.resourceType === "PAGE";
              })
            },
            {
              title: "Sections",
              permissions: pagePermissions.filter(function (permission) {
                return permission.resourceType === "REGION";
              })
            },
            {
              title: "Actions",
              permissions: pagePermissions.filter(function (permission) {
                return permission.resourceType === "BUTTON";
              })
            },
            {
              title: "Fields",
              permissions: pagePermissions.filter(function (permission) {
                return permission.resourceType === "ITEM";
              })
            }
          ].filter(function (group) {
            return group.permissions.length > 0;
          });
          return '<article class="rbac-page-card' +
            (pageIndex === 0 ? " is-open" : "") +
            '" data-page-id="' + pageId + '">' +
            '<div class="rbac-page-card-head">' +
            '<button type="button" class="rbac-page-card-toggle" data-rbac-action="role-page-card" ' +
            'data-module="' + attr(moduleCode) + '" data-page-id="' +
            pageId + '" data-permission-ids="' +
            attr(pagePermissionIds.join(",")) + '" aria-expanded="' +
            (pageIndex === 0 ? "true" : "false") + '">' +
            icon("chevron-right") + '<span><strong>Page ' + pageId + " · " +
            esc(pagePermission.resourceName || ("Page " + pageId)) +
            '</strong><small><span class="rbac-explorer-count">0/' +
            pagePermissions.length + "</span> granted</small></span></button>" +
            '<div class="rbac-page-card-actions">' +
            '<button type="button" class="rbac-button rbac-button--small rbac-page-bulk-toggle' +
            (pageAllSelected ? " is-selected" : "") +
            '" data-rbac-action="role-page-toggle" data-permission-ids="' +
            attr(pagePermissionIds.join(",")) + '" aria-pressed="' +
            (pageAllSelected ? "true" : "false") + '" title="' +
            (pageAllSelected ? "Clear all page controls" : "Select all page controls") +
            '">' + icon(pageAllSelected ? "check-circle" : "square-o") +
            '<span class="rbac-page-bulk-label">' +
            (pageAllSelected ? "All selected" : "Select all") +
            "</span></button></div></div>" +
            '<div class="rbac-page-card-body"' +
            (pageIndex === 0 ? "" : " hidden") + ">" +
            permissionGroups.map(function (group) {
              return '<section class="rbac-permission-group"><h4>' +
                esc(group.title) + "</h4>" +
                permissionMatrix(group.permissions) + "</section>";
            }).join("") +
            '<button type="button" class="rbac-button rbac-button--small rbac-customize-controls" data-rbac-action="role-page-customize">' +
            icon("sliders") + " Customize controls</button></div></article>";
        }).join("");
        applicationWorkspaces += '<section class="rbac-application-workspace" data-module="' +
          attr(moduleCode) + '"' +
          (moduleIndex === 0 ? "" : " hidden") + ">" +
          '<div class="rbac-application-head"><div class="rbac-application-title">' +
          '<span class="rbac-application-icon">' +
          icon(moduleIcons[moduleCode] || "desktop") +
          '</span><span><strong>' + esc(prettyModule(moduleCode)) +
          '</strong><small>' + pageIds.length + " " +
          (pageIds.length === 1 ? "page" : "pages") + " · " +
          modulePermissions.length + " " +
          (modulePermissions.length === 1 ? "resource" : "resources") +
          '</small></span></div><div class="rbac-application-tools">' +
          '<div class="rbac-application-filters"><div class="rbac-workspace-search">' +
          icon("search") +
          '<input type="search" class="rbac-input rbac-role-control-search" ' +
          'placeholder="Search this application" aria-label="Search this application"></div>' +
          '<select class="rbac-select rbac-role-control-type">' +
          '<option value="">All resource types</option>' +
          '<option value="NAVIGATION">Navigation menu</option>' +
          '<option value="PAGE">Pages</option><option value="REGION">Sections</option>' +
          '<option value="BUTTON">Actions</option><option value="ITEM">Fields</option>' +
          '</select></div><div class="rbac-application-actions">' +
          '<button type="button" class="rbac-button rbac-button--small" ' +
          'data-rbac-action="sync-apex-resources" title="Discover the latest APEX navigation, pages, regions, buttons and fields">' +
          icon("refresh") + ' Refresh APEX Resources</button>' +
          '<label class="rbac-access-preset-label">Access preset' +
          '<select class="rbac-select rbac-access-preset" data-permission-ids="' +
          attr(modulePermissionIds.join(",")) + '">' +
          '<option value="CUSTOM">Custom</option><option value="NONE">No access</option>' +
          '<option value="VIEW">View only</option><option value="FULL">Full access</option>' +
          "</select></label></div></div></div>" +
          '<section class="rbac-navigation-access"><div class="rbac-navigation-access-head">' +
          '<div><span class="rbac-navigation-icon">' + icon("bars") +
          '</span><span><strong>Navigation menu</strong>' +
          '<small>Controls whether this application appears in the left menu.</small>' +
          '</span></div><span class="rbac-count-pill">' +
          navigationPermissions.length + " " +
          (navigationPermissions.length === 1 ? "entry" : "entries") +
          "</span></div>" +
          (navigationPermissions.length ?
            permissionMatrix(navigationPermissions) :
            '<div class="rbac-empty-inline">No navigation entry is linked to this application.</div>') +
          "</section><div class=\"rbac-page-card-list\">" + pageCards + "</div>" +
          '<div class="rbac-application-summary" data-permission-ids="' +
          attr(modulePermissionIds.join(",")) + '">' + icon("check-circle") +
          '<strong>' + esc(prettyModule(moduleCode)) + ":</strong> " +
          '<span class="rbac-application-summary-count">0 of ' +
          modulePermissions.length + " resources granted</span>" +
          '<span class="rbac-summary-divider">·</span><span>No unsaved conflicts</span>' +
          "</div></section>";
      });
      var verticalIds = [];
      (d.allLevels || []).forEach(function (level) {
        if (verticalIds.indexOf(Number(level.verticalId)) < 0) {
          verticalIds.push(Number(level.verticalId));
        }
      });
      var selectedVerticalIndex = 0;
      verticalIds.some(function (verticalId, index) {
        var hasSelected = (d.allLevels || []).some(function (level) {
          return Number(level.verticalId) === verticalId &&
            r.id && allowedLevel(r, level.id);
        });
        if (hasSelected) {
          selectedVerticalIndex = index;
          return true;
        }
        return false;
      });
      var verticalNavigation = verticalIds.map(function (verticalId, index) {
        var levels = (d.allLevels || []).filter(function (level) {
          return Number(level.verticalId) === verticalId;
        });
        var vertical = find(d.verticals || [], verticalId);
        var selectedLevelCount = levels.filter(function (level) {
          return r.id && allowedLevel(r, level.id);
        }).length;
        var verticalComplete = levels.length > 0 &&
          selectedLevelCount === levels.length;
        var verticalPartial = selectedLevelCount > 0 && !verticalComplete;
        var verticalProgress = levels.length ?
          Math.round(selectedLevelCount * 100 / levels.length) : 0;
        var verticalIcon = String(vertical.code || "").indexOf("BRANCH") >= 0 ?
          "building" : "sitemap";
        return '<button type="button" class="rbac-explorer-nav-item rbac-explorer-vertical' +
          (index === selectedVerticalIndex ? " is-active" : "") +
          (verticalComplete ? " is-complete" :
            (verticalPartial ? " is-partial" : "")) +
          ' rbac-scope-card' +
          '" data-rbac-action="role-vertical" data-vertical-id="' + verticalId +
          '" aria-selected="' + (index === selectedVerticalIndex ? "true" : "false") +
          '"><span class="rbac-scope-card-row"><span class="rbac-scope-card-icon">' +
          icon(verticalIcon) + '</span><span class="rbac-scope-card-copy"><strong>' +
          esc(vertical.name || levels[0].verticalName) +
          '</strong><small><span class="rbac-explorer-count">' +
          selectedLevelCount + "/" + levels.length +
          '</span> levels selected</small></span><span class="rbac-scope-card-chevron">' +
          icon("chevron-right") +
          '</span></span><span class="rbac-scope-card-progress" aria-hidden="true">' +
          '<span style="width:' + verticalProgress + '%"></span></span></button>';
      }).join("");
      var levelPanels = verticalIds.map(function (verticalId, index) {
        var levels = (d.allLevels || []).filter(function (level) {
          return Number(level.verticalId) === verticalId;
        }).sort(function (a, b) {
          return Number(a.sequence) - Number(b.sequence);
        });
        var vertical = find(d.verticals || [], verticalId);
        var selectedLevelCount = levels.filter(function (level) {
          return r.id && allowedLevel(r, level.id);
        }).length;
        var verticalName = vertical.name ||
          (levels[0] && levels[0].verticalName);
        return '<section class="rbac-level-scope-panel" data-vertical-id="' +
          verticalId + '"' +
          (index === selectedVerticalIndex ? "" : " hidden") +
          '><div class="rbac-level-panel-head"><div class="rbac-level-panel-title">' +
          '<span>' + icon("sitemap") + '</span><div><strong>' +
          esc(verticalName) +
          '</strong><small>Choose where this role may be assigned</small></div></div>' +
          '<span class="rbac-level-panel-count">' + selectedLevelCount +
          " of " + levels.length + " selected</span></div>" +
          '<div class="rbac-level-scope-list">' +
          levels.map(function (level, levelIndex) {
            var selected = r.id && allowedLevel(r, level.id);
            return '<label class="rbac-level-scope-row' +
              (selected ? " is-selected" : "") +
              '"><span class="rbac-position">' +
              (levelIndex + 1) + '</span><span class="rbac-level-row-copy"><strong>' +
              esc(level.name) + '</strong><small>' + esc(level.code) +
              '</small></span><span class="rbac-level-check-control">' +
              '<input class="rbac-level-checkbox" type="checkbox" name="levelIds" value="' +
              level.id + '"' + (selected ? " checked" : "") +
              ' aria-label="' + attr("Allow assignment at " + level.name) +
              '"><span class="rbac-level-checkmark">' + icon("check") +
              "</span></span></label>";
          }).join("") + '</div><div class="rbac-level-scope-summary">' +
          icon("check-circle") + '<span><strong>' + esc(verticalName) +
          '</strong><small class="rbac-level-scope-summary-count">' +
          selectedLevelCount + " of " + levels.length +
          " assignment levels enabled</small></span></div></section>";
      }).join("");
      return {
        entity: type, title: (r.id ? "Edit" : "Create") + " Role",
        html: id + '<div id="rbac-role-permission-store" hidden>' +
          permissionStore + "</div>" +
          '<div class="rbac-inner-tabs rbac-role-tabs" role="tablist" aria-label="Role configuration">' +
          '<button type="button" class="rbac-inner-tab is-active" data-rbac-action="role-pane" data-pane="details">' +
          icon("info-circle") + ' Role Details</button>' +
          '<button type="button" class="rbac-inner-tab" data-rbac-action="role-pane" data-pane="application">' +
          icon("desktop") + ' Application Access <span class="rbac-count-pill">' +
          n(selectedApexCount) + "/" + n(apexPermissions.length) + "</span></button>" +
          '<button type="button" class="rbac-inner-tab" data-rbac-action="role-pane" data-pane="levels">' +
          icon("sitemap") + ' Hierarchy Scope</button></div>' +
          '<div class="rbac-role-pane" data-role-pane="details"><div class="rbac-form-grid">' +
          select("groupId", "Role Group", selectedGroupId,
            opts(availableGroups, "id", "name", "Select role group"),
            false, true) +
          input("code", "Role Code", r.code, "text", false, true) +
          input("name", "Role Name", r.name, "text", false, true) +
          textarea("description", "Description", r.description) +
          select("status", "Status", r.status || "DRAFT", statusOptions) +
          '</div><div class="rbac-notice">Application Access governs the left navigation menu, pages, sections, buttons and fields at runtime. Hierarchy scope is applied after user creation through RBAC Assignments.</div></div>' +
          '<div class="rbac-role-pane" data-role-pane="application" hidden>' +
          '<div class="rbac-application-access-layout">' +
          '<nav class="rbac-application-list" aria-label="Applications">' +
          '<div class="rbac-application-list-head">' +
          '<div class="rbac-application-list-title"><span>' + icon("th-large") +
          '</span><div><strong>Applications</strong><small>' +
          moduleCodes.length + ' connected modules</small></div></div>' +
          '<p>Select an application to configure its resources.</p>' +
          '<div class="rbac-application-search">' + icon("search") +
          '<input type="search" class="rbac-input" id="rbac-role-application-search" ' +
          'placeholder="Search applications" aria-label="Search applications"></div></div>' +
          '<div class="rbac-application-list-body">' + moduleNavigation +
          '</div></nav><div class="rbac-application-workspaces">' +
          applicationWorkspaces + "</div></div></div>" +
          '<div class="rbac-role-pane" data-role-pane="levels" hidden>' +
          '<div class="rbac-scope-intro"><span>' + icon("info-circle") +
          '</span><div><strong>Assignment boundaries</strong>' +
          '<small>Choose a hierarchy, then enable only the levels where this role may be assigned.</small></div></div>' +
          '<div class="rbac-level-scope-explorer"><nav class="rbac-explorer-nav rbac-scope-verticals" aria-label="Hierarchy verticals">' +
          '<div class="rbac-scope-step-head"><span>1</span><div><strong>Choose hierarchy</strong>' +
          '<small>Select a vertical</small></div></div>' + verticalNavigation +
          '</nav><div class="rbac-explorer-content rbac-scope-levels">' +
          '<div class="rbac-scope-step-head"><span>2</span><div><strong>Allowed levels</strong>' +
          '<small>Set assignment boundaries</small></div></div>' +
          levelPanels + "</div></div></div>"
      };
    }
    if (type === "USER_LEVEL") {
      return {
        entity: type, title: (r.id ? "Edit" : "Create") + " User Level",
        html: id + '<div class="rbac-form-grid">' +
          input("rank", "Rank", r.rank, "number", false, true) +
          input("code", "Level Code", r.code, "text", false, true) +
          input("name", "Level Name", r.name, "text", false, true) +
          select("status", "Status", r.status || "DRAFT", statusOptions) +
          textarea("description", "Purpose", r.description) + "</div>" +
          '<section class="rbac-form-section"><div class="rbac-form-section-head">' +
          '<strong>Delegation Controls</strong><small>Define which lower-level access changes this user level may govern.</small></div>' +
          '<div class="rbac-form-grid">' +
          check("manageLower", "Manage Lower Levels", r.manageLower === "Y") +
          check("approveAssignment", "Approve Assignments", r.approveAssignment === "Y") +
          "</div></section>" +
          '<section class="rbac-form-section"><div class="rbac-form-section-head">' +
          '<strong>User Administration</strong><small>Grant user onboarding and maker-checker responsibilities explicitly.</small></div>' +
          '<div class="rbac-form-grid">' +
          check("createUser", "Allow User Creation", r.createUser === "Y") +
          check("makerChecker", "Maker-Checker", r.makerChecker !== "N") +
          "</div></section>"
      };
    }
    if (type === "USER") {
      var localAuthentication = r.authentication ||
        (r.id ? "ENTERPRISE_SSO" : "APEX");
      var selectedDefaultNode = find(d.nodes, r.defaultScopeNodeId);
      var selectedDefaultName = r.defaultScopeName ||
        selectedDefaultNode.name ||
        (r.defaultScopeNodeId ? "Node " + r.defaultScopeNodeId : "");
      return {
        entity: type, title: (r.id ? "Edit" : "Create") + " User",
        html: id + '<div class="rbac-form-grid">' +
          input("userName", "User Name", r.userName, "text", false, true) +
          input("displayName", "Display Name", r.displayName, "text", false, true) +
          input("email", "Email", r.email, "email") +
          input("mobile", "Mobile", r.mobile) +
          select("userLevelId", "User Level", r.userLevelId,
            opts(d.userLevels, "id", "name", "Select level"), false, true) +
          select("authentication", "Authentication", localAuthentication,
            [{ value: "APEX", label: "APEX credentials" },
              { value: "ENTERPRISE_SSO", label: "Enterprise SSO (no local password)" }]) +
          "</div>" +
          '<section class="rbac-form-section" id="rbac-user-credentials">' +
          '<div class="rbac-form-section-head"><strong>Login Credentials</strong>' +
          '<small>The password is sent to Oracle APEX and is never stored in RBAC tables.</small></div>' +
          '<div class="rbac-form-grid">' +
          passwordInput("password", r.id ? "New Password" : "Password",
            !r.id, r.id ? "Leave blank to keep the existing password" :
              "Minimum 12 characters") +
          passwordInput("confirmPassword", "Confirm Password", !r.id,
            "Enter the same password again") +
          check("forcePasswordChange", "Require Password Change on First Login",
            r.id ? false : true) + "</div></section>" +
          '<section class="rbac-form-section rbac-form-section--node-picker">' +
          '<div class="rbac-form-section-head">' +
          '<strong>Organization & Reporting</strong>' +
          '<small>Set the user’s home location and reporting manager. Application access is assigned separately under RBAC Assignments.</small></div>' +
          '<div class="rbac-form-grid">' +
          select("primaryVerticalId", "Primary Hierarchy", r.primaryVerticalId,
            opts(d.verticals, "id", "name", "Select hierarchy"), false, false,
            "Choose the organization structure used to find this user’s home location.") +
          searchableNodePicker({
            prefix: "defaultScope",
            searchName: "defaultScopeSearch",
            valueName: "defaultScopeNodeId",
            label: "Default Location",
            value: r.defaultScopeNodeId,
            displayValue: selectedDefaultName,
            verticalSelector: "#rbac-f-primaryVerticalId",
            required: false,
            help: "The user’s saved home location. It does not grant application access."
          }) +
          searchableUserPicker({
            prefix: "manager",
            searchName: "managerSearch",
            valueName: "managerUserId",
            label: "Reports To / Approving Manager",
            value: r.managerUserId,
            displayValue: r.managerName,
            excludeId: r.id,
            help: "Optional. Search by manager name or user name; this does not assign permissions."
          }) +
          check("active", "Active", r.active !== "N") +
          input("validFrom", "Valid From", r.validFrom || today(), "date", false, true) +
          input("validTo", "Valid To", r.validTo, "date") +
          "</div></section>"
      };
    }
    if (type === "SCOPE") {
      var scopeGroups = (d.roleGroups || []).filter(function (group) {
        return group.status === "ACTIVE" ||
          Number(group.id) === Number(r.groupId);
      });
      var scopeGroupId = r.groupId ||
        (scopeGroups[0] && scopeGroups[0].id);
      var scopeRoles = d.roles.filter(function (role) {
        return Number(role.groupId) === Number(scopeGroupId) &&
          (role.status === "ACTIVE" || Number(role.id) === Number(r.roleId));
      });
      var selectedScopeNode = find(d.nodes, r.nodeId);
      var selectedScopeName = r.nodeName || selectedScopeNode.name ||
        (r.nodeId ? "Node " + r.nodeId : "");
      return {
        entity: type, title: (r.id ? "Edit" : "Add") + " RBAC Assignment",
        html: id +
          '<section class="rbac-form-section rbac-form-section--assignment">' +
          '<div class="rbac-form-section-head"><strong>Assignment</strong>' +
          '<small>Choose the user and reusable role within one hierarchy.</small></div>' +
          '<div class="rbac-form-grid">' +
          fixedAssignmentUser(
            r.userId || state.selectedAssignmentUserId,
            r.displayName || state.selectedAssignmentUserName
          ) +
          select("groupId", "Role Group", scopeGroupId,
            opts(scopeGroups, "id", "name", "Select role group"), false, true) +
          select("roleId", "Role", r.roleId,
            opts(scopeRoles, "id", "name", "Select role"), false, true) +
          select("verticalId", "Hierarchy", r.verticalId || state.verticalId,
            opts(d.verticals, "id", "name"), false, true,
            "Select the organization structure in which this role applies.") +
          "</div></section>" +
          '<section class="rbac-form-section rbac-form-section--node-picker">' +
          '<div class="rbac-form-section-head">' +
          '<strong>Access Scope & Validity</strong>' +
          '<small>Define where access begins, its coverage, and its active dates.</small></div>' +
          '<div class="rbac-form-grid">' +
          searchableNodePicker({
            prefix: "node",
            searchName: "nodeSearch",
            valueName: "nodeId",
            label: "Access Starts At",
            value: r.nodeId,
            displayValue: selectedScopeName,
            verticalSelector: "#rbac-f-verticalId",
            required: true,
            wide: true,
            help: "Search by location name or code, then select where this role becomes effective."
          }) +
          select("includeDescendants", "Access Coverage", r.includeDescendants || "Y",
            [{ value: "Y", label: "Selected node and descendants" },
              { value: "N", label: "Selected node only" }], false, false,
            "Choose whether access also flows to child nodes below the selected location.") +
          select("status", "Status", r.status || "DRAFT", statusOptions) +
          input("effectiveFrom", "Effective From", r.effectiveFrom || today(), "date", false, true) +
          input("effectiveTo", "Effective To", r.effectiveTo, "date") +
          "</div></section>" +
          '<section class="rbac-form-section rbac-form-section--preview">' +
          '<div class="rbac-form-section-head"><strong>Effective Access Preview</strong>' +
          '<small>Resources supplied by the selected role at the configured scope.</small></div>' +
          '<div class="rbac-form-grid">' +
          '<div class="rbac-field rbac-field--wide">' +
          '<div id="rbac-role-access-preview" class="rbac-access-preview"></div></div>' +
          "</div></section>"
      };
    }
    if (type === "NODE") {
      var vertical = find(d.verticals, r.verticalId || state.verticalId);
      var levelChoices = (d.allLevels || []).filter(function (level) {
        return Number(level.verticalId) === Number(r.verticalId || state.verticalId);
      }).map(function (level) {
        return { value: level.id, label: level.name };
      });
      return {
        entity: type, title: (r.id ? "Manage" : "Add") + " Hierarchy Node",
        html: id +
          '<input type="hidden" name="verticalId" value="' +
          attr(r.verticalId || state.verticalId) + '">' +
          '<div class="rbac-notice">The hierarchy enforces the configured level order. A source-managed rename or move becomes a protected manual override.</div>' +
          '<div class="rbac-form-grid">' +
          input("verticalDisplay", "Vertical", vertical.name || "", "text") +
          select("levelId", "Hierarchy Level", r.levelId, levelChoices, false, true) +
          input("code", "Node Code", r.code, "text", false, true) +
          input("name", "Node Name", r.name, "text", false, true) +
          input("parentSearch", "Find Parent", r.parentName || "", "search") +
          select("parentId", "Parent Node", r.parentId,
            nodeOptions(r.parentId, r.parentName, "Root node")) +
          check("active", "Active", r.active !== "N") + "</div>"
      };
    }
    return { entity: type, title: "Edit", html: id };
  }

  function toggleUserCredentials() {
    var localAccount = $("#rbac-f-authentication").val() === "APEX";
    var $section = $("#rbac-user-credentials");
    $section.prop("hidden", !localAccount);
    $section.find("input").prop("disabled", !localAccount);
    $section.find("input[data-required-for-apex='Y']")
      .prop("required", localAccount);
  }

  function serializeForm() {
    var form = document.getElementById("rbac-form");
    var data = {};
    Array.prototype.forEach.call(
      form.querySelectorAll("input, select, textarea"),
      function (el) {
      if (!el.name || el.disabled) { return; }
      if (el.type === "checkbox") {
        if (el.name === "permissionIds" || el.name === "levelIds") {
          if (el.checked) {
            (data[el.name] = data[el.name] || []).push(Number(el.value));
          }
        } else {
          data[el.name] = el.checked ? "Y" : "N";
        }
      } else {
        data[el.name] = el.value === "" ? null : el.value;
      }
      }
    );
    ["id", "rowVersion", "verticalId", "levelId", "position", "sequence", "rank", "userLevelId",
      "primaryVerticalId", "defaultScopeNodeId", "managerUserId", "userId",
      "groupId", "roleId", "nodeId", "parentId", "scheduleMinutes"].forEach(function (key) {
      if (data[key] !== null && data[key] !== undefined && data[key] !== "") {
        data[key] = Number(data[key]);
      }
    });
    delete data.nodeSearch;
    delete data.defaultScopeSearch;
    delete data.managerSearch;
    delete data.parentSearch;
    delete data.verticalDisplay;
    return { entity: form.dataset.entity, data: data };
  }

  function saveForm(assignAccessAfterSave) {
    var form = document.getElementById("rbac-form");
    var reloadPending = false;
    if (!form) {
      toast("The edit form is unavailable. Close it and try again.", true);
      return;
    }
    if (form.dataset.entity === "USER" &&
        $("#rbac-f-authentication").val() === "APEX") {
      var password = $("#rbac-f-password").val() || "";
      var confirmation = $("#rbac-f-confirmPassword").val() || "";
      if ((password || confirmation) && password !== confirmation) {
        $("#rbac-form-message").text("Password and confirmation must match.")
          .addClass("is-error");
        $("#rbac-f-confirmPassword").trigger("focus");
        return;
      }
      if (password && password.length < 12) {
        $("#rbac-form-message").text("Use a password with at least 12 characters.")
          .addClass("is-error");
        $("#rbac-f-password").trigger("focus");
        return;
      }
    }
    var $missingNodePicker = $(form)
      .find("[data-rbac-node-picker][data-required='Y']")
      .filter(function () {
        return !$(this).find("input[type='hidden']").val();
      }).first();
    if ($missingNodePicker.length) {
      $("#rbac-form-message")
        .text("Search for and select the location where access starts.")
        .addClass("is-error");
      $missingNodePicker.find(".rbac-node-picker-input")
        .attr("aria-invalid", "true")
        .trigger("focus");
      openNodeResults($missingNodePicker);
      return;
    }
    var invalidControl = Array.prototype.filter.call(
      form.querySelectorAll("input, select, textarea"),
      function (control) {
        return typeof control.checkValidity === "function" &&
          !control.checkValidity();
      }
    )[0];
    if (invalidControl) {
      invalidControl.reportValidity();
      $("#rbac-form-message").text("Complete the required fields before saving.")
        .addClass("is-error");
      return;
    }
    var payload = serializeForm();
    $("#rbac-form-message").text("Saving configuration…")
      .removeClass("is-error is-success");
    $("#rbac-dialog-save").html(icon("spinner fa-spin") + " Saving…");
    if (assignAccessAfterSave) {
      $("#rbac-dialog-save-assign")
        .html(icon("spinner fa-spin") + " Saving…");
    }
    setBusy(true);
    process("RBAC_SAVE", {
      x01: payload.entity,
      x02: JSON.stringify(payload.data)
    }).done(function (data) {
      if (data.saved === false) {
        var rejectedMessage = data.message || "The record could not be saved.";
        $("#rbac-form-message").text(rejectedMessage)
          .removeClass("is-success").addClass("is-error");
        toast(rejectedMessage, true);
        return;
      }
      $("#rbac-form-message").text(data.message || "Saved successfully.")
        .removeClass("is-error").addClass("is-success");
      if (payload.entity === "ROLE_GROUP") {
        state.selectedRoleGroupId = Number(data.entityId);
      }
      if (payload.entity === "SCOPE") {
        state.selectedAssignmentUserId = Number(payload.data.userId);
        apex.item("P60_SELECTED_RBAC_USER_ID")
          .setValue(state.selectedAssignmentUserId, null, true);
        state.refreshNative = "assignment-detail";
      }
      if (payload.entity === "USER" && assignAccessAfterSave) {
        state.selectedAssignmentUserId = Number(data.entityId);
        state.selectedAssignmentUserName =
          payload.data.displayName || payload.data.userName || "";
        apex.item("P60_SELECTED_RBAC_USER_ID")
          .setValue(state.selectedAssignmentUserId, null, true);
        state.tab = "assignments";
        state.search = "";
        state.offset = 0;
        state.refreshNative = "assignments";
      } else if (payload.entity === "USER") {
        state.refreshNative = "users";
      }
      closeEditor();
      toast(payload.entity === "USER" && assignAccessAfterSave ?
        "User saved. Add or review this user’s RBAC assignments." :
        (data.message || "Saved."));
      reloadPending = true;
      load(false);
    }).fail(function (xhr) {
      var message = errorMessage(xhr, "The record could not be saved.");
      $("#rbac-form-message").text(message)
        .removeClass("is-success").addClass("is-error");
      toast(message, true);
    }).always(function () {
      $("#rbac-dialog-save").html(icon("check") + " Save");
      $("#rbac-dialog-save-assign")
        .html(icon("key") +
          ($("#rbac-form").data("entity") === "USER" &&
           $("#rbac-form input[name='id']").val() ?
            " Save & Manage Access" : " Save & Assign Access"));
      if (!reloadPending) {
        setBusy(false);
      }
    });
  }

  function moveLevel(level, position) {
    apex.message.confirm(
      "Move " + level.name + " to position " + position +
        "? The hierarchy will be rebuilt from Agent Master. Repeated codes " +
        "will automatically use Within Parent identity.",
      function (confirmed) {
        if (!confirmed) { return; }
        setBusy(true);
        process("RBAC_SAVE", {
          x01: "LEVEL",
          x02: JSON.stringify({
            id: Number(level.id),
            rowVersion: Number(level.rowVersion),
            verticalId: Number(level.verticalId),
            position: Number(position),
            code: level.code,
            name: level.name,
            sourceCode: level.sourceCode,
            sourceName: level.sourceName,
            identityScope: level.identityScope || "GLOBAL",
            agentLeaf: level.agentLeaf,
            assignmentAllowed: level.assignmentAllowed,
            status: level.status
          })
        }).done(function (data) {
          if (data.saved === false) {
            toast(data.message || "The hierarchy level could not be moved.", true);
            return;
          }
          toast(data.message ||
            "Hierarchy level moved and identity scope resolved automatically.");
          load(false);
        }).fail(function (xhr) {
          toast(errorMessage(xhr, "The hierarchy level could not be moved."), true);
        }).always(function () {
          setBusy(false);
        });
      }
    );
  }

  function currentDialogLevel() {
    return find(state.data.levels, $("#rbac-form input[name='id']").val());
  }

  function currentDialogNode() {
    var id = $("#rbac-form input[name='id']").val();
    return state.treeNodes[String(id)] ||
      find(state.data.nodes, id);
  }

  function submitLevelAction(level, options) {
    var $button = $(options.button);
    if (!level.id) {
      toast("The hierarchy level is unavailable. Reload and try again.", true);
      return;
    }
    $("#rbac-form-message").text(options.progress)
      .removeClass("is-error is-success is-warning");
    $button.html(icon("spinner fa-spin") + " " + options.busyLabel);
    setBusy(true);
    process("RBAC_SAVE", {
      x01: options.type,
      x02: JSON.stringify({
        id: Number(level.id),
        rowVersion: Number(level.rowVersion)
      })
    }).done(function (data) {
      if (data.saved === false) {
        var rejected = data.message || options.failure;
        $("#rbac-form-message").text(rejected)
          .removeClass("is-success is-warning").addClass("is-error");
        toast(rejected, true);
        return;
      }
      closeEditor();
      toast(options.success);
      load(false);
    }).fail(function (xhr) {
      var message = errorMessage(xhr, options.failure);
      $("#rbac-form-message").text(message)
        .removeClass("is-success is-warning").addClass("is-error");
      toast(message, true);
    }).always(function () {
      $button.removeAttr("data-confirmed").html(options.defaultHtml);
      setBusy(false);
    });
  }

  function changeLevelState() {
    var level = currentDialogLevel();
    var restoring = level.status === "INACTIVE";
    var $button = $("#rbac-dialog-delete");
    if (!restoring && $button.attr("data-confirmed") !== String(level.id)) {
      $("#rbac-dialog-purge").removeAttr("data-confirmed")
        .html(icon("trash") + " Permanent Delete");
      $("#rbac-form-message")
        .text("This is a soft delete. The level will remain as Retired and can be restored. Click Confirm Make Inactive to continue.")
        .removeClass("is-error is-success").addClass("is-warning");
      $button.attr("data-confirmed", String(level.id))
        .html(icon("exclamation-triangle") + " Confirm Make Inactive");
      return;
    }
    submitLevelAction(level, {
      button: "#rbac-dialog-delete",
      type: restoring ? "LEVEL_RESTORE" : "LEVEL_DELETE",
      progress: restoring ? "Restoring level and parent links…" :
        "Checking dependencies and retiring level…",
      busyLabel: restoring ? "Restoring…" : "Retiring…",
      failure: restoring ? "The hierarchy level could not be restored." :
        "The hierarchy level could not be made inactive.",
      success: restoring ?
        "Hierarchy level restored with its saved relationships." :
        "Hierarchy level is inactive and retained for restoration.",
      defaultHtml: restoring ?
        icon("refresh") + " Restore Level" :
        icon("archive") + " Make Inactive"
    });
  }

  function purgeLevel() {
    var level = currentDialogLevel();
    var $button = $("#rbac-dialog-purge");
    if (!level.id) {
      toast("The hierarchy level is unavailable. Reload and try again.", true);
      return;
    }
    if ($button.attr("data-confirmed") !== String(level.id)) {
      $("#rbac-dialog-delete").removeAttr("data-confirmed").html(
        level.status === "INACTIVE" ?
          icon("refresh") + " Restore Level" :
          icon("archive") + " Make Inactive"
      );
      $("#rbac-form-message")
        .text("Permanent delete cannot be undone. The level metadata and its nodes will be removed. Click Confirm Permanent Delete to continue.")
        .removeClass("is-error is-success").addClass("is-warning");
      $button.attr("data-confirmed", String(level.id))
        .html(icon("exclamation-triangle") + " Confirm Permanent Delete");
      return;
    }
    submitLevelAction(level, {
      button: "#rbac-dialog-purge",
      type: "LEVEL_PURGE",
      progress: "Checking references and permanently deleting the level…",
      busyLabel: "Deleting…",
      failure: "The hierarchy level could not be permanently deleted.",
      success: "Hierarchy level permanently deleted.",
      defaultHtml: icon("trash") + " Permanent Delete"
    });
  }

  function changeNodeState() {
    var node = currentDialogNode();
    if (!node || !node.id) {
      toast("The hierarchy node is unavailable. Reload and try again.", true);
      return;
    }
    setTreeNodeActive(node, node.active === "Y" ? "N" : "Y", true);
  }

  function purgeDialogNode() {
    purgeTreeNode(currentDialogNode(), true);
  }

  function validateStudio() {
    setBusy(true);
    process("RBAC_VALIDATE").done(function (data) {
      var msg = data.message + " Missing parents: " + data.missingParents +
        "; invalid source columns: " + data.invalidSourceColumns + ".";
      toast(msg, !data.valid);
    }).fail(function (xhr) {
      toast(errorMessage(xhr, "Validation failed."), true);
    }).always(function () { setBusy(false); });
  }

  function runSync() {
    apex.message.confirm(
      "Run metadata-driven delta sync from SBOS_AGENT_MASTER now?",
      function (confirmed) {
        if (!confirmed) { return; }
        setBusy(true);
        process("RBAC_SYNC").done(function (data) {
          toast(data.message || "Delta sync completed.");
          load(false);
        }).fail(function (xhr) {
          toast(errorMessage(xhr, "Delta sync failed."), true);
        }).always(function () { setBusy(false); });
      }
    );
  }

  function activate() {
    var value = window.prompt("Activation reason", "RBAC configuration activated");
    if (value === null) { return; }
    setBusy(true);
    process("RBAC_ACTIVATE", { x01: value || "RBAC configuration activated" })
      .done(function (data) {
        toast(data.message || "Version activated.");
        load(false);
      }).fail(function (xhr) {
        toast(errorMessage(xhr, "Activation failed."), true);
      }).always(function () { setBusy(false); });
  }

  function syncApexResources() {
    setBusy(true);
    process("RBAC_SYNC_APEX_RESOURCES")
      .done(function (data) {
        toast(data.message || "APEX resource catalogue synchronized.");
        load(false);
      }).fail(function (xhr) {
        toast(errorMessage(xhr, "APEX resources could not be synchronized."), true);
      }).always(function () {
        setBusy(false);
      });
  }

  function find(list, id) {
    return (list || []).filter(function (item) {
      return Number(item.id) === Number(id);
    })[0] || {};
  }

  function lookupNodes(searchSelector, selectSelector, verticalSelector, levelId) {
    var verticalId = Number($(verticalSelector).val() || state.verticalId);
    var search = $(searchSelector).val().trim();
    if (!verticalId) {
      return;
    }
    process("RBAC_NODE_LOOKUP", {
      x01: verticalId,
      x02: search,
      x03: 100,
      x04: levelId || ""
    }).done(function (data) {
      var $select = $(selectSelector);
      var selected = $select.val();
      var html = '<option value="">Select a location from search results</option>' +
        (data.nodes || []).map(function (node) {
          return '<option value="' + attr(node.id) + '"' +
            (String(node.id) === String(selected) ? " selected" : "") + ">" +
            esc(node.name + " · " + node.levelName + " · " + node.code) +
            "</option>";
        }).join("");
      $select.html(html);
    }).fail(function (xhr) {
      toast(errorMessage(xhr, "Hierarchy lookup failed."), true);
    });
  }

  var nodeLookupSequence = 0;
  var nodeLookupRequest = null;

  function nodePickerOption(node, selectedId) {
    var selected = String(node.id) === String(selectedId || "");
    return '<button type="button" class="rbac-node-picker-option' +
      (selected ? " is-selected" : "") + '" role="option" data-node-id="' +
      attr(node.id) + '" data-node-name="' + attr(node.name) + '"' +
      ' aria-selected="' + (selected ? "true" : "false") + '">' +
      '<span class="rbac-node-picker-option-main">' + esc(node.name) + "</span>" +
      '<span class="rbac-node-picker-option-meta">' +
      esc(node.levelName || "Hierarchy location") + " · " + esc(node.code || "") +
      "</span></button>";
  }

  function openNodeResults($picker) {
    if (!$picker || !$picker.length) { return; }
    var $input = $picker.find(".rbac-node-picker-input");
    $picker.find(".rbac-node-picker-results").prop("hidden", false);
    $input.attr("aria-expanded", "true");
  }

  function closeNodeResults($picker) {
    var $target = $picker && $picker.length ?
      $picker : $("[data-rbac-node-picker]");
    $target.find(".rbac-node-picker-results").prop("hidden", true);
    $target.find(".rbac-node-picker-input")
      .attr("aria-expanded", "false")
      .removeAttr("aria-activedescendant");
    $target.find(".rbac-node-picker-option").removeClass("is-active");
  }

  function refreshNodePicker($picker, options) {
    options = options || {};
    if (!$picker || !$picker.length) { return; }
    $picker = $picker.first();
    var $input = $picker.find(".rbac-node-picker-input");
    var $value = $picker.find("input[type='hidden']");
    var $results = $picker.find(".rbac-node-picker-results");
    var verticalId = Number($($picker.attr("data-vertical-selector")).val());
    if (!$input.length || !$value.length || !$results.length) { return; }

    if (!options.keepSelection) {
      $value.val("");
      $input.val("").attr("aria-invalid", "false");
    }
    if (!verticalId) {
      $results.html(
        '<div class="rbac-node-picker-status">Select a hierarchy first.</div>'
      );
      return;
    }

    var query = options.query === undefined ?
      String($input.val() || "").trim() : String(options.query || "").trim();
    var selectedId = $value.val();
    var selectedName = selectedId ? String($input.val() || "").trim() : "";
    var requestSequence = ++nodeLookupSequence;
    if (nodeLookupRequest && typeof nodeLookupRequest.abort === "function") {
      nodeLookupRequest.abort();
    }
    $results.attr("aria-busy", "true").html(
      '<div class="rbac-node-picker-status">' +
      icon("spinner fa-spin") + " Loading locations…</div>"
    );
    if (options.open) {
      openNodeResults($picker);
    }

    nodeLookupRequest = process("RBAC_NODE_LOOKUP", {
      x01: verticalId,
      x02: query,
      x03: 100,
      x04: ""
    }).done(function (data) {
      if (requestSequence !== nodeLookupSequence ||
          !$results[0] || !document.documentElement.contains($results[0])) {
        return;
      }
      var nodes = data.nodes || [];
      var hasSelected = nodes.some(function (node) {
        return String(node.id) === String(selectedId);
      });
      if (selectedId && selectedName && !hasSelected) {
        nodes.unshift({
          id: selectedId,
          name: selectedName,
          levelName: "Current selection",
          code: ""
        });
      }
      $results.html(nodes.length ?
        nodes.map(function (node) {
          return nodePickerOption(node, selectedId);
        }).join("") :
        '<div class="rbac-node-picker-status">No matching locations found.</div>');
    }).fail(function (xhr, status) {
      if (status === "abort" || requestSequence !== nodeLookupSequence) {
        return;
      }
      $results.html(
        '<div class="rbac-node-picker-status is-error">' +
        "Locations could not be loaded. Type to try again.</div>"
      );
      toast(errorMessage(xhr, "Hierarchy lookup failed."), true);
    }).always(function () {
      if (requestSequence === nodeLookupSequence) {
        nodeLookupRequest = null;
        $results.removeAttr("aria-busy");
      }
    });
  }

  function moveNodeHighlight($picker, direction) {
    var $options = $picker.find(".rbac-node-picker-option");
    if (!$options.length) { return; }
    var currentIndex = $options.index($options.filter(".is-active"));
    var nextIndex = currentIndex < 0 ?
      (direction > 0 ? 0 : $options.length - 1) :
      Math.max(0, Math.min($options.length - 1, currentIndex + direction));
    $options.removeClass("is-active");
    var $next = $options.eq(nextIndex).addClass("is-active");
    var optionId = $picker.find(".rbac-node-picker-results").attr("id") +
      "-option-" + $next.data("node-id");
    $next.attr("id", optionId);
    $picker.find(".rbac-node-picker-input")
      .attr("aria-activedescendant", optionId);
    if ($next[0] && typeof $next[0].scrollIntoView === "function") {
      $next[0].scrollIntoView({ block: "nearest" });
    }
  }

  function selectPickerNode($option) {
    if (!$option || !$option.length) { return; }
    var $picker = $option.closest("[data-rbac-node-picker]");
    $picker.find("input[type='hidden']")
      .val($option.data("node-id"))
      .trigger("change");
    $picker.find(".rbac-node-picker-input")
      .val($option.data("node-name"))
      .attr("aria-invalid", "false");
    $picker.find(".rbac-node-picker-option")
      .removeClass("is-selected")
      .attr("aria-selected", "false");
    $option.addClass("is-selected").attr("aria-selected", "true");
    $("#rbac-form-message").empty().removeClass("is-error");
    closeNodeResults($picker);
  }

  function refreshUserPicker($picker) {
    var $input = $picker.find(".rbac-user-picker-input");
    var $results = $picker.find(".rbac-user-picker-results");
    var query = String($input.val() || "").trim();
    if (query.length < 2) {
      $results.prop("hidden", false).html(
        '<div class="rbac-node-picker-status">Type at least 2 characters.</div>'
      );
      $input.attr("aria-expanded", "true");
      return;
    }
    $results.prop("hidden", false).html(
      '<div class="rbac-node-picker-status">' +
      icon("spinner fa-spin") + " Searching users…</div>"
    );
    $input.attr("aria-expanded", "true");
    process("RBAC_USER_LOOKUP", {
      x01: query,
      x02: $picker.attr("data-exclude-id") || ""
    }).done(function (data) {
      var items = data.items || [];
      $results.html(items.length ? items.map(function (user) {
        return '<button type="button" class="rbac-node-picker-option ' +
          'rbac-user-picker-option" role="option" data-user-id="' +
          attr(user.id) + '" data-user-name="' + attr(user.displayName) + '">' +
          '<span class="rbac-node-picker-option-main">' +
          esc(user.displayName) + '</span><span class="rbac-node-picker-option-meta">' +
          esc(user.userName) + (user.userLevelName ?
            " · " + esc(user.userLevelName) : "") +
          "</span></button>";
      }).join("") :
        '<div class="rbac-node-picker-status">No matching active users found.</div>');
    }).fail(function (xhr) {
      $results.html(
        '<div class="rbac-node-picker-status is-error">User search failed. Type to try again.</div>'
      );
      toast(errorMessage(xhr, "User search failed."), true);
    });
  }

  function selectPickerUser($option) {
    var $picker = $option.closest("[data-rbac-user-picker]");
    $picker.find("input[type='hidden']").val($option.data("user-id"));
    $picker.find(".rbac-user-picker-input")
      .val($option.data("user-name"))
      .attr("aria-expanded", "false");
    $picker.find(".rbac-user-picker-results").prop("hidden", true);
  }

  function bind() {
    $(document).on("click", ".rbac-tab", function () {
      state.tab = this.dataset.rbacTab;
      state.search = "";
      state.offset = 0;
      $(".rbac-tab").removeClass("is-active").attr("aria-selected", "false");
      $(this).addClass("is-active").attr("aria-selected", "true");
      load();
    });
    $(document).on("change", "#rbac-vertical-select", function () {
      state.verticalId = Number(this.value);
      state.search = "";
      state.offset = 0;
      load();
    });
    $(document).on("keydown", "#rbac-search", function (event) {
      if (event.key === "Enter") {
        state.search = this.value.trim();
        state.offset = 0;
        load();
      }
    });
    $(document).on("click", "[data-rbac-action]", function () {
      if (state.busy) { return; }
      var action = this.dataset.rbacAction;
      var id = this.dataset.id;
      if (action === "overview-pane") {
        state.overviewPane = this.dataset.pane;
        render();
      }
      else if (action === "section-tab") {
        state.tab = this.dataset.tab;
        state.search = "";
        state.offset = 0;
        load();
      }
      else if (action === "versions-pane") {
        state.versionsPane = this.dataset.pane;
        render();
      }
      else if (action === "role-catalogue-pane") {
        state.roleCataloguePane = this.dataset.pane;
        state.search = "";
        render();
      }
      else if (action === "select-role-group") {
        state.selectedRoleGroupId = Number(id);
        render();
      }
      else if (action === "select-assignment-user") {
        state.selectedAssignmentUserId = Number(id);
        render();
      }
      else if (action === "manage-user-access") {
        state.selectedAssignmentUserId = Number(id);
        state.tab = "assignments";
        load();
      }
      else if (action === "native-edit-user") {
        editNativeEntity("USER", id);
      }
      else if (action === "native-manage-user-access") {
        selectNativeAssignmentUser(id, true,
          $(this).closest("tr").find(".rbac-ir-identity strong")
            .first().text().trim());
      }
      else if (action === "native-select-assignment-user") {
        selectNativeAssignmentUser(id, false,
          $(this).closest("tr").find(".rbac-ir-identity strong")
            .first().text().trim());
      }
      else if (action === "native-edit-scope") {
        editNativeEntity("SCOPE", id);
      }
      else if (action === "role-pane") {
        $(".rbac-role-tabs .rbac-inner-tab").removeClass("is-active")
          .attr("aria-selected", "false");
        $(this).addClass("is-active").attr("aria-selected", "true");
        $(".rbac-role-pane").prop("hidden", true);
        $(".rbac-role-pane[data-role-pane='" + this.dataset.pane + "']")
          .prop("hidden", false);
      }
      else if (action === "role-module") {
        showRoleModule(this.dataset.module);
      }
      else if (action === "role-page-card") {
        toggleRolePageCard(this.dataset.module, this.dataset.pageId);
      }
      else if (action === "role-page-toggle") {
        var toggleIds = permissionIds(this.dataset.permissionIds);
        var allSelected = toggleIds.length > 0 && toggleIds.every(
          function (permissionId) {
            return $("#rbac-role-permission-store input[value='" +
              permissionId + "']").prop("checked");
          }
        );
        setStoredRolePermissions(toggleIds, !allSelected);
        toast(toggleIds.length + " page resources " +
          (allSelected ? "cleared" : "selected") +
          ". Save the role to apply.");
      }
      else if (action === "role-page-customize") {
        var $card = $(this).closest(".rbac-page-card");
        $card.addClass("is-open");
        $card.find(".rbac-page-card-body").prop("hidden", false);
        $card.find(".rbac-page-card-toggle").attr("aria-expanded", "true");
      }
      else if (action === "role-vertical") {
        showRoleVertical(this.dataset.verticalId);
      }
      else if (action === "hierarchy-pane") {
        state.hierarchyPane = this.dataset.pane;
        render();
      }
      else if (action === "sync") { runSync(); }
      else if (action === "sync-apex-resources") { syncApexResources(); }
      else if (action === "validate") { validateStudio(); }
      else if (action === "activate") { activate(); }
      else if (action === "view-run-log") {
        openRunLog(find(state.data.runs, id));
      }
      else if (action === "delete-run") {
        deleteRun(find(state.data.runs, id));
      }
      else if (action === "add-vertical") { openForm("VERTICAL"); }
      else if (action === "edit-vertical") {
        openForm("VERTICAL", find(state.data.verticals, id));
      }
      else if (action === "add-level") { openForm("LEVEL"); }
      else if (action === "edit-level") { openForm("LEVEL", find(state.data.levels, id)); }
      else if (action === "restore-level") {
        openForm("LEVEL", find(state.data.levels, id));
      }
      else if (action === "move-level") {
        moveLevel(find(state.data.levels, id), Number(this.dataset.position));
      }
      else if (action === "add-role-group") { openForm("ROLE_GROUP"); }
      else if (action === "edit-role-group") {
        openForm("ROLE_GROUP", find(state.data.roleGroups, id));
      }
      else if (action === "add-role") {
        openForm("ROLE", { groupId: state.selectedRoleGroupId });
      }
      else if (action === "edit-role") { openForm("ROLE", find(state.data.roles, id)); }
      else if (action === "add-user-level") { openForm("USER_LEVEL"); }
      else if (action === "edit-user-level") { openForm("USER_LEVEL", find(state.data.userLevels, id)); }
      else if (action === "add-user") { openForm("USER"); }
      else if (action === "edit-user") { openForm("USER", find(state.data.users, id)); }
      else if (action === "add-scope") {
        openForm("SCOPE", { userId: state.selectedAssignmentUserId });
      }
      else if (action === "edit-scope") { openForm("SCOPE", find(state.data.scopes, id)); }
      else if (action === "edit-node") { openForm("NODE", find(state.data.nodes, id)); }
      else if (action === "tree-toggle") {
        var $button = $(this);
        var $children = $("#rbac-tree-children-" + id);
        if ($children.is(":hidden")) {
          $children.prop("hidden", false);
          $button.attr("aria-expanded", "true").find(".fa")
            .removeClass("fa-chevron-right").addClass("fa-chevron-down");
          if (!$children.data("loaded")) {
            $children.data("loaded", true);
            loadHierarchyTree(Number(id), "", "#rbac-tree-children-" + id);
          }
        } else {
          $children.prop("hidden", true);
          $button.attr("aria-expanded", "false").find(".fa")
            .removeClass("fa-chevron-down").addClass("fa-chevron-right");
        }
      }
      else if (action === "tree-select") {
        renderNodeDetail(state.treeNodes[String(id)]);
      }
      else if (action === "tree-search") {
        loadHierarchyTree(null, $("#rbac-tree-search").val().trim());
      }
      else if (action === "tree-reload") {
        $("#rbac-tree-search").val("");
        loadHierarchyTree(null, "");
      }
      else if (action === "add-root-node") {
        var rootLevel = firstHierarchyLevel();
        if (!rootLevel) {
          toast("Add and activate the first hierarchy level before adding a root node.", true);
        } else {
          openForm("NODE", {
            verticalId: state.verticalId,
            levelId: rootLevel.id,
            levelName: rootLevel.name,
            sequence: rootLevel.sequence,
            active: "Y"
          });
        }
      }
      else if (action === "add-child-node") {
        var parentNode = state.treeNodes[String(id)];
        var childLevel = nextHierarchyLevel(parentNode);
        if (!childLevel) {
          toast("The selected node is already at the final hierarchy level.", true);
        } else {
          openForm("NODE", {
            verticalId: parentNode.verticalId,
            levelId: childLevel.id,
            levelName: childLevel.name,
            sequence: childLevel.sequence,
            parentId: parentNode.id,
            parentName: parentNode.name,
            active: "Y"
          });
        }
      }
      else if (action === "edit-tree-node") {
        openForm("NODE", state.treeNodes[String(id)]);
      }
      else if (action === "toggle-tree-node-status") {
        var statusNode = state.treeNodes[String(id)];
        setTreeNodeActive(statusNode, statusNode.active === "Y" ? "N" : "Y");
      }
      else if (action === "purge-tree-node") {
        purgeTreeNode(state.treeNodes[String(id)], false);
      }
      else if (action === "page-prev") {
        state.offset = Math.max(0, state.offset - state.limit);
        load();
      } else if (action === "page-next") {
        state.offset += state.limit;
        load();
      }
    });
    var lookupTimer;
    $(document).on("input", ".rbac-node-picker-input", function () {
      var $picker = $(this).closest("[data-rbac-node-picker]");
      $picker.find("input[type='hidden']").val("");
      $(this).attr("aria-invalid", "false");
      window.clearTimeout(lookupTimer);
      lookupTimer = window.setTimeout(function () {
        refreshNodePicker($picker, { keepSelection: true, open: true });
      }, 250);
    });
    $(document).on("focus", ".rbac-node-picker-input", function () {
      var $picker = $(this).closest("[data-rbac-node-picker]");
      var $results = $picker.find(".rbac-node-picker-results");
      openNodeResults($picker);
      if ($results.attr("aria-busy") !== "true" &&
          !$results.find(".rbac-node-picker-option").length) {
        refreshNodePicker($picker, { keepSelection: true, open: true });
      }
    });
    $(document).on("click", ".rbac-node-picker-toggle", function () {
      var $picker = $(this).closest("[data-rbac-node-picker]");
      if ($picker.find(".rbac-node-picker-results").is(":hidden")) {
        openNodeResults($picker);
        refreshNodePicker($picker, {
          keepSelection: true,
          query: "",
          open: true
        });
        $picker.find(".rbac-node-picker-input").trigger("focus");
      } else {
        closeNodeResults($picker);
      }
    });
    $(document).on("mousedown", ".rbac-node-picker-option", function (event) {
      event.preventDefault();
      selectPickerNode($(this));
    });
    $(document).on("keydown", ".rbac-node-picker-input", function (event) {
      var $picker = $(this).closest("[data-rbac-node-picker]");
      if (event.key === "ArrowDown" || event.key === "ArrowUp") {
        event.preventDefault();
        event.stopImmediatePropagation();
        openNodeResults($picker);
        moveNodeHighlight($picker, event.key === "ArrowDown" ? 1 : -1);
      } else if (event.key === "Enter") {
        event.preventDefault();
        event.stopImmediatePropagation();
        var $active = $picker.find(".rbac-node-picker-option.is-active");
        if ($active.length) {
          selectPickerNode($active);
        }
      } else if (event.key === "Escape") {
        event.preventDefault();
        event.stopImmediatePropagation();
        closeNodeResults($picker);
      }
    });
    $(document).on("mousedown", function (event) {
      if (!$(event.target).closest("[data-rbac-node-picker]").length) {
        closeNodeResults();
      }
      if (!$(event.target).closest("[data-rbac-user-picker]").length) {
        $("[data-rbac-user-picker] .rbac-user-picker-results")
          .prop("hidden", true);
        $("[data-rbac-user-picker] .rbac-user-picker-input")
          .attr("aria-expanded", "false");
      }
    });
    $(document).on("input", ".rbac-user-picker-input", function () {
      var $picker = $(this).closest("[data-rbac-user-picker]");
      $picker.find("input[type='hidden']").val("");
      window.clearTimeout(userLookupTimer);
      userLookupTimer = window.setTimeout(function () {
        refreshUserPicker($picker);
      }, 250);
    });
    $(document).on("focus", ".rbac-user-picker-input", function () {
      if (String(this.value || "").trim().length >= 2) {
        refreshUserPicker($(this).closest("[data-rbac-user-picker]"));
      }
    });
    $(document).on("mousedown", ".rbac-user-picker-option", function (event) {
      event.preventDefault();
      selectPickerUser($(this));
    });
    $(document).on("input", "#rbac-f-parentSearch", function () {
      window.clearTimeout(lookupTimer);
      lookupTimer = window.setTimeout(function () {
        var selectedLevel = find(state.data.allLevels, $("#rbac-f-levelId").val());
        var parentLevel = (state.data.allLevels || []).filter(function (level) {
          return Number(level.verticalId) === Number(selectedLevel.verticalId) &&
            Number(level.sequence) < Number(selectedLevel.sequence);
        }).sort(function (a, b) {
          return Number(b.sequence) - Number(a.sequence);
        })[0];
        lookupNodes("#rbac-f-parentSearch", "#rbac-f-parentId",
          "#rbac-f-verticalId", parentLevel && parentLevel.id);
      }, 250);
    });
    $(document).on("keydown", "#rbac-tree-search", function (event) {
      if (event.key === "Enter") {
        event.preventDefault();
        loadHierarchyTree(null, this.value.trim());
      }
    });
    $(document).on("change", "#rbac-tree-show-disabled", function () {
      state.showInactive = this.checked;
      loadHierarchyTree(null, $("#rbac-tree-search").val().trim());
    });
    $(document).on("input", ".rbac-role-control-search", filterRoleControls);
    $(document).on("change", ".rbac-role-control-type", filterRoleControls);
    $(document).on("input", "#rbac-role-application-search", function () {
      var query = (this.value || "").trim().toUpperCase();
      $(".rbac-explorer-module").each(function () {
        $(this).prop("hidden", query &&
          String(this.dataset.module || "").toUpperCase().indexOf(query) < 0 &&
          $(this).text().toUpperCase().indexOf(query) < 0);
      });
    });
    $(document).on("change", ".rbac-access-preset", function () {
      var preset = this.value;
      var ids = permissionIds(this.dataset.permissionIds);
      applyPermissionPreset(ids, preset);
      toast(
        (preset === "FULL" ? "Full access" :
          (preset === "VIEW" ? "View-only access" :
            (preset === "NONE" ? "Application access cleared" :
              "Custom access"))) +
        " selected. Save the role to apply."
      );
    });
    $(document).on("change", ".rbac-explorer-permission", function () {
      setStoredRolePermissions([Number(this.dataset.permissionId)], this.checked);
    });
    $(document).on("change", ".rbac-level-scope-row input[name='levelIds']",
      updateRoleLevelCounts);
    $(document).on("change", "#rbac-role-permission-store input[name='permissionIds']",
      updateRoleExplorerCounts);
    $(document).on("change", "#rbac-f-roleId", function () {
      renderRoleAccessPreview(this.value);
    });
    $(document).on("change", "#rbac-f-groupId", function () {
      if ($("#rbac-f-roleId").length) {
        updateScopeRoleOptions();
      }
    });
    $(document).on("change", "#rbac-f-verticalId", function () {
      var $picker = $("[data-rbac-node-picker]" +
        "[data-vertical-selector='#rbac-f-verticalId']");
      if ($picker.length) {
        window.clearTimeout(lookupTimer);
        refreshNodePicker($picker, {
          keepSelection: false,
          query: "",
          open: true
        });
      }
    });
    $(document).on("change", "#rbac-f-primaryVerticalId", function () {
      var $picker = $("[data-rbac-node-picker]" +
        "[data-vertical-selector='#rbac-f-primaryVerticalId']");
      if ($picker.length) {
        window.clearTimeout(lookupTimer);
        refreshNodePicker($picker, {
          keepSelection: false,
          query: "",
          open: true
        });
      }
    });
    $(document).on("change", "#rbac-f-authentication", toggleUserCredentials);
    $("#rbac-dialog")
      .off(".rbacDrawerLifecycle")
      .on("dialogopen.rbacDrawerLifecycle", function () {
        this.setAttribute("data-rbac-open-requested", "Y");
        state.editorOpen = true;
        fixDrawerFrame();
      })
      .on("dialogbeforeclose.rbacDrawerLifecycle", beginEditorClose)
      .on("dialogclose.rbacDrawerLifecycle", function () {
        beginEditorClose();
        $("#rbac-dialog-cancel-foot").text("Cancel");
      });
    $(document).on(
      "pointerdown.rbacDrawerClose mousedown.rbacDrawerClose",
      ".rbac-editor-drawer .ui-dialog-titlebar-close",
      beginEditorClose
    );
    $(document).on("click", "#rbac-dialog-cancel, #rbac-dialog-cancel-foot", function (event) {
      event.preventDefault();
      event.stopPropagation();
      closeEditor();
      $("#rbac-dialog-cancel-foot").text("Cancel");
    });
    $(document).on("click", "#rbac-dialog-save", function (event) {
      event.preventDefault();
      event.stopImmediatePropagation();
      saveForm();
    });
    $(document).on("click", "#rbac-dialog-save-assign", function (event) {
      event.preventDefault();
      event.stopImmediatePropagation();
      saveForm(true);
    });
    $(document).on("click", "#rbac-dialog-delete", function (event) {
      event.preventDefault();
      event.stopImmediatePropagation();
      if ($("#rbac-form").data("entity") === "NODE") {
        changeNodeState();
      } else {
        changeLevelState();
      }
    });
    $(document).on("click", "#rbac-dialog-purge", function (event) {
      event.preventDefault();
      event.stopImmediatePropagation();
      if ($("#rbac-form").data("entity") === "NODE") {
        purgeDialogNode();
      } else {
        purgeLevel();
      }
    });
    $(document).on("keydown", "#rbac-form input", function (event) {
      if (event.key === "Enter") {
        event.preventDefault();
        saveForm();
      }
    });
  }

  $(function () {
    if (!document.getElementById("rbac-studio")) {
      return;
    }
    state.selectedAssignmentUserId =
      Number(apex.item("P60_SELECTED_RBAC_USER_ID").getValue() || 0) || null;
    bind();
    load();
  });
})(apex.jQuery);
