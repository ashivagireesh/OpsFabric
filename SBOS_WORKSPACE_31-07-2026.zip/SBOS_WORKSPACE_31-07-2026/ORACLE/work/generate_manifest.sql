set serveroutput on size unlimited feedback off verify off heading off pages 0 lines 32767
whenever sqlerror exit sql.sqlcode rollback

declare
  l_file       utl_file.file_type;
  l_count      number;
  l_mb         number;
  l_included   varchar2(1);
  l_category   varchar2(40);
  l_reason     varchar2(1000);

  function csv(p_value varchar2) return varchar2 is
  begin
    return '"' || replace(nvl(p_value, ''), '"', '""') || '"';
  end;

  function selected(p_table varchar2) return boolean is
  begin
    return p_table in (
      'AGENT_ADV_CONFIG','AGENT_ADV_CONFIG_VER','AGENT_ANALYTIC_BUCKET',
      'AGENT_ANALYTIC_BUCKET_VER','AGENT_ANALYTIC_FILTER',
      'AGENT_ANALYTIC_FILTER_VERSION','AGENT_ANALYTIC_METRIC',
      'AGENT_ANALYTIC_RETENTION','AGENT_BUCKET_CONFIG','AGENT_BUCKET_RISK_BAND',
      'AGENT_CLASS_BUCKET','AGENT_CLASS_BUCKET_VER',
      'AGENT_CONDITION_RECOMMENDATION','AGENT_FINDING_TYPE_REGISTRY',
      'AGENT_JSON_PATH_CATALOG','AGENT_MODULE_REGISTRY','AGENT_MONITOR_POLICY',
      'AGENT_MONITOR_POLICY_VER','AGENT_POLICY_BUCKET','AGENT_POLICY_SCHEDULE',
      'AGENT_PROFILE_FILTER_FIELD','AGENT_WORKFLOW_ACTION_REGISTRY',
      'SAS_AAM_QUESTIONNAIRE','SAS_AAM_QUESTION','SAS_AAM_QUESTION_I18N',
      'SAS_RULE_GROUP','SAS_RULE_DEFINITION','SAS_RULE_CONDITION',
      'SBOS_AGENT_CASE_CATALOG','SBOS_AGENT_CASE_FEATURE_MAP',
      'SBOS_AGENT_CASE_QUESTION','SBOS_AGENT_CASE_RULE_FEATURE',
      'SBOS_AGENT_CASE_RUNTIME','SBOS_CASE_SOURCE_RECOMMENDATION',
      'SBOS_CONDITION_INTELLIGENCE','SBOS_CONDITION_PEER_VERTICAL',
      'SBOS_ETL_CONNECTION','SBOS_ETL_PIPELINE','SBOS_ETL_COLUMN_MAP',
      'SBOS_ETL_DELTA_CONFIG','SBOS_ETL_RETENTION','SBOS_ETL_SCRIPT',
      'SBOS_ETL_SORT','SBOS_ETL_SOURCE','SBOS_ETL_SOURCE_JOIN',
      'SBOS_ETL_TRANSFORM','SBOS_ETL_SCHEDULE',
      'SBOS_FE_CONFIG','SBOS_FE_FEATURE','SBOS_FE_FEATURE_DEPENDENCY',
      'SBOS_FE_FEATURE_INPUT','SBOS_FE_FEATURE_VERSION','SBOS_FE_META_FIELD',
      'SBOS_JSON_GUARD_CONTROL','SBOS_PROFILE_CONFIG',
      'SBOS_PROFILE_CONFIG_VERSION','SBOS_PROFILE_FIELD_CONFIG',
      'SBOS_PROFILE_FUNCTION','SBOS_PROFILE_GROUP_METRIC_CONFIG',
      'SBOS_PROFILE_JSON_OUTPUT_CONTRACT','SBOS_PROFILE_REBUILD_JOB',
      'SBOS_PROFILE_REBUILD_BUCKET','SBOS_RBAC_VERTICAL','SBOS_RBAC_LEVEL',
      'SBOS_RBAC_PERMISSION','SBOS_RBAC_ROLE_GROUP','SBOS_RBAC_ROLE',
      'SBOS_RBAC_ROLE_LEVEL','SBOS_RBAC_ROLE_PERMISSION','SBOS_RBAC_SETTING',
      'SBOS_RBAC_VERSION'
    );
  end;
begin
  l_file := utl_file.fopen(
    'DATA_PUMP_DIR',
    'sas_export_manifest.csv',
    'w',
    32767
  );

  utl_file.put_line(
    l_file,
    'record_type,owner,object_name,object_type,classification,included_data,row_count,row_count_basis,allocated_mb,source_scn,reason,sha256'
  );

  for r in (
    select t.table_name,
           nvl(t.num_rows, 0) stats_rows,
           nvl(round(s.bytes / 1024 / 1024, 2), 0) allocated_mb
      from dba_tables t
      left join (
        select owner, segment_name, sum(bytes) bytes
          from dba_segments
         where owner = 'SAS'
           and segment_type like 'TABLE%'
         group by owner, segment_name
      ) s
        on s.owner = t.owner
       and s.segment_name = t.table_name
     where t.owner = 'SAS'
     order by t.table_name
  ) loop
    l_mb := r.allocated_mb;
    if selected(r.table_name) then
      execute immediate 'select count(*) from sas.' || dbms_assert.simple_sql_name(r.table_name)
        into l_count;
      l_included := 'Y';
      l_category := case
        when r.table_name in ('AGENT_POLICY_SCHEDULE','SBOS_ETL_SCHEDULE')
          then 'SCHEDULE_CONFIGURATION'
        when r.table_name like 'SBOS_ETL_%'
          then 'ETL_CONFIGURATION'
        when r.table_name like 'SBOS_RBAC_%' then 'RBAC_DEFINITION'
        when r.table_name like 'SBOS_PROFILE_%' then 'PROFILE_CONFIGURATION'
        when r.table_name like 'SBOS_FE_%' then 'FEATURE_CONFIGURATION'
        when r.table_name like 'SBOS_AGENT_CASE_%'
          or r.table_name like 'SBOS_CONDITION_%'
          or r.table_name = 'SBOS_CASE_SOURCE_RECOMMENDATION'
          then 'CASE_RULE_CONFIGURATION'
        when r.table_name like 'SAS_RULE_%'
          or r.table_name like 'SAS_AAM_QUESTION%'
          then 'APPLICATION_RULE_CONFIGURATION'
        else 'GOVERNED_ANALYTICS_CONFIGURATION'
      end;
      l_reason := case
        when r.table_name in ('SBOS_PROFILE_REBUILD_JOB','SBOS_PROFILE_REBUILD_BUCKET')
          then 'Required dependency metadata for profile configuration versions; no scheduler jobs exported'
        else 'Allowlisted application configuration metadata'
      end;
      utl_file.put_line(
        l_file,
        'TABLE,' || csv('SAS') || ',' || csv(r.table_name) || ',' || csv('TABLE') || ',' ||
        csv(l_category) || ',Y,' || l_count || ',EXACT,' || to_char(l_mb, 'FM999999990D00', 'NLS_NUMERIC_CHARACTERS=''.,''') ||
        ',23443166,' || csv(l_reason) || ','
      );
    else
      l_category := case
        when r.table_name like '%TRANS%' or r.table_name like '%TXN%'
          then 'TRANSACTION_DATA'
        when r.table_name like '%EVENT%'
          then 'EVENT_DATA'
        when r.table_name like '%SCHEDULE%'
          then 'SCHEDULE_DATA'
        when r.table_name like '%FINDING%' or r.table_name like '%EVIDENCE%'
          or r.table_name like '%RECOMMENDATION_INSTANCE%'
          then 'FINDING_EVIDENCE_DATA'
        when r.table_name like '%RUN%' or r.table_name like '%AUDIT%'
          or r.table_name like '%LOG%'
          then 'EXECUTION_AUDIT_DATA'
        when r.table_name like '%PROFILE_%STATE%'
          or r.table_name like '%PROFILE_DAILY%'
          or r.table_name like '%PROFILE_MONTHLY%'
          or r.table_name like '%PROFILE_360%'
          then 'PROFILE_RUNTIME_DATA'
        when r.table_name like '%USER%' or r.table_name = 'SAS_ALLOWED_USER'
          then 'USER_IDENTITY_DATA'
        when r.table_name = 'SBOS_ETL_CONNECTION'
          then 'SECRET_BEARING_CONFIGURATION'
        else 'OPERATIONAL_OR_REFERENCE_DATA'
      end;
      l_reason := case
        when r.table_name = 'SBOS_ETL_CONNECTION'
          then 'Excluded because encrypted credential fields are present'
        when r.table_name like '%SCHEDULE%'
          then 'Excluded schedule definition or schedule state'
        when r.table_name like '%EVENT%'
          then 'Excluded event or event-state data'
        when r.table_name like '%USER%' or r.table_name = 'SAS_ALLOWED_USER'
          then 'Excluded identity or user-assignment data'
        else 'Excluded operational, transactional, derived, runtime, audit, or reference data'
      end;
      utl_file.put_line(
        l_file,
        'TABLE,' || csv('SAS') || ',' || csv(r.table_name) || ',' || csv('TABLE') || ',' ||
        csv(l_category) || ',N,' || r.stats_rows || ',DBA_TABLES_STATISTICS,' ||
        to_char(l_mb, 'FM999999990D00', 'NLS_NUMERIC_CHARACTERS=''.,''') ||
        ',23443166,' || csv(l_reason) || ','
      );
    end if;
  end loop;

  for j in (
    select job_name, enabled, state, repeat_interval, job_type
      from dba_scheduler_jobs
     where owner = 'SAS'
     order by job_name
  ) loop
    utl_file.put_line(
      l_file,
      'SCHEDULER_JOB,' || csv('SAS') || ',' || csv(j.job_name) || ',' ||
      csv(j.job_type) || ',' || csv('SCHEDULER_CONFIGURATION') || ',Y,,,0.00,23443166,' ||
      csv('Exported as a disabled job definition; source enabled=' || j.enabled ||
          '; source state=' || j.state || '; repeat_interval=' || j.repeat_interval) || ','
    );
  end loop;

  utl_file.fclose(l_file);
  dbms_output.put_line('Manifest generated.');
exception
  when others then
    if utl_file.is_open(l_file) then
      utl_file.fclose(l_file);
    end if;
    raise;
end;
/
exit
