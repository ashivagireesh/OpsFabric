set define off verify off feedback on serveroutput on lines 240 pages 500
whenever sqlerror exit sql.sqlcode rollback

prompt ================================================================
prompt SAS application configuration post-import compile and validation
prompt Source export SCN: 23443166
prompt ================================================================

declare
  l_invalid_before number;
begin
  select count(*) into l_invalid_before
    from all_objects
   where owner = 'SAS'
     and status = 'INVALID';
  dbms_output.put_line('Invalid objects before compile: ' || l_invalid_before);

  dbms_utility.compile_schema(
    schema      => 'SAS',
    compile_all => false
  );
end;
/

prompt Clearing environment-specific compiled decision-plan artifacts

update sas.agent_adv_config_ver
   set compiled_plan_json = null,
       compiled_plan_hash = null
 where compiled_plan_json is not null
    or compiled_plan_hash is not null;

update sas.sbos_profile_field_config
   set compiled_plan_json = null,
       compiled_plan_hash = null
 where compiled_plan_json is not null
    or compiled_plan_hash is not null;

delete from sas.sbos_profile_v2_exec_plan;
commit;

prompt Recompiling active governed configurations

declare
  l_compiled number := 0;
begin
  for r in (
    select config_version_id
      from sas.agent_adv_config_ver
     where version_status = 'ACTIVE'
     order by config_version_id
  ) loop
    sas.pkg_agent_policy_engine.compile_config(r.config_version_id);
    l_compiled := l_compiled + 1;
  end loop;
  dbms_output.put_line('Compiled governed configuration versions: ' || l_compiled);
end;
/

prompt Recompiling active profile contracts

declare
  l_compiled number := 0;
begin
  for r in (
    select profile_config_id, version_no
      from sas.sbos_profile_config_version
     where version_status = 'ACTIVE'
     order by profile_config_id, version_no
  ) loop
    sas.pkg_sbos_profile_fns_v2.compile_config(
      r.profile_config_id,
      r.version_no
    );
    l_compiled := l_compiled + 1;
  end loop;
  dbms_output.put_line('Compiled active profile versions: ' || l_compiled);
end;
/

begin
  dbms_utility.compile_schema(
    schema      => 'SAS',
    compile_all => false
  );
end;
/

prompt Validating configuration relationships and compiled contracts

declare
  l_invalid_objects number;
  l_uncompiled_rules number;
  l_uncompiled_fields number;
  l_orphan_bucket_configs number;
begin
  select count(*) into l_invalid_objects
    from all_objects
   where owner = 'SAS'
     and status = 'INVALID';

  select count(*) into l_uncompiled_rules
    from sas.agent_adv_config_ver
   where version_status = 'ACTIVE'
     and (compiled_plan_json is null or compiled_plan_hash is null);

  select count(*) into l_uncompiled_fields
    from sas.sbos_profile_field_config
   where enabled_yn = 'Y'
     and (compiled_plan_json is null or compiled_plan_hash is null);

  select count(*) into l_orphan_bucket_configs
    from sas.agent_bucket_config bc
   where not exists (
           select 1
             from sas.agent_analytic_bucket_ver bv
            where bv.bucket_version_id = bc.bucket_version_id
         )
      or not exists (
           select 1
             from sas.agent_adv_config_ver cv
            where cv.config_version_id = bc.config_version_id
         );

  dbms_output.put_line('Invalid SAS objects: ' || l_invalid_objects);
  dbms_output.put_line('Uncompiled active governed rules: ' || l_uncompiled_rules);
  dbms_output.put_line('Uncompiled enabled profile fields: ' || l_uncompiled_fields);
  dbms_output.put_line('Orphan bucket/config mappings: ' || l_orphan_bucket_configs);

  if l_invalid_objects > 0
     or l_uncompiled_rules > 0
     or l_uncompiled_fields > 0
     or l_orphan_bucket_configs > 0 then
    raise_application_error(
      -20991,
      'Post-import validation failed. Review the reported counts.'
    );
  end if;
end;
/

prompt Post-import compilation and validation completed successfully.
