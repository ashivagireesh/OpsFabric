-- SAS Oracle Scheduler job definitions
-- Source SCN: 23443166
-- Safety policy: all jobs are created DISABLED regardless of source state.
-- Run 04_post_import_compile_validate.sql before the separate enable script.
-- CONNECT SYS
ALTER SESSION SET EVENTS '10150 TRACE NAME CONTEXT FOREVER, LEVEL 1';
ALTER SESSION SET EVENTS '10904 TRACE NAME CONTEXT FOREVER, LEVEL 1';
ALTER SESSION SET EVENTS '25475 TRACE NAME CONTEXT FOREVER, LEVEL 1';
ALTER SESSION SET EVENTS '10407 TRACE NAME CONTEXT FOREVER, LEVEL 1';
ALTER SESSION SET EVENTS '10851 TRACE NAME CONTEXT FOREVER, LEVEL 1';
ALTER SESSION SET EVENTS '22830 TRACE NAME CONTEXT FOREVER, LEVEL 192 ';
-- new object type path: SCHEMA_EXPORT/POST_SCHEMA/PROCOBJ
-- CONNECT SAS

BEGIN 
dbms_scheduler.create_job('"SAS"."SBOS_ETL_RECOVERY_JOB"',
job_type=>'STORED_PROCEDURE', job_action=>
'PKG_SBOS_ETL_RUNTIME.RECOVER_STALE_RUNS'
, number_of_arguments=>0,
start_date=>TO_TIMESTAMP_TZ('23-JUL-2026 12.35.47.085226000 PM +00:00','DD-MON-RRRR HH.MI.SSXFF AM TZR','NLS_DATE_LANGUAGE=english'), repeat_interval=> 
'FREQ=MINUTELY;INTERVAL=1'
, end_date=>NULL,
job_class=>'"DEFAULT_JOB_CLASS"', enabled=>FALSE, auto_drop=>FALSE,comments=>
'SBOS ETL stale-lock recovery and queued-run dispatcher'
);
sys.dbms_scheduler.set_attribute('"SAS"."SBOS_ETL_RECOVERY_JOB"','NLS_ENV','NLS_LANGUAGE=''AMERICAN'' NLS_TERRITORY=''AMERICA'' NLS_CURRENCY=''$'' NLS_ISO_CURRENCY=''AMERICA'' NLS_NUMERIC_CHARACTERS=''.,'' NLS_CALENDAR=''GREGORIAN'' NLS_DATE_FORMAT=''DD-MON-RR'' NLS_DATE_LANGUAGE=''AMERICAN'' NLS_SORT=''BINARY'' NLS_TIME_FORMAT=''HH.MI.SSXFF AM'' NLS_TIMESTAMP_FORMAT=''DD-MON-RR HH.MI.SSXFF AM'' NLS_TIME_TZ_FORMAT=''HH.MI.SSXFF AM TZR'' NLS_TIMESTAMP_TZ_FORMAT=''DD-MON-RR HH.MI.SSXFF AM TZR'' NLS_DUAL_CURRENCY=''$'' NLS_COMP=''BINARY'' NLS_LENGTH_SEMANTICS=''BYTE'' NLS_NCHAR_CONV_EXCP=''FALSE''');
COMMIT; 
END; 
/ 

BEGIN 
dbms_scheduler.create_job('"SAS"."AGENT_ANALYTIC_COORDINATOR"',
job_type=>'STORED_PROCEDURE', job_action=>
'SAS.PKG_AGENT_POLICY_ENGINE.RUN_COORDINATOR'
, number_of_arguments=>0,
start_date=>TO_TIMESTAMP_TZ('31-JUL-2026 01.59.27.909141000 PM +00:00','DD-MON-RRRR HH.MI.SSXFF AM TZR','NLS_DATE_LANGUAGE=english'), repeat_interval=> 
'FREQ=MINUTELY;INTERVAL=1'
, end_date=>NULL,
job_class=>'"DEFAULT_JOB_CLASS"', enabled=>FALSE, auto_drop=>FALSE,comments=>
'Claims due Agent analytic schedules and records sparse matches, findings, and partitioned run history.'
);
sys.dbms_scheduler.set_attribute('"SAS"."AGENT_ANALYTIC_COORDINATOR"','NLS_ENV','NLS_LANGUAGE=''AMERICAN'' NLS_TERRITORY=''AMERICA'' NLS_CURRENCY=''$'' NLS_ISO_CURRENCY=''AMERICA'' NLS_NUMERIC_CHARACTERS=''.,'' NLS_CALENDAR=''GREGORIAN'' NLS_DATE_FORMAT=''DD-MON-RR'' NLS_DATE_LANGUAGE=''AMERICAN'' NLS_SORT=''BINARY'' NLS_TIME_FORMAT=''HH.MI.SSXFF AM'' NLS_TIMESTAMP_FORMAT=''DD-MON-RR HH.MI.SSXFF AM'' NLS_TIME_TZ_FORMAT=''HH.MI.SSXFF AM TZR'' NLS_TIMESTAMP_TZ_FORMAT=''DD-MON-RR HH.MI.SSXFF AM TZR'' NLS_DUAL_CURRENCY=''$'' NLS_COMP=''BINARY'' NLS_LENGTH_SEMANTICS=''BYTE'' NLS_NCHAR_CONV_EXCP=''FALSE''');
COMMIT; 
END; 
/ 

BEGIN 
dbms_scheduler.create_job('"SAS"."SBOS_AGENT_EXCEPTION_SAMPLE_WORKER"',
job_type=>'PLSQL_BLOCK', job_action=>
'begin sas.pkg_sbos_agent_evidence.process_queue(1000); end;'
, number_of_arguments=>0,
start_date=>TO_TIMESTAMP_TZ('30-JUL-2026 12.29.59.906232000 PM +00:00','DD-MON-RRRR HH.MI.SSXFF AM TZR','NLS_DATE_LANGUAGE=english'), repeat_interval=> 
'FREQ=MINUTELY;INTERVAL=1'
, end_date=>NULL,
job_class=>'"DEFAULT_JOB_CLASS"', enabled=>FALSE, auto_drop=>FALSE,comments=>
'Captures up to three temporary transaction examples only for matched enterprise cases.'
);
sys.dbms_scheduler.set_attribute('"SAS"."SBOS_AGENT_EXCEPTION_SAMPLE_WORKER"','NLS_ENV','NLS_LANGUAGE=''AMERICAN'' NLS_TERRITORY=''AMERICA'' NLS_CURRENCY=''$'' NLS_ISO_CURRENCY=''AMERICA'' NLS_NUMERIC_CHARACTERS=''.,'' NLS_CALENDAR=''GREGORIAN'' NLS_DATE_FORMAT=''DD-MON-RR'' NLS_DATE_LANGUAGE=''AMERICAN'' NLS_SORT=''BINARY'' NLS_TIME_FORMAT=''HH.MI.SSXFF AM'' NLS_TIMESTAMP_FORMAT=''DD-MON-RR HH.MI.SSXFF AM'' NLS_TIME_TZ_FORMAT=''HH.MI.SSXFF AM TZR'' NLS_TIMESTAMP_TZ_FORMAT=''DD-MON-RR HH.MI.SSXFF AM TZR'' NLS_DUAL_CURRENCY=''$'' NLS_COMP=''BINARY'' NLS_LENGTH_SEMANTICS=''BYTE'' NLS_NCHAR_CONV_EXCP=''FALSE''');
COMMIT; 
END; 
/ 

BEGIN 
dbms_scheduler.create_job('"SAS"."SBOS_PROFILE_DAILY_CLOCK_REFRESH"',
job_type=>'PLSQL_BLOCK', job_action=>
'begin pkg_sbos_profile_fns_v2.refresh_clock_profiles; end;'
, number_of_arguments=>0,
start_date=>TO_TIMESTAMP_TZ('26-JUL-2026 12.10.00.000000000 AM ASIA/KOLKATA','DD-MON-RRRR HH.MI.SSXFF AM TZR','NLS_DATE_LANGUAGE=english'), repeat_interval=> 
'FREQ=DAILY;BYHOUR=0;BYMINUTE=10;BYSECOND=0'
, end_date=>NULL,
job_class=>'"DEFAULT_JOB_CLASS"', enabled=>FALSE, auto_drop=>FALSE,comments=>
'Reevaluates clock-driven profile functions for entities that have no new transactions.'
);
sys.dbms_scheduler.set_attribute('"SAS"."SBOS_PROFILE_DAILY_CLOCK_REFRESH"','NLS_ENV','NLS_LANGUAGE=''AMERICAN'' NLS_TERRITORY=''AMERICA'' NLS_CURRENCY=''$'' NLS_ISO_CURRENCY=''AMERICA'' NLS_NUMERIC_CHARACTERS=''.,'' NLS_CALENDAR=''GREGORIAN'' NLS_DATE_FORMAT=''DD-MON-RR'' NLS_DATE_LANGUAGE=''AMERICAN'' NLS_SORT=''BINARY'' NLS_TIME_FORMAT=''HH.MI.SSXFF AM'' NLS_TIMESTAMP_FORMAT=''DD-MON-RR HH.MI.SSXFF AM'' NLS_TIME_TZ_FORMAT=''HH.MI.SSXFF AM TZR'' NLS_TIMESTAMP_TZ_FORMAT=''DD-MON-RR HH.MI.SSXFF AM TZR'' NLS_DUAL_CURRENCY=''$'' NLS_COMP=''BINARY'' NLS_LENGTH_SEMANTICS=''BYTE'' NLS_NCHAR_CONV_EXCP=''FALSE''');
COMMIT; 
END; 
/ 

BEGIN 
dbms_scheduler.create_job('"SAS"."SBOS_PROFILE_REBUILD_DISPATCH"',
job_type=>'STORED_PROCEDURE', job_action=>
'PKG_SBOS_PROFILE_STUDIO.DISPATCH_REBUILD'
, number_of_arguments=>0,
start_date=>TO_TIMESTAMP_TZ('24-JUL-2026 08.46.26.191610000 AM +00:00','DD-MON-RRRR HH.MI.SSXFF AM TZR','NLS_DATE_LANGUAGE=english'), repeat_interval=> 
'FREQ=MINUTELY;INTERVAL=1'
, end_date=>NULL,
job_class=>'"DEFAULT_JOB_CLASS"', enabled=>FALSE, auto_drop=>FALSE,comments=>
'Dispatches versioned Agent and Customer profile rebuilds.'
);
sys.dbms_scheduler.set_attribute('"SAS"."SBOS_PROFILE_REBUILD_DISPATCH"','NLS_ENV','NLS_LANGUAGE=''AMERICAN'' NLS_TERRITORY=''AMERICA'' NLS_CURRENCY=''$'' NLS_ISO_CURRENCY=''AMERICA'' NLS_NUMERIC_CHARACTERS=''.,'' NLS_CALENDAR=''GREGORIAN'' NLS_DATE_FORMAT=''DD-MON-RR'' NLS_DATE_LANGUAGE=''AMERICAN'' NLS_SORT=''BINARY'' NLS_TIME_FORMAT=''HH.MI.SSXFF AM'' NLS_TIMESTAMP_FORMAT=''DD-MON-RR HH.MI.SSXFF AM'' NLS_TIME_TZ_FORMAT=''HH.MI.SSXFF AM TZR'' NLS_TIMESTAMP_TZ_FORMAT=''DD-MON-RR HH.MI.SSXFF AM TZR'' NLS_DUAL_CURRENCY=''$'' NLS_COMP=''BINARY'' NLS_LENGTH_SEMANTICS=''BYTE'' NLS_NCHAR_CONV_EXCP=''FALSE''');
COMMIT; 
END; 
/ 

BEGIN 
dbms_scheduler.create_job('"SAS"."SBOS_RBAC_WEEKLY_RECONCILE"',
job_type=>'PLSQL_BLOCK', job_action=>
'declare l_run number;
      begin
        pkg_sbos_rbac_studio.run_sync(
          ''WEEKLY_RECONCILE'',''FULL'',l_run
        );
        commit;
      end;'
, number_of_arguments=>0,
start_date=>TO_TIMESTAMP_TZ('26-JUL-2026 02.00.00.000000000 AM ASIA/KOLKATA','DD-MON-RRRR HH.MI.SSXFF AM TZR','NLS_DATE_LANGUAGE=english'), repeat_interval=> 
'FREQ=WEEKLY;BYDAY=SUN;BYHOUR=2;BYMINUTE=0;BYSECOND=0'
, end_date=>NULL,
job_class=>'"DEFAULT_JOB_CLASS"', enabled=>FALSE, auto_drop=>FALSE,comments=>
'Weekly full hierarchy reconciliation and deletion detection'
);
sys.dbms_scheduler.set_attribute('"SAS"."SBOS_RBAC_WEEKLY_RECONCILE"','NLS_ENV','NLS_LANGUAGE=''AMERICAN'' NLS_TERRITORY=''AMERICA'' NLS_CURRENCY=''$'' NLS_ISO_CURRENCY=''AMERICA'' NLS_NUMERIC_CHARACTERS=''.,'' NLS_CALENDAR=''GREGORIAN'' NLS_DATE_FORMAT=''DD-MON-RR'' NLS_DATE_LANGUAGE=''AMERICAN'' NLS_SORT=''BINARY'' NLS_TIME_FORMAT=''HH.MI.SSXFF AM'' NLS_TIMESTAMP_FORMAT=''DD-MON-RR HH.MI.SSXFF AM'' NLS_TIME_TZ_FORMAT=''HH.MI.SSXFF AM TZR'' NLS_TIMESTAMP_TZ_FORMAT=''DD-MON-RR HH.MI.SSXFF AM TZR'' NLS_DUAL_CURRENCY=''$'' NLS_COMP=''BINARY'' NLS_LENGTH_SEMANTICS=''BYTE'' NLS_NCHAR_CONV_EXCP=''FALSE''');
COMMIT; 
END; 
/ 

BEGIN 
dbms_scheduler.create_job('"SAS"."SBOS_RBAC_AUDIT_RETENTION"',
job_type=>'PLSQL_BLOCK', job_action=>
'declare
      l_rows number;
      begin
        loop
          delete from sbos_rbac_audit_log
           where event_on<add_months(systimestamp,-84)
             and rownum<=10000;
          l_rows:=sql%rowcount;
          commit;
          exit when l_rows<10000;
        end loop;
      end;'
, number_of_arguments=>0,
start_date=>TO_TIMESTAMP_TZ('01-AUG-2026 03.00.00.000000000 AM ASIA/KOLKATA','DD-MON-RRRR HH.MI.SSXFF AM TZR','NLS_DATE_LANGUAGE=english'), repeat_interval=> 
'FREQ=MONTHLY;BYMONTHDAY=1;BYHOUR=3;BYMINUTE=0;BYSECOND=0'
, end_date=>NULL,
job_class=>'"DEFAULT_JOB_CLASS"', enabled=>FALSE, auto_drop=>FALSE,comments=>
'Seven-year RBAC audit retention in bounded batches'
);
sys.dbms_scheduler.set_attribute('"SAS"."SBOS_RBAC_AUDIT_RETENTION"','NLS_ENV','NLS_LANGUAGE=''AMERICAN'' NLS_TERRITORY=''AMERICA'' NLS_CURRENCY=''$'' NLS_ISO_CURRENCY=''AMERICA'' NLS_NUMERIC_CHARACTERS=''.,'' NLS_CALENDAR=''GREGORIAN'' NLS_DATE_FORMAT=''DD-MON-RR'' NLS_DATE_LANGUAGE=''AMERICAN'' NLS_SORT=''BINARY'' NLS_TIME_FORMAT=''HH.MI.SSXFF AM'' NLS_TIMESTAMP_FORMAT=''DD-MON-RR HH.MI.SSXFF AM'' NLS_TIME_TZ_FORMAT=''HH.MI.SSXFF AM TZR'' NLS_TIMESTAMP_TZ_FORMAT=''DD-MON-RR HH.MI.SSXFF AM TZR'' NLS_DUAL_CURRENCY=''$'' NLS_COMP=''BINARY'' NLS_LENGTH_SEMANTICS=''BYTE'' NLS_NCHAR_CONV_EXCP=''FALSE''');
COMMIT; 
END; 
/ 

BEGIN 
dbms_scheduler.create_job('"SAS"."AGENT_LOCATION_DAILY_REFRESH"',
job_type=>'PLSQL_BLOCK', job_action=>
'begin sas.pkg_agent_location_analyser.refresh_summaries; sas.pkg_agent_location_analyser.snapshot_360; end;'
, number_of_arguments=>0,
start_date=>TO_TIMESTAMP_TZ('27-JUL-2026 04.14.34.663568000 AM +00:00','DD-MON-RRRR HH.MI.SSXFF AM TZR','NLS_DATE_LANGUAGE=english'), repeat_interval=> 
'FREQ=DAILY;BYHOUR=0;BYMINUTE=40;BYSECOND=0'
, end_date=>NULL,
job_class=>'"DEFAULT_JOB_CLASS"', enabled=>FALSE, auto_drop=>TRUE,comments=>
'Refresh Agent Location Analyser serving summaries after daily profiles.'
);
sys.dbms_scheduler.set_attribute('"SAS"."AGENT_LOCATION_DAILY_REFRESH"','NLS_ENV','NLS_LANGUAGE=''AMERICAN'' NLS_TERRITORY=''AMERICA'' NLS_CURRENCY=''$'' NLS_ISO_CURRENCY=''AMERICA'' NLS_NUMERIC_CHARACTERS=''.,'' NLS_CALENDAR=''GREGORIAN'' NLS_DATE_FORMAT=''DD-MON-RR'' NLS_DATE_LANGUAGE=''AMERICAN'' NLS_SORT=''BINARY'' NLS_TIME_FORMAT=''HH.MI.SSXFF AM'' NLS_TIMESTAMP_FORMAT=''DD-MON-RR HH.MI.SSXFF AM'' NLS_TIME_TZ_FORMAT=''HH.MI.SSXFF AM TZR'' NLS_TIMESTAMP_TZ_FORMAT=''DD-MON-RR HH.MI.SSXFF AM TZR'' NLS_DUAL_CURRENCY=''$'' NLS_COMP=''BINARY'' NLS_LENGTH_SEMANTICS=''BYTE'' NLS_NCHAR_CONV_EXCP=''FALSE''');
COMMIT; 
END; 
/ 

BEGIN 
dbms_scheduler.create_job('"SAS"."SBOS_ETL_PURGE_JOB"',
job_type=>'STORED_PROCEDURE', job_action=>
'SAS.PKG_SBOS_ETL_RUNTIME.PURGE_HISTORY'
, number_of_arguments=>0,
start_date=>TO_TIMESTAMP_TZ('23-JUL-2026 02.14.20.960544000 PM +00:00','DD-MON-RRRR HH.MI.SSXFF AM TZR','NLS_DATE_LANGUAGE=english'), repeat_interval=> 
'FREQ=DAILY;BYHOUR=2;BYMINUTE=15;BYSECOND=0'
, end_date=>NULL,
job_class=>'"DEFAULT_JOB_CLASS"', enabled=>FALSE, auto_drop=>FALSE,comments=>
'SBOS ETL bounded history and resolved-reject retention'
);
sys.dbms_scheduler.set_attribute('"SAS"."SBOS_ETL_PURGE_JOB"','NLS_ENV','NLS_LANGUAGE=''AMERICAN'' NLS_TERRITORY=''AMERICA'' NLS_CURRENCY=''$'' NLS_ISO_CURRENCY=''AMERICA'' NLS_NUMERIC_CHARACTERS=''.,'' NLS_CALENDAR=''GREGORIAN'' NLS_DATE_FORMAT=''DD-MON-RR'' NLS_DATE_LANGUAGE=''AMERICAN'' NLS_SORT=''BINARY'' NLS_TIME_FORMAT=''HH.MI.SSXFF AM'' NLS_TIMESTAMP_FORMAT=''DD-MON-RR HH.MI.SSXFF AM'' NLS_TIME_TZ_FORMAT=''HH.MI.SSXFF AM TZR'' NLS_TIMESTAMP_TZ_FORMAT=''DD-MON-RR HH.MI.SSXFF AM TZR'' NLS_DUAL_CURRENCY=''$'' NLS_COMP=''BINARY'' NLS_LENGTH_SEMANTICS=''BYTE'' NLS_NCHAR_CONV_EXCP=''FALSE''');
COMMIT; 
END; 
/ 

BEGIN 
dbms_scheduler.create_job('"SAS"."SBOS_PEER_AUTO_CALIBRATION"',
job_type=>'PLSQL_BLOCK', job_action=>
'begin sas.pkg_sbos_rbac_peer_intel.run_automatic_calibration(''N''); end;'
, number_of_arguments=>0,
start_date=>TO_TIMESTAMP_TZ('31-JUL-2026 03.11.27.259224000 AM ASIA/KOLKATA','DD-MON-RRRR HH.MI.SSXFF AM TZR','NLS_DATE_LANGUAGE=english'), repeat_interval=> 
'FREQ=HOURLY;INTERVAL=1;BYMINUTE=45;BYSECOND=0'
, end_date=>NULL,
job_class=>'"DEFAULT_JOB_CLASS"', enabled=>FALSE, auto_drop=>FALSE,comments=>
'Recalibrates vertical RBAC peer intelligence once daily after a successful profile clock refresh.'
);
sys.dbms_scheduler.set_attribute('"SAS"."SBOS_PEER_AUTO_CALIBRATION"','NLS_ENV','NLS_LANGUAGE=''AMERICAN'' NLS_TERRITORY=''AMERICA'' NLS_CURRENCY=''$'' NLS_ISO_CURRENCY=''AMERICA'' NLS_NUMERIC_CHARACTERS=''.,'' NLS_CALENDAR=''GREGORIAN'' NLS_DATE_FORMAT=''DD-MON-RR'' NLS_DATE_LANGUAGE=''AMERICAN'' NLS_SORT=''BINARY'' NLS_TIME_FORMAT=''HH.MI.SSXFF AM'' NLS_TIMESTAMP_FORMAT=''DD-MON-RR HH.MI.SSXFF AM'' NLS_TIME_TZ_FORMAT=''HH.MI.SSXFF AM TZR'' NLS_TIMESTAMP_TZ_FORMAT=''DD-MON-RR HH.MI.SSXFF AM TZR'' NLS_DUAL_CURRENCY=''$'' NLS_COMP=''BINARY'' NLS_LENGTH_SEMANTICS=''BYTE'' NLS_NCHAR_CONV_EXCP=''FALSE''');
COMMIT; 
END; 
/ 

BEGIN 
dbms_scheduler.create_job('"SAS"."SBOS_RBAC_DAILY_SYNC"',
job_type=>'PLSQL_BLOCK', job_action=>
'begin pkg_sbos_rbac_studio.run_daily_sync; end;'
, number_of_arguments=>0,
start_date=>TO_TIMESTAMP_TZ('26-JUL-2026 01.00.00.000000000 AM ASIA/KOLKATA','DD-MON-RRRR HH.MI.SSXFF AM TZR','NLS_DATE_LANGUAGE=english'), repeat_interval=> 
'FREQ=DAILY;BYHOUR=1;BYMINUTE=0;BYSECOND=0'
, end_date=>NULL,
job_class=>'"DEFAULT_JOB_CLASS"', enabled=>FALSE, auto_drop=>FALSE,comments=>
'Delta-only RBAC hierarchy sync from SBOS_AGENT_MASTER'
);
sys.dbms_scheduler.set_attribute('"SAS"."SBOS_RBAC_DAILY_SYNC"','NLS_ENV','NLS_LANGUAGE=''AMERICAN'' NLS_TERRITORY=''AMERICA'' NLS_CURRENCY=''$'' NLS_ISO_CURRENCY=''AMERICA'' NLS_NUMERIC_CHARACTERS=''.,'' NLS_CALENDAR=''GREGORIAN'' NLS_DATE_FORMAT=''DD-MON-RR'' NLS_DATE_LANGUAGE=''AMERICAN'' NLS_SORT=''BINARY'' NLS_TIME_FORMAT=''HH.MI.SSXFF AM'' NLS_TIMESTAMP_FORMAT=''DD-MON-RR HH.MI.SSXFF AM'' NLS_TIME_TZ_FORMAT=''HH.MI.SSXFF AM TZR'' NLS_TIMESTAMP_TZ_FORMAT=''DD-MON-RR HH.MI.SSXFF AM TZR'' NLS_DUAL_CURRENCY=''$'' NLS_COMP=''BINARY'' NLS_LENGTH_SEMANTICS=''BYTE'' NLS_NCHAR_CONV_EXCP=''FALSE''');
COMMIT; 
END; 
/ 

BEGIN 
dbms_scheduler.create_job('"SAS"."SBOS_AGENT_EXCEPTION_SAMPLE_PURGE"',
job_type=>'PLSQL_BLOCK', job_action=>
'begin sas.pkg_sbos_agent_evidence.purge_expired; end;'
, number_of_arguments=>0,
start_date=>TO_TIMESTAMP_TZ('30-JUL-2026 12.29.59.942716000 PM +00:00','DD-MON-RRRR HH.MI.SSXFF AM TZR','NLS_DATE_LANGUAGE=english'), repeat_interval=> 
'FREQ=MINUTELY;INTERVAL=15'
, end_date=>NULL,
job_class=>'"DEFAULT_JOB_CLASS"', enabled=>FALSE, auto_drop=>FALSE,comments=>
'Enforces the one-day TTL for raw transaction examples.'
);
sys.dbms_scheduler.set_attribute('"SAS"."SBOS_AGENT_EXCEPTION_SAMPLE_PURGE"','NLS_ENV','NLS_LANGUAGE=''AMERICAN'' NLS_TERRITORY=''AMERICA'' NLS_CURRENCY=''$'' NLS_ISO_CURRENCY=''AMERICA'' NLS_NUMERIC_CHARACTERS=''.,'' NLS_CALENDAR=''GREGORIAN'' NLS_DATE_FORMAT=''DD-MON-RR'' NLS_DATE_LANGUAGE=''AMERICAN'' NLS_SORT=''BINARY'' NLS_TIME_FORMAT=''HH.MI.SSXFF AM'' NLS_TIMESTAMP_FORMAT=''DD-MON-RR HH.MI.SSXFF AM'' NLS_TIME_TZ_FORMAT=''HH.MI.SSXFF AM TZR'' NLS_TIMESTAMP_TZ_FORMAT=''DD-MON-RR HH.MI.SSXFF AM TZR'' NLS_DUAL_CURRENCY=''$'' NLS_COMP=''BINARY'' NLS_LENGTH_SEMANTICS=''BYTE'' NLS_NCHAR_CONV_EXCP=''FALSE''');
COMMIT; 
END; 
/ 

BEGIN 
dbms_scheduler.create_job('"SAS"."SBOS_PROFILE_5MIN_COORDINATOR"',
job_type=>'PLSQL_BLOCK', job_action=>
'begin SAS.pkg_sbos_feature_engine.run_delta(''SCHEDULED''); end;'
, number_of_arguments=>0,
start_date=>TO_TIMESTAMP_TZ('24-JUL-2026 10.05.59.224487000 AM +00:00','DD-MON-RRRR HH.MI.SSXFF AM TZR','NLS_DATE_LANGUAGE=english'), repeat_interval=> 
'FREQ=MINUTELY;INTERVAL=5'
, end_date=>NULL,
job_class=>'"DEFAULT_JOB_CLASS"', enabled=>FALSE, auto_drop=>FALSE,comments=>
'Profile-only delta coordinator. Standalone Function Library is retired.'
);
sys.dbms_scheduler.set_attribute('"SAS"."SBOS_PROFILE_5MIN_COORDINATOR"','NLS_ENV','NLS_LANGUAGE=''AMERICAN'' NLS_TERRITORY=''AMERICA'' NLS_CURRENCY=''$'' NLS_ISO_CURRENCY=''AMERICA'' NLS_NUMERIC_CHARACTERS=''.,'' NLS_CALENDAR=''GREGORIAN'' NLS_DATE_FORMAT=''DD-MON-RR'' NLS_DATE_LANGUAGE=''AMERICAN'' NLS_SORT=''BINARY'' NLS_TIME_FORMAT=''HH.MI.SSXFF AM'' NLS_TIMESTAMP_FORMAT=''DD-MON-RR HH.MI.SSXFF AM'' NLS_TIME_TZ_FORMAT=''HH.MI.SSXFF AM TZR'' NLS_TIMESTAMP_TZ_FORMAT=''DD-MON-RR HH.MI.SSXFF AM TZR'' NLS_DUAL_CURRENCY=''$'' NLS_COMP=''BINARY'' NLS_LENGTH_SEMANTICS=''BYTE'' NLS_NCHAR_CONV_EXCP=''FALSE''');
COMMIT; 
END; 
/ 

BEGIN 
dbms_scheduler.create_job('"SAS"."SBOS_ETL_PIPE_1"',
job_type=>'PLSQL_BLOCK', job_action=>
'declare l_run_id number; begin pkg_sbos_etl_runtime.submit_run(1,''SCHEDULED'',''SBOS_SCHEDULER'',l_run_id); end;'
, number_of_arguments=>0,
start_date=>TO_TIMESTAMP_TZ('24-JUL-2026 05.00.20.771893000 PM ASIA/KOLKATA','DD-MON-RRRR HH.MI.SSXFF AM TZR','NLS_DATE_LANGUAGE=english'), repeat_interval=> 
'FREQ=MINUTELY;INTERVAL=5'
, end_date=>NULL,
job_class=>'"DEFAULT_JOB_CLASS"', enabled=>FALSE, auto_drop=>FALSE,comments=>
'SBOS ETL five-minute micro-batch dispatcher'
);
sys.dbms_scheduler.set_attribute('"SAS"."SBOS_ETL_PIPE_1"','NLS_ENV','NLS_LANGUAGE=''AMERICAN'' NLS_TERRITORY=''AMERICA'' NLS_CURRENCY=''$'' NLS_ISO_CURRENCY=''AMERICA'' NLS_NUMERIC_CHARACTERS=''.,'' NLS_CALENDAR=''GREGORIAN'' NLS_DATE_FORMAT=''DS'' NLS_DATE_LANGUAGE=''AMERICAN'' NLS_SORT=''BINARY'' NLS_TIME_FORMAT=''HH.MI.SSXFF AM'' NLS_TIMESTAMP_FORMAT=''DS'' NLS_TIME_TZ_FORMAT=''HH.MI.SSXFF AM TZR'' NLS_TIMESTAMP_TZ_FORMAT=''DS'' NLS_DUAL_CURRENCY=''$'' NLS_COMP=''BINARY'' NLS_LENGTH_SEMANTICS=''BYTE'' NLS_NCHAR_CONV_EXCP=''FALSE''');
COMMIT; 
END; 
/ 

BEGIN 
dbms_scheduler.create_job('"SAS"."AGENT_FINDING_MAINTENANCE"',
job_type=>'PLSQL_BLOCK', job_action=>
'
        begin
          sas.pkg_agent_finding_store.archive_terminal(
            p_before=>systimestamp,
            p_batch_size=>100000
          );
          commit;
          sas.pkg_agent_finding_store.purge_expired_partitions(
            p_as_of_date=>trunc(sysdate),
            p_max_months=>120
          );
          commit;
        end;
      '
, number_of_arguments=>0,
start_date=>TO_TIMESTAMP_TZ('31-JUL-2026 02.15.00.000000000 AM ASIA/KOLKATA','DD-MON-RRRR HH.MI.SSXFF AM TZR','NLS_DATE_LANGUAGE=english'), repeat_interval=> 
'FREQ=DAILY;BYHOUR=2;BYMINUTE=15;BYSECOND=0'
, end_date=>NULL,
job_class=>'"DEFAULT_JOB_CLASS"', enabled=>FALSE, auto_drop=>FALSE,comments=>
'Archives terminal Agent findings and drops expired monthly output partitions.'
);
sys.dbms_scheduler.set_attribute('"SAS"."AGENT_FINDING_MAINTENANCE"','NLS_ENV','NLS_LANGUAGE=''AMERICAN'' NLS_TERRITORY=''AMERICA'' NLS_CURRENCY=''$'' NLS_ISO_CURRENCY=''AMERICA'' NLS_NUMERIC_CHARACTERS=''.,'' NLS_CALENDAR=''GREGORIAN'' NLS_DATE_FORMAT=''DD-MON-RR'' NLS_DATE_LANGUAGE=''AMERICAN'' NLS_SORT=''BINARY'' NLS_TIME_FORMAT=''HH.MI.SSXFF AM'' NLS_TIMESTAMP_FORMAT=''DD-MON-RR HH.MI.SSXFF AM'' NLS_TIME_TZ_FORMAT=''HH.MI.SSXFF AM TZR'' NLS_TIMESTAMP_TZ_FORMAT=''DD-MON-RR HH.MI.SSXFF AM TZR'' NLS_DUAL_CURRENCY=''$'' NLS_COMP=''BINARY'' NLS_LENGTH_SEMANTICS=''BYTE'' NLS_NCHAR_CONV_EXCP=''FALSE''');
COMMIT; 
END; 
/ 
-- fixup virtual columns... 
-- done fixup virtual columns 
