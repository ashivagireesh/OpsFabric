set define off verify off feedback on serveroutput on lines 240 pages 200
whenever sqlerror exit sql.sqlcode rollback

prompt Enabling the 12 SAS Scheduler jobs that were enabled at source SCN 23443166
prompt Run this only after 04_post_import_compile_validate.sql succeeds.

declare
  procedure enable_job(p_job_name varchar2) is
    l_count number;
  begin
    select count(*)
      into l_count
      from all_scheduler_jobs
     where owner = 'SAS'
       and job_name = upper(p_job_name);

    if l_count = 0 then
      raise_application_error(-20993, 'Missing SAS Scheduler job: ' || p_job_name);
    end if;

    dbms_scheduler.enable('SAS.' || upper(p_job_name));
    dbms_output.put_line('Enabled SAS.' || upper(p_job_name));
  end;
begin
  enable_job('AGENT_LOCATION_DAILY_REFRESH');
  enable_job('SBOS_AGENT_EXCEPTION_SAMPLE_PURGE');
  enable_job('SBOS_AGENT_EXCEPTION_SAMPLE_WORKER');
  enable_job('SBOS_ETL_PURGE_JOB');
  enable_job('SBOS_ETL_RECOVERY_JOB');
  enable_job('SBOS_PEER_AUTO_CALIBRATION');
  enable_job('SBOS_PROFILE_5MIN_COORDINATOR');
  enable_job('SBOS_PROFILE_DAILY_CLOCK_REFRESH');
  enable_job('SBOS_PROFILE_REBUILD_DISPATCH');
  enable_job('SBOS_RBAC_AUDIT_RETENTION');
  enable_job('SBOS_RBAC_DAILY_SYNC');
  enable_job('SBOS_RBAC_WEEKLY_RECONCILE');
end;
/

prompt The following source-disabled jobs remain disabled:
prompt AGENT_ANALYTIC_COORDINATOR
prompt AGENT_FINDING_MAINTENANCE
prompt SBOS_ETL_PIPE_1

select owner, job_name, enabled, state, repeat_interval
  from all_scheduler_jobs
 where owner = 'SAS'
 order by job_name;

